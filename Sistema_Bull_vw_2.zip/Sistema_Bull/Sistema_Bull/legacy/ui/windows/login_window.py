"""
Ventana de login y gestión de usuarios.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional, Callable

from bull_bar.infra.auth import (
    autenticar, cambiar_password, crear_usuario, generar_token_reset,
    reset_password_con_token, listar_usuarios, RolUsuario, tiene_permiso
)


def show_copyable_token_dialog(parent, token: str):
    """
    Muestra un diálogo modal con el token generado que permite copiarlo.
    
    Args:
        parent: Widget padre (ventana padre)
        token: Token a mostrar y copiar
    """
    # Crear ventana modal
    win = tk.Toplevel(parent)
    win.title("Token generado")
    win.geometry("500x250")
    win.resizable(False, False)
    win.transient(parent)
    win.grab_set()
    
    # Centrar ventana
    win.update_idletasks()
    try:
        screen_width = win.winfo_screenwidth()
        screen_height = win.winfo_screenheight()
        x = (screen_width - 500) // 2
        y = (screen_height - 250) // 2
        win.geometry(f"500x250+{x}+{y}")
    except:
        pass
    
    # Frame principal con padding
    main_frame = ttk.Frame(win, padding=20)
    main_frame.pack(fill="both", expand=True)
    
    # Texto informativo
    info_text = "Guarde este token. Tiene 1 hora de validez. Úselo en la siguiente pantalla para restablecer su contraseña."
    ttk.Label(main_frame, text=info_text, wraplength=450, justify="left").pack(anchor="w", pady=(0, 10))
    
    # Frame para el Entry con el token
    token_frame = ttk.Frame(main_frame)
    token_frame.pack(fill="x", pady=(0, 15))
    
    ttk.Label(token_frame, text="Token:").pack(anchor="w", pady=(0, 5))
    
    # Entry readonly con el token (seleccionable)
    token_var = tk.StringVar(value=token)
    token_entry = ttk.Entry(token_frame, textvariable=token_var, state="readonly", width=60)
    token_entry.pack(fill="x", padx=(0, 5))
    
    # Función para copiar al portapapeles
    def copiar_token():
        """Copia el token al portapapeles."""
        parent.clipboard_clear()
        parent.clipboard_append(token)
        parent.update()  # Asegurar que se copie
        # Mostrar feedback visual
        btn_copiar.config(text="✓ Copiado")
        win.after(2000, lambda: btn_copiar.config(text="Copiar"))
    
    # Función para atajo Ctrl+C
    def on_ctrl_c(event):
        """Maneja Ctrl+C para copiar."""
        copiar_token()
        return "break"
    
    # Función para atajo Ctrl+A
    def on_ctrl_a(event):
        """Maneja Ctrl+A para seleccionar todo."""
        token_entry.selection_range(0, tk.END)
        return "break"
    
    # Bind atajos de teclado
    token_entry.bind("<Control-c>", on_ctrl_c)
    token_entry.bind("<Control-a>", on_ctrl_a)
    win.bind("<Control-c>", on_ctrl_c)
    win.bind("<Control-a>", lambda e: (token_entry.focus(), on_ctrl_a(e)))
    
    # Frame para botones
    btn_frame = ttk.Frame(main_frame)
    btn_frame.pack(fill="x", pady=(10, 0))
    
    # Botón Copiar
    btn_copiar = ttk.Button(btn_frame, text="Copiar", command=copiar_token)
    btn_copiar.pack(side="left", padx=(0, 10))
    
    # Botón Cerrar
    btn_cerrar = ttk.Button(btn_frame, text="Cerrar", command=win.destroy)
    btn_cerrar.pack(side="right")
    
    # Seleccionar token automáticamente al abrir
    win.after(100, lambda: (token_entry.focus(), token_entry.selection_range(0, tk.END)))
    
    # Forzar foco en la ventana
    win.focus_force()
    
    # Esperar a que se cierre la ventana
    win.wait_window()


class LoginWindow(tk.Toplevel):
    """Ventana de login."""
    
    def __init__(self, parent, db_path: str, on_success: Callable[[dict], None]):
        print("[DEBUG] LoginWindow.__init__: Iniciando creación de ventana de login...")
        print(f"[DEBUG] LoginWindow.__init__: parent = {parent}")
        print(f"[DEBUG] LoginWindow.__init__: parent.winfo_exists() = {parent.winfo_exists() if hasattr(parent, 'winfo_exists') else 'N/A'}")
        
        super().__init__(parent)
        print("[DEBUG] LoginWindow.__init__: [OK] Toplevel creado")
        self.db_path = db_path
        self.on_success = on_success
        self.usuario_autenticado: Optional[dict] = None
        
        self.title("Bull Bar - Login")
        self.geometry("400x300")
        self.resizable(False, False)
        # NO usar transient si el parent está oculto - puede causar problemas
        # self.transient(parent)  # Comentado temporalmente
        print("[DEBUG] LoginWindow.__init__: [OK] Propiedades básicas configuradas")
        
        # Centrar ventana ANTES de construir UI
        print("[DEBUG] LoginWindow.__init__: Centrando ventana...")
        self.update_idletasks()
        try:
            screen_width = self.winfo_screenwidth()
            screen_height = self.winfo_screenheight()
            x = (screen_width // 2) - (400 // 2)
            y = (screen_height // 2) - (300 // 2)
            self.geometry(f"400x300+{x}+{y}")
            print(f"[DEBUG] LoginWindow.__init__: [OK] Ventana centrada en ({x}, {y})")
            print(f"[DEBUG] LoginWindow.__init__: Resolución pantalla: {screen_width}x{screen_height}")
        except Exception as e:
            print(f"[DEBUG] LoginWindow.__init__: [WARN] Error centrando ventana: {e}")
            import traceback
            traceback.print_exc()
        
        print("[DEBUG] LoginWindow.__init__: Construyendo UI...")
        self._build_ui()
        print("[DEBUG] LoginWindow.__init__: [OK] UI construida")
        
        # Asegurar que la ventana sea visible - MÚLTIPLES INTENTOS
        print("[DEBUG] LoginWindow.__init__: Forzando visibilidad de ventana...")
        
        # Primero hacer visible
        self.deiconify()
        print("[DEBUG] LoginWindow.__init__: [OK] deiconify() ejecutado")
        
        # Actualizar para que los cambios se apliquen
        self.update()
        self.update_idletasks()
        print("[DEBUG] LoginWindow.__init__: [OK] update() ejecutado")
        
        # Luego lift y focus
        try:
            self.lift()
            print("[DEBUG] LoginWindow.__init__: [OK] lift() ejecutado")
        except Exception as e:
            print(f"[DEBUG] LoginWindow.__init__: [WARN] Error en lift(): {e}")
        
        try:
            self.focus_force()
            print("[DEBUG] LoginWindow.__init__: [OK] focus_force() ejecutado")
        except Exception as e:
            print(f"[DEBUG] LoginWindow.__init__: [WARN] Error en focus_force(): {e}")
        
        # Verificar visibilidad
        try:
            is_viewable = self.winfo_viewable()
            print(f"[DEBUG] LoginWindow.__init__: winfo_viewable() = {is_viewable}")
            if not is_viewable:
                print("[DEBUG] LoginWindow.__init__: [WARN] Ventana no es viewable, intentando corregir...")
                self.deiconify()
                self.lift()
                self.update()
        except Exception as e:
            print(f"[DEBUG] LoginWindow.__init__: [WARN] Error verificando visibilidad: {e}")
        
        # NO usar grab_set() si puede causar problemas - comentado temporalmente
        # try:
        #     self.grab_set()
        #     print("[DEBUG] LoginWindow.__init__: ✓ grab_set() aplicado")
        # except Exception as e:
        #     print(f"[DEBUG] LoginWindow.__init__: ⚠ Error en grab_set(): {e}")
        
        # Enfocar campo usuario
        try:
            self.entry_usuario.focus()
            print("[DEBUG] LoginWindow.__init__: [OK] Campo usuario enfocado")
        except Exception as e:
            print(f"[DEBUG] LoginWindow.__init__: [WARN] Error enfocando campo usuario: {e}")
        
        # Bind Enter
        self.entry_password.bind("<Return>", lambda e: self._login())
        print("[DEBUG] LoginWindow.__init__: [OK] Bind de Enter configurado")
        
        # Última actualización
        self.update()
        self.update_idletasks()
        
        print("[DEBUG] LoginWindow.__init__: [OK] Ventana de login completamente inicializada")
        print(f"[DEBUG] LoginWindow.__init__: Estado final - viewable: {self.winfo_viewable()}, exists: {self.winfo_exists()}")
    
    def _build_ui(self):
        print("[DEBUG] LoginWindow._build_ui: Iniciando construcción de UI...")
        container = ttk.Frame(self, padding=20)
        container.pack(fill="both", expand=True)
        print("[DEBUG] LoginWindow._build_ui: [OK] Container creado")
        
        # Título
        ttk.Label(container, text="Bull Bar", font=("Helvetica", 18, "bold")).pack(pady=(0, 20))
        print("[DEBUG] LoginWindow._build_ui: [OK] Título creado")
        
        # Usuario
        ttk.Label(container, text="Usuario:").pack(anchor="w", pady=(0, 5))
        self.entry_usuario = ttk.Entry(container, width=30)
        self.entry_usuario.pack(pady=(0, 15))
        print("[DEBUG] LoginWindow._build_ui: [OK] Campo usuario creado")
        
        # Contraseña
        ttk.Label(container, text="Contraseña:").pack(anchor="w", pady=(0, 5))
        self.entry_password = ttk.Entry(container, width=30, show="*")
        self.entry_password.pack(pady=(0, 15))
        print("[DEBUG] LoginWindow._build_ui: [OK] Campo contraseña creado")
        
        # Botones
        btn_frame = ttk.Frame(container)
        btn_frame.pack(pady=(10, 0))
        
        ttk.Button(btn_frame, text="Ingresar", command=self._login, width=15).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Recuperar", command=self._recuperar_password, width=15).pack(side="left", padx=5)
        print("[DEBUG] LoginWindow._build_ui: [OK] Botones creados")
        print("[DEBUG] LoginWindow._build_ui: [OK] UI completamente construida")
    
    def _login(self):
        print("[DEBUG] LoginWindow._login: Intentando autenticar...")
        username = self.entry_usuario.get().strip()
        password = self.entry_password.get().strip()
        
        if not username or not password:
            print("[DEBUG] LoginWindow._login: [WARN] Usuario o contraseña vacíos")
            messagebox.showerror("Error", "Ingrese usuario y contraseña")
            return
        
        try:
            print(f"[DEBUG] LoginWindow._login: Autenticando usuario: {username}")
            usuario = autenticar(self.db_path, username, password)
            if not usuario:
                print("[DEBUG] LoginWindow._login: [ERROR] Autenticación fallida")
                messagebox.showerror("Error", "Usuario o contraseña incorrectos")
                self.entry_password.delete(0, "end")
                return
            print(f"[DEBUG] LoginWindow._login: [OK] Usuario autenticado: {usuario.get('username', 'N/A')}")
        except Exception as e:
            print(f"[DEBUG] LoginWindow._login: [ERROR] Error en autenticación: {e}")
            from bull_bar.infra.error_logger import log_error
            log_error(e, context="Autenticando usuario", 
                     extra_info={"username": username})
            messagebox.showerror("Error", f"Error al autenticar:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")
            return
        
        # Verificar si debe cambiar contraseña
        if usuario.get("debe_cambiar_password") or username.lower() == password.lower():
            print("[DEBUG] LoginWindow._login: Usuario debe cambiar contraseña")
            self._mostrar_cambio_password(usuario)
        else:
            print("[DEBUG] LoginWindow._login: Login exitoso, cerrando ventana y llamando callback...")
            self.usuario_autenticado = usuario
            self.destroy()
            print("[DEBUG] LoginWindow._login: Llamando on_success callback...")
            self.on_success(usuario)
            print("[DEBUG] LoginWindow._login: [OK] Callback ejecutado")
    
    def _mostrar_cambio_password(self, usuario: dict):
        """Muestra ventana para cambiar contraseña obligatoria."""
        win = tk.Toplevel(self)
        win.title("Cambiar Contraseña")
        # Aumentado el tamaño de la ventana para que se vean todos los campos sin necesidad de extenderla
        win.geometry("450x380")
        win.transient(self)
        win.grab_set()
        
        # Hacer que la ventana no sea redimensionable para mantener el diseño
        win.resizable(False, False)
        
        container = ttk.Frame(win, padding=20)
        container.pack(fill="both", expand=True)
        
        # Título principal
        ttk.Label(container, text="Debe cambiar su contraseña", font=("Helvetica", 12, "bold")).pack(pady=(0, 10))
        ttk.Label(container, text="Su usuario y contraseña son iguales.\nPor seguridad, debe cambiarla.").pack(pady=(0, 20))
        
        # Campo: Contraseña actual
        ttk.Label(container, text="Contraseña actual:").pack(anchor="w", pady=(0, 5))
        entry_actual = ttk.Entry(container, width=35, show="*")
        entry_actual.pack(pady=(0, 15))
        
        # Campo: Nueva contraseña
        ttk.Label(container, text="Nueva contraseña:").pack(anchor="w", pady=(0, 5))
        entry_nueva = ttk.Entry(container, width=35, show="*")
        entry_nueva.pack(pady=(0, 15))
        
        # Campo: Confirmar nueva contraseña
        ttk.Label(container, text="Confirmar nueva contraseña:").pack(anchor="w", pady=(0, 5))
        entry_confirmar = ttk.Entry(container, width=35, show="*")
        entry_confirmar.pack(pady=(0, 25))
        
        # Botón de cambio
        def cambiar():
            actual = entry_actual.get().strip()
            nueva = entry_nueva.get().strip()
            confirmar = entry_confirmar.get().strip()
            
            if not actual or not nueva or not confirmar:
                messagebox.showerror("Error", "Complete todos los campos")
                return
            
            if nueva != confirmar:
                messagebox.showerror("Error", "Las contraseñas no coinciden")
                return
            
            if len(nueva) < 6:
                messagebox.showerror("Error", "La contraseña debe tener al menos 6 caracteres")
                return
            
            try:
                ok, msg = cambiar_password(self.db_path, usuario["id"], actual, nueva)
                if ok:
                    messagebox.showinfo("Éxito", msg)
                    win.destroy()
                    self.usuario_autenticado = usuario
                    self.destroy()
                    self.on_success(usuario)
                else:
                    messagebox.showerror("Error", msg)
            except Exception as e:
                from bull_bar.infra.error_logger import log_error
                log_error(e, context="Cambiando contraseña de usuario", 
                         extra_info={"user_id": usuario.get("id"), "username": usuario.get("username")})
                messagebox.showerror("Error", f"Error al cambiar contraseña:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")
        
        ttk.Button(container, text="Cambiar", command=cambiar).pack(pady=(0, 10))
    
    def _recuperar_password(self):
        """Muestra ventana para recuperar contraseña."""
        win = tk.Toplevel(self)
        win.title("Recuperar Contraseña")
        win.geometry("450x300")
        win.transient(self)
        win.grab_set()
        
        container = ttk.Frame(win, padding=20)
        container.pack(fill="both", expand=True)
        
        ttk.Label(container, text="Recuperar Contraseña", font=("Helvetica", 12, "bold")).pack(pady=(0, 15))
        ttk.Label(container, text="Ingrese su usuario para generar un token de recuperación:").pack(pady=(0, 10))
        
        ttk.Label(container, text="Usuario:").pack(anchor="w", pady=(0, 5))
        entry_user = ttk.Entry(container, width=35)
        entry_user.pack(pady=(0, 15))
        
        def generar_token():
            username = entry_user.get().strip()
            if not username:
                messagebox.showerror("Error", "Ingrese un usuario")
                return
            
            try:
                token = generar_token_reset(self.db_path, username)
                if token:
                    # Mostrar token en diálogo copiable
                    win.destroy()
                    show_copyable_token_dialog(self, token)
                    self._usar_token_reset()
                else:
                    messagebox.showerror("Error", "Usuario no encontrado o inactivo")
            except Exception as e:
                from bull_bar.infra.error_logger import log_error
                log_error(e, context="Generando token de recuperación de contraseña", 
                         extra_info={"username": username})
                messagebox.showerror("Error", f"Error al generar token:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")
        
        ttk.Button(container, text="Generar Token", command=generar_token).pack(pady=(0, 20))
        ttk.Button(container, text="Ya tengo un token", command=lambda: (win.destroy(), self._usar_token_reset())).pack()
    
    def _usar_token_reset(self):
        """Ventana para usar token de recuperación."""
        win = tk.Toplevel(self)
        win.title("Restablecer Contraseña")
        win.geometry("450x300")
        win.transient(self)
        win.grab_set()
        
        container = ttk.Frame(win, padding=20)
        container.pack(fill="both", expand=True)
        
        ttk.Label(container, text="Restablecer Contraseña", font=("Helvetica", 12, "bold")).pack(pady=(0, 15))
        
        ttk.Label(container, text="Token:").pack(anchor="w", pady=(0, 5))
        entry_token = ttk.Entry(container, width=35)
        entry_token.pack(pady=(0, 10))
        
        ttk.Label(container, text="Nueva contraseña:").pack(anchor="w", pady=(0, 5))
        entry_nueva = ttk.Entry(container, width=35, show="*")
        entry_nueva.pack(pady=(0, 10))
        
        ttk.Label(container, text="Confirmar contraseña:").pack(anchor="w", pady=(0, 5))
        entry_confirmar = ttk.Entry(container, width=35, show="*")
        entry_confirmar.pack(pady=(0, 15))
        
        def restablecer():
            token = entry_token.get().strip()
            nueva = entry_nueva.get().strip()
            confirmar = entry_confirmar.get().strip()
            
            if not token or not nueva or not confirmar:
                messagebox.showerror("Error", "Complete todos los campos")
                return
            
            if nueva != confirmar:
                messagebox.showerror("Error", "Las contraseñas no coinciden")
                return
            
            if len(nueva) < 6:
                messagebox.showerror("Error", "La contraseña debe tener al menos 6 caracteres")
                return
            
            try:
                ok, msg = reset_password_con_token(self.db_path, token, nueva)
                if ok:
                    messagebox.showinfo("Éxito", msg)
                    win.destroy()
                else:
                    messagebox.showerror("Error", msg)
            except Exception as e:
                from bull_bar.infra.error_logger import log_error
                log_error(e, context="Restableciendo contraseña con token")
                messagebox.showerror("Error", f"Error al restablecer contraseña:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")
        
        ttk.Button(container, text="Restablecer", command=restablecer).pack()


class GestionUsuariosWindow(tk.Toplevel):
    """Ventana para que admin gestione usuarios."""
    
    def __init__(self, parent, db_path: str, usuario_actual: dict):
        super().__init__(parent)
        self.db_path = db_path
        self.usuario_actual = usuario_actual
        
        self.title("Gestión de Usuarios")
        self.geometry("800x600")
        self.transient(parent)
        
        self._build_ui()
        self._refresh_lista()
    
    def _build_ui(self):
        # Barra superior
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")
        
        ttk.Label(top, text="Gestión de Usuarios", font=("Helvetica", 14, "bold")).pack(side="left")
        ttk.Button(top, text="Nuevo Usuario", command=self._nuevo_usuario).pack(side="right", padx=5)
        ttk.Button(top, text="Refrescar", command=self._refresh_lista).pack(side="right", padx=5)
        
        # Lista de usuarios
        cols = ("username", "rol", "nombre_completo", "email", "activo", "last_login")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")
        
        self.tree.heading("username", text="Usuario")
        self.tree.heading("rol", text="Rol")
        self.tree.heading("nombre_completo", text="Nombre")
        self.tree.heading("email", text="Email")
        self.tree.heading("activo", text="Activo")
        self.tree.heading("last_login", text="Último Login")
        
        self.tree.column("username", width=120)
        self.tree.column("rol", width=100)
        self.tree.column("nombre_completo", width=200)
        self.tree.column("email", width=150)
        self.tree.column("activo", width=80)
        self.tree.column("last_login", width=150)
        
        scroll = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        
        self.tree.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=10)
        scroll.pack(side="right", fill="y", padx=(0, 10), pady=10)
        
        self.tree.bind("<Double-1>", lambda e: self._editar_usuario())
    
    def _refresh_lista(self):
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        
        usuarios = listar_usuarios(self.db_path)
        for u in usuarios:
            self.tree.insert("", "end", values=(
                u["username"],
                u["rol"],
                u["nombre_completo"] or "",
                u["email"] or "",
                "Sí" if u["activo"] else "No",
                u["last_login"][:19] if u["last_login"] else "",
            ))
    
    def _nuevo_usuario(self):
        win = tk.Toplevel(self)
        win.title("Nuevo Usuario")
        win.geometry("400x350")
        win.transient(self)
        win.grab_set()
        
        container = ttk.Frame(win, padding=20)
        container.pack(fill="both", expand=True)
        container.columnconfigure(1, weight=1)
        
        ttk.Label(container, text="Usuario:").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=5)
        entry_user = ttk.Entry(container)
        entry_user.grid(row=0, column=1, sticky="ew", pady=5)
        
        ttk.Label(container, text="Rol:").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=5)
        combo_rol = ttk.Combobox(container, values=["ADMIN", "GERENTE", "USUARIO"], state="readonly")
        combo_rol.set("USUARIO")
        combo_rol.grid(row=1, column=1, sticky="ew", pady=5)
        
        ttk.Label(container, text="Nombre completo:").grid(row=2, column=0, sticky="w", padx=(0, 10), pady=5)
        entry_nombre = ttk.Entry(container)
        entry_nombre.grid(row=2, column=1, sticky="ew", pady=5)
        
        ttk.Label(container, text="Email:").grid(row=3, column=0, sticky="w", padx=(0, 10), pady=5)
        entry_email = ttk.Entry(container)
        entry_email.grid(row=3, column=1, sticky="ew", pady=5)
        
        ttk.Label(container, text="Nota: La contraseña inicial será igual al usuario.", 
                 foreground="gray", font=("Helvetica", 9)).grid(row=4, column=0, columnspan=2, pady=(10, 0))
        
        def crear():
            username = entry_user.get().strip()
            rol = combo_rol.get()
            nombre = entry_nombre.get().strip()
            email = entry_email.get().strip()
            
            if not username:
                messagebox.showerror("Error", "Ingrese un usuario")
                return
            
            ok, msg = crear_usuario(self.db_path, username, rol, nombre or None, email or None)
            if ok:
                messagebox.showinfo("Éxito", msg)
                win.destroy()
                self._refresh_lista()
            else:
                messagebox.showerror("Error", msg)
        
        btn_frame = ttk.Frame(container)
        btn_frame.grid(row=5, column=0, columnspan=2, pady=(20, 0))
        ttk.Button(btn_frame, text="Crear", command=crear).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Cancelar", command=win.destroy).pack(side="left", padx=5)
    
    def _editar_usuario(self):
        selection = self.tree.selection()
        if not selection:
            return
        # Por ahora solo mostrar info, se puede expandir para editar
        values = self.tree.item(selection[0], "values")
        messagebox.showinfo("Usuario", f"Usuario: {values[0]}\nRol: {values[1]}")

