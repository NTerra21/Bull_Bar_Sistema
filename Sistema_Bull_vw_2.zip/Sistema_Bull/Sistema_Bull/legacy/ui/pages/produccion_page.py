"""
Página principal de Producción con flujo tipo wizard por pasos.
Implementa selección de receta, confirmación, mezcla y wizard de etapas por grupos.
"""
import tkinter as tk
from tkinter import ttk, messagebox
from bull_bar.core.models import DocumentoItem
from bull_bar.infra.sqlite_recetas import (
    list_recetas, 
    get_receta_items, 
    get_producto_nombre,
    get_receta_chocolate_info,
)
from bull_bar.infra.sqlite_barritas import (
    get_next_lote_number,
    upsert_lote,
)
from bull_bar.produccion.helpers import (
    ordenar_items_por_grupo,
    partir_items_en_etapas,
    calcular_chocolate_total,
    calcular_mezcla_maxima_posible,
)
from uuid import uuid4
from datetime import datetime, date
import sqlite3


class ProduccionPage(ttk.Frame):
    """
    Página principal de Producción con flujo tipo wizard por pasos.
    Paso 0: Selección de receta
    Paso 1: Confirmación de receta
    Paso 2: Selección de mezcla
    Paso 3: Checklist de insumos
    """
    
    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        self.db_path = ctx["db_path"]
        
        # Estado interno del wizard
        self.paso_actual = 0  # 0: selección receta, 1: confirmación receta, 2: mezcla, 3: preparación (etapas)
        self.receta_seleccionada = None  # código de receta seleccionada
        self.receta_nombre = None  # nombre de la receta
        self.mezcla_confirmada = None  # cantidad de mezcla confirmada
        self.etapas = []  # Lista de etapas generadas
        self.etapa_actual_idx = 0  # Índice de la etapa actual
        self.etapas_completadas = set()  # Set de índices de etapas completadas
        self.chocolate_info = None  # Info de chocolate (si aplica)
        self.chocolate_tipo_seleccionado = None  # Tipo de chocolate seleccionado (blanco/negro)
        self.usuario_actual = ctx.get("usuario_actual", {})
        
        # Estados guardados para navegación
        self.pasos_completados = {}  # {paso: True/False}
        self.selecciones = {}  # Guarda selecciones (tipo chocolate, etc.)
        
        # Configurar grid para la página completa (igual que Stock y Movimientos)
        self.grid_rowconfigure(0, weight=1)  # notebook expande
        self.grid_columnconfigure(0, weight=1)
        
        # =========================
        # NOTEBOOK INTERNO (igual estética que Stock y Movimientos)
        # =========================
        self.produccion_notebook = ttk.Notebook(self)
        self.produccion_notebook.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self.produccion_notebook.grid_rowconfigure(0, weight=1)
        self.produccion_notebook.grid_columnconfigure(0, weight=1)
        
        # Crear las pestañas de pasos (inicialmente solo "Elegir Receta")
        self.tab_elegir_receta = self._create_elegir_receta_tab()
        self.produccion_notebook.add(self.tab_elegir_receta, text="Elegir Receta")
        
        # Pestañas de etapas (se crearán dinámicamente cuando haya etapas)
        self.tab_solidos = None
        self.tab_chocolate = None
        self.tab_liquidos = None
        self.tab_confirmacion = None
        self.tab_cargar_lote = None  # Pestaña para cargar lote después de finalizar producción
        
        # Listener para cambios de pestaña
        self.produccion_notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)
    
    def _get_recetas_con_nombres(self):
        """Obtiene lista de recetas con sus códigos y nombres."""
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            # Intentar obtener de tabla recetas con nombre
            try:
                cur.execute("SELECT codigo, nombre FROM recetas ORDER BY codigo")
                rows = cur.fetchall()
                conn.close()
                return [(r[0], r[1] or r[0]) for r in rows]  # Si no hay nombre, usar código
            except:
                # Si no existe columna nombre, solo códigos
                codigos = list_recetas(self.db_path, active=True)
                conn.close()
                return [(c, c) for c in codigos]  # código como nombre también
        except Exception:
            return []
    
    def _create_elegir_receta_tab(self) -> ttk.Frame:
        """Crea la pestaña de 'Elegir Receta'."""
        page = ttk.Frame(self.produccion_notebook)
        # NO usar pack() aquí - el notebook maneja el layout automáticamente
        
        # Configurar grid de la página
        page.grid_rowconfigure(4, weight=1)  # recipe_frame puede expandirse
        page.grid_columnconfigure(0, weight=1)
        
        # Nota: El mix_frame estará en row=2 (antes del nav_bar) para que esté más arriba
        
        # =========================
        # STEPPER HORIZONTAL (oculto según solicitud del usuario)
        # =========================
        self.stepper_frame = ttk.Frame(page, padding=8)
        # Ocultar el stepper - no se muestra
        self.stepper_frame.grid_remove()
        
        # Stepper labels (inicialmente vacío, se llenará cuando haya etapas)
        self.stepper_labels = {}
        self.stepper_arrow_labels = {}
        
        # =========================
        # DETALLES DE PRODUCCIÓN (siempre visible, diseño anterior)
        # =========================
        self.header_expandido_frame = ttk.LabelFrame(page, text="Detalles de producción", padding=8)
        self.header_expandido_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 5))
        self.header_expandido_frame.columnconfigure(1, weight=1)
        self.header_expandido_frame.columnconfigure(3, weight=1)
        
        # Fila 1: Receta y Mezcla
        ttk.Label(self.header_expandido_frame, text="Receta:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 5))
        self.header_receta_label = ttk.Label(self.header_expandido_frame, text="—", font=("Segoe UI", 10))
        self.header_receta_label.grid(row=0, column=1, sticky="w", padx=(0, 20))
        
        ttk.Label(self.header_expandido_frame, text="Mezcla (kg):", font=("Segoe UI", 10, "bold")).grid(row=0, column=2, sticky="w", padx=(0, 5))
        self.header_mezcla_label = ttk.Label(self.header_expandido_frame, text="—", font=("Segoe UI", 10))
        self.header_mezcla_label.grid(row=0, column=3, sticky="w", padx=(0, 20))
        
        # Fila 2: Chocolate
        self.header_choco_frame = ttk.Frame(self.header_expandido_frame)
        self.header_choco_frame.grid(row=1, column=0, columnspan=2, sticky="w", pady=(5, 0))
        ttk.Label(self.header_choco_frame, text="Chocolate:", font=("Segoe UI", 10, "bold")).pack(side="left", padx=(0, 5))
        self.header_choco_label = ttk.Label(self.header_choco_frame, text="—", font=("Segoe UI", 10))
        self.header_choco_label.pack(side="left")
        
        # Fila 3: Mezcla máxima posible
        ttk.Label(self.header_expandido_frame, text="Mezcla máxima:", font=("Segoe UI", 10, "bold")).grid(row=2, column=0, sticky="w", padx=(0, 5), pady=(5, 0))
        self.header_mezcla_max_label = ttk.Label(self.header_expandido_frame, text="—", font=("Segoe UI", 10), foreground="blue")
        self.header_mezcla_max_label.grid(row=2, column=1, sticky="w", padx=(0, 20), pady=(5, 0))
        
        # =========================
        # BARRA DE NAVEGACIÓN
        # =========================
        nav_bar = ttk.Frame(page, padding=5)
        nav_bar.grid(row=3, column=0, sticky="ew", padx=10, pady=(0, 5))
        nav_bar.columnconfigure(1, weight=1)
        
        # Botón Atrás (izquierda)
        self.btn_atras = ttk.Button(nav_bar, text="« Atrás", command=self._atras, state="disabled")
        self.btn_atras.grid(row=0, column=0, sticky="w", padx=(0, 10))
        
        # Botón derecho (dinámico: "Etapa lista →" o "Finalizar producción")
        self.btn_accion_derecha = ttk.Button(nav_bar, text="", command=self._accion_derecha, state="disabled")
        self.btn_accion_derecha.grid(row=0, column=2, sticky="e", padx=(10, 0))
        
        # Botón Cancelar
        self.btn_cancelar = ttk.Button(nav_bar, text="Cancelar", command=self._cancelar)
        self.btn_cancelar.grid(row=0, column=3, sticky="e", padx=(10, 0))
        
        # Botón de prueba de stock (solo para desarrollo/testing)
        # Se puede ocultar o eliminar en producción
        self.btn_prueba_stock = ttk.Button(
            nav_bar, 
            text="🧪 Prueba Stock 100kg", 
            command=self._prueba_stock_100kg,
            state="normal"
        )
        self.btn_prueba_stock.grid(row=0, column=4, sticky="e", padx=(10, 0))
        
        # =========================
        # CONTENIDO: Selección de receta
        # =========================
        self.recipe_frame = ttk.LabelFrame(page, text="Elegir receta", padding=15)
        self.recipe_frame.grid(row=4, column=0, sticky="nsew", padx=10, pady=10)
        self.recipe_frame.columnconfigure(0, weight=1)
        
        # Frame para botones de recetas (con wrap)
        recetas_buttons_frame = ttk.Frame(self.recipe_frame)
        recetas_buttons_frame.grid(row=0, column=0, sticky="ew")
        
        # Obtener recetas y crear botones
        recetas = self._get_recetas_con_nombres()
        self.receta_buttons = []
        for idx, (codigo, nombre) in enumerate(recetas):
            btn = ttk.Button(
                recetas_buttons_frame, 
                text=f"{codigo}\n{nombre}",
                command=lambda c=codigo, n=nombre: self._seleccionar_receta(c, n),
                width=20
            )
            # Organizar en grid (4 columnas)
            row = idx // 4
            col = idx % 4
            btn.grid(row=row, column=col, padx=5, pady=5, sticky="ew")
            self.receta_buttons.append(btn)
            recetas_buttons_frame.columnconfigure(col, weight=1)
        
        # Label de confirmación y botón confirmar (inicialmente oculto)
        self.confirmacion_frame = ttk.Frame(self.recipe_frame)
        self.confirmacion_frame.grid(row=1, column=0, pady=(15, 0))
        
        self.confirmacion_label = ttk.Label(
            self.confirmacion_frame, 
            text="", 
            font=("Helvetica", 10, "bold"),
            foreground="green"
        )
        self.confirmacion_label.pack(side="left", padx=(0, 10))
        
        self.btn_confirmar_receta = ttk.Button(
            self.confirmacion_frame, 
            text="Confirmar receta", 
            command=self._confirmar_receta,
            state="disabled"
        )
        self.btn_confirmar_receta.pack(side="left")
        
        # Inicialmente oculto
        self.confirmacion_frame.grid_remove()
        
        # Frame de mezcla (dentro de esta pestaña, después de confirmar receta)
        # Posicionado en row=2 (antes del nav_bar) para que esté más arriba
        self.mix_frame = ttk.LabelFrame(page, text="Mezcla (kg)", padding=15)
        self.mix_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=10)
        self.mix_frame.columnconfigure(0, weight=1)
        
        # Botones 10/20/30/40
        btn_frame = ttk.Frame(self.mix_frame)
        btn_frame.grid(row=0, column=0, sticky="w", pady=(0, 10))
        
        self.mezcla_buttons = []
        for val in (10, 20, 30, 40):
            btn = ttk.Button(
                btn_frame, 
                text=str(val), 
                command=lambda v=val: self._set_mezcla(v),
                state="disabled"
            )
            btn.pack(side="left", padx=2)
            self.mezcla_buttons.append((btn, val))
        
        # Input manual
        input_frame = ttk.Frame(self.mix_frame)
        input_frame.grid(row=1, column=0, sticky="w", pady=(0, 10))
        
        ttk.Label(input_frame, text="Cantidad (kg):").pack(side="left", padx=(0, 5))
        self.mezcla_entry = ttk.Entry(input_frame, width=10)
        self.mezcla_entry.pack(side="left")
        self.mezcla_entry.config(state="disabled")
        
        # Validar solo números al escribir
        self.mezcla_entry.bind("<KeyRelease>", self._validar_mezcla_input)
        
        # Botón confirmar mezcla (dentro del frame, este es el principal)
        self.btn_confirmar_mezcla = ttk.Button(
            self.mix_frame, 
            text="Confirmar mezcla", 
            command=self._confirmar_mezcla,
            state="disabled"
        )
        self.btn_confirmar_mezcla.grid(row=2, column=0, pady=(10, 0))
        
        # Inicialmente oculto
        self.mix_frame.grid_remove()
        
        # Los frames de etapas se crearán en pestañas separadas cuando sea necesario
        self.etapas_frames = {}  # {grupo: frame}
        self.etapas_trees = {}  # {grupo: treeview}
        self.etapa_subpaso_labels = {}  # {grupo: label}
        
        # Estado inicial: mostrar solo recipe_frame
        self._mostrar_paso(0)
        
        return page
    
    def _on_tab_changed(self, event=None):
        """Se ejecuta cuando el usuario cambia de pestaña manualmente."""
        try:
            current_tab = self.produccion_notebook.select()
            current_tab_text = self.produccion_notebook.tab(current_tab, "text")
            
            # Stepper oculto - no actualizar
            
            # Actualizar botón derecho
            self._actualizar_boton_derecho()
        except Exception:
            pass
    
    def _actualizar_header_detalles(self):
        """Actualiza el panel de detalles de producción."""
        # Receta
        if self.receta_seleccionada:
            receta_text = f"{self.receta_seleccionada} - {self.receta_nombre}"
            self.header_receta_label.config(text=receta_text)
        else:
            self.header_receta_label.config(text="—")
        
        # Mezcla
        if self.mezcla_confirmada:
            self.header_mezcla_label.config(text=f"{self.mezcla_confirmada:.2f} kg")
        else:
            self.header_mezcla_label.config(text="—")
        
        # Chocolate
        if self.chocolate_info and self.chocolate_info.get("usa_chocolate", False):
            choco_receta = self.chocolate_info.get("choco_receta_kg", 0)
            choco_min = self.chocolate_info.get("choco_min_maquina_kg", 8.0)
            choco_total = self.chocolate_info.get("choco_total_kg", 0)
            tipo = self.chocolate_tipo_seleccionado or "NEGRO"
            choco_text = f"Receta: {choco_receta:.2f} kg | Mín. máq: {choco_min:.2f} kg | Total: {choco_total:.2f} kg ({tipo})"
            self.header_choco_label.config(text=choco_text)
            self.header_choco_frame.grid()
        else:
            self.header_choco_label.config(text="—")
            self.header_choco_frame.grid_remove()
        
        # Mezcla máxima posible (calcular si hay receta seleccionada)
        if self.receta_seleccionada:
            try:
                # Obtener items de la receta
                items_receta = get_receta_items(self.db_path, self.receta_seleccionada)
                if items_receta:
                    # Obtener stock actual de cada producto
                    deposito_id = self.ctx["depo"].id
                    stock_por_producto = {}
                    for item in items_receta:
                        producto_codigo = item.get("producto_codigo", "")
                        if producto_codigo:
                            prod_obj = self.ctx["products"].get(producto_codigo)
                            if prod_obj:
                                stock_actual = self.ctx["ledger"].stock_confirmado(deposito_id, prod_obj.id)
                                stock_por_producto[producto_codigo] = stock_actual
                    
                    # Calcular mezcla máxima
                    resultado = calcular_mezcla_maxima_posible(
                        items_receta=items_receta,
                        deposito_id=deposito_id,
                        ledger=self.ctx["ledger"],
                        ctx_products=self.ctx["products"]
                    )
                    
                    mezcla_max = resultado.get("mezcla_max_kg", 0.0)
                    if mezcla_max > 0:
                        self.header_mezcla_max_label.config(
                            text=f"Alcanza hasta {mezcla_max:.1f} kg de mezcla",
                            foreground="blue"
                        )
                    else:
                        faltantes = resultado.get("faltantes", [])
                        if faltantes:
                            self.header_mezcla_max_label.config(
                                text="Faltan productos",
                                foreground="red"
                            )
                        else:
                            self.header_mezcla_max_label.config(text="—", foreground="black")
                else:
                    self.header_mezcla_max_label.config(text="—", foreground="black")
            except Exception as e:
                print(f"[DEBUG] Error calculando mezcla máxima: {e}")
                self.header_mezcla_max_label.config(text="—", foreground="black")
        else:
            self.header_mezcla_max_label.config(text="—", foreground="black")
    
    def _crear_stepper_inicial(self):
        """Crea el stepper inicial genérico (solo números, sin nombres de grupos)."""
        # Limpiar stepper anterior
        for widget in self.stepper_frame.winfo_children():
            widget.destroy()
        self.stepper_labels = {}
        self.stepper_arrow_labels = {}
        
        # Stepper genérico: solo números (1, 2, 3, 4...)
        # Se actualizará cuando haya etapas
        pasos_stepper = [("1",), ("2",), ("3",), ("4",)]
        
        # Crear labels del stepper (todos en gris inicialmente)
        for idx, (num,) in enumerate(pasos_stepper):
            if idx > 0:
                arrow = ttk.Label(self.stepper_frame, text="→", font=("Segoe UI", 10), foreground="#999")
                arrow.grid(row=0, column=idx*2-1, padx=10)
                self.stepper_arrow_labels[idx] = arrow
            
            label = ttk.Label(
                self.stepper_frame, 
                text=num, 
                font=("Segoe UI", 10),
                foreground="#999"  # Gris inicialmente
            )
            label.grid(row=0, column=idx*2, padx=5)
            self.stepper_labels[num] = label
    
    def _crear_stepper(self, num_etapas: int):
        """Actualiza el stepper con el número de etapas (solo números, sin nombres)."""
        # Limpiar stepper anterior
        for widget in self.stepper_frame.winfo_children():
            widget.destroy()
        self.stepper_labels = {}
        self.stepper_arrow_labels = {}
        
        # Crear stepper con números según cantidad de etapas
        pasos_stepper = [(str(i+1),) for i in range(num_etapas)]
        
        # Crear labels del stepper
        for idx, (num,) in enumerate(pasos_stepper):
            if idx > 0:
                arrow = ttk.Label(self.stepper_frame, text="→", font=("Segoe UI", 10), foreground="#999")
                arrow.grid(row=0, column=idx*2-1, padx=10)
                self.stepper_arrow_labels[idx] = arrow
            
            label = ttk.Label(
                self.stepper_frame, 
                text=num, 
                font=("Segoe UI", 10),
                foreground="#999"  # Gris inicialmente
            )
            label.grid(row=0, column=idx*2, padx=5)
            self.stepper_labels[num] = label
    
    
    def _actualizar_stepper(self, etapa_idx: int):
        """Resalta el paso actual en el stepper (por índice de etapa)."""
        if not self.stepper_labels:
            return
        paso_actual_num = str(etapa_idx + 1)  # Convertir índice a número (1-based)
        for num, label in self.stepper_labels.items():
            if num == paso_actual_num:
                label.config(font=("Segoe UI", 10, "bold"), foreground="#0066CC")
            else:
                label.config(font=("Segoe UI", 10), foreground="#999")
    
    def _mostrar_paso(self, paso: int):
        """Muestra/oculta frames según el paso actual del wizard."""
        self.paso_actual = paso
        
        # Cambiar a la pestaña correspondiente en el notebook (solo si existe)
        if paso == 0:
            # Paso 0: Pestaña "Elegir Receta"
            if hasattr(self, 'tab_elegir_receta') and self.tab_elegir_receta:
                try:
                    self.produccion_notebook.select(self.tab_elegir_receta)
                except:
                    pass  # Si aún no está agregado al notebook, ignorar
            if hasattr(self, 'recipe_frame'):
                self.recipe_frame.grid()
            if hasattr(self, 'confirmacion_frame'):
                self.confirmacion_frame.grid_remove()
            if hasattr(self, 'mix_frame'):
                self.mix_frame.grid_remove()
        elif paso == 1:
            # Paso 1: Confirmación de receta (misma pestaña)
            if hasattr(self, 'tab_elegir_receta') and self.tab_elegir_receta:
                try:
                    self.produccion_notebook.select(self.tab_elegir_receta)
                except:
                    pass
            if hasattr(self, 'recipe_frame'):
                self.recipe_frame.grid()
            if hasattr(self, 'confirmacion_frame'):
                self.confirmacion_frame.grid()
            if hasattr(self, 'mix_frame'):
                self.mix_frame.grid_remove()
        elif paso == 2:
            # Paso 2: Mezcla (misma pestaña)
            if hasattr(self, 'tab_elegir_receta') and self.tab_elegir_receta:
                try:
                    self.produccion_notebook.select(self.tab_elegir_receta)
                except:
                    pass
            if hasattr(self, 'recipe_frame'):
                self.recipe_frame.grid_remove()
            if hasattr(self, 'confirmacion_frame'):
                self.confirmacion_frame.grid_remove()
            if hasattr(self, 'mix_frame'):
                self.mix_frame.grid()
        
        # Actualizar botón Atrás (ocultar en paso 0)
        if hasattr(self, 'btn_atras'):
            if paso == 0:
                self.btn_atras.grid_remove()
            else:
                self.btn_atras.grid()
                self.btn_atras.config(state="normal")
        
        # Actualizar botón derecho dinámico
        # En paso 2 (mezcla), NO mostrar el botón de la barra superior
        # El usuario debe usar el botón dentro del frame de mezcla
        if hasattr(self, 'btn_accion_derecha'):
            if paso == 0 or paso == 1 or paso == 2:
                # Ocultar en pasos 0, 1 y 2 (mezcla tiene su propio botón)
                self.btn_accion_derecha.grid_remove()
            else:
                # Mostrar solo en paso 3 (etapas)
                self.btn_accion_derecha.grid()
                self._actualizar_boton_derecho()
    
    def _seleccionar_receta(self, codigo: str, nombre: str):
        """Selecciona una receta y muestra confirmación (Paso 1)."""
        self.receta_seleccionada = codigo
        self.receta_nombre = nombre
        
        # Mostrar confirmación
        self.confirmacion_label.config(text=f"✓ Receta '{codigo}' seleccionada")
        self.confirmacion_frame.grid()
        self.btn_confirmar_receta.config(state="normal")
        
        # Cambiar a paso 1 (esto actualizará el botón derecho dinámico también)
        self._mostrar_paso(1)
    
    def _confirmar_receta(self):
        """Confirma la receta seleccionada y avanza al paso 2 (mezcla)."""
        if not self.receta_seleccionada:
            return
        
        # Verificar stock antes de confirmar
        try:
            items_receta = get_receta_items(self.db_path, self.receta_seleccionada)
            if items_receta:
                deposito_id = self.ctx["depo"].id
                stock_por_producto = {}
                faltantes = []
                
                for item in items_receta:
                    producto_codigo = item.get("producto_codigo", "")
                    if producto_codigo:
                        prod_obj = self.ctx["products"].get(producto_codigo)
                        if prod_obj:
                            stock_actual = self.ctx["ledger"].stock_confirmado(deposito_id, prod_obj.id)
                            stock_por_producto[producto_codigo] = stock_actual
                            if stock_actual <= 0:
                                faltantes.append(producto_codigo)
                
                if faltantes:
                    nombres_faltantes = []
                    for codigo in faltantes:
                        prod_obj = self.ctx["products"].get(codigo)
                        if prod_obj:
                            nombres_faltantes.append(f"{codigo} - {prod_obj.nombre}")
                        else:
                            nombres_faltantes.append(codigo)
                    
                    messagebox.showwarning(
                        "Stock insuficiente",
                        f"No hay stock suficiente para esta receta.\n\n"
                        f"Productos faltantes:\n" + "\n".join(nombres_faltantes) + "\n\n"
                        f"Por favor, verifique el stock antes de continuar."
                    )
                    return
        except Exception as e:
            print(f"[DEBUG] Error verificando stock: {e}")
            # Continuar de todas formas si hay error en la verificación
        
        # Obtener info de chocolate
        self.chocolate_info = get_receta_chocolate_info(self.db_path, self.receta_seleccionada)
        if self.chocolate_info.get("usa_chocolate", False):
            # Mostrar selector de tipo de chocolate si aplica
            tipo_sugerido = self.chocolate_info.get("choco_tipo_sugerido") or "NEGRO"
            self.chocolate_tipo_seleccionado = tipo_sugerido
        
        # Actualizar panel de detalles
        self._actualizar_header_detalles()
        
        # Habilitar controles de mezcla (están en la misma pestaña)
        for btn, _ in self.mezcla_buttons:
            btn.config(state="normal")
        self.mezcla_entry.config(state="normal")
        
        # Limpiar mezcla
        self.mezcla_entry.delete(0, "end")
        self.mezcla_confirmada = None
        
        # Cambiar a paso 2 (mostrar frame de mezcla)
        self._mostrar_paso(2)
    
    def _set_mezcla(self, valor: int):
        """Establece la cantidad de mezcla desde un botón."""
        if self.paso_actual != 2:
            return
        
        self.mezcla_entry.delete(0, "end")
        self.mezcla_entry.insert(0, str(valor))
        self._validar_mezcla_para_confirmar()
    
    def _validar_mezcla_input(self, event):
        """Valida que el input solo contenga números y habilita confirmar si es válido."""
        current = self.mezcla_entry.get()
        # Filtrar solo dígitos
        filtered = ''.join(filter(str.isdigit, current))
        if filtered != current:
            # Si cambió, actualizar
            cursor_pos = self.mezcla_entry.index(tk.INSERT)
            self.mezcla_entry.delete(0, "end")
            self.mezcla_entry.insert(0, filtered)
            # Restaurar posición del cursor
            try:
                self.mezcla_entry.icursor(min(cursor_pos - 1, len(filtered)))
            except:
                pass
        
        self._validar_mezcla_para_confirmar()
    
    def _crear_validador_mezcla(self):
        """Crea una función que valida la mezcla y habilita/deshabilita el botón dentro del frame."""
        def validar():
            if hasattr(self, 'mezcla_entry') and hasattr(self, 'btn_confirmar_mezcla'):
                valor = self.mezcla_entry.get().strip()
                if valor and valor.isdigit() and float(valor) > 0:
                    self.btn_confirmar_mezcla.config(state="normal")
                else:
                    self.btn_confirmar_mezcla.config(state="disabled")
        return validar
    
    def _validar_mezcla_para_confirmar(self):
        """Valida la mezcla y habilita/deshabilita el botón confirmar."""
        # Actualizar el botón dentro del frame de mezcla
        if hasattr(self, 'btn_confirmar_mezcla'):
            valor = self.mezcla_entry.get().strip()
            if valor and valor.isdigit() and float(valor) > 0:
                self.btn_confirmar_mezcla.config(state="normal")
            else:
                self.btn_confirmar_mezcla.config(state="disabled")
        
        # NO actualizar el botón de la barra superior (ya no se usa en paso 2)
    
    def _confirmar_mezcla(self):
        """Confirma la mezcla y avanza al paso 3 (preparación/etapas)."""
        mezcla_str = self.mezcla_entry.get().strip()
        if not mezcla_str:
            return
        
        try:
            mezcla = float(mezcla_str)
            if mezcla < 1:
                return
        except:
            return
        
        self.mezcla_confirmada = mezcla
        
        # Calcular chocolate si aplica
        if self.chocolate_info and self.chocolate_info.get("usa_chocolate", False):
            choco_calc = calcular_chocolate_total(
                mezcla_kg=mezcla,
                choco_porcentaje=self.chocolate_info.get("choco_porcentaje"),
                choco_min_maquina_kg=self.chocolate_info.get("choco_min_maquina_kg", 8.0)
            )
            self.chocolate_info.update(choco_calc)
        
        # Actualizar panel de detalles
        self._actualizar_header_detalles()
        
        # Calcular y mostrar etapas (esto crea las pestañas dinámicamente)
        self._calcular_y_mostrar_etapas()
        
        # Mostrar stepper (ahora que hay receta y mezcla confirmada)
        self._mostrar_stepper()
        
        # Cambiar a primera pestaña de etapa
        if self.tab_solidos:
            self.produccion_notebook.select(self.tab_solidos)
            self.paso_actual = 3  # Estamos en preparación
            self._actualizar_boton_derecho()
    
    
    def _mostrar_stepper(self):
        """Actualiza el stepper con el número de etapas cuando hay receta y mezcla confirmada."""
        # Stepper oculto según solicitud del usuario - no hacer nada
        return
    
    def _calcular_y_mostrar_etapas(self):
        """Calcula y muestra las etapas de preparación basadas en grupos."""
        if not self.receta_seleccionada or not self.mezcla_confirmada:
            return
        
        # Obtener items de la receta
        items = get_receta_items(self.db_path, self.receta_seleccionada)
        if not items:
            return
        
        # Ordenar items por grupo y orden
        items_ordenados = ordenar_items_por_grupo(items)
        
        # Partir en etapas
        self.etapas = partir_items_en_etapas(items_ordenados)
        
        # Agregar etapa de chocolate si aplica
        if self.chocolate_info and self.chocolate_info.get("usa_chocolate", False):
            choco_total = self.chocolate_info.get("choco_total_kg", 0)
            tipo = self.chocolate_tipo_seleccionado or "NEGRO"
            self.etapas.append({
                "nombre": f"CHOCOLATE ({tipo})",
                "grupo": "CHOCOLATE",
                "items": [{
                    "producto_codigo": f"CHOCO-{tipo}",
                    "cantidad_kg": choco_total,
                    "es_chocolate": True,
                }],
                "etapa_num": 1,
                "total_etapas_grupo": 1,
            })
        
        # Crear pestañas dinámicamente para cada grupo
        self._crear_tabs_etapas()
        
        # Reiniciar estado de etapas
        if self.etapa_actual_idx >= len(self.etapas):
            self.etapa_actual_idx = 0
            self.etapas_completadas = set()
        
        # Llenar todas las pestañas con sus datos
        self._llenar_todas_las_pestanas_etapas()
        
        # Mostrar primera etapa
        self._mostrar_etapa_actual()
    
    def _crear_tabs_etapas(self):
        """Crea pestañas dinámicamente para cada grupo de etapas."""
        # Agrupar etapas por grupo
        etapas_por_grupo = {}
        for etapa in self.etapas:
            grupo = etapa.get("grupo", "OTROS")
            if grupo not in etapas_por_grupo:
                etapas_por_grupo[grupo] = []
            etapas_por_grupo[grupo].append(etapa)
        
        # Crear pestaña para cada grupo principal
        if "SOLIDOS" in etapas_por_grupo and not self.tab_solidos:
            self.tab_solidos = self._crear_tab_etapa("SOLIDOS", etapas_por_grupo["SOLIDOS"])
            self.produccion_notebook.add(self.tab_solidos, text="Sólidos")
        
        if "CHOCOLATE" in etapas_por_grupo and not self.tab_chocolate:
            self.tab_chocolate = self._crear_tab_etapa("CHOCOLATE", etapas_por_grupo["CHOCOLATE"])
            self.produccion_notebook.add(self.tab_chocolate, text="Chocolate")
        
        if "LIQUIDOS" in etapas_por_grupo and not self.tab_liquidos:
            self.tab_liquidos = self._crear_tab_etapa("LIQUIDOS", etapas_por_grupo["LIQUIDOS"])
            self.produccion_notebook.add(self.tab_liquidos, text="Líquidos")
        
        # NO crear pestaña de confirmación - será un botón que aparece al completar todo
        # El botón se mostrará dinámicamente cuando todas las etapas estén completadas
    
    def _crear_tab_etapa(self, grupo: str, etapas_grupo: list) -> ttk.Frame:
        """Crea una pestaña para un grupo de etapas."""
        page = ttk.Frame(self.produccion_notebook)
        page.pack(fill="both", expand=True)
        
        page.grid_rowconfigure(1, weight=1)
        page.grid_columnconfigure(0, weight=1)
        
        # Frame para subpaso y botones de navegación
        etapa_subpaso_frame = ttk.Frame(page)
        etapa_subpaso_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        etapa_subpaso_frame.columnconfigure(0, weight=1)
        
        etapa_subpaso_label = ttk.Label(
            etapa_subpaso_frame, 
            text="", 
            font=("Segoe UI", 10, "italic"),
            foreground="#666"
        )
        etapa_subpaso_label.grid(row=0, column=0, sticky="w")
        self.etapa_subpaso_labels[grupo] = etapa_subpaso_label
        
        # Frame para botones de navegación
        botones_frame = ttk.Frame(etapa_subpaso_frame)
        botones_frame.grid(row=0, column=1, sticky="e", padx=(10, 0))
        
        # Botón "Atrás" para retroceder entre sub-etapas
        btn_atras_etapa = ttk.Button(
            botones_frame,
            text="← Atrás",
            command=lambda: self._atras_etapa_grupo(grupo)
        )
        btn_atras_etapa.pack(side="left", padx=(0, 5))
        # Guardar referencia al botón
        if not hasattr(self, 'btn_atras_por_grupo'):
            self.btn_atras_por_grupo = {}
        self.btn_atras_por_grupo[grupo] = btn_atras_etapa
        
        # Botón "Siguiente" para avanzar entre sub-etapas
        btn_siguiente = ttk.Button(
            botones_frame,
            text="Siguiente →",
            command=lambda: self._siguiente_etapa_grupo(grupo)
        )
        btn_siguiente.pack(side="left")
        # Guardar referencia al botón
        if not hasattr(self, 'btn_siguiente_por_grupo'):
            self.btn_siguiente_por_grupo = {}
        self.btn_siguiente_por_grupo[grupo] = btn_siguiente
        
        # Tabla tipo stock
        tabla_frame = ttk.Frame(page)
        tabla_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        tabla_frame.columnconfigure(0, weight=1)
        tabla_frame.rowconfigure(0, weight=1)
        
        cols = ("codigo", "nombre", "cantidad", "unidad", "porcentaje")
        etapas_tree = ttk.Treeview(tabla_frame, columns=cols, show="headings", height=15)
        
        # Configurar columnas
        etapas_tree.heading("codigo", text="Código")
        etapas_tree.heading("nombre", text="Nombre")
        etapas_tree.heading("cantidad", text="Cantidad")
        etapas_tree.heading("unidad", text="Unidad")
        etapas_tree.heading("porcentaje", text="%")
        
        etapas_tree.column("codigo", width=150, anchor="w")
        etapas_tree.column("nombre", width=400, anchor="w")
        etapas_tree.column("cantidad", width=120, anchor="e")
        etapas_tree.column("unidad", width=80, anchor="c")
        etapas_tree.column("porcentaje", width=80, anchor="e")
        
        # Scrollbar
        tabla_scrollbar = ttk.Scrollbar(tabla_frame, orient="vertical", command=etapas_tree.yview)
        etapas_tree.configure(yscrollcommand=tabla_scrollbar.set)
        
        etapas_tree.grid(row=0, column=0, sticky="nsew")
        tabla_scrollbar.grid(row=0, column=1, sticky="ns")
        
        # Configurar fuente grande
        style = ttk.Style()
        style.configure("Treeview", font=("Segoe UI", 11))
        style.configure("Treeview.Heading", font=("Segoe UI", 11, "bold"))
        
        # Guardar referencia
        self.etapas_trees[grupo] = etapas_tree
        self.etapas_frames[grupo] = page
        
        return page
    
    def _crear_tab_cargar_lote(self):
        """Crea la pestaña de 'Cargar lote' después de finalizar producción."""
        if self.tab_cargar_lote:
            # Si ya existe, solo seleccionarla
            self.produccion_notebook.select(self.tab_cargar_lote)
            return
        
        page = ttk.Frame(self.produccion_notebook)
        page.pack(fill="both", expand=True)
        
        page.grid_rowconfigure(0, weight=1)
        page.grid_columnconfigure(0, weight=1)
        
        # Frame principal con scroll si es necesario
        main_frame = ttk.Frame(page, padding=15)
        main_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        main_frame.columnconfigure(1, weight=1)
        
        # Título
        ttk.Label(
            main_frame,
            text="Cargar Lote de Producción",
            font=("Segoe UI", 14, "bold")
        ).grid(row=0, column=0, columnspan=2, pady=(0, 20), sticky="w")
        
        # Generar número de lote automáticamente
        lote_numero = get_next_lote_number(self.db_path)
        
        # Lote (autogenerado, solo lectura)
        ttk.Label(main_frame, text="Lote:", font=("Segoe UI", 10, "bold")).grid(row=1, column=0, sticky="w", pady=5)
        self.lote_id_label = ttk.Label(main_frame, text=lote_numero, font=("Segoe UI", 10))
        self.lote_id_label.grid(row=1, column=1, sticky="w", padx=(10, 0), pady=5)
        
        # Tipo de Producto (receta utilizada, solo lectura)
        ttk.Label(main_frame, text="Tipo de Producto:", font=("Segoe UI", 10, "bold")).grid(row=2, column=0, sticky="w", pady=5)
        ttk.Label(
            main_frame, 
            text=f"{self.receta_seleccionada} - {self.receta_nombre}", 
            font=("Segoe UI", 10)
        ).grid(row=2, column=1, sticky="w", padx=(10, 0), pady=5)
        
        # Cantidad de Barritas producidas (puede quedar vacío)
        ttk.Label(main_frame, text="Cantidad:", font=("Segoe UI", 10, "bold")).grid(row=3, column=0, sticky="w", pady=5)
        self.lote_cantidad_entry = ttk.Entry(main_frame, width=15)
        self.lote_cantidad_entry.grid(row=3, column=1, sticky="w", padx=(10, 0), pady=5)
        ttk.Label(main_frame, text="(puede completarse más adelante)", font=("Segoe UI", 8), foreground="gray").grid(row=3, column=1, sticky="w", padx=(150, 0), pady=5)
        
        # Fecha de producción (predeterminada a hoy, editable)
        from datetime import date
        fecha_hoy = date.today().strftime("%Y-%m-%d")
        ttk.Label(main_frame, text="Fecha de producción:", font=("Segoe UI", 10, "bold")).grid(row=4, column=0, sticky="w", pady=5)
        self.lote_fecha_prod_entry = ttk.Entry(main_frame, width=15)
        self.lote_fecha_prod_entry.insert(0, fecha_hoy)
        self.lote_fecha_prod_entry.grid(row=4, column=1, sticky="w", padx=(10, 0), pady=5)
        # Botón para seleccionar fecha
        btn_fecha_prod = ttk.Button(
            main_frame,
            text="📅",
            command=lambda: self._seleccionar_fecha(self.lote_fecha_prod_entry),
            width=3
        )
        btn_fecha_prod.grid(row=4, column=1, sticky="w", padx=(150, 0), pady=5)
        
        # Fecha de vencimiento (manual, editable)
        ttk.Label(main_frame, text="Fecha de vencimiento:", font=("Segoe UI", 10, "bold")).grid(row=5, column=0, sticky="w", pady=5)
        self.lote_fecha_venc_entry = ttk.Entry(main_frame, width=15)
        self.lote_fecha_venc_entry.grid(row=5, column=1, sticky="w", padx=(10, 0), pady=5)
        # Botón para seleccionar fecha
        btn_fecha_venc = ttk.Button(
            main_frame,
            text="📅",
            command=lambda: self._seleccionar_fecha(self.lote_fecha_venc_entry),
            width=3
        )
        btn_fecha_venc.grid(row=5, column=1, sticky="w", padx=(150, 0), pady=5)
        
        # Depósito/Ubicación (fijo, solo lectura - por defecto el de la fábrica)
        deposito_nombre = self.ctx.get("depo").nombre if self.ctx.get("depo") else "Deposito Principal"
        ttk.Label(main_frame, text="Depósito/Ubicación:", font=("Segoe UI", 10, "bold")).grid(row=6, column=0, sticky="w", pady=5)
        self.lote_deposito_label = ttk.Label(main_frame, text=deposito_nombre, font=("Segoe UI", 10))
        self.lote_deposito_label.grid(row=6, column=1, sticky="w", padx=(10, 0), pady=5)
        
        # Estado: Activo/Inactivo
        ttk.Label(main_frame, text="Estado:", font=("Segoe UI", 10, "bold")).grid(row=7, column=0, sticky="w", pady=5)
        self.lote_estado_var = tk.StringVar(value="Activo")
        estado_frame = ttk.Frame(main_frame)
        estado_frame.grid(row=7, column=1, sticky="w", padx=(10, 0), pady=5)
        ttk.Radiobutton(estado_frame, text="Activo", variable=self.lote_estado_var, value="Activo").pack(side="left", padx=(0, 10))
        ttk.Radiobutton(estado_frame, text="Inactivo", variable=self.lote_estado_var, value="Inactivo").pack(side="left")
        
        # Observaciones/Notas (opcional)
        ttk.Label(main_frame, text="Observaciones:", font=("Segoe UI", 10, "bold")).grid(row=8, column=0, sticky="nw", pady=5)
        self.lote_notas_text = tk.Text(main_frame, width=40, height=4, wrap="word")
        self.lote_notas_text.grid(row=8, column=1, sticky="ew", padx=(10, 0), pady=5)
        
        # Estado de ventas (se calcula automáticamente, solo lectura)
        # Se actualizará cuando se ingrese la cantidad
        ttk.Label(main_frame, text="Estado de ventas:", font=("Segoe UI", 10, "bold")).grid(row=9, column=0, sticky="w", pady=5)
        self.lote_estado_ventas_label = ttk.Label(main_frame, text="Sin vender", font=("Segoe UI", 10), foreground="green")
        self.lote_estado_ventas_label.grid(row=9, column=1, sticky="w", padx=(10, 0), pady=5)
        
        # Actualizar estado de ventas cuando cambie la cantidad
        self.lote_cantidad_entry.bind("<KeyRelease>", lambda e: self._actualizar_estado_ventas_lote())
        
        # Botones de acción
        botones_frame = ttk.Frame(main_frame)
        botones_frame.grid(row=10, column=0, columnspan=2, pady=20)
        
        btn_guardar = ttk.Button(
            botones_frame,
            text="Guardar Lote",
            command=self._guardar_lote,
            state="normal"
        )
        btn_guardar.pack(side="left", padx=(0, 10))
        
        btn_cancelar_lote = ttk.Button(
            botones_frame,
            text="Cancelar",
            command=self._cancelar_carga_lote
        )
        btn_cancelar_lote.pack(side="left")
        
        self.tab_cargar_lote = page
        self.produccion_notebook.add(page, text="Cargar Lote")
        
        return page
    
    def _seleccionar_fecha(self, entry_widget):
        """Abre un diálogo simple para ingresar fecha manualmente."""
        fecha_actual = entry_widget.get()
        
        # Crear ventana temporal para ingresar fecha
        fecha_window = tk.Toplevel(self)
        fecha_window.title("Seleccionar fecha")
        fecha_window.transient(self)
        fecha_window.grab_set()
        fecha_window.geometry("300x150")
        
        ttk.Label(fecha_window, text="Ingrese la fecha (YYYY-MM-DD):", font=("Segoe UI", 10)).pack(pady=10)
        
        fecha_entry = ttk.Entry(fecha_window, width=15, font=("Segoe UI", 10))
        fecha_entry.pack(pady=5)
        fecha_entry.insert(0, fecha_actual if fecha_actual else date.today().strftime("%Y-%m-%d"))
        fecha_entry.focus()
        fecha_entry.select_range(0, "end")
        
        def aplicar_fecha():
            fecha_str = fecha_entry.get().strip()
            # Validar formato básico
            try:
                datetime.strptime(fecha_str, "%Y-%m-%d")
                entry_widget.delete(0, "end")
                entry_widget.insert(0, fecha_str)
                fecha_window.destroy()
            except ValueError:
                messagebox.showerror("Error", "Formato de fecha inválido. Use YYYY-MM-DD (ej: 2024-12-25)")
        
        botones_frame = ttk.Frame(fecha_window)
        botones_frame.pack(pady=10)
        ttk.Button(botones_frame, text="Aplicar", command=aplicar_fecha).pack(side="left", padx=5)
        ttk.Button(botones_frame, text="Hoy", command=lambda: fecha_entry.delete(0, "end") or fecha_entry.insert(0, date.today().strftime("%Y-%m-%d"))).pack(side="left", padx=5)
        ttk.Button(botones_frame, text="Cancelar", command=fecha_window.destroy).pack(side="left", padx=5)
        
        # Permitir Enter para aplicar
        fecha_entry.bind("<Return>", lambda e: aplicar_fecha())
    
    def _actualizar_estado_ventas_lote(self):
        """Actualiza el estado de ventas del lote según la cantidad ingresada."""
        if not hasattr(self, 'lote_cantidad_entry') or not hasattr(self, 'lote_estado_ventas_label'):
            return
        
        cantidad_str = self.lote_cantidad_entry.get().strip()
        try:
            cantidad_total = float(cantidad_str) if cantidad_str and cantidad_str.replace(".", "").replace("-", "").isdigit() else 0.0
            cantidad_vendida = 0.0  # Al crear el lote, siempre empieza sin ventas
            
            if cantidad_total == 0:
                estado_texto = "Sin vender"
                color = "green"
            elif cantidad_vendida == 0:
                estado_texto = "Sin vender"
                color = "green"
            elif cantidad_vendida >= cantidad_total:
                estado_texto = "Vendidas todas"
                color = "red"
            else:
                cantidad_disponible = cantidad_total - cantidad_vendida
                estado_texto = f"Vendidas parcial ({cantidad_vendida:.0f} vendidas, {cantidad_disponible:.0f} disponibles)"
                color = "orange"
            
            self.lote_estado_ventas_label.config(text=estado_texto, foreground=color)
        except:
            self.lote_estado_ventas_label.config(text="Sin vender", foreground="green")
    
    def _guardar_lote(self):
        """Guarda el lote en la base de datos."""
        # Mostrar diálogo de confirmación
        respuesta = messagebox.askyesno(
            "Confirmar guardado",
            "¿Está seguro de que desea guardar este lote?\n\n"
            "Esta acción guardará el lote en la base de datos y no se podrá deshacer fácilmente.",
            icon="question"
        )
        if not respuesta:
            return  # El usuario canceló
        
        # Validar campos obligatorios
        lote_id = self.lote_id_label.cget("text")
        if not lote_id:
            messagebox.showerror("Error", "El número de lote es obligatorio.")
            return
        
        # SKU será el código de la receta
        sku = self.receta_seleccionada
        nombre = self.receta_nombre or self.receta_seleccionada
        
        # Cantidad (puede estar vacía, se puede completar después)
        cantidad_str = self.lote_cantidad_entry.get().strip()
        try:
            cantidad_total = float(cantidad_str) if cantidad_str and cantidad_str.replace(".", "").replace("-", "").isdigit() else 0.0
        except:
            cantidad_total = 0.0
        
        # Fechas
        fecha_produccion = self.lote_fecha_prod_entry.get().strip()
        fecha_vencimiento = self.lote_fecha_venc_entry.get().strip()
        
        # Validar formato de fechas
        if fecha_produccion:
            try:
                datetime.strptime(fecha_produccion, "%Y-%m-%d")
            except ValueError:
                messagebox.showerror("Error", "Formato de fecha de producción inválido. Use YYYY-MM-DD")
                return
        
        if fecha_vencimiento:
            try:
                datetime.strptime(fecha_vencimiento, "%Y-%m-%d")
            except ValueError:
                messagebox.showerror("Error", "Formato de fecha de vencimiento inválido. Use YYYY-MM-DD")
                return
        
        # Depósito/Ubicación (fijo, siempre el de la fábrica)
        deposito = self.ctx.get("depo").nombre if self.ctx.get("depo") else "Deposito Principal"
        
        # Estado (Activo/Inactivo) - mapear a estados de la BD
        estado_activo = self.lote_estado_var.get() == "Activo"
        estado = "DISPONIBLE" if estado_activo else "BLOQUEADO"
        
        # Notas
        notas = self.lote_notas_text.get("1.0", "end-1c").strip()
        
        # Mezcla usada (guardar la mezcla confirmada)
        mezcla_kg = self.mezcla_confirmada if self.mezcla_confirmada else None
        
        # Guardar lote
        try:
            ok = upsert_lote(
                db_path=self.db_path,
                lote_id=lote_id,
                sku=sku,
                nombre=nombre,
                cantidad_total=cantidad_total,
                cantidad_vendida=0.0,  # Al crear, siempre empieza en 0
                cantidad_disponible=cantidad_total,
                fecha_produccion=fecha_produccion,
                fecha_vencimiento=fecha_vencimiento,
                deposito=deposito,
                estado=estado,
                notas=notas,
                mezcla_kg=mezcla_kg
            )
            
            if ok:
                messagebox.showinfo("Lote guardado", f"Lote {lote_id} guardado correctamente.")
                # Registrar auditoría
                try:
                    from bull_bar.infra.audit import log_audit
                    log_audit(
                        db_path=self.db_path,
                        usuario=self.usuario_actual.get("username", "USUARIO"),
                        accion="LOTE_CREADO",
                        modulo="PRODUCCION",
                        entidad_id=lote_id,
                        entidad_tipo="LOTE",
                        metadata=f"Lote creado desde producción {self.produccion_numero}. Cantidad: {cantidad_total}, Receta: {self.receta_seleccionada}"
                    )
                except Exception:
                    pass
                
                # Refrescar vista de lotes si está abierta
                try:
                    # Buscar todas las ventanas Toplevel y refrescar tabs de lotes
                    root = self.winfo_toplevel()
                    for widget in root.winfo_children():
                        if isinstance(widget, tk.Toplevel):
                            try:
                                # Buscar notebook dentro de la ventana
                                for child in widget.winfo_children():
                                    if isinstance(child, ttk.Notebook):
                                        # Buscar tab de lotes en el notebook
                                        for i in range(child.index("end")):
                                            try:
                                                tab = child.nametowidget(child.tabs()[i])
                                                # Verificar si es el tab de lotes (tiene método refresh y view_mode)
                                                if hasattr(tab, 'refresh') and hasattr(tab, 'view_mode'):
                                                    tab.refresh()
                                            except Exception:
                                                continue
                            except Exception:
                                pass
                except Exception as e:
                    # Si falla el refresh, no es crítico, solo no se actualiza la vista
                    print(f"[DEBUG] No se pudo refrescar vista de lotes: {e}")
                
                # Limpiar y volver al inicio
                self._cancelar()
            else:
                messagebox.showerror("Error", "Error al guardar el lote.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al guardar el lote: {str(e)}")
    
    def _cancelar_carga_lote(self):
        """Cancela la carga de lote y vuelve al inicio."""
        if self.tab_cargar_lote:
            try:
                self.produccion_notebook.forget(self.tab_cargar_lote)
            except:
                pass
            self.tab_cargar_lote = None
        
        # Limpiar variables
        self.produccion_doc_id = None
        self.produccion_numero = None
        
        # Volver al inicio
        self._cancelar()
    
    def _llenar_todas_las_pestanas_etapas(self):
        """Llena todas las pestañas de etapas con sus datos correspondientes."""
        # Agrupar etapas por grupo
        etapas_por_grupo = {}
        for etapa in self.etapas:
            grupo = etapa.get("grupo", "OTROS")
            if grupo not in etapas_por_grupo:
                etapas_por_grupo[grupo] = []
            etapas_por_grupo[grupo].append(etapa)
        
        # Llenar cada pestaña con todas sus etapas
        for grupo, etapas_grupo in etapas_por_grupo.items():
            tree = self.etapas_trees.get(grupo)
            if not tree:
                continue
            
            # Limpiar tabla
            for item in tree.get_children():
                tree.delete(item)
            
            # Llenar con todos los items de todas las etapas del grupo
            for etapa in etapas_grupo:
                for item_data in etapa["items"]:
                    if item_data.get("es_chocolate"):
                        codigo = item_data.get("producto_codigo", "CHOCO")
                        nombre = f"Chocolate {self.chocolate_tipo_seleccionado or 'NEGRO'}"
                        cantidad = item_data.get("cantidad_kg", 0)
                        unidad = "kg"
                        porcentaje = ""
                    else:
                        producto_codigo = item_data.get("producto_codigo", "")
                        porcentaje = float(item_data.get("porcentaje", 0))
                        cantidad = self.mezcla_confirmada * (porcentaje / 100.0)
                        
                        nombre = get_producto_nombre(self.db_path, producto_codigo) or producto_codigo
                        codigo = producto_codigo
                        unidad = "kg"
                        porcentaje = f"{porcentaje:.2f}"
                    
                    tree.insert("", "end", values=(
                        codigo,
                        nombre,
                        f"{cantidad:.3f}",
                        unidad,
                        porcentaje
                    ))
    
    def _siguiente_etapa_grupo(self, grupo: str):
        """Avanza a la siguiente etapa dentro del mismo grupo o a la siguiente pestaña."""
        # Marcar la etapa actual como completada
        self.etapas_completadas.add(self.etapa_actual_idx)
        self.pasos_completados[self.etapa_actual_idx] = True
        
        # Encontrar la siguiente etapa del mismo grupo
        siguiente_idx = None
        for idx in range(self.etapa_actual_idx + 1, len(self.etapas)):
            if self.etapas[idx].get("grupo", "") == grupo:
                siguiente_idx = idx
                break
        
        if siguiente_idx is not None:
            # Hay más etapas en este grupo, avanzar
            self.etapa_actual_idx = siguiente_idx
            self._mostrar_etapa_actual()
        else:
            # No hay más etapas en este grupo, avanzar a la siguiente pestaña (grupo)
            siguiente_grupo_idx = None
            siguiente_grupo = None
            
            # Buscar el siguiente grupo disponible
            grupos_orden = ["SOLIDOS", "CHOCOLATE", "LIQUIDOS"]
            try:
                grupo_actual_pos = grupos_orden.index(grupo)
            except ValueError:
                grupo_actual_pos = -1
            
            # Buscar siguiente grupo en el orden
            for siguiente_grupo_nombre in grupos_orden[grupo_actual_pos + 1:]:
                # Buscar primera etapa de ese grupo
                for idx in range(len(self.etapas)):
                    if self.etapas[idx].get("grupo", "") == siguiente_grupo_nombre:
                        siguiente_grupo_idx = idx
                        siguiente_grupo = siguiente_grupo_nombre
                        break
                if siguiente_grupo_idx is not None:
                    break
            
            if siguiente_grupo_idx is not None:
                # Avanzar a la siguiente pestaña
                self.etapa_actual_idx = siguiente_grupo_idx
                self._mostrar_etapa_actual()
                
                # Cambiar a la pestaña del siguiente grupo
                if siguiente_grupo == "SOLIDOS" and self.tab_solidos:
                    self.produccion_notebook.select(self.tab_solidos)
                elif siguiente_grupo == "CHOCOLATE" and self.tab_chocolate:
                    self.produccion_notebook.select(self.tab_chocolate)
                elif siguiente_grupo == "LIQUIDOS" and self.tab_liquidos:
                    self.produccion_notebook.select(self.tab_liquidos)
            else:
                # No hay más grupos, verificar si todas las etapas están completadas
                todas_completadas = (len(self.etapas_completadas) == len(self.etapas))
                if todas_completadas:
                    # Mostrar botón de confirmación
                    self._mostrar_boton_confirmacion()
                    messagebox.showinfo("Etapas completadas", "Todas las etapas están completadas. Puede finalizar la producción.")
    
    def _atras_etapa_grupo(self, grupo: str):
        """Retrocede a la etapa anterior dentro del mismo grupo o a la pestaña anterior."""
        # Encontrar la etapa anterior del mismo grupo
        anterior_idx = None
        for idx in range(self.etapa_actual_idx - 1, -1, -1):
            if self.etapas[idx].get("grupo", "") == grupo:
                anterior_idx = idx
                break
        
        if anterior_idx is not None:
            # Hay una etapa anterior en este grupo, retroceder
            self.etapa_actual_idx = anterior_idx
            # Quitar de completadas si estaba
            if self.etapa_actual_idx in self.etapas_completadas:
                self.etapas_completadas.remove(self.etapa_actual_idx)
            self._mostrar_etapa_actual()
        else:
            # No hay más etapas anteriores en este grupo, retroceder a la pestaña anterior
            grupos_orden = ["SOLIDOS", "CHOCOLATE", "LIQUIDOS"]
            try:
                grupo_actual_pos = grupos_orden.index(grupo)
            except ValueError:
                grupo_actual_pos = -1
            
            # Buscar grupo anterior en el orden
            anterior_grupo = None
            anterior_grupo_idx = None
            for anterior_grupo_nombre in reversed(grupos_orden[:grupo_actual_pos]):
                # Buscar última etapa de ese grupo
                for idx in range(len(self.etapas) - 1, -1, -1):
                    if self.etapas[idx].get("grupo", "") == anterior_grupo_nombre:
                        anterior_grupo_idx = idx
                        anterior_grupo = anterior_grupo_nombre
                        break
                if anterior_grupo_idx is not None:
                    break
            
            if anterior_grupo_idx is not None:
                # Retroceder a la pestaña anterior
                self.etapa_actual_idx = anterior_grupo_idx
                # Quitar de completadas si estaba
                if self.etapa_actual_idx in self.etapas_completadas:
                    self.etapas_completadas.remove(self.etapa_actual_idx)
                self._mostrar_etapa_actual()
                
                # Cambiar a la pestaña del grupo anterior
                if anterior_grupo == "SOLIDOS" and self.tab_solidos:
                    self.produccion_notebook.select(self.tab_solidos)
                elif anterior_grupo == "CHOCOLATE" and self.tab_chocolate:
                    self.produccion_notebook.select(self.tab_chocolate)
                elif anterior_grupo == "LIQUIDOS" and self.tab_liquidos:
                    self.produccion_notebook.select(self.tab_liquidos)
    
    def _mostrar_etapa_actual(self):
        """Muestra la etapa actual en la tabla correspondiente."""
        if not self.etapas or self.etapa_actual_idx >= len(self.etapas):
            return
        
        etapa = self.etapas[self.etapa_actual_idx]
        grupo = etapa.get("grupo", "")
        
        # Stepper oculto - no actualizar
        
        # Obtener treeview del grupo
        tree = self.etapas_trees.get(grupo)
        if not tree:
            return
        
        # Limpiar tabla
        for item in tree.get_children():
            tree.delete(item)
        
        # Mostrar subpaso si el grupo se partió (ej: "Etapa 1/3")
        total_etapas_grupo = etapa.get("total_etapas_grupo", 1)
        etapa_num = etapa.get("etapa_num", 1)
        subpaso_label = self.etapa_subpaso_labels.get(grupo)
        if subpaso_label:
            if total_etapas_grupo > 1:
                # Mostrar solo número de etapa dentro del grupo
                subpaso_label.config(text=f"Etapa {etapa_num}/{total_etapas_grupo}")
            else:
                subpaso_label.config(text="")
        
        # Actualizar estado de los botones de navegación
        btn_siguiente = self.btn_siguiente_por_grupo.get(grupo) if hasattr(self, 'btn_siguiente_por_grupo') else None
        btn_atras = self.btn_atras_por_grupo.get(grupo) if hasattr(self, 'btn_atras_por_grupo') else None
        
        if btn_siguiente:
            # Verificar si hay más etapas en este grupo o siguiente grupo
            hay_siguiente_en_grupo = False
            for idx in range(self.etapa_actual_idx + 1, len(self.etapas)):
                if self.etapas[idx].get("grupo", "") == grupo:
                    hay_siguiente_en_grupo = True
                    break
            
            # Verificar si hay siguiente grupo
            grupos_orden = ["SOLIDOS", "CHOCOLATE", "LIQUIDOS"]
            try:
                grupo_actual_pos = grupos_orden.index(grupo)
            except ValueError:
                grupo_actual_pos = -1
            
            hay_siguiente_grupo = False
            for siguiente_grupo_nombre in grupos_orden[grupo_actual_pos + 1:]:
                for idx in range(len(self.etapas)):
                    if self.etapas[idx].get("grupo", "") == siguiente_grupo_nombre:
                        hay_siguiente_grupo = True
                        break
                if hay_siguiente_grupo:
                    break
            
            # Verificar si es la última etapa de Líquidos
            es_ultima_etapa_liquidos = False
            if grupo == "LIQUIDOS" and not hay_siguiente_en_grupo and not hay_siguiente_grupo:
                # Es la última etapa y estamos en Líquidos
                es_ultima_etapa_liquidos = True
            
            if hay_siguiente_en_grupo or hay_siguiente_grupo:
                btn_siguiente.config(state="normal", text="Siguiente →")
            elif es_ultima_etapa_liquidos:
                # Última etapa de Líquidos: mostrar "Final" (termina producción y descuenta stock)
                btn_siguiente.config(state="normal", text="Final")
                # Cambiar comando para que llame a _finalizar_y_cargar_lote en lugar de avanzar
                btn_siguiente.config(command=self._finalizar_y_cargar_lote)
            else:
                # No hay más etapas, verificar si todas están completadas
                todas_completadas = (len(self.etapas_completadas) == len(self.etapas))
                if todas_completadas:
                    btn_siguiente.config(state="disabled", text="Completado")
                else:
                    btn_siguiente.config(state="disabled", text="Siguiente →")
        
        if btn_atras:
            # Verificar si hay etapa anterior en este grupo o grupo anterior
            hay_anterior_en_grupo = False
            for idx in range(self.etapa_actual_idx - 1, -1, -1):
                if self.etapas[idx].get("grupo", "") == grupo:
                    hay_anterior_en_grupo = True
                    break
            
            # Verificar si hay grupo anterior
            grupos_orden = ["SOLIDOS", "CHOCOLATE", "LIQUIDOS"]
            try:
                grupo_actual_pos = grupos_orden.index(grupo)
            except ValueError:
                grupo_actual_pos = -1
            
            hay_anterior_grupo = False
            for anterior_grupo_nombre in reversed(grupos_orden[:grupo_actual_pos]):
                for idx in range(len(self.etapas)):
                    if self.etapas[idx].get("grupo", "") == anterior_grupo_nombre:
                        hay_anterior_grupo = True
                        break
                if hay_anterior_grupo:
                    break
            
            if hay_anterior_en_grupo or hay_anterior_grupo:
                btn_atras.config(state="normal")
            else:
                btn_atras.config(state="disabled")
        
        # Llenar tabla con items de la etapa
        for item_data in etapa["items"]:
            if item_data.get("es_chocolate"):
                # Item especial de chocolate
                codigo = item_data.get("producto_codigo", "CHOCO")
                nombre = f"Chocolate {self.chocolate_tipo_seleccionado or 'NEGRO'}"
                cantidad = item_data.get("cantidad_kg", 0)
                unidad = "kg"
                porcentaje = ""
            else:
                # Item normal
                producto_codigo = item_data.get("producto_codigo", "")
                porcentaje = float(item_data.get("porcentaje", 0))
                cantidad = self.mezcla_confirmada * (porcentaje / 100.0)
                
                nombre = get_producto_nombre(self.db_path, producto_codigo) or producto_codigo
                codigo = producto_codigo
                unidad = "kg"
                porcentaje = f"{porcentaje:.2f}"
            
            tree.insert("", "end", values=(
                codigo,
                nombre,
                f"{cantidad:.3f}",
                unidad,
                porcentaje
            ))
        
        # Cambiar a la pestaña del grupo
        if grupo == "SOLIDOS" and self.tab_solidos:
            self.produccion_notebook.select(self.tab_solidos)
        elif grupo == "CHOCOLATE" and self.tab_chocolate:
            self.produccion_notebook.select(self.tab_chocolate)
        elif grupo == "LIQUIDOS" and self.tab_liquidos:
            self.produccion_notebook.select(self.tab_liquidos)
        
        # Actualizar botón derecho dinámico
        self._actualizar_boton_derecho()
    
    def _actualizar_boton_derecho(self):
        """Actualiza el botón derecho dinámicamente según el paso."""
        # Obtener pestaña actual
        try:
            current_tab = self.produccion_notebook.select()
            current_tab_text = self.produccion_notebook.tab(current_tab, "text")
        except:
            current_tab_text = ""
        
        if current_tab_text in ["Sólidos", "Chocolate", "Líquidos"]:
            # En pestañas de etapas: siempre ocultar el botón de la barra superior
            # El usuario usa el botón "Siguiente" dentro de cada pestaña
            self.btn_accion_derecha.grid_remove()
            
            # Verificar si todas están completadas para mostrar botón de confirmación
            todas_completadas = (len(self.etapas_completadas) == len(self.etapas))
            if todas_completadas:
                self._mostrar_boton_confirmacion()
        elif self.paso_actual == 2:
            # En mezcla: botón confirmar mezcla
            self.btn_accion_derecha.config(
                text="Confirmar mezcla →",
                command=self._confirmar_mezcla,
                state="normal" if self.mezcla_entry.get().strip() else "disabled"
            )
        else:
            # Paso 0, 1 u otros: deshabilitado
            self.btn_accion_derecha.config(state="disabled")
    
    def _accion_derecha(self):
        """Ejecuta la acción del botón derecho según el paso actual."""
        # Obtener pestaña actual
        try:
            current_tab = self.produccion_notebook.select()
            current_tab_text = self.produccion_notebook.tab(current_tab, "text")
        except:
            current_tab_text = ""
        
        if current_tab_text in ["Sólidos", "Chocolate", "Líquidos"]:
            # En pestañas de etapas, el botón derecho no se usa (se usa "Siguiente")
            pass
        elif self.paso_actual == 2:
            self._confirmar_mezcla()
        elif self.paso_actual == 1:
            self._confirmar_receta()
    
    def _confirmar_etapa_actual(self):
        """Confirma que la etapa actual está lista y avanza a la siguiente."""
        if not self.etapas or self.etapa_actual_idx >= len(self.etapas):
            return
        
        # Marcar etapa como completada
        self.etapas_completadas.add(self.etapa_actual_idx)
        self.pasos_completados[self.etapa_actual_idx] = True
        
        # Registrar auditoría
        try:
            from bull_bar.infra.audit import log_audit
            log_audit(
                db_path=self.db_path,
                usuario=self.usuario_actual.get("username", "USUARIO"),
                accion="ETAPA_COMPLETADA",
                modulo="PRODUCCION",
                entidad_id=self.receta_seleccionada,
                entidad_tipo="RECETA",
                metadata=f"Etapa {self.etapa_actual_idx + 1}/{len(self.etapas)}: {self.etapas[self.etapa_actual_idx]['nombre']}"
            )
        except Exception:
            pass  # Si falla auditoría, continuar
        
        # Avanzar a siguiente etapa
        self.etapa_actual_idx += 1
        
        if self.etapa_actual_idx < len(self.etapas):
            # Mostrar siguiente etapa
            self._mostrar_etapa_actual()
        else:
            # Todas las etapas completadas: mostrar botón de confirmación
            self._mostrar_boton_confirmacion()
            messagebox.showinfo("Etapas completadas", "Todas las etapas están completadas. Puede finalizar la producción.")
    
    def _mostrar_boton_confirmacion(self):
        """Muestra el botón de confirmación cuando todas las etapas están completadas."""
        # Agregar el botón en todas las pestañas de etapas
        for grupo, frame in self.etapas_frames.items():
            if frame:
                # Verificar si ya existe el botón
                btn_id = f"btn_finalizar_{grupo}"
                if not hasattr(self, btn_id):
                    # Crear botón de confirmación
                    btn_finalizar = ttk.Button(
                        frame,
                        text="Finalizar producción",
                        command=self._finalizar_produccion,
                        state="normal"
                    )
                    # Agregar al final del frame (usando pack para que esté abajo)
                    btn_finalizar.pack(side="bottom", pady=20, fill="x", padx=10)
                    setattr(self, btn_id, btn_finalizar)
                else:
                    # Mostrar el botón si ya existe
                    btn = getattr(self, btn_id)
                    btn.pack(side="bottom", pady=20, fill="x", padx=10)
    
    def _atras(self):
        """Retrocede un paso en el wizard sin perder confirmaciones."""
        if self.paso_actual == 0:
            return  # No se puede retroceder desde el primer paso
        
        if self.paso_actual == 1:
            # Volver a paso 0 (selección de receta)
            self._mostrar_paso(0)
        elif self.paso_actual == 2:
            # Volver a paso 1 (confirmación de receta)
            self._mostrar_paso(1)
            self.confirmacion_label.config(text=f"✓ Receta '{self.receta_seleccionada}' seleccionada")
            self.confirmacion_frame.grid()
            self.btn_confirmar_receta.config(state="normal")
        elif self.paso_actual == 3:
            # Volver a paso anterior dentro de las etapas o a mezcla
            if self.etapa_actual_idx > 0:
                # Retroceder dentro de las etapas
                self.etapa_actual_idx -= 1
                # Quitar de completadas si estaba
                if self.etapa_actual_idx in self.etapas_completadas:
                    self.etapas_completadas.remove(self.etapa_actual_idx)
                self._mostrar_etapa_actual()
            else:
                # Volver a paso 2 (mezcla)
                self._mostrar_paso(2)
                # Mantener valor de mezcla si existe
                if self.mezcla_confirmada:
                    self.mezcla_entry.delete(0, "end")
                    self.mezcla_entry.insert(0, str(int(self.mezcla_confirmada)))
                    self._validar_mezcla_para_confirmar()
    
    def _finalizar_y_cargar_lote(self):
        """Finaliza la producción, descuenta stock y abre la pestaña de cargar lote."""
        if not self.receta_seleccionada or not self.mezcla_confirmada:
            return
        
        # Marcar la etapa actual como completada (si no estaba marcada)
        if self.etapa_actual_idx not in self.etapas_completadas:
            self.etapas_completadas.add(self.etapa_actual_idx)
            self.pasos_completados[self.etapa_actual_idx] = True
        
        # Verificar que todas las etapas estén completadas
        if len(self.etapas_completadas) < len(self.etapas):
            messagebox.showwarning("Etapas incompletas", "Debe completar todas las etapas antes de finalizar.")
            return
        
        # Obtener rol del usuario
        rol_usuario = self.usuario_actual.get("rol", "USUARIO")
        from bull_bar.infra.auth import RolUsuario
        
        # Preparar consumos desde todas las etapas
        consumos = []
        for etapa in self.etapas:
            for item_data in etapa["items"]:
                if item_data.get("es_chocolate"):
                    # Chocolate: usar código especial
                    producto_codigo = f"CHOCO-{self.chocolate_tipo_seleccionado or 'NEGRO'}"
                    cantidad_calc = item_data.get("cantidad_kg", 0)
                else:
                    producto_codigo = item_data.get("producto_codigo", "")
                    porcentaje = float(item_data.get("porcentaje", 0))
                    cantidad_calc = self.mezcla_confirmada * (porcentaje / 100.0)
                
                if not producto_codigo or cantidad_calc <= 0:
                    continue
                
                prod_obj = self.ctx["products"].get(producto_codigo)
                if not prod_obj:
                    from bull_bar.core.models import Producto
                    nombre_prod = get_producto_nombre(self.db_path, producto_codigo) or producto_codigo
                    prod_obj = Producto(id=str(uuid4()), codigo=producto_codigo, nombre=nombre_prod, unidad_medida="kg")
                    self.ctx["products"][producto_codigo] = prod_obj
                
                consumos.append(DocumentoItem(
                    producto_id=prod_obj.id,
                    descripcion=prod_obj.nombre,
                    cantidad=cantidad_calc
                ))
        
        # Preparar producto final (usar código de receta como código de producto)
        producto_final_codigo = f"PROD-{self.receta_seleccionada}"
        prod_final_obj = self.ctx["products"].get(producto_final_codigo)
        if not prod_final_obj:
            from bull_bar.core.models import Producto
            prod_final_obj = Producto(
                id=str(uuid4()),
                codigo=producto_final_codigo,
                nombre=self.receta_nombre or self.receta_seleccionada,
                unidad_medida="u"
            )
            self.ctx["products"][producto_final_codigo] = prod_final_obj
        
        producto_final = DocumentoItem(
            producto_id=prod_final_obj.id,
            descripcion=prod_final_obj.nombre,
            cantidad=1.0  # Se actualizará con la cantidad real cuando se guarde el lote
        )
        
        # Descontar stock inmediatamente (solo ADMIN por ahora, pero el usuario dijo "por AHORA es manual")
        # Para usuarios regulares, también descontamos si presionan "Final"
        try:
            numero = f"P-{self.receta_seleccionada}-{int(self.mezcla_confirmada)}-{uuid4().hex[:4]}"
            doc, movs = self.ctx["production_service"].registrar_remito_produccion_rapido(
                numero=numero,
                deposito_id=self.ctx["depo"].id,
                consumos=consumos,
                producto_final=producto_final,
                usuario=self.usuario_actual.get("username", "ADMIN")
            )
            
            # Guardar información de la producción para la pestaña de lote
            self.produccion_doc_id = doc.id
            self.produccion_numero = numero
            
            # Registrar auditoría
            try:
                from bull_bar.infra.audit import log_audit
                log_audit(
                    db_path=self.db_path,
                    usuario=self.usuario_actual.get("username", "USUARIO"),
                    accion="PRODUCCION_FINALIZADA",
                    modulo="PRODUCCION",
                    entidad_id=self.receta_seleccionada,
                    entidad_tipo="RECETA",
                    metadata=f"Producción {numero} finalizada. Stock descontado. Abriendo carga de lote."
                )
            except Exception:
                pass
            
            # Crear o mostrar pestaña de cargar lote
            self._crear_tab_cargar_lote()
            self.produccion_notebook.select(self.tab_cargar_lote)
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al finalizar producción: {str(e)}")
    
    def _finalizar_produccion(self):
        """Finaliza la producción según el rol del usuario (método antiguo, mantenido para compatibilidad)."""
        # Redirigir al nuevo método
        self._finalizar_y_cargar_lote()
    
    def _cancelar(self):
        """Cancela todo y vuelve al paso 0."""
        # Limpiar estado
        self.receta_seleccionada = None
        self.receta_nombre = None
        self.mezcla_confirmada = None
        self.etapas = []
        self.etapa_actual_idx = 0
        self.etapas_completadas = set()
        self.chocolate_info = None
        self.chocolate_tipo_seleccionado = None
        self.produccion_doc_id = None
        self.produccion_numero = None
        
        # Limpiar UI
        self._actualizar_header_detalles()
        
        self.mezcla_entry.delete(0, "end")
        # Limpiar tablas de etapas
        for tree in self.etapas_trees.values():
            for item in tree.get_children():
                tree.delete(item)
        
        # Ocultar confirmación
        self.confirmacion_frame.grid_remove()
        self.btn_confirmar_receta.config(state="disabled")
        
        # Deshabilitar controles
        for btn, _ in self.mezcla_buttons:
            btn.config(state="disabled")
        self.mezcla_entry.config(state="disabled")
        
        # Stepper ya está oculto (no se muestra)
        # No es necesario hacer nada aquí
        
        # Eliminar pestañas de etapas (excepto "Elegir Receta")
        if self.tab_solidos:
            try:
                self.produccion_notebook.forget(self.tab_solidos)
            except:
                pass
            self.tab_solidos = None
        if self.tab_chocolate:
            try:
                self.produccion_notebook.forget(self.tab_chocolate)
            except:
                pass
            self.tab_chocolate = None
        if self.tab_liquidos:
            try:
                self.produccion_notebook.forget(self.tab_liquidos)
            except:
                pass
            self.tab_liquidos = None
        if self.tab_cargar_lote:
            try:
                self.produccion_notebook.forget(self.tab_cargar_lote)
            except:
                pass
            self.tab_cargar_lote = None
        # Limpiar botones de confirmación si existen
        for grupo in ["SOLIDOS", "CHOCOLATE", "LIQUIDOS"]:
            btn_id = f"btn_finalizar_{grupo}"
            if hasattr(self, btn_id):
                btn = getattr(self, btn_id)
                try:
                    btn.pack_forget()
                except:
                    pass
                delattr(self, btn_id)
        
        self.etapas_frames = {}
        self.etapas_trees = {}
        self.etapa_subpaso_labels = {}
        
        # Resetear botones de navegación
        self.btn_atras.config(state="disabled")
        self.btn_accion_derecha.config(state="disabled", text="")
        
        # Volver a paso 0
        self._mostrar_paso(0)
    
    def _prueba_stock_100kg(self):
        """Función de prueba: ajusta el stock de todos los productos a 100kg."""
        respuesta = messagebox.askyesno(
            "Prueba de Stock",
            "¿Está seguro de que desea ajustar el stock de TODOS los productos a 100kg?\n\n"
            "Esta acción es solo para pruebas y ajustará el stock de todos los productos en el depósito.",
            icon="warning"
        )
        if not respuesta:
            return
        
        try:
            from bull_bar.stock.adjustment import StockAdjustmentService
            adjust_svc = StockAdjustmentService(self.ctx["ledger"], db_path=self.db_path)
            deposito_id = self.ctx["depo"].id
            usuario = self.usuario_actual.get("username", "USUARIO")
            
            productos_ajustados = 0
            productos_con_error = []
            
            # Iterar sobre todos los productos en el contexto
            for codigo, producto in self.ctx.get("products", {}).items():
                try:
                    # Obtener stock actual
                    stock_actual = self.ctx["ledger"].stock_confirmado(deposito_id, producto.id)
                    
                    # Calcular ajuste necesario para llegar a 100kg
                    ajuste_necesario = 100.0 - stock_actual
                    
                    # Solo ajustar si es necesario (diferencia > 0.01 para evitar ajustes mínimos)
                    if abs(ajuste_necesario) > 0.01:
                        adjust_svc.apply_adjustment(
                            deposito_id=deposito_id,
                            producto_id=producto.id,
                            cantidad=ajuste_necesario,
                            motivo=f"Prueba de stock - Ajuste a 100kg",
                            usuario=usuario
                        )
                        productos_ajustados += 1
                except Exception as e:
                    productos_con_error.append(f"{codigo}: {str(e)}")
            
            mensaje = f"Prueba de stock completada.\n\n"
            mensaje += f"Productos ajustados: {productos_ajustados}\n"
            if productos_con_error:
                mensaje += f"Errores: {len(productos_con_error)}\n"
                mensaje += "\n".join(productos_con_error[:5])  # Mostrar solo los primeros 5 errores
                if len(productos_con_error) > 5:
                    mensaje += f"\n... y {len(productos_con_error) - 5} más"
            
            messagebox.showinfo("Prueba de Stock", mensaje)
            
            # Registrar auditoría
            try:
                from bull_bar.infra.audit import log_audit
                log_audit(
                    db_path=self.db_path,
                    usuario=usuario,
                    accion="PRUEBA_STOCK_100KG",
                    modulo="PRODUCCION",
                    entidad_id="TODOS",
                    entidad_tipo="PRODUCTOS",
                    metadata=f"Prueba de stock: {productos_ajustados} productos ajustados a 100kg"
                )
            except Exception:
                pass
                
        except Exception as e:
            messagebox.showerror("Error", f"Error en prueba de stock: {str(e)}")
