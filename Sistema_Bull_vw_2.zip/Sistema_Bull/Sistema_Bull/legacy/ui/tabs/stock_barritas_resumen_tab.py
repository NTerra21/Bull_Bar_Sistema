from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from datetime import date, datetime

from bull_bar.infra.sqlite_barritas import list_lotes
from bull_bar.ui.utils.ui_helpers import parse_ymd, get_vencimiento_alert_color, configure_vencimiento_tags


class StockBarritasResumenTab(ttk.Frame):
    """Resumen por SKU (usa lotes activos: disponibles > 0)."""

    def __init__(self, notebook, ctx):
        super().__init__(notebook)
        self.ctx = ctx
        self._open_lotes_cb = None

        self._sort_col = None
        self._sort_desc = False

        self._build_ui()
        self.refresh()

    def set_open_lotes_callback(self, cb):
        """cb(sku: str) -> None"""
        self._open_lotes_cb = cb

    def _build_ui(self):
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=8)

        ttk.Label(top, text="Buscar SKU:").pack(side="left")
        self.search = ttk.Entry(top)
        self.search.pack(side="left", fill="x", expand=True, padx=(6, 10))
        self.search.bind("<KeyRelease>", lambda e: self.refresh())

        ttk.Button(top, text="Refrescar", command=self.refresh).pack(side="right")

        cols = ("sku", "nombre", "total", "vendidas", "disponibles", "prox_venc", "alerta")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")

        self._set_heading("sku", "SKU")
        self._set_heading("nombre", "Producto")
        self._set_heading("total", "Total")
        self._set_heading("vendidas", "Vendidas")
        self._set_heading("disponibles", "Disponibles")
        self._set_heading("prox_venc", "Próx. venc.")
        self._set_heading("alerta", "Alerta")

        self.tree.column("sku", width=160, stretch=False)
        self.tree.column("nombre", width=360, stretch=True)
        self.tree.column("total", width=90, anchor="e", stretch=False)
        self.tree.column("vendidas", width=90, anchor="e", stretch=False)
        self.tree.column("disponibles", width=110, anchor="e", stretch=False)
        self.tree.column("prox_venc", width=120, stretch=False)
        self.tree.column("alerta", width=80, stretch=False)

        self.tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tree.bind("<Double-1>", lambda e: self._open_lotes())

        # Configurar tags de colores usando helper
        configure_vencimiento_tags(self.tree)

        bottom = ttk.Frame(self)
        bottom.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Label(bottom, text="Doble click: ver lotes del SKU.", foreground="#666").pack(side="left")
        ttk.Button(bottom, text="Ver lotes del SKU", command=self._open_lotes).pack(side="right")

    def _set_heading(self, col: str, text: str):
        self.tree.heading(col, text=text, command=lambda c=col: self._toggle_sort(c))

    def _toggle_sort(self, col: str):
        if self._sort_col == col:
            self._sort_desc = not self._sort_desc
        else:
            self._sort_col = col
            self._sort_desc = False
        self.refresh()

    def refresh(self):
        q = (self.search.get() or "").strip().upper()
        lotes = list_lotes(self.ctx["db_path"], q=q)

        grouped = {}
        for r in lotes:
            sku = (r.get("sku") or "").strip()
            if not sku:
                continue

            total = float(r.get("cantidad_total") or 0)
            vend = float(r.get("cantidad_vendida") or 0)
            disp = float(r.get("cantidad_disponible") or 0)

            # Resumen SOLO activos
            if disp <= 0.00001:
                continue

            name = r.get("nombre") or ""
            venc = parse_ymd(r.get("fecha_vencimiento") or "")

            g = grouped.setdefault(
                sku,
                {"sku": sku, "nombre": name, "total": 0.0, "vend": 0.0, "disp": 0.0, "min_venc": None},
            )
            g["total"] += total
            g["vend"] += vend
            g["disp"] += disp

            if venc and (g["min_venc"] is None or venc < g["min_venc"]):
                g["min_venc"] = venc
            if not g["nombre"] and name:
                g["nombre"] = name

        rows = list(grouped.values())

        if self._sort_col:
            col = self._sort_col

            def k(r):
                if col == "total":
                    return float(r.get("total") or 0)
                if col == "vendidas":
                    return float(r.get("vend") or 0)
                if col == "disponibles":
                    return float(r.get("disp") or 0)
                if col == "prox_venc":
                    return r.get("min_venc") or date.max
                if col == "sku":
                    return str(r.get("sku") or "").upper()
                return str(r.get("nombre") or "").upper()

            rows = sorted(rows, key=k, reverse=self._sort_desc)

        for iid in self.tree.get_children():
            self.tree.delete(iid)

        for r in rows:
            min_v = r.get("min_venc")
            prox = min_v.isoformat() if min_v else ""
            alerta, tag = self._alert_for(min_v)
            self.tree.insert(
                "",
                "end",
                values=(
                    r["sku"],
                    r.get("nombre") or "",
                    f"{r['total']:.0f}",
                    f"{r['vend']:.0f}",
                    f"{r['disp']:.0f}",
                    prox,
                    alerta,
                ),
                tags=(tag,),
            )

        self._render_sort_arrows()

    def _alert_for(self, venc_date):
        """Usa helper para obtener alerta de vencimiento."""
        return get_vencimiento_alert_color(venc_date)

    def _render_sort_arrows(self):
        base = {
            "sku": "SKU",
            "nombre": "Producto",
            "total": "Total",
            "vendidas": "Vendidas",
            "disponibles": "Disponibles",
            "prox_venc": "Próx. venc.",
            "alerta": "Alerta",
        }
        for col, text in base.items():
            arrow = ""
            if self._sort_col == col:
                arrow = " ▼" if self._sort_desc else " ▲"
            self.tree.heading(col, text=text + arrow)

    def _open_lotes(self):
        sel = self.tree.selection()
        if not sel:
            return
        sku = self.tree.item(sel[0], "values")[0]
        if sku and self._open_lotes_cb:
            self._open_lotes_cb(sku)


# Compat por si algún lado importa el nombre viejo
StockBarritasTab = StockBarritasResumenTab
