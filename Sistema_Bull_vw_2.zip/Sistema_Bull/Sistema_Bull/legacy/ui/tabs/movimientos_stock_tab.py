"""
Tab para mostrar movimientos de compras y ventas en Ver Stock.
"""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from uuid import uuid4

from bull_bar.core.models import DocumentoItem
from bull_bar.ui.panels.historial_panel import create_historial_button


class MovimientosStockTab(ttk.Frame):
    """Tab para mostrar y gestionar movimientos de compras y ventas."""
    
    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        self._build_ui()
    
    def _build_ui(self):
        # Barra superior con botones
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=8)
        
        ttk.Label(top, text="Movimientos de Stock", font=("Helvetica", 12, "bold")).pack(side="left")
        
        btn_frame = ttk.Frame(top)
        btn_frame.pack(side="right")
        
        ttk.Button(btn_frame, text="Nueva Compra", command=self._nueva_compra).pack(side="left", padx=4)
        ttk.Button(btn_frame, text="Nueva Venta", command=self._nueva_venta).pack(side="left", padx=4)
        create_historial_button(btn_frame, self.ctx, "Ver Historial").pack(side="left", padx=4)
        
        # Notebook para separar compras y ventas
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        
        # Tab de compras
        compras_frame = ttk.Frame(nb)
        nb.add(compras_frame, text="Compras / Entradas")
        self._build_compras_tab(compras_frame)
        
        # Tab de ventas
        ventas_frame = ttk.Frame(nb)
        nb.add(ventas_frame, text="Ventas")
        self._build_ventas_tab(ventas_frame)
    
    def _build_compras_tab(self, parent):
        """Construye la pestaña de compras."""
        form = ttk.LabelFrame(parent, text="Registrar Compra / Entrada", padding=10)
        form.pack(fill="x", padx=8, pady=8)
        
        form.columnconfigure(1, weight=1)
        
        ttk.Label(form, text="Código producto:").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=5)
        self.compra_codigo = ttk.Entry(form)
        self.compra_codigo.grid(row=0, column=1, sticky="ew", pady=5)
        
        ttk.Label(form, text="Descripción:").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=5)
        self.compra_desc = ttk.Entry(form)
        self.compra_desc.grid(row=1, column=1, sticky="ew", pady=5)
        
        ttk.Label(form, text="Cantidad:").grid(row=2, column=0, sticky="w", padx=(0, 10), pady=5)
        self.compra_cant = ttk.Entry(form)
        self.compra_cant.grid(row=2, column=1, sticky="ew", pady=5)
        
        ttk.Label(form, text="Precio unitario (opcional):").grid(row=3, column=0, sticky="w", padx=(0, 10), pady=5)
        self.compra_precio = ttk.Entry(form)
        self.compra_precio.grid(row=3, column=1, sticky="ew", pady=5)
        
        ttk.Label(form, text="Ruta archivo comprobante (opcional):").grid(row=4, column=0, sticky="w", padx=(0, 10), pady=5)
        file_frame = ttk.Frame(form)
        file_frame.grid(row=4, column=1, sticky="ew", pady=5)
        file_frame.columnconfigure(0, weight=1)
        self.compra_archivo = ttk.Entry(file_frame)
        self.compra_archivo.pack(side="left", fill="x", expand=True)
        ttk.Button(file_frame, text="Buscar...", command=self._buscar_archivo_compra).pack(side="left", padx=(5, 0))
        
        btn_frame = ttk.Frame(form)
        btn_frame.grid(row=5, column=0, columnspan=2, pady=(10, 0))
        ttk.Button(btn_frame, text="Registrar Compra", command=self._registrar_compra).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Limpiar", command=self._limpiar_compra).pack(side="left", padx=5)
    
    def _build_ventas_tab(self, parent):
        """Construye la pestaña de ventas."""
        form = ttk.LabelFrame(parent, text="Registrar Venta", padding=10)
        form.pack(fill="x", padx=8, pady=8)
        
        form.columnconfigure(1, weight=1)
        
        ttk.Label(form, text="Código producto:").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=5)
        self.venta_codigo = ttk.Entry(form)
        self.venta_codigo.grid(row=0, column=1, sticky="ew", pady=5)
        
        ttk.Label(form, text="Cantidad:").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=5)
        self.venta_cant = ttk.Entry(form)
        self.venta_cant.grid(row=1, column=1, sticky="ew", pady=5)
        
        btn_frame = ttk.Frame(form)
        btn_frame.grid(row=2, column=0, columnspan=2, pady=(10, 0))
        ttk.Button(btn_frame, text="Registrar Venta", command=self._registrar_venta).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Limpiar", command=self._limpiar_venta).pack(side="left", padx=5)
    
    def _buscar_archivo_compra(self):
        """Abre diálogo para buscar archivo."""
        from tkinter import filedialog
        archivo = filedialog.askopenfilename(
            title="Seleccionar comprobante",
            filetypes=[("Todos los archivos", "*.*"), ("PDF", "*.pdf"), ("Imágenes", "*.png *.jpg *.jpeg")]
        )
        if archivo:
            self.compra_archivo.delete(0, "end")
            self.compra_archivo.insert(0, archivo)
    
    def _registrar_compra(self):
        """Registra una compra."""
        codigo = self.compra_codigo.get().strip()
        descripcion = self.compra_desc.get().strip() or codigo
        
        try:
            cantidad = float(self.compra_cant.get())
        except Exception:
            messagebox.showerror("Error", "Cantidad inválida")
            return
        
        precio_txt = self.compra_precio.get().strip()
        precio = None
        if precio_txt:
            try:
                precio = float(precio_txt)
            except Exception:
                messagebox.showerror("Error", "Precio inválido")
                return
        
        ruta_archivo = self.compra_archivo.get().strip()
        
        prod = self.ctx["products"].get(codigo)
        if not prod:
            from bull_bar.core.models import Producto
            prod = Producto(id=str(uuid4()), codigo=codigo, nombre=descripcion, unidad_medida="u")
            self.ctx["products"][codigo] = prod
        
        item = DocumentoItem(producto_id=prod.id, descripcion=descripcion, cantidad=cantidad, precio_unitario=precio)
        
        try:
            numero = f"C-{uuid4().hex[:6]}"
            doc, movs = self.ctx["purchase_service"].registrar_compra_recibida(
                numero=numero,
                ClienteProveedor_id=self.ctx["prov"].id,
                deposito_id=self.ctx["depo"].id,
                items=[item],
                usuario="Usuario"  # TODO: obtener usuario real
            )
            
            # Registrar lote de compra con precio y archivo
            if precio is not None or ruta_archivo:
                from bull_bar.infra.sqlite_compras import registrar_lote_compra
                registrar_lote_compra(
                    self.ctx["db_path"],
                    prod.id,
                    doc.id,
                    numero,
                    cantidad,
                    fecha_compra=doc.fecha_emision.isoformat(),
                    precio_unitario=precio,
                    deposito=self.ctx["depo"].nombre,
                    comprobante=numero,
                    ruta_archivo=ruta_archivo if ruta_archivo else None,
                )
            
            messagebox.showinfo("OK", f"Compra registrada: {numero}")
            self._limpiar_compra()
        except Exception as e:
            messagebox.showerror("Error registro", str(e))
    
    def _registrar_venta(self):
        """Registra una venta."""
        codigo = self.venta_codigo.get().strip()
        try:
            cant = float(self.venta_cant.get())
        except Exception:
            messagebox.showerror("Error", "Cantidad inválida")
            return
        
        prod = self.ctx["products"].get(codigo)
        if not prod:
            messagebox.showerror("Error", "Producto no encontrado en catálogo")
            return
        
        numero = f"V-{uuid4().hex[:6]}"
        doc_venta, movs, faltantes = self.ctx["sale_service"].intentar_venta(
            numero=numero,
            ClienteProveedor_id=self.ctx["cli"].id,
            deposito_id=self.ctx["depo"].id,
            items=[DocumentoItem(producto_id=prod.id, descripcion=prod.nombre, cantidad=cant)],
            usuario="Usuario"  # TODO: obtener usuario real
        )
        
        if faltantes:
            messagebox.showwarning("Stock insuficiente", f"Faltantes: {faltantes}")
        else:
            messagebox.showinfo("Venta OK", f"Venta {numero} realizada")
            self._limpiar_venta()
    
    def _limpiar_compra(self):
        self.compra_codigo.delete(0, "end")
        self.compra_desc.delete(0, "end")
        self.compra_cant.delete(0, "end")
        self.compra_precio.delete(0, "end")
        self.compra_archivo.delete(0, "end")
    
    def _limpiar_venta(self):
        self.venta_codigo.delete(0, "end")
        self.venta_cant.delete(0, "end")
    
    def _nueva_compra(self):
        """Abre diálogo para nueva compra."""
        # Cambiar a tab de compras y enfocar
        nb = self.winfo_children()[0]  # Obtener el notebook
        nb.select(0)  # Seleccionar primera tab (compras)
        self.compra_codigo.focus()
    
    def _nueva_venta(self):
        """Abre diálogo para nueva venta."""
        # Cambiar a tab de ventas y enfocar
        nb = self.winfo_children()[0]  # Obtener el notebook
        nb.select(1)  # Seleccionar segunda tab (ventas)
        self.venta_codigo.focus()

