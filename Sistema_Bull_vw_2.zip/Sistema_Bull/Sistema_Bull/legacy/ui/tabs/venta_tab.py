import tkinter as tk
from tkinter import ttk, messagebox
from bull_bar.core.models import DocumentoItem
from uuid import uuid4
from datetime import datetime

class VentaTab:
    def __init__(self, notebook, ctx):
        self.ctx = ctx
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="Venta")

        ttk.Label(frame, text="Producto (codigo)").grid(row=0, column=0, sticky="w")
        self.codigo = ttk.Entry(frame); self.codigo.grid(row=0, column=1, sticky="ew")
        ttk.Label(frame, text="Cantidad").grid(row=1, column=0, sticky="w")
        self.cantidad = ttk.Entry(frame); self.cantidad.grid(row=1, column=1, sticky="ew")

        sell_btn = ttk.Button(frame, text="Intentar vender", command=self.intentar)
        sell_btn.grid(row=2, column=0, columnspan=2, pady=8)
        frame.columnconfigure(1, weight=1)

    def intentar(self):
        codigo = self.codigo.get().strip()
        try:
            cant = float(self.cantidad.get())
        except Exception:
            messagebox.showerror("Error", "Cantidad inválida")
            return
        prod = self.ctx["products"].get(codigo)
        if not prod:
            messagebox.showerror("Error", "Producto no encontrado en catálogo")
            return

        numero = f"V-{uuid4().hex[:6]}"
        doc_venta, movs, faltantes = self.ctx["sale_service"].intentar_venta(
            numero=numero,
            ClienteProveedor_id=self.ctx["cli"].id,
            deposito_id=self.ctx["depo"].id,
            items=[DocumentoItem(producto_id=prod.id, descripcion=prod.nombre, cantidad=cant)],
        )
        if faltantes:
            # diálogo con opciones; crear orden pendiente persistente en ctx
            dlg = tk.Toplevel()
            dlg.title("Faltante de stock")
            dlg.grab_set()
            ttk.Label(dlg, text=f"Faltantes: {faltantes}").pack(padx=8, pady=6)

            def crear_pendiente():
                order = {
                    "id": uuid4().hex,
                    "numero": numero,
                    "producto_codigo": codigo,
                    "cantidad_solicitada": cant,
                    "cliente_id": self.ctx["cli"].id,
                    "deposito_id": self.ctx["depo"].id,
                    "estado": "PENDIENTE",
                    "faltantes": faltantes,
                    "created_at": datetime.now().isoformat(),
                }
                self.ctx.setdefault("pending_orders", []).append(order)
                messagebox.showinfo("Pendiente", f"Orden PENDIENTE creada: {order['id']}")
                dlg.destroy()

            def ajustar_y_reintentar():
                try:
                    disponible = getattr(self.ctx["ledger"], "stock_confirmado")(self.ctx["depo"].id, prod.id)
                except Exception:
                    disponible = 0
                if disponible <= 0:
                    messagebox.showwarning("No hay stock", "No hay cantidad disponible para ajustar")
                    dlg.destroy(); return
                # reintentar con disponible
                self.ctx["sale_service"].intentar_venta(
                    numero=f"{numero}-AJ",
                    ClienteProveedor_id=self.ctx["cli"].id,
                    deposito_id=self.ctx["depo"].id,
                    items=[DocumentoItem(producto_id=prod.id, descripcion=prod.nombre, cantidad=disponible)],
                )
                messagebox.showinfo("Reintento", f"Venta realizada por {disponible}")
                dlg.destroy()

            ttk.Button(dlg, text="Crear Orden PENDIENTE", command=crear_pendiente).pack(fill="x", padx=8, pady=4)
            ttk.Button(dlg, text="Ajustar a disponible y reintentar", command=ajustar_y_reintentar).pack(fill="x", padx=8, pady=4)
            ttk.Button(dlg, text="Cancelar", command=dlg.destroy).pack(fill="x", padx=8, pady=4)
        else:
            messagebox.showinfo("Venta OK", f"Venta {numero} realizada")
