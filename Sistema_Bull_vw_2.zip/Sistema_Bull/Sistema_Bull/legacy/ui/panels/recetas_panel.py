import re
import tkinter as tk
from tkinter import ttk, messagebox

from bull_bar.infra.sqlite_recetas import (
    list_products,
    list_receta_versions,
    get_receta_items,
    bump_receta_version,
    set_receta_active_version,
    create_new_version_from_items,
    replace_receta_items,
    create_receta_named,
    update_product_detail,
    get_receta_chocolate_info,
    update_receta_chocolate_info,
)
from bull_bar.core.enums import (
    GrupoPreparacion,
    ORDEN_GRUPO_SOLIDOS,
    ORDEN_GRUPO_CHOCOLATE,
    ORDEN_GRUPO_LIQUIDOS,
    ORDEN_GRUPO_OTROS,
)

from bull_bar.ui.utils.tree_sort import TreeSortController
from bull_bar.ui.utils.delayed_deselect import DelayedDeselect


def _slug_code(nombre: str) -> str:
    s = (nombre or "").upper().strip()
    s = re.sub(r"[^A-Z0-9]+", "-", s).strip("-")
    if not s:
        s = "RECETA"
    return ("R-" + s)[:24]


class RecetasPanel(ttk.Frame):
    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        self.root = self.winfo_toplevel()
        self.usuario = ctx.get("usuario_actual", {})

        self._prod_cache = {}
        self._load_products_cache()

        self.subnb = ttk.Notebook(self)
        self.subnb.pack(fill="both", expand=True, padx=6, pady=6)

        self.tab_active = ttk.Frame(self.subnb)
        self.subnb.add(self.tab_active, text="Recetas Activas")
        
        # Tab inactivas solo para admin/gerente
        from bull_bar.infra.auth import tiene_permiso, RolUsuario
        if tiene_permiso(self.usuario, "ver", "recetas_inactivas") or self.usuario.get("rol") in [RolUsuario.ADMIN.value, RolUsuario.GERENTE.value]:
            self.tab_inactive = ttk.Frame(self.subnb)
            self.subnb.add(self.tab_inactive, text="Recetas Inactivas")
        else:
            self.tab_inactive = None
        
        # Tab crear solo si tiene permiso
        if tiene_permiso(self.usuario, "crear", "recetas"):
            self.tab_new = ttk.Frame(self.subnb)
            self.subnb.add(self.tab_new, text="Crear Receta Nueva")
        else:
            self.tab_new = None

        self.ui_active = self._build_panel(self.tab_active, mode="active")
        if self.tab_inactive:
            self.ui_inactive = self._build_panel(self.tab_inactive, mode="inactive")
        else:
            self.ui_inactive = None
        if self.tab_new:
            self._build_new_tab(self.tab_new)

        # tabs de edición abiertos: (codigo, version) -> frame
        self._edit_tabs = {}

        self._refresh_all()

    # ------------------------------------------------------------
    # UI base
    # ------------------------------------------------------------
    def _build_panel(self, parent, mode: str):
        parent.columnconfigure(1, weight=1)
        parent.rowconfigure(0, weight=1)

        left = ttk.Frame(parent)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 10))

        right = ttk.Frame(parent)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(4, weight=1)

        ttk.Label(left, text="Recetas").pack(anchor="w")
        lb = tk.Listbox(left, height=20)
        lb.pack(fill="y", expand=True)
        lb.bind("<<ListboxSelect>>", lambda e: self._show_detalle(mode))

        left_btns = ttk.Frame(left)
        left_btns.pack(fill="x", pady=(8, 0))

        btn_refresh = ttk.Button(left_btns, text="Refrescar", command=self._refresh_all)
        btn_refresh.pack(fill="x")

        from bull_bar.infra.auth import tiene_permiso
        
        if mode == "active":
            if tiene_permiso(self.usuario, "editar", "recetas"):
                btn_main = ttk.Button(left_btns, text="Editar", command=self._editar_receta_activa)
                btn_main.pack(fill="x", pady=(6, 0))
            else:
                btn_main = None  # Usuario solo puede ver
        else:
            if tiene_permiso(self.usuario, "editar", "recetas"):
                btn_main = ttk.Button(left_btns, text="Reactivar", command=self._reactivar_receta_inactiva)
                btn_main.pack(fill="x", pady=(6, 0))
            else:
                btn_main = None

        # Header info
        lbl_title = ttk.Label(right, text="Seleccione una receta…", font=("Segoe UI", 11, "bold"))
        lbl_title.grid(row=0, column=0, sticky="w", pady=(0, 2))

        lbl_meta = ttk.Label(right, text="", foreground="#666")
        lbl_meta.grid(row=1, column=0, sticky="w", pady=(0, 4))

        lbl_info = ttk.Label(right, text="", foreground="#666")
        lbl_info.grid(row=2, column=0, sticky="w", pady=(0, 8))

        actions = ttk.Frame(right)
        actions.grid(row=3, column=0, sticky="we", pady=(0, 6))
        actions.columnconfigure(0, weight=1)

        btn_ver_prod = ttk.Button(actions, text="Ver producto", command=lambda: self._open_product_selected(mode))
        btn_ver_prod.pack(side="right")

        cols = ("codigo", "nombre", "porcentaje", "stock_conf", "stock_pend")
        tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")

        tree.heading("codigo", text="Código")
        tree.column("codigo", width=0, minwidth=0, stretch=False)

        tree.column("nombre", width=520, stretch=True)
        tree.column("porcentaje", width=90, anchor="e", stretch=False)
        tree.column("stock_conf", width=90, anchor="e", stretch=False)
        tree.column("stock_pend", width=90, anchor="e", stretch=False)

        tree.grid(row=4, column=0, sticky="nsew")

        yscroll = ttk.Scrollbar(right, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=yscroll.set)
        yscroll.grid(row=4, column=1, sticky="ns")

        sorter = TreeSortController(
            tree=tree,
            base_headings={
                "nombre": "Nombre",
                "porcentaje": "% uso",
                "stock_conf": "Stock",
                "stock_pend": "Pendiente",
            },
            numeric_cols={"porcentaje", "stock_conf", "stock_pend"},
        )
        sorter.install()

        deselect = DelayedDeselect(
            root=self.root,
            tree=tree,
            is_active=lambda m=mode: self._is_panel_active(m),
            clear_selection=lambda t=tree: t.selection_remove(t.selection()),
            exempt_widgets=[btn_ver_prod, btn_refresh, btn_main],
            delay_click_ms=80,
            delay_focusout_ms=250,
        )

        tree.bind("<Return>", lambda e: self._open_product_selected(mode))
        tree.bind("<Double-1>", lambda e: self._on_tree_double_click(e, mode, deselect))

        return {
            "lb": lb,
            "map": [],
            "lbl_title": lbl_title,
            "lbl_meta": lbl_meta,
            "lbl_info": lbl_info,
            "tree": tree,
            "sorter": sorter,
            "btn_main": btn_main,
        }

    def _build_new_tab(self, parent):
        parent.columnconfigure(0, weight=1)

        box = ttk.Frame(parent, padding=10)
        box.grid(row=0, column=0, sticky="nwe")
        box.columnconfigure(1, weight=1)

        ttk.Label(box, text="Crear Receta Nueva", font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10)
        )

        ttk.Label(box, text="Nombre:").grid(row=1, column=0, sticky="e", padx=(0, 8), pady=4)
        self.new_name = ttk.Entry(box)
        self.new_name.grid(row=1, column=1, sticky="we", pady=4)
        self.new_name.bind("<KeyRelease>", lambda e: self._update_preview_code())

        ttk.Label(box, text="Código generado:").grid(row=2, column=0, sticky="e", padx=(0, 8), pady=4)
        self.new_code_preview = ttk.Label(box, text="R-…", foreground="#666")
        self.new_code_preview.grid(row=2, column=1, sticky="w", pady=4)

        from bull_bar.infra.auth import tiene_permiso
        
        if tiene_permiso(self.usuario, "crear", "recetas"):
            ttk.Button(box, text="Crear y editar", command=self._crear_y_editar).grid(
                row=3, column=0, columnspan=2, sticky="e", pady=(10, 0)
            )
        else:
            ttk.Label(box, text="No tiene permisos para crear recetas", foreground="red").grid(
                row=3, column=0, columnspan=2, sticky="w", pady=(10, 0)
            )

        self._update_preview_code()

    def _update_preview_code(self):
        code = _slug_code(self.new_name.get())
        self.new_code_preview.config(text=code)

    # ------------------------------------------------------------
    # Active checks
    # ------------------------------------------------------------
    def _is_panel_active(self, mode: str) -> bool:
        try:
            current_sub = self.subnb.select()
        except Exception:
            return False
        return current_sub == str(self.tab_active) if mode == "active" else current_sub == str(self.tab_inactive)

    # ------------------------------------------------------------
    # Data
    # ------------------------------------------------------------
    def _load_products_cache(self):
        self._prod_cache.clear()
        for p in list_products(self.ctx["db_path"]) or []:
            codigo = (p.get("codigo") or "").strip()
            self._prod_cache[codigo] = {
                "marca": (p.get("marca") or "").strip(),
                "nombre": (p.get("nombre") or "").strip(),
                "uuid": p.get("uuid") or "",
                "precio": p.get("precio"),
            }

    def _refresh_all(self):
        self._load_products_cache()

        active = list_receta_versions(self.ctx["db_path"], active=True)
        inactive = list_receta_versions(self.ctx["db_path"], active=False)

        self._fill_list(self.ui_active, active)
        if self.ui_inactive:
            self._fill_list(self.ui_inactive, inactive)

        self._show_detalle("active")
        if self.ui_inactive:
            self._show_detalle("inactive")

    def _fill_list(self, ui: dict, rows: list[dict]):
        ui["lb"].delete(0, "end")
        ui["map"] = []
        for r in rows:
            ui["lb"].insert("end", f"{r['codigo']}  (v{r['version']})")
            ui["map"].append(r)

    def _get_selected_meta(self, mode: str):
        ui = self.ui_active if mode == "active" else self.ui_inactive
        sel = ui["lb"].curselection()
        if not sel:
            return None
        idx = sel[0]
        if idx >= len(ui["map"]):
            return None
        return ui["map"][idx]

    # ------------------------------------------------------------
    # Detalle
    # ------------------------------------------------------------
    def _show_detalle(self, mode: str):
        ui = self.ui_active if mode == "active" else self.ui_inactive
        meta = self._get_selected_meta(mode)
        if not meta:
            return

        codigo = meta["codigo"]
        version = int(meta["version"])

        ui["lbl_title"].config(text=f"Receta: {codigo}")

        created = meta.get("created_at") or "-"
        updated = meta.get("updated_at") or "-"
        line = f"Versión: v{version}  |  Creada: {created}  |  Modif: {updated}"
        if not meta.get("is_active", True):
            inact = meta.get("inactivated_at") or "-"
            line += f"  |  Inactiva: {inact}"
        ui["lbl_meta"].config(text=line)

        items = get_receta_items(self.ctx["db_path"], codigo, version=version) or []
        ui["lbl_info"].config(text=f"Ingredientes: {len(items)}")

        tree = ui["tree"]
        for iid in tree.get_children():
            tree.delete(iid)

        depo_id = self.ctx["depo"].id
        ledger = self.ctx["ledger"]
        has_pend = hasattr(ledger, "stock_pendiente")

        for it in items:
            prod_codigo = (it.get("producto_codigo") or "").strip()
            porcentaje = it.get("porcentaje")

            pdata = self._prod_cache.get(prod_codigo, {})
            marca = pdata.get("marca", "")
            nombre = pdata.get("nombre", "") or prod_codigo
            display = f"{marca} - {nombre}" if marca else nombre

            prod_obj = self.ctx.get("products", {}).get(prod_codigo)
            prod_id = pdata.get("uuid") or (prod_obj.id if prod_obj else "")

            stock_conf_str = "N/A"
            stock_pend_str = "0.00"
            try:
                stock_conf = ledger.stock_confirmado(depo_id, prod_id)
                stock_conf_str = f"{float(stock_conf):.2f}"
                if has_pend:
                    stock_pend = ledger.stock_pendiente(depo_id, prod_id)
                    stock_pend_str = f"{float(stock_pend):.2f}"
            except Exception:
                pass

            porc_str = "" if porcentaje is None else f"{float(porcentaje):.2f}"
            tree.insert("", "end", values=(prod_codigo, display, porc_str, stock_conf_str, stock_pend_str))

        ui["sorter"].set_original_order()
        ui["sorter"].reset()

    # ------------------------------------------------------------
    # Acciones: Editar / Reactivar / Crear
    # ------------------------------------------------------------
    def _editar_receta_activa(self):
        from bull_bar.infra.auth import tiene_permiso
        if not tiene_permiso(self.usuario, "editar", "recetas"):
            messagebox.showwarning("Sin permisos", "No tiene permisos para editar recetas")
            return
        
        meta = self._get_selected_meta("active")
        if not meta:
            return

        codigo = meta["codigo"]
        base_v = int(meta["version"])

        # abre editor como BORRADOR de la versión actual
        self._open_editor_tab(codigo, base_v, draft=True)


    def _reactivar_receta_inactiva(self):
        from bull_bar.infra.auth import tiene_permiso
        if not tiene_permiso(self.usuario, "editar", "recetas"):
            messagebox.showwarning("Sin permisos", "No tiene permisos para reactivar recetas")
            return
        
        meta = self._get_selected_meta("inactive")
        if not meta:
            return

        codigo = meta["codigo"]
        version = int(meta["version"])

        try:
            ok = set_receta_active_version(self.ctx["db_path"], codigo, version)
            if not ok:
                messagebox.showerror("Error", "No se pudo reactivar la receta")
                return
        except Exception as e:
            from bull_bar.infra.error_logger import log_error
            log_error(e, context="Reactivando receta inactiva", 
                     extra_info={"codigo": codigo, "version": version})
            messagebox.showerror("Error", f"Error al reactivar receta:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")
            return

        self._refresh_all()

        # ir a activas y seleccionar esa versión
        self.subnb.select(self.tab_active)
        self._select_in_list(self.ui_active, codigo, version)
        self._show_detalle("active")

    def _crear_y_editar(self):
        from bull_bar.infra.auth import tiene_permiso
        if not tiene_permiso(self.usuario, "crear", "recetas"):
            messagebox.showwarning("Sin permisos", "No tiene permisos para crear recetas")
            return
        
        nombre = self.new_name.get().strip()
        if not nombre:
            messagebox.showerror("Error", "Ingresá un nombre.")
            return

        codigo = _slug_code(nombre)

        ok = create_receta_named(self.ctx["db_path"], codigo, nombre)
        if not ok:
            messagebox.showerror("Error", "No se pudo crear (¿ya existe el código?)")
            return

        self._refresh_all()
        self.subnb.select(self.tab_active)
        # version 1
        self._select_in_list(self.ui_active, codigo, 1)
        self._open_editor_tab(codigo, 1)

    def _select_in_list(self, ui: dict, codigo: str, version: int):
        for idx, m in enumerate(ui["map"]):
            if m["codigo"] == codigo and int(m["version"]) == int(version):
                ui["lb"].selection_clear(0, "end")
                ui["lb"].selection_set(idx)
                ui["lb"].see(idx)
                return

    # ------------------------------------------------------------
    # Editor en pestaña aparte
    # ------------------------------------------------------------
    def _open_editor_tab(self, receta_codigo: str, version: int, draft: bool = False):
        key = (receta_codigo, int(version), "draft" if draft else "fixed")
        if key in self._edit_tabs:
            self.subnb.select(self._edit_tabs[key])
            return

        frame = ttk.Frame(self.subnb)
        self._edit_tabs[key] = frame

        title = f"Editar {receta_codigo} v{version}"
        if draft:
            title += " (BORRADOR)"

        self.subnb.add(frame, text=title)
        self.subnb.select(frame)

        self._build_editor(frame, receta_codigo, version, draft=draft)


    def _build_editor(self, parent, receta_codigo: str, version: int, draft: bool = False):
        parent.columnconfigure(1, weight=1)
        parent.rowconfigure(2, weight=1)  # Tabla expande

        top = ttk.Frame(parent, padding=8)
        top.grid(row=0, column=0, columnspan=2, sticky="we")

        ttk.Label(top, text=f"Editar {receta_codigo} (v{version})", font=("Segoe UI", 11, "bold")).pack(side="left")
        ttk.Label(top, text="(Agregar/quitar/cambiar porcentajes, grupos y orden)", foreground="#666").pack(side="left", padx=10)

        # Sección 1: Datos base (código/nombre/mezcla base kg/activa)
        datos_frame = ttk.LabelFrame(parent, text="Datos base", padding=8)
        datos_frame.grid(row=1, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 8))
        datos_frame.columnconfigure(1, weight=1)
        
        # Obtener info de chocolate
        choco_info = get_receta_chocolate_info(self.ctx["db_path"], receta_codigo)
        
        # Sección 2: Ingredientes de mezcla (tabla estilo stock) con columnas: Grupo, Insumo, % o kg, orden_item
        ingredientes_frame = ttk.LabelFrame(parent, text="Ingredientes de mezcla", padding=8)
        ingredientes_frame.grid(row=2, column=0, columnspan=2, sticky="nsew", padx=8, pady=(0, 8))
        ingredientes_frame.columnconfigure(0, weight=1)
        ingredientes_frame.rowconfigure(0, weight=1)
        
        # Tabla items editable (con panel de edición)
        cols = ("grupo", "producto_codigo", "producto_nombre", "porcentaje", "orden_item")
        tree = ttk.Treeview(ingredientes_frame, columns=cols, show="headings", selectmode="browse")
        tree.heading("grupo", text="Grupo")
        tree.heading("producto_codigo", text="Código")
        tree.heading("producto_nombre", text="Producto")
        tree.heading("porcentaje", text="% uso")
        tree.heading("orden_item", text="Orden")
        tree.column("grupo", width=100, stretch=False)
        tree.column("producto_codigo", width=120, stretch=False)
        tree.column("producto_nombre", width=400, stretch=True)
        tree.column("porcentaje", width=80, anchor="e", stretch=False)
        tree.column("orden_item", width=60, anchor="e", stretch=False)
        tree.grid(row=0, column=0, sticky="nsew", padx=(0, 4), pady=(0, 8))

        yscroll = ttk.Scrollbar(ingredientes_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=yscroll.set)
        yscroll.grid(row=0, column=1, sticky="ns", pady=(0, 8))

        # Cargar items actuales
        items = get_receta_items(self.ctx["db_path"], receta_codigo, version=version) or []
        for it in items:
            pc = (it.get("producto_codigo") or "").strip()
            pdata = self._prod_cache.get(pc, {})
            marca = pdata.get("marca", "")
            nombre = pdata.get("nombre", "") or pc
            disp = f"{marca} - {nombre}" if marca else nombre
            porc = it.get("porcentaje") or 0.0
            grupo = it.get("grupo_preparacion") or "SOLIDOS"
            orden_item = it.get("orden_item") or 0
            tree.insert("", "end", values=(grupo, pc, disp, f"{float(porc):.2f}", orden_item))

        # Panel de edición (selección)
        form = ttk.Frame(ingredientes_frame, padding=8)
        form.grid(row=1, column=0, columnspan=2, sticky="we")
        form.columnconfigure(1, weight=1)

        ttk.Label(form, text="Grupo:").grid(row=0, column=0, sticky="e", padx=(0, 8), pady=4)
        cb_grupo = ttk.Combobox(
            form, 
            state="readonly" if not puede_editar_receta else "readonly",
            values=["SOLIDOS", "CHOCOLATE", "LIQUIDOS", "OTROS"],
            width=15
        )
        cb_grupo.grid(row=0, column=1, sticky="w", pady=4, padx=(0, 10))

        ttk.Label(form, text="Producto:").grid(row=0, column=2, sticky="e", padx=(0, 8), pady=4)

        # combobox solo productos ya registrados (stock/products)
        prod_values = []
        self._prod_list_index = []
        for codigo, p in sorted(self._prod_cache.items()):
            marca = p.get("marca", "")
            nombre = p.get("nombre", "") or codigo
            disp = f"{codigo} | {marca} - {nombre}" if marca else f"{codigo} | {nombre}"
            prod_values.append(disp)
            self._prod_list_index.append(codigo)

        cb_prod = ttk.Combobox(form, state="readonly" if not puede_editar_receta else "readonly", values=prod_values)
        cb_prod.grid(row=0, column=3, sticky="we", pady=4)

        ttk.Label(form, text="% uso:").grid(row=1, column=0, sticky="e", padx=(0, 8), pady=4)
        ent_pct = ttk.Entry(form, state="readonly" if not puede_editar_receta else "normal", width=10)
        ent_pct.grid(row=1, column=1, sticky="w", pady=4, padx=(0, 10))
        
        ttk.Label(form, text="Orden:").grid(row=1, column=2, sticky="e", padx=(0, 8), pady=4)
        ent_orden = ttk.Entry(form, state="readonly" if not puede_editar_receta else "normal", width=10)
        ent_orden.grid(row=1, column=3, sticky="w", pady=4)

        def on_select(_e=None):
            sel = tree.selection()
            if not sel:
                return
            grupo, pc, _, pct, orden = tree.item(sel[0], "values")
            # set combobox al grupo
            cb_grupo.set(grupo)
            # set combobox al producto
            try:
                idx = self._prod_list_index.index(pc)
                cb_prod.current(idx)
            except ValueError:
                cb_prod.set("")
            ent_pct.delete(0, "end")
            ent_pct.insert(0, pct)
            ent_orden.delete(0, "end")
            ent_orden.insert(0, orden)

        tree.bind("<<TreeviewSelect>>", on_select)

        def add_item():
            if cb_prod.current() < 0:
                return
            grupo = cb_grupo.get() or "SOLIDOS"
            pc = self._prod_list_index[cb_prod.current()]
            try:
                pct = float(ent_pct.get().strip())
            except Exception:
                messagebox.showerror("Error", "Porcentaje inválido.")
                return
            try:
                orden = int(ent_orden.get().strip() or "0")
            except Exception:
                orden = 0

            # evitar duplicados: si ya existe, lo selecciona y actualiza
            for iid in tree.get_children():
                v = tree.item(iid, "values")
                if v and v[1] == pc:  # v[1] es producto_codigo
                    tree.selection_set(iid)
                    tree.focus(iid)
                    pdata = self._prod_cache.get(pc, {})
                    marca = pdata.get("marca", "")
                    nombre = pdata.get("nombre", "") or pc
                    disp = f"{marca} - {nombre}" if marca else nombre
                    tree.item(iid, values=(grupo, pc, disp, f"{pct:.2f}", orden))
                    return

            pdata = self._prod_cache.get(pc, {})
            marca = pdata.get("marca", "")
            nombre = pdata.get("nombre", "") or pc
            disp = f"{marca} - {nombre}" if marca else nombre
            tree.insert("", "end", values=(grupo, pc, disp, f"{pct:.2f}", orden))

        def apply_change():
            sel = tree.selection()
            if not sel:
                return
            if cb_prod.current() < 0:
                return
            grupo = cb_grupo.get() or "SOLIDOS"
            pc = self._prod_list_index[cb_prod.current()]
            try:
                pct = float(ent_pct.get().strip())
            except Exception:
                messagebox.showerror("Error", "Porcentaje inválido.")
                return
            try:
                orden = int(ent_orden.get().strip() or "0")
            except Exception:
                orden = 0

            pdata = self._prod_cache.get(pc, {})
            marca = pdata.get("marca", "")
            nombre = pdata.get("nombre", "") or pc
            disp = f"{marca} - {nombre}" if marca else nombre
            tree.item(sel[0], values=(grupo, pc, disp, f"{pct:.2f}", orden))

        def remove_item():
            sel = tree.selection()
            if not sel:
                return
            tree.delete(sel[0])

        from bull_bar.infra.auth import tiene_permiso
        puede_editar_receta = tiene_permiso(self.usuario, "editar", "recetas")
        
        btns = ttk.Frame(form)
        btns.grid(row=0, column=4, rowspan=2, sticky="ns", padx=(10, 0))

        if puede_editar_receta:
            ttk.Button(btns, text="Agregar", command=add_item).pack(fill="x")
            ttk.Button(btns, text="Aplicar", command=apply_change).pack(fill="x", pady=(6, 0))
            ttk.Button(btns, text="Quitar", command=remove_item).pack(fill="x", pady=(6, 0))
        else:
            ttk.Label(btns, text="Solo lectura", foreground="gray").pack()

        # Sección 3: Chocolate/Máquina (aparte de ingredientes)
        choco_frame = ttk.LabelFrame(parent, text="Chocolate/Máquina", padding=8)
        choco_frame.grid(row=3, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 8))
        choco_frame.columnconfigure(1, weight=1)
        
        var_usa_choco = tk.BooleanVar(value=choco_info.get("usa_chocolate", False))
        cb_usa_choco = ttk.Checkbutton(
            choco_frame, 
            text="Usa chocolate", 
            variable=var_usa_choco,
            state="normal" if puede_editar_receta else "disabled"
        )
        cb_usa_choco.grid(row=0, column=0, columnspan=2, sticky="w", pady=4)
        
        ttk.Label(choco_frame, text="Chocolate receta (%):").grid(row=1, column=0, sticky="e", padx=(0, 8), pady=4)
        ent_choco_pct = ttk.Entry(choco_frame, state="normal" if puede_editar_receta else "readonly", width=15)
        ent_choco_pct.insert(0, str(choco_info.get("choco_porcentaje") or ""))
        ent_choco_pct.grid(row=1, column=1, sticky="w", pady=4)
        
        ttk.Label(choco_frame, text="Mínimo máquina (kg):").grid(row=2, column=0, sticky="e", padx=(0, 8), pady=4)
        ent_choco_min = ttk.Entry(choco_frame, state="normal" if puede_editar_receta else "readonly", width=15)
        ent_choco_min.insert(0, str(choco_info.get("choco_min_maquina_kg") or "8.0"))
        ent_choco_min.grid(row=2, column=1, sticky="w", pady=4)
        
        ttk.Label(choco_frame, text="Tipo sugerido:").grid(row=3, column=0, sticky="e", padx=(0, 8), pady=4)
        cb_choco_tipo = ttk.Combobox(
            choco_frame, 
            state="readonly" if not puede_editar_receta else "readonly",
            values=["NEGRO", "BLANCO"],
            width=15
        )
        cb_choco_tipo.set(choco_info.get("choco_tipo_sugerido") or "NEGRO")
        cb_choco_tipo.grid(row=3, column=1, sticky="w", pady=4)
        
        # Barra inferior: Guardar / Cerrar pestaña
        bottom = ttk.Frame(parent, padding=8)
        bottom.grid(row=4, column=0, columnspan=2, sticky="e")

        def save():
            if not puede_editar_receta:
                messagebox.showwarning("Sin permisos", "No tiene permisos para guardar recetas")
                return
            
            rows = []
            total = 0.0
            for iid in tree.get_children():
                grupo, pc, _, pct, orden = tree.item(iid, "values")
                try:
                    p = float(str(pct).strip())
                except Exception:
                    messagebox.showerror("Error", f"% inválido en {pc}")
                    return
                try:
                    orden_int = int(str(orden).strip() or "0")
                except Exception:
                    orden_int = 0
                
                # Obtener orden_grupo según grupo
                from bull_bar.produccion.helpers import obtener_orden_grupo
                orden_grupo = obtener_orden_grupo(grupo)
                
                rows.append({
                    "producto_codigo": pc, 
                    "porcentaje": p,
                    "grupo_preparacion": grupo or "SOLIDOS",
                    "orden_grupo": orden_grupo,
                    "orden_item": orden_int,
                })
                total += p
            
            # Guardar info de chocolate
            usa_choco = var_usa_choco.get()
            choco_pct_str = ent_choco_pct.get().strip()
            choco_min_str = ent_choco_min.get().strip()
            choco_tipo = cb_choco_tipo.get() or "NEGRO"
            
            choco_pct = None
            if choco_pct_str:
                try:
                    choco_pct = float(choco_pct_str)
                except Exception:
                    pass
            
            choco_min = 8.0
            if choco_min_str:
                try:
                    choco_min = float(choco_min_str)
                except Exception:
                    pass
            
            update_receta_chocolate_info(
                self.ctx["db_path"],
                receta_codigo,
                usa_chocolate=usa_choco,
                choco_porcentaje=choco_pct,
                choco_min_maquina_kg=choco_min,
                choco_tipo_sugerido=choco_tipo if usa_choco else None,
            )
        
            if not rows:
                messagebox.showerror("Error", "La receta no puede quedar vacía.")
                return
        
            if abs(total - 100.0) > 0.01:
                if not messagebox.askyesno("Confirmar", f"La suma da {total:.2f}% (no 100%). ¿Guardar igual?"):
                    return
        
            # Si es borrador => crea nueva versión y recién ahí inactiva la vieja
            if draft:
                try:
                    new_v = create_new_version_from_items(self.ctx["db_path"], receta_codigo, rows)
                    if not new_v:
                        messagebox.showerror("Error", "No se pudo guardar (no se cambió la versión anterior).")
                        return
            
                    self._refresh_all()
                    self.subnb.select(self.tab_active)
                    self._select_in_list(self.ui_active, receta_codigo, int(new_v))
                    self._show_detalle("active")
                    messagebox.showinfo("OK", f"Guardado como v{new_v}.")
                    return
                except Exception as e:
                    from bull_bar.infra.error_logger import log_error
                    log_error(e, context="Guardando nueva versión de receta (borrador)", 
                             extra_info={"receta_codigo": receta_codigo, "version": version, "items_count": len(rows)})
                    messagebox.showerror("Error", f"Error al guardar receta:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")
                    return
        
            # Si NO es borrador (caso raro): reemplaza items en esa versión
            try:
                ok = replace_receta_items(self.ctx["db_path"], receta_codigo, version, rows)
                if not ok:
                    messagebox.showerror("Error", "No se pudo guardar la receta.")
                    return
            
                self._refresh_all()
                self.subnb.select(self.tab_active)
                self._select_in_list(self.ui_active, receta_codigo, version)
                self._show_detalle("active")
                messagebox.showinfo("OK", "Receta guardada.")
            except Exception as e:
                from bull_bar.infra.error_logger import log_error
                log_error(e, context="Reemplazando items de receta", 
                         extra_info={"receta_codigo": receta_codigo, "version": version, "items_count": len(rows)})
                messagebox.showerror("Error", f"Error al guardar receta:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")

        def close_tab():
            key = (receta_codigo, int(version))
            tab = self._edit_tabs.get(key)
            if tab:
                self.subnb.forget(tab)
                del self._edit_tabs[key]

        if puede_editar_receta:
            ttk.Button(bottom, text="Guardar", command=save).pack(side="right", padx=(6, 0))
        ttk.Button(bottom, text="Cerrar pestaña", command=close_tab).pack(side="right")

    # ------------------------------------------------------------
    # Producto detalle (igual que venías usando)
    # ------------------------------------------------------------
    def _on_tree_double_click(self, event, mode: str, deselect: DelayedDeselect):
        deselect.cancel()
        ui = self.ui_active if mode == "active" else self.ui_inactive
        tree = ui["tree"]
        row_id = tree.identify_row(event.y)
        if not row_id:
            return
        tree.selection_set(row_id)
        tree.focus(row_id)
        self._open_product_selected(mode)

    def _open_product_selected(self, mode: str):
        ui = self.ui_active if mode == "active" else self.ui_inactive
        tree = ui["tree"]
        sel = tree.selection()
        if not sel:
            return
        values = tree.item(sel[0], "values")
        if not values:
            return
        codigo = values[0]
        pdata = self._prod_cache.get(codigo)
        if not pdata:
            return
        self._open_product_detail_window(codigo, pdata)

    def _open_product_detail_window(self, codigo: str, pdata: dict):
        depo_id = self.ctx["depo"].id
        ledger = self.ctx["ledger"]
        has_pend = hasattr(ledger, "stock_pendiente")

        prod_obj = self.ctx.get("products", {}).get(codigo)
        prod_id = pdata.get("uuid") or (prod_obj.id if prod_obj else "")

        stock_conf_str = "N/A"
        stock_pend_str = "0.00"
        try:
            stock_conf = ledger.stock_confirmado(depo_id, prod_id)
            stock_conf_str = f"{float(stock_conf):.2f}"
            if has_pend:
                stock_pend = ledger.stock_pendiente(depo_id, prod_id)
                stock_pend_str = f"{float(stock_pend):.2f}"
        except Exception:
            pass

        win = tk.Toplevel(self.root)
        win.title(f"Detalle - {codigo}")
        win.transient(self.root)

        container = ttk.Frame(win, padding=10)
        container.pack(fill="both", expand=True)
        container.columnconfigure(1, weight=1)

        def row(label, widget, r):
            ttk.Label(container, text=label).grid(row=r, column=0, sticky="e", padx=(0, 8), pady=4)
            widget.grid(row=r, column=1, sticky="we", pady=4)

        var_codigo = tk.StringVar(value=codigo)
        var_marca = tk.StringVar(value=pdata.get("marca", ""))
        var_nombre = tk.StringVar(value=pdata.get("nombre", ""))
        var_precio = tk.StringVar(value="" if pdata.get("precio") is None else f"{float(pdata.get('precio')):.2f}")
        var_stock = tk.StringVar(value=stock_conf_str)
        var_pend = tk.StringVar(value=stock_pend_str)

        row("Código:", ttk.Entry(container, textvariable=var_codigo, state="readonly"), 0)
        row("Marca:", ttk.Entry(container, textvariable=var_marca), 1)
        row("Nombre:", ttk.Entry(container, textvariable=var_nombre), 2)
        row("Precio / kg:", ttk.Entry(container, textvariable=var_precio), 3)
        row("Stock (confirmado):", ttk.Entry(container, textvariable=var_stock, state="readonly"), 4)
        row("Stock (pendiente):", ttk.Entry(container, textvariable=var_pend, state="readonly"), 5)
        
        # Calcular y mostrar mezcla máxima posible
        try:
            from bull_bar.infra.sqlite_recetas import get_recetas_que_usen_producto, get_receta_items
            from bull_bar.produccion.helpers import calcular_mezcla_maxima_posible
            
            if prod_id:
                # Obtener recetas que usan este producto
                recetas = get_recetas_que_usen_producto(self.ctx["db_path"], codigo)
                
                mezclas_maximas = []
                for receta in recetas:
                    items_receta = get_receta_items(self.ctx["db_path"], receta["codigo"])
                    if items_receta:
                        resultado = calcular_mezcla_maxima_posible(
                            items_receta=items_receta,
                            deposito_id=depo_id,
                            ledger=ledger,
                            ctx_products=self.ctx.get("products", {})
                        )
                        mezcla_max = resultado.get("mezcla_max_kg", 0.0)
                        if mezcla_max > 0:
                            mezclas_maximas.append({
                                "receta": receta["codigo"],
                                "nombre": receta["nombre"],
                                "mezcla_max": mezcla_max
                            })
                
                # Mostrar información de mezcla máxima SOLO si hay datos útiles
                if mezclas_maximas:
                    # Encontrar la máxima mezcla posible entre todas las recetas
                    max_mezcla_total = max([m["mezcla_max"] for m in mezclas_maximas])
                    if max_mezcla_total > 0:
                        texto_mezcla = f"Alcanza hasta {max_mezcla_total:.1f} kg de mezcla"
                        
                        # Si hay múltiples recetas, mostrar detalles
                        if len(mezclas_maximas) > 1:
                            detalles = "\n".join([f"  • {m['receta']}: {m['mezcla_max']:.1f} kg" for m in mezclas_maximas])
                            texto_mezcla += f"\n\nPor receta:\n{detalles}"
                        
                        # Solo mostrar si hay datos útiles
                        if "\n" in texto_mezcla:
                            ttk.Label(container, text="Cantidad máxima de Mezcla:", font=("Segoe UI", 9, "bold")).grid(row=6, column=0, sticky="ne", padx=(0, 8), pady=4)
                            mezcla_text = tk.Text(container, height=4, wrap="word", font=("Segoe UI", 9), state="disabled", bg="white")
                            mezcla_text.insert("1.0", texto_mezcla)
                            mezcla_text.grid(row=6, column=1, sticky="we", pady=4)
                        else:
                            var_mezcla_max = tk.StringVar(value=texto_mezcla)
                            row("Cantidad máxima de Mezcla:", ttk.Entry(container, textvariable=var_mezcla_max, state="readonly"), 6)
                # Si no hay mezclas o todas son 0, NO mostrar el campo
        except Exception as e:
            print(f"[DEBUG] Error calculando mezcla máxima en detalle: {e}")
            var_mezcla_max = tk.StringVar(value="Error al calcular")
            row("Cantidad máxima de Mezcla:", ttk.Entry(container, textvariable=var_mezcla_max, state="readonly"), 6)

        ttk.Separator(container).grid(row=7, column=0, columnspan=2, sticky="we", pady=(10, 8))

        def save():
            marca = var_marca.get().strip()
            nombre = var_nombre.get().strip()
            precio_txt = var_precio.get().strip()
            if precio_txt == "":
                precio_val = None
            else:
                try:
                    precio_val = float(precio_txt)
                except Exception:
                    messagebox.showerror("Error", "Precio inválido")
                    return

            ok = update_product_detail(self.ctx["db_path"], codigo, marca=marca, nombre=nombre, precio=precio_val)
            if not ok:
                messagebox.showerror("Error", "No se pudo guardar en la DB")
                return

            self._refresh_all()
            win.destroy()

        btns = ttk.Frame(container)
        btns.grid(row=8, column=0, columnspan=2, sticky="e")
        ttk.Button(btns, text="Guardar", command=save).pack(side="right", padx=(6, 0))
        ttk.Button(btns, text="Cerrar", command=win.destroy).pack(side="right")

        win.grab_set()
        win.wait_window(win)
