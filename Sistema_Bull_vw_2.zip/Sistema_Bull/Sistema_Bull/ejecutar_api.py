#!/usr/bin/env python
"""
Script simple para ejecutar la API de Bull Bar.
Muestra los logs en tiempo real.
"""
import uvicorn
import sys
import os

# Asegurar que estamos en el directorio correcto
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# Agregar el directorio actual al PYTHONPATH para que Python encuentre bull_bar
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

print("=" * 50)
print("🚀 Iniciando Bull Bar API")
print("=" * 50)
print(f"📁 Directorio: {os.getcwd()}")
print(f"🐍 Python: {sys.version.split()[0]}")
print()
print("🌐 Servidor: http://localhost:8000")
print("📚 Documentación: http://localhost:8000/docs")
print("💚 Health Check: http://localhost:8000/health")
print()
print("Presiona Ctrl+C para detener el servidor")
print("=" * 50)
print()

# Configurar PYTHONPATH en las variables de entorno para que uvicorn lo herede
os.environ["PYTHONPATH"] = script_dir + os.pathsep + os.environ.get("PYTHONPATH", "")

try:
    # Importar la app directamente para evitar problemas con el path
    from bull_bar.api.main import app
    
    # Ejecutar uvicorn con la app importada directamente
    uvicorn.run(
        app,  # Pasar la app directamente en lugar de string
        host="0.0.0.0",
        port=8000,
        reload=False,  # Desactivar reload para evitar problemas con subprocesos
        log_level="info"
    )
except KeyboardInterrupt:
    print("\n\n👋 Servidor detenido. ¡Hasta luego!")
except Exception as e:
    print(f"\n❌ Error al iniciar el servidor: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
