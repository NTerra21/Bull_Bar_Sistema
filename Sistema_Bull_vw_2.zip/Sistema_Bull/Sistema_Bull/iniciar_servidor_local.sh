#!/bin/bash

echo "========================================"
echo "  Bull Bar - Servidor Local"
echo "========================================"
echo ""

# Obtener IP local
IP=$(hostname -I | awk '{print $1}')

if [ -z "$IP" ]; then
    IP=$(ip addr show | grep "inet " | grep -v 127.0.0.1 | awk '{print $2}' | cut -d/ -f1 | head -n1)
fi

echo "Tu IP local es: $IP"
echo ""

# Verificar si los puertos están en uso
if lsof -Pi :8000 -sTCP:LISTEN -t >/dev/null 2>&1 ; then
    echo "[ADVERTENCIA] El puerto 8000 ya está en uso. La API puede estar corriendo."
    echo ""
fi

if lsof -Pi :8080 -sTCP:LISTEN -t >/dev/null 2>&1 ; then
    echo "[ADVERTENCIA] El puerto 8080 ya está en uso. El servidor web puede estar corriendo."
    echo ""
fi

echo "Iniciando servidores..."
echo ""

# Obtener directorio del script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Iniciar API en background
echo "[1/2] Iniciando API en puerto 8000..."
python3 scripts/run_api.py > /tmp/bullbar_api.log 2>&1 &
API_PID=$!
sleep 2

# Iniciar servidor web en background
echo "[2/2] Iniciando servidor web en puerto 8080..."
cd web
python3 -m http.server 8080 > /tmp/bullbar_web.log 2>&1 &
WEB_PID=$!
cd ..

echo ""
echo "========================================"
echo "  Servidores iniciados!"
echo "========================================"
echo ""
echo "Frontend (Web): http://$IP:8080"
echo "API: http://$IP:8000"
echo ""
echo "Para acceder desde otros dispositivos en tu red:"
echo "  - Abre el navegador y ve a: http://$IP:8080"
echo ""
echo "Logs:"
echo "  - API: tail -f /tmp/bullbar_api.log"
echo "  - Web: tail -f /tmp/bullbar_web.log"
echo ""
echo "Presiona Ctrl+C para detener los servidores..."
echo ""

# Función para limpiar al salir
cleanup() {
    echo ""
    echo "Deteniendo servidores..."
    kill $API_PID $WEB_PID 2>/dev/null
    echo "Servidores detenidos."
    exit 0
}

# Capturar Ctrl+C
trap cleanup INT TERM

# Esperar
wait

