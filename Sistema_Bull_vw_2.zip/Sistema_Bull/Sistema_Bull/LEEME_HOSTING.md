# 🚀 Cómo Hostear el Sistema Bull Bar

## Opción Rápida: Hosting Local (Red LAN)

### Para Windows:

1. **Ejecuta el script:**
   ```
   iniciar_servidor_local.bat
   ```

2. **El script te mostrará:**
   - Tu IP local (ej: `192.168.1.100`)
   - URLs para acceder:
     - Frontend: `http://192.168.1.100:8080`
     - API: `http://192.168.1.100:8000`

3. **Desde otros dispositivos en tu red:**
   - Abre el navegador
   - Ve a: `http://TU_IP:8080`
   - Ejemplo: `http://192.168.1.100:8080`

### Para Linux/Mac:

1. **Ejecuta:**
   ```bash
   chmod +x iniciar_servidor_local.sh
   ./iniciar_servidor_local.sh
   ```

---

## Configurar URL de la API

Si necesitas cambiar la URL de la API (por ejemplo, si la API está en otra máquina):

1. **Edita `web/config.js`:**
   ```javascript
   // Descomenta y edita esta línea:
   const API_BASE = 'http://TU_IP:8000';
   ```

2. **O edita directamente `web/shared/api.js`:**
   ```javascript
   let API_BASE = 'http://TU_IP:8000';
   ```

---

## Hosting en la Nube (Internet)

Para que sea accesible desde cualquier lugar:

### Opción 1: Railway (Backend) + Netlify (Frontend) - GRATIS

1. **Backend (Railway):**
   - Crea cuenta en [railway.app](https://railway.app)
   - Conecta tu repositorio
   - Railway detectará automáticamente FastAPI
   - Obtén la URL: `https://tu-proyecto.railway.app`

2. **Frontend (Netlify):**
   - Crea cuenta en [netlify.com](https://netlify.com)
   - Arrastra la carpeta `web/` o conecta GitHub
   - Edita `web/config.js` con la URL de Railway:
     ```javascript
     const API_BASE = 'https://tu-proyecto.railway.app';
     ```

### Opción 2: Render.com - GRATIS

Similar a Railway, con plan gratuito.

---

## Seguridad

⚠️ **IMPORTANTE antes de hostear públicamente:**

1. Cambia `JWT_SECRET` en `.env` o variables de entorno
2. Configura `CORS_ORIGINS` con tu dominio específico
3. Usa HTTPS (certificado SSL)
4. Cambia las contraseñas por defecto

---

## Más Información

Ver `tutorial/GUIA_HOSTING.md` para detalles completos.

