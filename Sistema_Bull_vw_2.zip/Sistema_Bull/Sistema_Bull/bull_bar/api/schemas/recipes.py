"""
Schemas para endpoints de recetas.
"""
from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel


class RecetaItem(BaseModel):
    """Item de una receta."""
    producto_codigo: str
    porcentaje: float
    grupo_preparacion: Optional[str] = None
    orden_grupo: Optional[int] = None
    orden_item: Optional[int] = None


class RecetaCreate(BaseModel):
    """Schema para crear una receta."""
    codigo: str
    nombre: str
    items: List[RecetaItem]
    base_codigo: Optional[str] = None


class RecetaUpdate(BaseModel):
    """Schema para actualizar una receta."""
    nombre: Optional[str] = None
    items: Optional[List[RecetaItem]] = None


class RecetaResponse(BaseModel):
    """Schema de respuesta para una receta."""
    codigo: str
    nombre: str
    version: int
    is_active: bool
    items: List[RecetaItem]
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
