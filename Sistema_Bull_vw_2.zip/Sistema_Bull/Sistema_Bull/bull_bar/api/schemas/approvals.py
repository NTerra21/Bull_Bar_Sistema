"""
Schemas para endpoints de aprobaciones.
"""
from __future__ import annotations

from typing import Optional
from pydantic import BaseModel


class ApprovalResponse(BaseModel):
    """Schema de respuesta para una aprobación."""
    id: str
    tipo: str
    estado: str
    payload: dict
    usuario_creador_id: str
    usuario_creador_nombre: Optional[str] = None
    timestamp_creacion: str
    usuario_aprobador_id: Optional[str] = None
    usuario_aprobador_nombre: Optional[str] = None
    timestamp_aprobacion: Optional[str] = None
    motivo_denegacion: Optional[str] = None
    observaciones: Optional[str] = None


class ApprovalAction(BaseModel):
    """Schema para aprobar/rechazar una solicitud."""
    motivo: Optional[str] = None
