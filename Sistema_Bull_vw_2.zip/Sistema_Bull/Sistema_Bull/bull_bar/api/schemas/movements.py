"""
Schemas para endpoints de movimientos.
"""
from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel


class DocumentoItem(BaseModel):
    """Item de un documento."""
    producto_id: str
    descripcion: str
    cantidad: float
    precio_unitario: Optional[float] = None


class CompraRequest(BaseModel):
    """Schema para registrar una compra."""
    numero: str
    proveedor_id: str
    deposito_id: str
    items: List[DocumentoItem]


class VentaRequest(BaseModel):
    """Schema para registrar una venta."""
    numero: str
    cliente_id: str
    deposito_id: str
    items: List[DocumentoItem]


class AjusteRequest(BaseModel):
    """Schema para registrar un ajuste de stock."""
    deposito_id: str
    producto_id: str
    cantidad: float  # Positivo = entrada, Negativo = salida
    motivo: str = ""


class ProduccionRequest(BaseModel):
    """Schema para registrar una producción."""
    numero: str
    deposito_id: str
    consumos: List[DocumentoItem]  # Insumos (salidas)
    producto_final: DocumentoItem  # Producto terminado (entrada)


class MovimientoResponse(BaseModel):
    """Schema de respuesta para un movimiento."""
    documento_id: str
    tipo: str
    numero: str
    estado: str
    items: List[DocumentoItem]
    requiere_aprobacion: bool = False
    aprobacion_id: Optional[str] = None
