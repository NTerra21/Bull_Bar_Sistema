"""
Schemas para endpoints de stock.
"""
from __future__ import annotations

from typing import Optional
from pydantic import BaseModel


class StockItem(BaseModel):
    """Item de stock."""
    id: str
    nombre: str
    unidad: str
    cantidad: float
    deposito: Optional[str] = None
    updated_at: Optional[str] = None
    
    class Config:
        from_attributes = True
