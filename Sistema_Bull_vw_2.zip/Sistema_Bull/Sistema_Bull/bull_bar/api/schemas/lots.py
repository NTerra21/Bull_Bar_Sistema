"""
Schemas para endpoints de lotes.
"""
from __future__ import annotations

from typing import Optional
from pydantic import BaseModel


class LoteCreate(BaseModel):
    """Schema para crear un lote."""
    sku: str
    nombre: str = ""
    cantidad_total: float
    fecha_produccion: Optional[str] = None
    fecha_vencimiento: Optional[str] = None
    deposito: str = ""
    notas: str = ""
    mezcla_kg: Optional[float] = None


class LoteResponse(BaseModel):
    """Schema de respuesta para un lote."""
    lote_id: str
    sku: str
    nombre: str
    cantidad_total: float
    cantidad_vendida: float
    cantidad_disponible: float
    fecha_produccion: Optional[str] = None
    fecha_vencimiento: Optional[str] = None
    deposito: str
    estado: str
    notas: str
    mezcla_kg: Optional[float] = None
    cajas_grandes: Optional[float] = None
    cajas_chicas: Optional[float] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
