"""
Dependencias de FastAPI para inyección de servicios.
Reutiliza el build_ctx del core existente.
"""
from __future__ import annotations

import os
from functools import lru_cache
from typing import Dict, Any
from uuid import uuid4

from .settings import get_db_path
from ..stock.service import StockLedger
from ..compra_venta.services import PurchaseService, SaleService
from ..produccion.services import ProductionService
from ..stock.adjustment import StockAdjustmentService
from ..core.models import Deposito, ClienteProveedor as ClienteProveedorModel, Producto
from ..core.enums import ClienteProveedor as ClienteProveedorTipo


@lru_cache()
def get_app_context() -> Dict[str, Any]:
    """
    Construye el contexto de la aplicación (ledger, services, repos).
    Cacheado para reutilizar la misma instancia en toda la app.
    """
    ledger = StockLedger()
    db_path = get_db_path()
    
    # Servicios
    purchase_svc = PurchaseService(ledger, db_path=db_path)
    sale_svc = SaleService(ledger, db_path=db_path)
    prod_svc = ProductionService(ledger, db_path=db_path)
    adjustment_svc = StockAdjustmentService(ledger, db_path=db_path)
    
    # Datos base (por ahora hardcodeados, se pueden mover a DB después)
    depo = Deposito(id=str(uuid4()), nombre="Deposito Principal", descripcion="Depósito principal")
    prov = ClienteProveedorModel(
        id=str(uuid4()),
        tipo=ClienteProveedorTipo.PROVEEDOR,
        razon_social="Proveedor X",
    )
    cli = ClienteProveedorModel(
        id=str(uuid4()),
        tipo=ClienteProveedorTipo.CLIENTE,
        razon_social="Cliente Y",
    )
    
    # Cargar productos desde DB
    from ..infra.sqlite_recetas import list_products
    
    products = {}
    for p in list_products(db_path):
        prod = Producto(
            id=p.get("uuid") or str(uuid4()),
            codigo=p.get("codigo", ""),
            nombre=p.get("nombre", ""),
            unidad_medida="u",
        )
        if prod.codigo:
            products[prod.codigo] = prod
    
    return {
        "ledger": ledger,
        "purchase_service": purchase_svc,
        "sale_service": sale_svc,
        "production_service": prod_svc,
        "adjustment_service": adjustment_svc,
        "db_path": db_path,
        "deposito": depo,
        "proveedor": prov,
        "cliente": cli,
        "products": products,
    }


def get_stock_ledger() -> StockLedger:
    """Dependencia para obtener el StockLedger."""
    ctx = get_app_context()
    return ctx["ledger"]


def get_purchase_service() -> PurchaseService:
    """Dependencia para obtener PurchaseService."""
    ctx = get_app_context()
    return ctx["purchase_service"]


def get_sale_service() -> SaleService:
    """Dependencia para obtener SaleService."""
    ctx = get_app_context()
    return ctx["sale_service"]


def get_production_service() -> ProductionService:
    """Dependencia para obtener ProductionService."""
    ctx = get_app_context()
    return ctx["production_service"]


def get_adjustment_service() -> StockAdjustmentService:
    """Dependencia para obtener StockAdjustmentService."""
    ctx = get_app_context()
    return ctx["adjustment_service"]


def get_db_path_dep() -> str:
    """Dependencia para obtener la ruta de la DB."""
    ctx = get_app_context()
    return ctx["db_path"]


def get_deposito() -> Deposito:
    """Dependencia para obtener el depósito por defecto."""
    ctx = get_app_context()
    return ctx["deposito"]


def get_products() -> Dict[str, Producto]:
    """Dependencia para obtener el diccionario de productos."""
    ctx = get_app_context()
    return ctx["products"]
