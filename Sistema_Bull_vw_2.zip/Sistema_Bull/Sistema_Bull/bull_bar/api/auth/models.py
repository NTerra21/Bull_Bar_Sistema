"""
Modelos de datos para autenticación.
"""
from __future__ import annotations

from typing import Optional
from pydantic import BaseModel


class User(BaseModel):
    """Modelo de usuario para la API."""
    id: int
    username: str
    rol: str
    nombre_completo: Optional[str] = None
    email: Optional[str] = None


class Token(BaseModel):
    """Modelo de token JWT."""
    access_token: str
    token_type: str = "bearer"
