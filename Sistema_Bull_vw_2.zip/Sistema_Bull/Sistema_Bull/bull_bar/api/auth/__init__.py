"""
Módulo de autenticación y autorización.
"""
