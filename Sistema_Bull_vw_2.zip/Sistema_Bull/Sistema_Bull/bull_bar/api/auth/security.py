"""
Funciones de seguridad: JWT, verificación de contraseñas, etc.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

from ..settings import settings
from ...infra.auth import autenticar, RolUsuario


# Contexto para hashing de contraseñas (no usado actualmente, pero disponible para futuras mejoras)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Crea un token JWT.
    
    Args:
        data: Datos a incluir en el token (ej: {"sub": username, "rol": rol})
        expires_delta: Tiempo de expiración. Si None, usa el default de settings.
    """
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
    return encoded_jwt


def decode_access_token(token: str) -> Optional[dict]:
    """
    Decodifica y valida un token JWT.
    
    Returns:
        dict con los datos del token si es válido, None si no.
    """
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
        return payload
    except JWTError:
        return None


def authenticate_user(db_path: str, username: str, password: str) -> Optional[dict]:
    """
    Autentica un usuario usando el sistema existente.
    
    Returns:
        dict con datos del usuario si es exitoso, None si falla.
    """
    user_data = autenticar(db_path, username, password)
    return user_data
