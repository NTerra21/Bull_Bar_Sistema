"""
Router de autenticación.
"""
from __future__ import annotations

from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm, HTTPBearer, HTTPAuthorizationCredentials

from .models import Token, User
from .security import authenticate_user, create_access_token, decode_access_token
from ..settings import settings
from ..deps import get_db_path_dep

router = APIRouter(prefix="/auth", tags=["auth"])

# Usar HTTPBearer para que Swagger UI permita pegar el token directamente
http_bearer = HTTPBearer()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login", auto_error=False)


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(http_bearer),
    db_path: str = Depends(get_db_path_dep),
) -> User:
    """
    Dependencia para obtener el usuario actual desde el token JWT.
    """
    token = credentials.credentials
    payload = decode_access_token(token)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido o expirado",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    username: str = payload.get("sub")
    if username is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Obtener datos del usuario desde la DB
    from ...infra.auth import listar_usuarios
    
    usuarios = listar_usuarios(db_path)
    user_data = next((u for u in usuarios if u["username"] == username), None)
    
    if user_data is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuario no encontrado",
        )
    
    return User(
        id=user_data["id"],
        username=user_data["username"],
        rol=user_data["rol"],
        nombre_completo=user_data.get("nombre_completo"),
        email=user_data.get("email"),
    )


def require_role(allowed_roles: list[str]):
    """
    Factory para crear dependencias que requieren roles específicos.
    
    Usage:
        @router.get("/admin-only")
        def admin_endpoint(user: User = Depends(require_role(["ADMIN"]))):
            ...
    """
    def role_checker(user: User = Depends(get_current_user)) -> User:
        if user.rol not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Se requiere uno de los roles: {allowed_roles}",
            )
        return user
    
    return role_checker


@router.post("/login", response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Endpoint de login. Recibe username y password, devuelve JWT.
    """
    user_data = authenticate_user(db_path, form_data.username, form_data.password)
    
    if user_data is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuario o contraseña incorrectos",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Crear token
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user_data["username"], "rol": user_data["rol"]},
        expires_delta=access_token_expires,
    )
    
    return Token(access_token=access_token, token_type="bearer")


@router.get("/me", response_model=User)
async def get_current_user_info(user: User = Depends(get_current_user)):
    """
    Devuelve información del usuario actual.
    """
    return user
