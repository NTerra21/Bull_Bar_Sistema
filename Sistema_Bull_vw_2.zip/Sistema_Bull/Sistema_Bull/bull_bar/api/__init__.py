"""
API Web para Bull Bar - FastAPI
"""
