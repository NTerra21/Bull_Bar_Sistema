"""
Router para endpoints de movimientos (compras, ventas, ajustes, producción).
"""
from __future__ import annotations

import json
from uuid import uuid4
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException

from ..schemas.movements import (
    CompraRequest,
    VentaRequest,
    AjusteRequest,
    ProduccionRequest,
    MovimientoResponse,
    DocumentoItem,
)
from ..deps import (
    get_purchase_service,
    get_sale_service,
    get_production_service,
    get_adjustment_service,
    get_deposito,
    get_db_path_dep,
)
from ..auth.router import get_current_user, require_role
from ..auth.models import User

router = APIRouter(prefix="/movimientos", tags=["movimientos"])


def _is_sensitive_action(tipo: str, cantidad: float = 0.0) -> bool:
    """
    Determina si una acción es "sensible" y requiere aprobación.
    
    Acciones sensibles:
    - Ajuste negativo (resta stock)
    - Producción que consume insumos (siempre)
    - Cualquier movimiento que reduzca stock real
    """
    if tipo == "AJUSTE" and cantidad < 0:
        return True
    if tipo == "PRODUCCION":
        return True  # Producción siempre requiere aprobación
    return False


def _create_approval_request(
    db_path: str,
    tipo: str,
    payload: dict,
    usuario_id: str,
    usuario_nombre: str,
) -> str:
    """
    Crea una solicitud de aprobación en la tabla approvals.
    
    Returns:
        ID de la aprobación creada.
    """
    import sqlite3
    from ...infra.sqlite_db import connect
    
    approval_id = str(uuid4())
    conn = connect(db_path)
    cur = conn.cursor()
    
    cur.execute("""
    INSERT INTO approvals 
    (id, tipo, estado, payload, usuario_creador_id, usuario_creador_nombre, timestamp_creacion)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        approval_id,
        tipo,
        "PENDIENTE",
        json.dumps(payload),
        usuario_id,
        usuario_nombre,
        datetime.now().isoformat(),
    ))
    
    conn.commit()
    conn.close()
    
    return approval_id


@router.post("/compra", response_model=MovimientoResponse)
async def registrar_compra(
    compra: CompraRequest,
    user: User = Depends(require_role(["ADMIN", "USUARIO"])),
    purchase_service=Depends(get_purchase_service),
    deposito=Depends(get_deposito),
):
    """
    Registra una compra. Las compras NO requieren aprobación.
    """
    from ...core.models import DocumentoItem as CoreDocumentoItem
    
    # Convertir items
    items = [
        CoreDocumentoItem(
            producto_id=it.producto_id,
            descripcion=it.descripcion,
            cantidad=it.cantidad,
            precio_unitario=it.precio_unitario,
        )
        for it in compra.items
    ]
    
    doc, movs = purchase_service.registrar_compra_recibida(
        numero=compra.numero,
        ClienteProveedor_id=compra.proveedor_id,
        deposito_id=compra.deposito_id,
        items=items,
        usuario=user.username,
    )
    
    return MovimientoResponse(
        documento_id=doc.id,
        tipo="COMPRA",
        numero=doc.numero,
        estado=doc.estado.value,
        items=[
            DocumentoItem(
                producto_id=it.producto_id,
                descripcion=it.descripcion,
                cantidad=it.cantidad,
                precio_unitario=it.precio_unitario,
            )
            for it in doc.items
        ],
        requiere_aprobacion=False,
    )


@router.post("/venta", response_model=MovimientoResponse)
async def registrar_venta(
    venta: VentaRequest,
    user: User = Depends(require_role(["ADMIN", "USUARIO"])),
    sale_service=Depends(get_sale_service),
):
    """
    Registra una venta. Las ventas NO requieren aprobación (pero pueden quedar pendientes si falta stock).
    """
    from ...core.models import DocumentoItem as CoreDocumentoItem
    
    # Convertir items
    items = [
        CoreDocumentoItem(
            producto_id=it.producto_id,
            descripcion=it.descripcion,
            cantidad=it.cantidad,
            precio_unitario=it.precio_unitario,
        )
        for it in venta.items
    ]
    
    doc, movs, faltantes = sale_service.intentar_venta(
        numero=venta.numero,
        ClienteProveedor_id=venta.cliente_id,
        deposito_id=venta.deposito_id,
        items=items,
        usuario=user.username,
    )
    
    return MovimientoResponse(
        documento_id=doc.id,
        tipo="VENTA",
        numero=doc.numero,
        estado=doc.estado.value,
        items=[
            DocumentoItem(
                producto_id=it.producto_id,
                descripcion=it.descripcion,
                cantidad=it.cantidad,
                precio_unitario=it.precio_unitario,
            )
            for it in doc.items
        ],
        requiere_aprobacion=False,
    )


@router.post("/ajuste", response_model=MovimientoResponse)
async def registrar_ajuste(
    ajuste: AjusteRequest,
    user: User = Depends(require_role(["ADMIN", "USUARIO"])),
    adjustment_service=Depends(get_adjustment_service),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Registra un ajuste de stock.
    Si el ajuste es negativo (resta stock), requiere aprobación de ADMIN.
    """
    # Verificar si es acción sensible
    es_sensible = _is_sensitive_action("AJUSTE", ajuste.cantidad)
    
    if es_sensible and user.rol != "ADMIN":
        # Crear solicitud de aprobación
        payload = {
            "tipo": "AJUSTE",
            "deposito_id": ajuste.deposito_id,
            "producto_id": ajuste.producto_id,
            "cantidad": ajuste.cantidad,
            "motivo": ajuste.motivo,
        }
        
        approval_id = _create_approval_request(
            db_path,
            "AJUSTE",
            payload,
            str(user.id),
            user.username,
        )
        
        return MovimientoResponse(
            documento_id="",
            tipo="AJUSTE",
            numero="",
            estado="PENDIENTE_APROBACION",
            items=[],
            requiere_aprobacion=True,
            aprobacion_id=approval_id,
        )
    
    # Si es ADMIN o el ajuste es positivo, ejecutar directamente
    mov = adjustment_service.apply_adjustment(
        deposito_id=ajuste.deposito_id,
        producto_id=ajuste.producto_id,
        cantidad=ajuste.cantidad,
        motivo=ajuste.motivo,
        usuario=user.username,
    )
    
    return MovimientoResponse(
        documento_id=mov.id,
        tipo="AJUSTE",
        numero=mov.origen_documento_id,
        estado="CONFIRMADO",
        items=[],
        requiere_aprobacion=False,
    )


@router.post("/produccion", response_model=MovimientoResponse)
async def registrar_produccion(
    produccion: ProduccionRequest,
    user: User = Depends(require_role(["ADMIN", "USUARIO"])),
    production_service=Depends(get_production_service),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Registra una producción.
    Si el usuario es USUARIO (no ADMIN), crea una solicitud de aprobación.
    Si es ADMIN, ejecuta directamente.
    """
    from ...core.models import DocumentoItem as CoreDocumentoItem
    
    # Convertir items
    consumos = [
        CoreDocumentoItem(
            producto_id=it.producto_id,
            descripcion=it.descripcion,
            cantidad=it.cantidad,
            precio_unitario=it.precio_unitario,
        )
        for it in produccion.consumos
    ]
    
    producto_final = CoreDocumentoItem(
        producto_id=produccion.producto_final.producto_id,
        descripcion=produccion.producto_final.descripcion,
        cantidad=produccion.producto_final.cantidad,
        precio_unitario=produccion.producto_final.precio_unitario,
    )
    
    # Si es USUARIO, crear solicitud de aprobación
    if user.rol != "ADMIN":
        payload = {
            "tipo": "PRODUCCION",
            "numero": produccion.numero,
            "deposito_id": produccion.deposito_id,
            "consumos": [
                {
                    "producto_id": it.producto_id,
                    "descripcion": it.descripcion,
                    "cantidad": it.cantidad,
                }
                for it in consumos
            ],
            "producto_final": {
                "producto_id": producto_final.producto_id,
                "descripcion": producto_final.descripcion,
                "cantidad": producto_final.cantidad,
            },
        }
        
        approval_id = _create_approval_request(
            db_path,
            "PRODUCCION",
            payload,
            str(user.id),
            user.username,
        )
        
        return MovimientoResponse(
            documento_id="",
            tipo="PRODUCCION",
            numero=produccion.numero,
            estado="PENDIENTE_APROBACION",
            items=[],
            requiere_aprobacion=True,
            aprobacion_id=approval_id,
        )
    
    # Si es ADMIN, ejecutar directamente
    doc, movs = production_service.registrar_remito_produccion_rapido(
        numero=produccion.numero,
        deposito_id=produccion.deposito_id,
        consumos=consumos,
        producto_final=producto_final,
        usuario=user.username,
    )
    
    return MovimientoResponse(
        documento_id=doc.id,
        tipo="PRODUCCION",
        numero=doc.numero,
        estado=doc.estado.value,
        items=[
            DocumentoItem(
                producto_id=it.producto_id,
                descripcion=it.descripcion,
                cantidad=it.cantidad,
                precio_unitario=it.precio_unitario,
            )
            for it in doc.items
        ],
        requiere_aprobacion=False,
    )
