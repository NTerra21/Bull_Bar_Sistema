"""
Router para endpoints de lotes.
"""
from __future__ import annotations

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from ..schemas.lots import LoteCreate, LoteResponse
from ..deps import get_db_path_dep
from ..auth.router import get_current_user, require_role
from ..auth.models import User

router = APIRouter(prefix="/lotes", tags=["lotes"])


@router.get("", response_model=List[LoteResponse])
async def list_lotes(
    estado: Optional[str] = Query(None, description="Filtro por estado: activos, finalizados"),
    user: User = Depends(get_current_user),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Lista lotes de barritas.
    """
    from ...infra.sqlite_barritas import list_lotes
    
    lotes = list_lotes(db_path)
    
    # Filtrar por estado si se especifica
    if estado:
        estado_upper = estado.upper()
        if estado_upper == "ACTIVOS":
            lotes = [l for l in lotes if l["estado"] in ["DISPONIBLE", "EN_PRODUCCION"]]
        elif estado_upper == "FINALIZADOS":
            lotes = [l for l in lotes if l["estado"] in ["VENDIDO_TOTAL", "BLOQUEADO"]]
    
    return [LoteResponse(**l) for l in lotes]


@router.post("", response_model=LoteResponse)
async def create_lote(
    lote: LoteCreate,
    user: User = Depends(require_role(["ADMIN", "USUARIO"])),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Crea un nuevo lote de barritas.
    """
    from ...infra.sqlite_barritas import upsert_lote, get_next_lote_number
    from uuid import uuid4
    
    lote_id = get_next_lote_number(db_path)
    
    success = upsert_lote(
        db_path,
        lote_id=lote_id,
        sku=lote.sku,
        nombre=lote.nombre,
        cantidad_total=lote.cantidad_total,
        cantidad_vendida=0.0,
        cantidad_disponible=lote.cantidad_total,
        fecha_produccion=lote.fecha_produccion,
        fecha_vencimiento=lote.fecha_vencimiento,
        deposito=lote.deposito,
        estado="DISPONIBLE",
        notas=lote.notas,
        mezcla_kg=lote.mezcla_kg,
    )
    
    if not success:
        raise HTTPException(status_code=400, detail="Error al crear el lote")
    
    # Obtener el lote creado
    from ...infra.sqlite_barritas import list_lotes
    lotes = list_lotes(db_path)
    lote_creado = next((l for l in lotes if l["lote_id"] == lote_id), None)
    
    if lote_creado is None:
        raise HTTPException(status_code=404, detail="Lote creado pero no encontrado")
    
    return LoteResponse(**lote_creado)


@router.patch("/{lote_id}/finalizar")
async def finalizar_lote(
    lote_id: str,
    user: User = Depends(require_role(["ADMIN", "USUARIO"])),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Finaliza un lote (marca como VENDIDO_TOTAL o BLOQUEADO).
    """
    from ...infra.sqlite_barritas import list_lotes, upsert_lote
    
    lotes = list_lotes(db_path)
    lote = next((l for l in lotes if l["lote_id"] == lote_id), None)
    
    if lote is None:
        raise HTTPException(status_code=404, detail="Lote no encontrado")
    
    # Marcar como vendido total si tiene cantidad disponible 0, sino como bloqueado
    nuevo_estado = "VENDIDO_TOTAL" if lote["cantidad_disponible"] == 0 else "BLOQUEADO"
    
    success = upsert_lote(
        db_path,
        lote_id=lote_id,
        sku=lote["sku"],
        nombre=lote["nombre"],
        cantidad_total=lote["cantidad_total"],
        cantidad_vendida=lote["cantidad_vendida"],
        cantidad_disponible=lote["cantidad_disponible"],
        fecha_produccion=lote["fecha_produccion"],
        fecha_vencimiento=lote["fecha_vencimiento"],
        deposito=lote["deposito"],
        estado=nuevo_estado,
        notas=lote["notas"],
        mezcla_kg=lote.get("mezcla_kg"),
    )
    
    if not success:
        raise HTTPException(status_code=400, detail="Error al finalizar el lote")
    
    return {"message": f"Lote {lote_id} finalizado", "estado": nuevo_estado}
