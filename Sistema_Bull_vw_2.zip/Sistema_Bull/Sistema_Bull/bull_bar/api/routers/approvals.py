"""
Router para endpoints de aprobaciones.
Solo ADMIN puede aprobar/rechazar solicitudes.
"""
from __future__ import annotations

import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from ..schemas.approvals import ApprovalResponse, ApprovalAction
from ..deps import (
    get_production_service,
    get_adjustment_service,
    get_db_path_dep,
)
from ..auth.router import get_current_user, require_role
from ..auth.models import User

router = APIRouter(prefix="/aprobaciones", tags=["aprobaciones"])


def _get_approval(db_path: str, approval_id: str) -> Optional[dict]:
    """Obtiene una aprobación por ID."""
    import sqlite3
    from ...infra.sqlite_db import connect
    
    conn = connect(db_path)
    cur = conn.cursor()
    
    cur.execute("""
    SELECT id, tipo, estado, payload, usuario_creador_id, usuario_creador_nombre,
           timestamp_creacion, usuario_aprobador_id, usuario_aprobador_nombre,
           timestamp_aprobacion, motivo_denegacion, observaciones
    FROM approvals
    WHERE id = ?
    """, (approval_id,))
    
    row = cur.fetchone()
    conn.close()
    
    if row is None:
        return None
    
    return {
        "id": row[0],
        "tipo": row[1],
        "estado": row[2],
        "payload": json.loads(row[3]),
        "usuario_creador_id": row[4],
        "usuario_creador_nombre": row[5],
        "timestamp_creacion": row[6],
        "usuario_aprobador_id": row[7],
        "usuario_aprobador_nombre": row[8],
        "timestamp_aprobacion": row[9],
        "motivo_denegacion": row[10],
        "observaciones": row[11],
    }


def _update_approval_status(
    db_path: str,
    approval_id: str,
    estado: str,
    usuario_aprobador_id: str,
    usuario_aprobador_nombre: str,
    motivo_denegacion: Optional[str] = None,
):
    """Actualiza el estado de una aprobación."""
    import sqlite3
    from datetime import datetime
    from ...infra.sqlite_db import connect
    
    conn = connect(db_path)
    cur = conn.cursor()
    
    timestamp = datetime.now().isoformat()
    
    cur.execute("""
    UPDATE approvals
    SET estado = ?, usuario_aprobador_id = ?, usuario_aprobador_nombre = ?,
        timestamp_aprobacion = ?, motivo_denegacion = ?
    WHERE id = ?
    """, (estado, usuario_aprobador_id, usuario_aprobador_nombre, timestamp, motivo_denegacion, approval_id))
    
    conn.commit()
    conn.close()


@router.get("", response_model=List[ApprovalResponse])
async def list_approvals(
    estado: Optional[str] = Query("pendiente", description="Filtro por estado: pendiente, aprobada, rechazada"),
    user: User = Depends(require_role(["ADMIN"])),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Lista solicitudes de aprobación. Solo ADMIN.
    """
    import sqlite3
    from ...infra.sqlite_db import connect
    
    conn = connect(db_path)
    cur = conn.cursor()
    
    estado_upper = estado.upper() if estado else "PENDIENTE"
    
    cur.execute("""
    SELECT id, tipo, estado, payload, usuario_creador_id, usuario_creador_nombre,
           timestamp_creacion, usuario_aprobador_id, usuario_aprobador_nombre,
           timestamp_aprobacion, motivo_denegacion, observaciones
    FROM approvals
    WHERE estado = ?
    ORDER BY timestamp_creacion DESC
    """, (estado_upper,))
    
    rows = cur.fetchall()
    conn.close()
    
    approvals = []
    for row in rows:
        approvals.append(ApprovalResponse(
            id=row[0],
            tipo=row[1],
            estado=row[2],
            payload=json.loads(row[3]),
            usuario_creador_id=row[4],
            usuario_creador_nombre=row[5],
            timestamp_creacion=row[6],
            usuario_aprobador_id=row[7],
            usuario_aprobador_nombre=row[8],
            timestamp_aprobacion=row[9],
            motivo_denegacion=row[10],
            observaciones=row[11],
        ))
    
    return approvals


@router.post("/{approval_id}/aprobar")
async def aprobar_solicitud(
    approval_id: str,
    action: ApprovalAction,
    user: User = Depends(require_role(["ADMIN"])),
    db_path: str = Depends(get_db_path_dep),
    production_service=Depends(get_production_service),
    adjustment_service=Depends(get_adjustment_service),
):
    """
    Aprueba una solicitud pendiente. Solo ADMIN.
    Al aprobar, ejecuta realmente el movimiento (impacta stock).
    """
    approval = _get_approval(db_path, approval_id)
    
    if approval is None:
        raise HTTPException(status_code=404, detail="Solicitud no encontrada")
    
    if approval["estado"] != "PENDIENTE":
        raise HTTPException(status_code=400, detail=f"La solicitud ya está {approval['estado']}")
    
    payload = approval["payload"]
    tipo = approval["tipo"]
    
    # Ejecutar el movimiento según el tipo
    if tipo == "PRODUCCION":
        from ...core.models import DocumentoItem as CoreDocumentoItem
        
        consumos = [
            CoreDocumentoItem(
                producto_id=it["producto_id"],
                descripcion=it["descripcion"],
                cantidad=it["cantidad"],
            )
            for it in payload["consumos"]
        ]
        
        producto_final = CoreDocumentoItem(
            producto_id=payload["producto_final"]["producto_id"],
            descripcion=payload["producto_final"]["descripcion"],
            cantidad=payload["producto_final"]["cantidad"],
        )
        
        doc, movs = production_service.registrar_remito_produccion_rapido(
            numero=payload["numero"],
            deposito_id=payload["deposito_id"],
            consumos=consumos,
            producto_final=producto_final,
            usuario=user.username,
        )
        
    elif tipo == "AJUSTE":
        mov = adjustment_service.apply_adjustment(
            deposito_id=payload["deposito_id"],
            producto_id=payload["producto_id"],
            cantidad=payload["cantidad"],
            motivo=payload.get("motivo", ""),
            usuario=user.username,
        )
    else:
        raise HTTPException(status_code=400, detail=f"Tipo de solicitud no soportado: {tipo}")
    
    # Marcar como aprobada
    _update_approval_status(
        db_path,
        approval_id,
        "APROBADA",
        str(user.id),
        user.username,
    )
    
    return {"message": "Solicitud aprobada y ejecutada", "approval_id": approval_id}


@router.post("/{approval_id}/rechazar")
async def rechazar_solicitud(
    approval_id: str,
    action: ApprovalAction,
    user: User = Depends(require_role(["ADMIN"])),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Rechaza una solicitud pendiente. Solo ADMIN.
    """
    approval = _get_approval(db_path, approval_id)
    
    if approval is None:
        raise HTTPException(status_code=404, detail="Solicitud no encontrada")
    
    if approval["estado"] != "PENDIENTE":
        raise HTTPException(status_code=400, detail=f"La solicitud ya está {approval['estado']}")
    
    # Marcar como rechazada
    _update_approval_status(
        db_path,
        approval_id,
        "RECHAZADA",
        str(user.id),
        user.username,
        motivo_denegacion=action.motivo,
    )
    
    return {"message": "Solicitud rechazada", "approval_id": approval_id}
