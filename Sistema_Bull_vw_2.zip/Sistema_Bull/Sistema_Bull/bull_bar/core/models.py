from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from .enums import ClienteProveedor as ClienteProveedorTipo, TipoDocumento, EstadoDocumento


def now_ts() -> datetime:
    return datetime.now()


@dataclass(frozen=True)
class ClienteProveedor:
    """
    Representa una entidad externa con la que operamos.
    Puede ser PROVEEDOR o CLIENTE (según TipoTercero).
    """
    id: str
    tipo: ClienteProveedorTipo
    razon_social: str
    cuit: Optional[str] = None
    email: Optional[str] = None
    telefono: Optional[str] = None


@dataclass(frozen=True)
class Deposito:
    id: str
    nombre: str
    descripcion: str = ""


@dataclass(frozen=True)
class Producto:
    id: str
    codigo: str
    nombre: str
    unidad_medida: str = "u"
    activo: bool = True


@dataclass
class DocumentoItem:
    producto_id: str
    descripcion: str
    cantidad: float
    precio_unitario: Optional[float] = None

    @property
    def total_linea(self) -> Optional[float]:
        if self.precio_unitario is None:
            return None
        return float(self.cantidad) * float(self.precio_unitario)


@dataclass
class Documento:
    id: str
    tipo: TipoDocumento
    numero: str
    fecha_emision: datetime = field(default_factory=now_ts)

    tercero_id: Optional[str] = None
    origen_id: Optional[str] = None
    destino_id: Optional[str] = None

    estado: EstadoDocumento = EstadoDocumento.BORRADOR
    observaciones: str = ""
    items: List[DocumentoItem] = field(default_factory=list)


@dataclass
class DocumentoCompra(Documento):
    """Documento especializado para compras (remitos, facturas de compra, pedidos)."""

    def __post_init__(self):
        valid = {
            TipoDocumento.PEDIDO_COMPRA,
            TipoDocumento.REMITO_COMPRA,
            TipoDocumento.FACTURA_COMPRA,
        }
        if self.tipo not in valid:
            raise ValueError(f"DocumentoCompra tipo inválido: {self.tipo}")


@dataclass
class DocumentoVenta(Documento):
    """Documento especializado para ventas (pedidos, remitos, facturas de venta)."""

    def __post_init__(self):
        valid = {
            TipoDocumento.PEDIDO_VENTA,
            TipoDocumento.REMITO_VENTA,
            TipoDocumento.FACTURA_VENTA,
        }
        if self.tipo not in valid:
            raise ValueError(f"DocumentoVenta tipo inválido: {self.tipo}")
