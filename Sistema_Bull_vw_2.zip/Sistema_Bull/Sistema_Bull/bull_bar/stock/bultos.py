"""
Funciones de conversión entre barritas, cajas chicas y cajas grandes.

Conversión:
- 1 Caja Grande = 10 Cajas Chicas
- 1 Caja Chica = 12 Barritas
- 1 Caja Grande = 120 Barritas
"""
from __future__ import annotations

# Constantes de conversión
BARRITAS_POR_CAJA_CHICA = 12
CAJAS_CHICAS_POR_CAJA_GRANDE = 10
BARRITAS_POR_CAJA_GRANDE = BARRITAS_POR_CAJA_CHICA * CAJAS_CHICAS_POR_CAJA_GRANDE  # 120


def barritas_a_cajas_chicas(barritas: float) -> float:
    """Convierte barritas a cajas chicas."""
    return barritas / BARRITAS_POR_CAJA_CHICA


def cajas_chicas_a_barritas(cajas_chicas: float) -> float:
    """Convierte cajas chicas a barritas."""
    return cajas_chicas * BARRITAS_POR_CAJA_CHICA


def barritas_a_cajas_grandes(barritas: float) -> float:
    """Convierte barritas a cajas grandes."""
    return barritas / BARRITAS_POR_CAJA_GRANDE


def cajas_grandes_a_barritas(cajas_grandes: float) -> float:
    """Convierte cajas grandes a barritas."""
    return cajas_grandes * BARRITAS_POR_CAJA_GRANDE


def cajas_grandes_a_cajas_chicas(cajas_grandes: float) -> float:
    """Convierte cajas grandes a cajas chicas."""
    return cajas_grandes * CAJAS_CHICAS_POR_CAJA_GRANDE


def cajas_chicas_a_cajas_grandes(cajas_chicas: float) -> float:
    """Convierte cajas chicas a cajas grandes."""
    return cajas_chicas / CAJAS_CHICAS_POR_CAJA_GRANDE


def calcular_bultos(barritas: float) -> dict[str, float]:
    """
    Calcula cajas grandes, cajas chicas y barritas sueltas a partir de un total de barritas.
    
    Returns:
        {
            'cajas_grandes': float,
            'cajas_chicas': float,
            'barritas_sueltas': float,
            'total_barritas': float
        }
    """
    total_barritas = float(barritas)
    
    # Calcular cajas grandes (parte entera)
    cajas_grandes = int(total_barritas // BARRITAS_POR_CAJA_GRANDE)
    barritas_restantes = total_barritas - (cajas_grandes * BARRITAS_POR_CAJA_GRANDE)
    
    # Calcular cajas chicas del resto
    cajas_chicas = int(barritas_restantes // BARRITAS_POR_CAJA_CHICA)
    barritas_sueltas = barritas_restantes - (cajas_chicas * BARRITAS_POR_CAJA_CHICA)
    
    return {
        'cajas_grandes': float(cajas_grandes),
        'cajas_chicas': float(cajas_chicas),
        'barritas_sueltas': float(barritas_sueltas),
        'total_barritas': total_barritas
    }


def bultos_a_barritas(cajas_grandes: float = 0, cajas_chicas: float = 0, barritas_sueltas: float = 0) -> float:
    """
    Convierte bultos (cajas grandes, chicas y barritas sueltas) a total de barritas.
    
    Args:
        cajas_grandes: Cantidad de cajas grandes
        cajas_chicas: Cantidad de cajas chicas
        barritas_sueltas: Cantidad de barritas sueltas
    
    Returns:
        Total de barritas
    """
    total = 0.0
    total += cajas_grandes * BARRITAS_POR_CAJA_GRANDE
    total += cajas_chicas * BARRITAS_POR_CAJA_CHICA
    total += barritas_sueltas
    return total

