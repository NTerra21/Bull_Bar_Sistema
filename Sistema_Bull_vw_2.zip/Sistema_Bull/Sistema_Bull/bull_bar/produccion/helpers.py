"""
Helpers para el módulo de Producción.
Funciones para ordenar ingredientes, partir etapas y calcular chocolate.
"""
from typing import List, Dict, Tuple, Optional
from bull_bar.core.enums import (
    GrupoPreparacion,
    ORDEN_GRUPO_SOLIDOS,
    ORDEN_GRUPO_CHOCOLATE,
    ORDEN_GRUPO_LIQUIDOS,
    ORDEN_GRUPO_OTROS,
    MAX_ITEMS_POR_ETAPA,
)


def obtener_orden_grupo(grupo: str) -> int:
    """Obtiene el orden numérico para un grupo de preparación."""
    grupo_upper = (grupo or "").upper()
    if grupo_upper == GrupoPreparacion.SOLIDOS.value:
        return ORDEN_GRUPO_SOLIDOS
    elif grupo_upper == GrupoPreparacion.CHOCOLATE.value:
        return ORDEN_GRUPO_CHOCOLATE
    elif grupo_upper == GrupoPreparacion.LIQUIDOS.value:
        return ORDEN_GRUPO_LIQUIDOS
    elif grupo_upper == GrupoPreparacion.OTROS.value:
        return ORDEN_GRUPO_OTROS
    else:
        return ORDEN_GRUPO_SOLIDOS  # Default


def ordenar_items_por_grupo(items: List[Dict]) -> List[Dict]:
    """
    Ordena items de receta por grupo_preparacion y orden_item.
    Retorna lista ordenada: primero por orden_grupo, luego por orden_item.
    """
    def sort_key(item: Dict) -> Tuple[int, int]:
        grupo = item.get("grupo_preparacion") or "SOLIDOS"
        orden_grupo = item.get("orden_grupo")
        if orden_grupo is None:
            orden_grupo = obtener_orden_grupo(grupo)
        
        orden_item = item.get("orden_item") or 0
        return (orden_grupo, orden_item)
    
    return sorted(items, key=sort_key)


def partir_items_en_etapas(items: List[Dict]) -> List[Dict]:
    """
    Parte items en etapas según grupo y límite MAX_ITEMS_POR_ETAPA.
    Cada etapa tiene: nombre_grupo, items, etapa_num, total_etapas_grupo.
    """
    if not items:
        return []
    
    # Agrupar por grupo_preparacion
    grupos_dict: Dict[str, List[Dict]] = {}
    for item in items:
        grupo = item.get("grupo_preparacion") or "SOLIDOS"
        if grupo not in grupos_dict:
            grupos_dict[grupo] = []
        grupos_dict[grupo].append(item)
    
    # Ordenar grupos por orden_grupo
    grupos_ordenados = sorted(
        grupos_dict.items(),
        key=lambda x: obtener_orden_grupo(x[0])
    )
    
    etapas = []
    for grupo_nombre, items_grupo in grupos_ordenados:
        # Si el grupo tiene más items que MAX_ITEMS_POR_ETAPA, partirlo
        total_items = len(items_grupo)
        num_etapas_grupo = (total_items + MAX_ITEMS_POR_ETAPA - 1) // MAX_ITEMS_POR_ETAPA  # Ceil division
        
        for etapa_idx in range(num_etapas_grupo):
            inicio = etapa_idx * MAX_ITEMS_POR_ETAPA
            fin = min(inicio + MAX_ITEMS_POR_ETAPA, total_items)
            items_etapa = items_grupo[inicio:fin]
            
            nombre_etapa = grupo_nombre
            if num_etapas_grupo > 1:
                nombre_etapa = f"{grupo_nombre} ({etapa_idx + 1}/{num_etapas_grupo})"
            
            etapas.append({
                "nombre": nombre_etapa,
                "grupo": grupo_nombre,
                "items": items_etapa,
                "etapa_num": etapa_idx + 1,
                "total_etapas_grupo": num_etapas_grupo,
            })
    
    return etapas


def calcular_chocolate_total(
    mezcla_kg: float,
    choco_porcentaje: Optional[float] = None,
    choco_min_maquina_kg: float = 8.0
) -> Dict[str, float]:
    """
    Calcula el chocolate total a preparar.
    
    Args:
        mezcla_kg: Cantidad de mezcla en kg
        choco_porcentaje: Porcentaje de chocolate en la receta (opcional)
        choco_min_maquina_kg: Mínimo de chocolate para la máquina (default 8.0)
    
    Returns:
        Dict con:
            - choco_receta_kg: Chocolate según receta
            - choco_min_maquina_kg: Mínimo de máquina
            - choco_total_kg: max(choco_receta_kg, choco_min_maquina_kg)
    """
    choco_receta_kg = 0.0
    if choco_porcentaje is not None and choco_porcentaje > 0:
        choco_receta_kg = mezcla_kg * (choco_porcentaje / 100.0)
    
    choco_total_kg = max(choco_receta_kg, choco_min_maquina_kg)
    
    return {
        "choco_receta_kg": choco_receta_kg,
        "choco_min_maquina_kg": choco_min_maquina_kg,
        "choco_total_kg": choco_total_kg,
    }


def calcular_mezcla_maxima_posible(
    items_receta: List[Dict],
    deposito_id: str,
    ledger,  # StockLedger
    ctx_products: Dict,  # ctx["products"]
) -> Dict[str, any]:
    """
    Calcula cuánta mezcla máxima se puede hacer con el stock actual.
    
    Args:
        items_receta: Lista de items de la receta con porcentaje
        stock_por_producto: Dict con stock actual por código de producto
        deposito_id: ID del depósito
        ledger: StockLedger para obtener stock
        ctx_products: Dict de productos del contexto
    
    Returns:
        Dict con:
            - mezcla_max_kg: Cantidad máxima de mezcla posible (float)
            - producto_limitante: Código del producto que limita la producción
            - faltantes: Lista de productos que faltan completamente
            - advertencias: Lista de productos con stock bajo
    """
    if not items_receta:
        return {
            "mezcla_max_kg": 0.0,
            "producto_limitante": None,
            "faltantes": [],
            "advertencias": []
        }
    
    mezclas_posibles = []
    faltantes = []
    advertencias = []
    
    # Encontrar el producto que más consume (para referencia de advertencias)
    max_consumo = 0.0
    producto_max_consumo = None
    
    for item in items_receta:
        producto_codigo = item.get("producto_codigo", "")
        porcentaje = float(item.get("porcentaje", 0))
        
        if not producto_codigo or porcentaje <= 0:
            continue
        
        # Obtener stock actual
        prod_obj = ctx_products.get(producto_codigo)
        if not prod_obj:
            # Intentar obtener desde la BD si no está en contexto
            from bull_bar.infra.sqlite_recetas import get_producto_nombre
            nombre_prod = get_producto_nombre(None, producto_codigo) or producto_codigo
            from bull_bar.core.models import Producto
            from uuid import uuid4
            prod_obj = Producto(id=str(uuid4()), codigo=producto_codigo, nombre=nombre_prod, unidad_medida="kg")
        
        stock_actual = ledger.stock_confirmado(deposito_id, prod_obj.id) if ledger else 0.0
        
        # Calcular cuánta mezcla se puede hacer con este producto
        # Si porcentaje es 10%, entonces 1kg de producto = 10kg de mezcla
        if porcentaje > 0:
            mezcla_posible = (stock_actual / porcentaje) * 100.0
            mezclas_posibles.append({
                "producto": producto_codigo,
                "mezcla_kg": mezcla_posible,
                "stock_kg": stock_actual,
                "porcentaje": porcentaje
            })
            
            # Verificar si falta completamente
            if stock_actual <= 0:
                faltantes.append(producto_codigo)
            
            # Verificar consumo para encontrar el que más consume
            consumo_por_mezcla = porcentaje / 100.0  # kg de producto por kg de mezcla
            if consumo_por_mezcla > max_consumo:
                max_consumo = consumo_por_mezcla
                producto_max_consumo = producto_codigo
    
    # La mezcla máxima es la mínima de todas las posibles
    mezcla_max_kg = min([m["mezcla_kg"] for m in mezclas_posibles], default=0.0)
    producto_limitante = None
    if mezclas_posibles:
        producto_limitante = min(mezclas_posibles, key=lambda x: x["mezcla_kg"])["producto"]
    
    return {
        "mezcla_max_kg": mezcla_max_kg,
        "producto_limitante": producto_limitante,
        "faltantes": faltantes,
        "advertencias": advertencias,
        "producto_max_consumo": producto_max_consumo,  # Para referencia de advertencias
    }
