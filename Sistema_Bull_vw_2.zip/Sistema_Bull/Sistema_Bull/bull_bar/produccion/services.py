from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List, Tuple, Optional
from uuid import uuid4

from ..core.enums import (
    TipoDocumento, EstadoDocumento, ModoProduccion, TipoMovimiento, EstadoMovimiento
)
from ..core.models import Documento, DocumentoItem
from ..stock.models import MovimientoStock
from ..stock.service import StockLedger


@dataclass
class ProductionService:
    ledger: StockLedger
    db_path: Optional[str] = None  # Para auditoría

    def crear_produccion_por_receta_guiada(
        self,
        numero: str,
        receta_id: str,
        deposito_id: str,
        consumos_calculados: List[DocumentoItem],  # insumos (SALIDA)
        producto_final: DocumentoItem,             # terminado (ENTRADA)
        doc_id: str | None = None,
    ) -> Tuple[Documento, List[MovimientoStock]]:
        """Modo GUIADO: crea movimientos PENDIENTES. Se confirman al finalizar."""
        doc = Documento(
            id=doc_id or str(uuid4()),
            tipo=TipoDocumento.PRODUCCION,
            numero=numero,
            fecha_emision=datetime.now(),
            origen_id=deposito_id,
            destino_id=deposito_id,
            estado=EstadoDocumento.EN_PROCESO,
            observaciones=f"GUIADO|receta_id={receta_id}",
            items=[*consumos_calculados, producto_final],
        )
        movs: List[MovimientoStock] = []

        # Insumos: SALIDA PENDIENTE
        for it in consumos_calculados:
            movs.append(
                MovimientoStock(
                    id=str(uuid4()),
                    fecha=datetime.now(),
                    producto_id=it.producto_id,
                    deposito_id=deposito_id,
                    tipo=TipoMovimiento.SALIDA,
                    cantidad=float(it.cantidad),
                    origen_documento_id=doc.id,
                    estado=EstadoMovimiento.PENDIENTE,
                )
            )

        # Producto final: ENTRADA PENDIENTE
        movs.append(
            MovimientoStock(
                id=str(uuid4()),
                fecha=datetime.now(),
                producto_id=producto_final.producto_id,
                deposito_id=deposito_id,
                tipo=TipoMovimiento.ENTRADA,
                cantidad=float(producto_final.cantidad),
                origen_documento_id=doc.id,
                estado=EstadoMovimiento.PENDIENTE,
            )
        )

        self.ledger.add_many(movs)
        return doc, movs

    def finalizar_produccion_guiada(self, doc_id: str) -> int:
        """Confirma movimientos pendientes de un documento (descarta UI)."""
        changed = 0
        for idx, m in enumerate(self.ledger.movimientos):
            if m.origen_documento_id == doc_id and m.estado == EstadoMovimiento.PENDIENTE:
                # como es frozen dataclass, recreamos
                self.ledger.movimientos[idx] = MovimientoStock(
                    id=m.id,
                    fecha=m.fecha,
                    producto_id=m.producto_id,
                    deposito_id=m.deposito_id,
                    tipo=m.tipo,
                    cantidad=m.cantidad,
                    origen_documento_id=m.origen_documento_id,
                    estado=EstadoMovimiento.CONFIRMADO,
                )
                changed += 1
        return changed

    def registrar_remito_produccion_rapido(
        self,
        numero: str,
        deposito_id: str,
        consumos: List[DocumentoItem],      # insumos usados (SALIDA) - ya decidido
        producto_final: DocumentoItem,      # terminado (ENTRADA)
        doc_id: str | None = None,
        usuario: Optional[str] = None,
    ) -> Tuple[Documento, List[MovimientoStock]]:
        """Modo RÁPIDO: descuenta al toque (movimientos CONFIRMADOS)."""
        doc = Documento(
            id=doc_id or str(uuid4()),
            tipo=TipoDocumento.PRODUCCION,
            numero=numero,
            fecha_emision=datetime.now(),
            origen_id=deposito_id,
            destino_id=deposito_id,
            estado=EstadoDocumento.CONFIRMADO,
            observaciones="RAPIDO|remito_produccion",
            items=[*consumos, producto_final],
        )

        movs: List[MovimientoStock] = []
        for it in consumos:
            movs.append(
                MovimientoStock(
                    id=str(uuid4()),
                    fecha=datetime.now(),
                    producto_id=it.producto_id,
                    deposito_id=deposito_id,
                    tipo=TipoMovimiento.SALIDA,
                    cantidad=float(it.cantidad),
                    origen_documento_id=doc.id,
                    estado=EstadoMovimiento.CONFIRMADO,
                )
            )

        movs.append(
            MovimientoStock(
                id=str(uuid4()),
                fecha=datetime.now(),
                producto_id=producto_final.producto_id,
                deposito_id=deposito_id,
                tipo=TipoMovimiento.ENTRADA,
                cantidad=float(producto_final.cantidad),
                origen_documento_id=doc.id,
                estado=EstadoMovimiento.CONFIRMADO,
            )
        )

        self.ledger.add_many(movs)
        
        # Registrar auditoría
        if self.db_path:
            try:
                from ..infra.audit import log_audit
                log_audit(
                    self.db_path,
                    "PRODUCCION_REGISTRADA",
                    usuario=usuario,
                    modulo="produccion",
                    entidad_id=doc.id,
                    entidad_tipo="Documento",
                    despues={
                        "numero": numero,
                        "consumos": [{"producto_id": it.producto_id, "cantidad": it.cantidad} for it in consumos],
                        "producto_final": {"producto_id": producto_final.producto_id, "cantidad": producto_final.cantidad},
                    },
                    metadata={"deposito_id": deposito_id},
                )
            except Exception as e:
                print(f"Error en auditoría de producción: {e}")
        
        return doc, movs
