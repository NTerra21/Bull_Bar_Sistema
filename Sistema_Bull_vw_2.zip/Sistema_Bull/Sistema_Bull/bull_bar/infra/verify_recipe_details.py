from pathlib import Path
import sys
from typing import List, Dict, Tuple

from .sqlite_db import connect, init_schema

DB_DEFAULT = "bullbar.sqlite"
DEFAULT_RECETA = "R-CAKE"
DEFAULT_KG = 10.0

def _norm(s: str) -> str:
    if not s:
        return ""
    return "".join(ch for ch in s.lower() if ch.isalnum())

def verify_recipe(db_path: str, receta: str, batch_kg: float) -> int:
    dbf = Path(db_path)
    if not dbf.exists():
        print(f"DB no encontrada en {db_path}. Se creará esquema de ejemplo.")
    conn = connect(db_path)
    init_schema(conn)
    cur = conn.cursor()

    # cargar products: codigo -> nombre
    cur.execute("SELECT codigo, nombre FROM products")
    products: Dict[str, str] = {r[0]: r[1] for r in cur.fetchall()}

    # mapa nombre normalizado -> list(codigo)
    name_map: Dict[str, List[str]] = {}
    for codigo, nombre in products.items():
        key = _norm(nombre or codigo)
        name_map.setdefault(key, []).append(codigo)

    # obtener items de receta
    cur.execute("SELECT producto_codigo, porcentaje FROM receta_items WHERE receta_codigo = ?", (receta,))
    rows = cur.fetchall()
    if not rows:
        print(f"Receta '{receta}' no encontrada o sin ingredientes en DB.")
        conn.close()
        return 2

    print(f"Verificando receta: {receta}  (batch: {batch_kg} kg -> {batch_kg*1000:.0f} g)\n")
    missing = []
    for prod_codigo, porcentaje in rows:
        porcentaje = float(porcentaje or 0.0)
        prod_nombre = products.get(prod_codigo)
        exists = prod_codigo in products
        grams = batch_kg * 1000.0 * (porcentaje / 100.0)
        status = "OK" if exists else "MISSING"
        print(f" - {prod_codigo}: {porcentaje:.2f}% -> {grams:.0f} g   ({status})   Nombre: {prod_nombre or 'N/D'}")
        if not exists:
            missing.append(prod_codigo)

    # detectar posibles duplicados por nombre (misma materia prima con distintos códigos)
    dup_report: Dict[str, List[str]] = {}
    # considerar solo los códigos de la receta
    receta_codigos = {r[0] for r in rows}
    for codigo in receta_codigos:
        nombre = products.get(codigo)
        if not nombre:
            continue
        key = _norm(nombre)
        found = [c for c in name_map.get(key, []) if c != codigo]
        if found:
            dup_report[codigo] = found

    if dup_report:
        print("\nPosibles duplicados de materias primas detectados (mismo nombre normalizado, distintos códigos):")
        for base, others in dup_report.items():
            print(f"  - {base}  -> otros códigos: {', '.join(others)}")
    else:
        print("\nNo se detectaron duplicados por nombre normalizado entre los productos de la receta.")

    if missing:
        print("\nResumen: faltan productos en tabla 'products' para los códigos:")
        for m in missing:
            print("  -", m)
        conn.close()
        return 3

    print("\nVerificación completada: todos los ingredientes están registrados en 'products'.")
    conn.close()
    return 0

def main(argv: List[str]):
    db_path = DB_DEFAULT
    receta = DEFAULT_RECETA
    batch = DEFAULT_KG
    if len(argv) > 0:
        receta = argv[0]
    if len(argv) > 1:
        try:
            batch = float(argv[1])
        except Exception:
            print("KG inválido, usando valor por defecto:", DEFAULT_KG)
            batch = DEFAULT_KG
    rc = verify_recipe(db_path, receta, batch)
    sys.exit(rc)

if __name__ == "__main__":
    main(sys.argv[1:])
