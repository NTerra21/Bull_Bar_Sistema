import sqlite3
from pathlib import Path

def connect(db_path: str):
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    return conn

def init_schema(conn):
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS recetas (
        codigo TEXT PRIMARY KEY,
        nombre TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS receta_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        receta_codigo TEXT,
        producto_codigo TEXT,
        porcentaje REAL
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS products (
        codigo TEXT PRIMARY KEY,
        nombre TEXT,
        uuid TEXT,
        precio REAL
    )
    """)

    # Stock Barritas por Lote (producto terminado)
    # Estados recomendados: EN_PRODUCCION | DISPONIBLE | BLOQUEADO | VENDIDO_TOTAL
    cur.execute("""
    CREATE TABLE IF NOT EXISTS barritas_lotes (
        lote_id TEXT PRIMARY KEY,
        sku TEXT NOT NULL,
        nombre TEXT,
        cantidad_total REAL NOT NULL,
        cantidad_vendida REAL NOT NULL DEFAULT 0,
        cantidad_disponible REAL NOT NULL,
        fecha_produccion TEXT,
        fecha_vencimiento TEXT,
        deposito TEXT,
        estado TEXT NOT NULL DEFAULT 'DISPONIBLE',
        notas TEXT,
        mezcla_kg REAL,
        created_at TEXT,
        updated_at TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS barritas_lote_movs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        lote_id TEXT NOT NULL,
        tipo TEXT NOT NULL,
        cantidad REAL,
        timestamp TEXT,
        nota TEXT
    )
    """)
    
    # Tabla de auditoría
    cur.execute("""
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        usuario TEXT,
        accion TEXT NOT NULL,
        modulo TEXT,
        entidad_id TEXT,
        entidad_tipo TEXT,
        antes TEXT,
        despues TEXT,
        metadata TEXT,
        ip_address TEXT
    )
    """)
    
    # Tabla de movimientos pendientes de producción
    cur.execute("""
    CREATE TABLE IF NOT EXISTS produccion_pendientes (
        id TEXT PRIMARY KEY,
        tipo TEXT NOT NULL DEFAULT 'PRODUCCION',
        estado TEXT NOT NULL DEFAULT 'PENDIENTE_APROBACION',
        receta_codigo TEXT NOT NULL,
        receta_nombre TEXT,
        mezcla_kg REAL NOT NULL,
        consumos TEXT NOT NULL,
        usuario_creador_id TEXT,
        usuario_creador_nombre TEXT,
        timestamp_creacion TEXT NOT NULL,
        usuario_aprobador_id TEXT,
        usuario_aprobador_nombre TEXT,
        timestamp_aprobacion TEXT,
        motivo_denegacion TEXT,
        documento_id TEXT,
        observaciones TEXT
    )
    """)
    
    # Tabla para lotes de compra (para mostrar en detalle de producto)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS compra_lotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        producto_id TEXT NOT NULL,
        documento_id TEXT,
        documento_numero TEXT,
        fecha_compra TEXT,
        fecha_vencimiento TEXT,
        cantidad REAL NOT NULL,
        precio_unitario REAL,
        deposito TEXT,
        comprobante TEXT,
        ruta_archivo TEXT,
        created_at TEXT
    )
    """)
    
    # Migración: agregar columnas si no existen
    try:
        cur.execute("ALTER TABLE compra_lotes ADD COLUMN precio_unitario REAL")
    except sqlite3.OperationalError:
        pass  # Columna ya existe
    
    try:
        cur.execute("ALTER TABLE compra_lotes ADD COLUMN ruta_archivo TEXT")
    except sqlite3.OperationalError:
        pass  # Columna ya existe
    
    # Migración: agregar límite de advertencia a products
    try:
        cur.execute("ALTER TABLE products ADD COLUMN limite_advertencia_kg REAL")
    except sqlite3.OperationalError:
        pass  # Columna ya existe
    
    # Migración: agregar mezcla_kg a barritas_lotes (si la tabla ya existía sin esta columna)
    try:
        cur.execute("ALTER TABLE barritas_lotes ADD COLUMN mezcla_kg REAL")
    except sqlite3.OperationalError:
        pass  # Columna ya existe o tabla no existe (se creará con la columna)
    
    # Migración: agregar campos de cajas a barritas_lotes
    try:
        cur.execute("ALTER TABLE barritas_lotes ADD COLUMN cajas_grandes REAL")
    except sqlite3.OperationalError:
        pass
    
    try:
        cur.execute("ALTER TABLE barritas_lotes ADD COLUMN cajas_chicas REAL")
    except sqlite3.OperationalError:
        pass
    
    # Tabla de usuarios (creada por auth.py)
    # Se crea automáticamente al importar auth
    
    conn.commit()
    # Nota: no se insertan datos de ejemplo automáticamente.
