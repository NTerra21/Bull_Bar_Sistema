// ===== DASHBOARD =====
// Este archivo se carga cuando se muestra la página del dashboard

// Función principal para cargar los datos del dashboard
async function loadDashboard() {
    console.log('Cargando dashboard...');
    try {
        const [insumos, barritas, lotes, aprobaciones] = await Promise.all([
            apiCall('/stock/insumos').catch(() => []),
            apiCall('/stock/barritas').catch(() => []),
            apiCall('/lotes?estado=activos').catch(() => []),
            apiCall('/aprobaciones?estado=pendiente').catch(() => []),
        ]);

        const totalInsumos = insumos.reduce((sum, item) => sum + (item.cantidad || 0), 0);
        const totalBarritas = barritas.reduce((sum, item) => sum + (item.cantidad || 0), 0);

        // Actualizar estadísticas en el DOM
        const statInsumos = document.getElementById('stat-insumos');
        const statBarritas = document.getElementById('stat-barritas');
        const statLotes = document.getElementById('stat-lotes');
        const statAprobaciones = document.getElementById('stat-aprobaciones');

        if (statInsumos) statInsumos.textContent = totalInsumos.toFixed(2) + ' kg';
        if (statBarritas) statBarritas.textContent = totalBarritas.toFixed(0) + ' unidades';
        if (statLotes) statLotes.textContent = lotes.length || 0;
        if (statAprobaciones) statAprobaciones.textContent = aprobaciones.length || 0;

        console.log('✅ Dashboard cargado exitosamente');
    } catch (error) {
        console.error('Error cargando dashboard:', error);
    }
}

// Auto-cargar cuando el script se ejecuta (la página ya está visible)
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadDashboard);
} else {
    loadDashboard();
}

