// ===== ROUTER - Sistema de Carga Dinámica de Páginas =====

/**
 * Router para cargar páginas y sub-páginas dinámicamente
 */

// Cache de páginas cargadas
const pageCache = new Map();
const loadedScripts = new Set();

/**
 * Carga una página principal
 */
async function loadPage(pageName) {
    console.log(`[Router] Cargando página: ${pageName}`);
    
    try {
        // Ocultar todas las páginas
        document.querySelectorAll('.page').forEach(p => {
            p.classList.remove('active');
        });
        
        // Obtener el contenedor principal
        const mainContent = document.querySelector('.main-content');
        if (!mainContent) {
            console.error('[Router] No se encuentra .main-content');
            return;
        }
        
        // Si la página ya está en el DOM, solo mostrarla y cargar su script
        let pageElement = document.getElementById(`page-${pageName}`);
        if (pageElement) {
            pageElement.classList.add('active');
            await loadPageScript(pageName);
            // Llamar a la función de carga de la página si existe
            const loadFunction = window[`load${pageName.charAt(0).toUpperCase() + pageName.slice(1)}`];
            if (typeof loadFunction === 'function') {
                loadFunction();
            }
            updateActiveNavButton(pageName);
            return;
        }
        
        // Si no existe, cargar desde archivo HTML
        try {
            const htmlContent = await loadPageHTML(pageName);
            
            // Crear el elemento de la página
            pageElement = document.createElement('div');
            pageElement.id = `page-${pageName}`;
            pageElement.className = 'page active';
            pageElement.innerHTML = htmlContent;
            
            // Agregar al DOM
            mainContent.appendChild(pageElement);
            
            // Cargar el JavaScript de la página
            await loadPageScript(pageName);
            
            // Llamar a la función de carga de la página si existe
            const loadFunction = window[`load${pageName.charAt(0).toUpperCase() + pageName.slice(1)}`];
            if (typeof loadFunction === 'function') {
                loadFunction();
            }
            
            updateActiveNavButton(pageName);
            
            console.log(`[Router] ✅ Página ${pageName} cargada exitosamente`);
        } catch (htmlError) {
            console.warn(`[Router] No se pudo cargar HTML de ${pageName}, usando placeholder:`, htmlError);
            // Crear placeholder si no existe el archivo
            pageElement = document.createElement('div');
            pageElement.id = `page-${pageName}`;
            pageElement.className = 'page active';
            pageElement.innerHTML = `<h1>${pageName.charAt(0).toUpperCase() + pageName.slice(1)}</h1><p>Cargando...</p>`;
            mainContent.appendChild(pageElement);
            
            // Intentar cargar el script de todos modos
            await loadPageScript(pageName);
            updateActiveNavButton(pageName);
        }
        
    } catch (error) {
        console.error(`[Router] Error cargando página ${pageName}:`, error);
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'page active';
            errorDiv.innerHTML = `<h1>Error</h1><p>Error al cargar la página ${pageName}: ${error.message}</p>`;
            mainContent.appendChild(errorDiv);
        }
    }
}

/**
 * Actualiza el botón de navegación activo
 */
function updateActiveNavButton(pageName) {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.page === pageName) {
            btn.classList.add('active');
        }
    });
}

/**
 * Carga el HTML de una página desde archivo
 */
async function loadPageHTML(pageName) {
    // Verificar cache
    if (pageCache.has(`${pageName}-html`)) {
        return pageCache.get(`${pageName}-html`);
    }
    
    try {
        const response = await fetch(`pages/${pageName}/${pageName}.html`);
        if (!response.ok) {
            throw new Error(`No se encontró el archivo: pages/${pageName}/${pageName}.html`);
        }
        
        const html = await response.text();
        pageCache.set(`${pageName}-html`, html);
        return html;
    } catch (error) {
        console.error(`Error cargando HTML de ${pageName}:`, error);
        throw error;
    }
}

/**
 * Carga el JavaScript de una página
 */
async function loadPageScript(pageName) {
    // Verificar si el script ya se cargó
    if (loadedScripts.has(pageName)) {
        console.log(`[Router] Script de ${pageName} ya está cargado`);
        return;
    }
    
    try {
        const script = document.createElement('script');
        script.id = `script-${pageName}`;
        script.src = `pages/${pageName}/${pageName}.js`;
        script.type = 'text/javascript';
        
        // Esperar a que el script se cargue
        await new Promise((resolve, reject) => {
            script.onload = () => {
                loadedScripts.add(pageName);
                resolve();
            };
            script.onerror = () => {
                console.warn(`[Router] No se pudo cargar script de ${pageName}, puede que no exista`);
                // No marcar como cargado si falla, pero no bloquear
                resolve(); // Resolver para no bloquear la carga
            };
            document.head.appendChild(script);
        });
        
        console.log(`[Router] ✅ Script de ${pageName} procesado`);
    } catch (error) {
        console.error(`[Router] Error procesando script de ${pageName}:`, error);
        // No lanzar error, la página puede funcionar sin JS específico
    }
}

/**
 * Carga una sub-pestaña dentro de una página
 */
async function loadSubTab(pageName, subTabName) {
    console.log(`Cargando sub-pestaña: ${pageName}/${subTabName}`);
    
    try {
        // Buscar el contenedor de contenido de la página
        const pageElement = document.getElementById(`page-${pageName}`);
        if (!pageElement) {
            throw new Error(`No se encuentra la página: ${pageName}`);
        }
        
        const contentElement = pageElement.querySelector(`[id$="-content"]`);
        if (!contentElement) {
            throw new Error(`No se encuentra el contenedor de contenido en ${pageName}`);
        }
        
        // Cargar el HTML de la sub-pestaña
        const htmlContent = await loadSubTabHTML(pageName, subTabName);
        contentElement.innerHTML = htmlContent;
        
        // Cargar el JavaScript de la sub-pestaña
        await loadSubTabScript(pageName, subTabName);
        
        console.log(`✅ Sub-pestaña ${pageName}/${subTabName} cargada exitosamente`);
        
    } catch (error) {
        console.error(`Error cargando sub-pestaña ${pageName}/${subTabName}:`, error);
        const pageElement = document.getElementById(`page-${pageName}`);
        if (pageElement) {
            const contentElement = pageElement.querySelector(`[id$="-content"]`);
            if (contentElement) {
                contentElement.innerHTML = `<p class="message message-error">Error al cargar: ${error.message}</p>`;
            }
        }
    }
}

/**
 * Carga el HTML de una sub-pestaña desde archivo
 */
async function loadSubTabHTML(pageName, subTabName) {
    const cacheKey = `${pageName}-${subTabName}-html`;
    if (pageCache.has(cacheKey)) {
        return pageCache.get(cacheKey);
    }
    
    try {
        const response = await fetch(`pages/${pageName}/tabs/${subTabName}.html`);
        if (!response.ok) {
            throw new Error(`No se encontró: pages/${pageName}/tabs/${subTabName}.html`);
        }
        
        const html = await response.text();
        pageCache.set(cacheKey, html);
        return html;
    } catch (error) {
        console.error(`Error cargando HTML de sub-pestaña ${pageName}/${subTabName}:`, error);
        throw error;
    }
}

/**
 * Carga el JavaScript de una sub-pestaña
 */
async function loadSubTabScript(pageName, subTabName) {
    const scriptId = `script-${pageName}-${subTabName}`;
    if (document.getElementById(scriptId)) {
        console.log(`Script de ${pageName}/${subTabName} ya está cargado`);
        return;
    }
    
    try {
        const script = document.createElement('script');
        script.id = scriptId;
        script.src = `pages/${pageName}/tabs/${subTabName}.js`;
        script.type = 'text/javascript';
        
        await new Promise((resolve, reject) => {
            script.onload = resolve;
            script.onerror = () => reject(new Error(`Error cargando: pages/${pageName}/tabs/${subTabName}.js`));
            document.head.appendChild(script);
        });
        
        console.log(`✅ Script de sub-pestaña ${pageName}/${subTabName} cargado`);
    } catch (error) {
        console.error(`Error cargando script de sub-pestaña ${pageName}/${subTabName}:`, error);
    }
}

// Función showPage - alias para loadPage (compatibilidad)
function showPage(pageName) {
    return loadPage(pageName);
}

// Exportar funciones globalmente
window.loadPage = loadPage;
window.showPage = showPage;
window.loadSubTab = loadSubTab;

