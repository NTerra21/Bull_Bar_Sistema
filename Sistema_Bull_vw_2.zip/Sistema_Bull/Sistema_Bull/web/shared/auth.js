// ===== AUTENTICACIÓN =====
function logout() {
    currentToken = null;
    currentUser = null;
    document.getElementById('login-screen').classList.add('active');
    document.getElementById('main-screen').classList.remove('active');
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}

function showMainScreen() {
    document.getElementById('login-screen').classList.remove('active');
    document.getElementById('main-screen').classList.add('active');
    
    // Mostrar información del usuario
    document.getElementById('user-name').textContent = currentUser.username;
    document.getElementById('user-role').textContent = currentUser.rol;
    
    // Mostrar/ocultar aprobaciones según el rol
    if (currentUser.rol === 'ADMIN') {
        document.getElementById('nav-aprobaciones').style.display = 'block';
    }
    
    // Mostrar/ocultar pestañas según permisos
    const isAdmin = currentUser.rol === 'ADMIN';
    const tabComprasVentas = document.getElementById('tab-compras-ventas');
    const tabAjuste = document.getElementById('tab-ajuste');
    const tabCrearReceta = document.getElementById('tab-crear-receta');
    
    // Compras/Ventas y Ajuste Stock: mostrar siempre (pero pueden requerir permisos en el backend)
    if (tabComprasVentas) tabComprasVentas.style.display = 'inline-block';
    if (tabAjuste) tabAjuste.style.display = 'inline-block';
    
    // Crear Receta: solo si tiene permisos (por ahora, mostrar siempre)
    if (tabCrearReceta) tabCrearReceta.style.display = 'inline-block';
    
    // Cargar dashboard
    if (typeof loadDashboard === 'function') loadDashboard();
    showPage('dashboard');
}

// Inicializar login
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('login-error');
            errorDiv.style.display = 'none';

            try {
                const formData = new URLSearchParams();
                formData.append('username', username);
                formData.append('password', password);

                const response = await fetch(`${API_BASE}/auth/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: formData,
                });

                if (!response.ok) {
                    const error = await response.json().catch(() => ({ detail: 'Usuario o contraseña incorrectos' }));
                    showError(error.detail || 'Error al iniciar sesión');
                    return;
                }

                const data = await response.json();
                currentToken = data.access_token;

                // Obtener información del usuario
                const userResponse = await fetch(`${API_BASE}/auth/me`, {
                    headers: {
                        'Authorization': `Bearer ${currentToken}`,
                    },
                });

                if (userResponse.ok) {
                    currentUser = await userResponse.json();
                    showMainScreen();
                } else {
                    showError('Error al obtener información del usuario');
                }
            } catch (error) {
                showError('Error de conexión. Verifica que la API esté corriendo.');
            }
        });
    }
});

