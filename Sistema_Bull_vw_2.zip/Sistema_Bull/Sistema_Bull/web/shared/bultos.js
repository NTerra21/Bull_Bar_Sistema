// ===== FUNCIONES COMPARTIDAS PARA CÁLCULO DE BULTOS =====

/**
 * Convierte barritas a cajas grandes (1 caja grande = 120 barritas)
 */
function barritasACajasGrandes(barritas) {
    return barritas / 120;
}

/**
 * Convierte barritas a cajas chicas (1 caja chica = 12 barritas)
 */
function barritasACajasChicas(barritas) {
    return barritas / 12;
}

/**
 * Calcula los bultos (cajas grandes, cajas chicas y barritas sueltas) a partir de un total de barritas
 * @param {number} barritas - Total de barritas
 * @returns {Object} Objeto con cajasGrandes, cajasChicas, barritasSueltas y totalBarritas
 */
function calcularBultos(barritas) {
    const total = parseFloat(barritas);
    const cajasGrandes = Math.floor(total / 120);
    const resto = total - (cajasGrandes * 120);
    const cajasChicas = Math.floor(resto / 12);
    const barritasSueltas = resto - (cajasChicas * 12);
    
    return {
        cajasGrandes: cajasGrandes,
        cajasChicas: cajasChicas,
        barritasSueltas: barritasSueltas,
        totalBarritas: total
    };
}

// Exportar funciones globalmente
window.barritasACajasGrandes = barritasACajasGrandes;
window.barritasACajasChicas = barritasACajasChicas;
window.calcularBultos = calcularBultos;

