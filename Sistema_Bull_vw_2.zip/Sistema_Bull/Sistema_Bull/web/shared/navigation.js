// ===== NAVEGACIÓN =====
function showPage(pageName) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const page = document.getElementById(`page-${pageName}`);
    if (page) {
        page.classList.add('active');
        loadPageContent(pageName);
        
        // Actualizar botones de navegación activos
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.page === pageName) {
                btn.classList.add('active');
            }
        });
    }
}

// Hacer showPage disponible globalmente para onclick
window.showPage = showPage;

function loadPageContent(pageName) {
    switch (pageName) {
        case 'dashboard':
            if (typeof loadDashboard === 'function') loadDashboard();
            break;
        case 'stock':
            if (typeof loadStock === 'function') loadStock();
            break;
        case 'movimientos':
            if (typeof loadMovimientos === 'function') loadMovimientos();
            break;
        case 'produccion':
            if (typeof loadProduccion === 'function') loadProduccion();
            break;
        case 'recetas':
            if (typeof loadRecetas === 'function') loadRecetas();
            break;
        case 'aprobaciones':
            if (typeof loadAprobaciones === 'function') loadAprobaciones();
            break;
    }
}

// Inicializar navegación
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const page = btn.dataset.page;
            showPage(page);
            
            // Actualizar botones activos
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });
});

