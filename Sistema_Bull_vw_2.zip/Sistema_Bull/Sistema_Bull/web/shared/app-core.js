// ===== CORE - Funciones esenciales de la aplicación =====
// Este archivo contiene funciones compartidas que todas las páginas necesitan

// Configuración de la API (se carga desde config.js)
let API_BASE = window.API_BASE || 'http://localhost:8000';

// Estado global (se actualizarán desde app.js después del login)
let currentUser = null;
let currentToken = null;

// Función para actualizar el estado global desde otros scripts
function setCurrentUser(user, token) {
    currentUser = user;
    currentToken = token;
    window.currentUser = user;
    window.currentToken = token;
}

// Función para obtener el usuario actual
function getCurrentUser() {
    return window.currentUser || currentUser;
}

function getCurrentToken() {
    return window.currentToken || currentToken;
}

/**
 * Realiza una llamada a la API
 */
async function apiCall(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
    };

    const token = getCurrentToken();
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    try {
        const response = await fetch(url, {
            ...options,
            headers,
        });

        if (response.status === 401) {
            logout();
            return null;
        }

        if (!response.ok) {
            const error = await response.json().catch(() => ({ detail: 'Error desconocido' }));
            throw new Error(error.detail || `Error ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Muestra un mensaje de error en el login
 */
function showError(message) {
    const errorDiv = document.getElementById('login-error');
    if (errorDiv) {
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
    } else {
        alert(message);
    }
}

/**
 * Muestra un mensaje en un elemento
 */
function showMessage(elementId, message, type = 'success') {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = `<div class="message message-${type}">${message}</div>`;
        setTimeout(() => {
            element.innerHTML = '';
        }, 5000);
    }
}

/**
 * Función de logout
 */
function logout() {
    currentToken = null;
    currentUser = null;
    window.currentToken = null;
    window.currentUser = null;
    
    const loginScreen = document.getElementById('login-screen');
    const mainScreen = document.getElementById('main-screen');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    
    if (loginScreen) loginScreen.classList.add('active');
    if (mainScreen) mainScreen.classList.remove('active');
    if (usernameInput) usernameInput.value = '';
    if (passwordInput) passwordInput.value = '';
}

// Exportar funciones globalmente
window.apiCall = apiCall;
window.showError = showError;
window.showMessage = showMessage;
window.logout = logout;
window.API_BASE = API_BASE;
window.setCurrentUser = setCurrentUser;
window.getCurrentUser = getCurrentUser;
window.getCurrentToken = getCurrentToken;

// Hacer currentUser y currentToken accesibles como propiedades
// Se actualizarán cuando se haga login
Object.defineProperty(window, 'currentUser', {
    get: function() { return currentUser; },
    set: function(value) { currentUser = value; },
    configurable: true
});

Object.defineProperty(window, 'currentToken', {
    get: function() { return currentToken; },
    set: function(value) { currentToken = value; },
    configurable: true
});

