# Estructura del Proyecto Web

## Organización por Páginas

El proyecto está organizado por páginas, cada una en su propia carpeta dentro de `web/pages/`:

```
web/
├── index.html              # Página principal (login + layout)
├── styles.css              # Estilos globales
├── shared/                 # Código compartido
│   ├── api.js              # Configuración API y utilidades
│   ├── auth.js             # Autenticación y login
│   └── navigation.js       # Navegación entre páginas
├── pages/                  # Páginas del sistema
│   ├── dashboard/          # Dashboard principal
│   ├── stock/              # Gestión de stock
│   ├── movimientos/        # Compras, ventas, ajustes
│   ├── produccion/         # Producción y recetas
│   ├── recetas/            # Gestión de recetas
│   ├── aprobaciones/       # Aprobaciones (solo ADMIN)
│   └── login/              # Página de login (si se separa)
└── components/             # Componentes reutilizables (futuro)
```

## Cómo funciona

1. **index.html** carga todos los scripts en orden:
   - Primero `shared/api.js` (configuración base)
   - Luego `shared/auth.js` (autenticación)
   - Luego `shared/navigation.js` (navegación)
   - Finalmente los scripts de cada página

2. Cada página tiene su propio archivo JavaScript que define:
   - `load[NombrePagina]()` - función para cargar el contenido
   - Variables de estado específicas de la página
   - Event listeners específicos

3. La navegación se maneja centralmente en `shared/navigation.js`

## Migración en progreso

El archivo `app.js` original contiene todo el código. Estamos migrando gradualmente a esta estructura modular.

