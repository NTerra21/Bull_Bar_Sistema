// Script de diagnóstico para problemas de conexión
console.log('=== DIAGNÓSTICO BULL BAR ===');
console.log('URL actual:', window.location.href);
console.log('API_BASE configurado:', window.API_BASE || 'NO CONFIGURADO');

// Probar conexión con la API
async function diagnosticarAPI() {
    const apiBase = window.API_BASE || 'http://localhost:8000';
    console.log('Probando conexión con:', apiBase);
    
    try {
        const response = await fetch(`${apiBase}/health`);
        if (response.ok) {
            const data = await response.json();
            console.log('✅ API está respondiendo:', data);
            return true;
        } else {
            console.error('❌ API respondió con error:', response.status);
            return false;
        }
    } catch (error) {
        console.error('❌ No se puede conectar con la API:', error.message);
        console.error('   Verifica que:');
        console.error('   1. La API esté corriendo (python scripts/run_api.py)');
        console.error('   2. La URL sea correcta:', apiBase);
        console.error('   3. No haya firewall bloqueando el puerto 8000');
        return false;
    }
}

// Ejecutar diagnóstico al cargar
if (typeof window !== 'undefined') {
    window.addEventListener('load', () => {
        setTimeout(() => {
            diagnosticarAPI();
        }, 1000);
    });
}

