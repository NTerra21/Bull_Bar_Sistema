#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script para verificar y actualizar la contraseña del usuario Bull.
"""
import sys
from pathlib import Path

# Agregar el directorio raíz al path
root_dir = Path(__file__).parent
sys.path.insert(0, str(root_dir))

from bull_bar.infra.auth import _hash_password, _ensure_users_table, autenticar
from bull_bar.infra.sqlite_db import connect, init_schema
from bull_bar.api.settings import get_db_path

def verificar_usuario_bull():
    """Verifica el usuario Bull y actualiza su contraseña si es necesario."""
    db_path = get_db_path()
    print(f"Base de datos: {db_path}")
    print()
    
    conn = connect(db_path)
    init_schema(conn)
    _ensure_users_table(conn)
    
    cur = conn.cursor()
    
    # Verificar si existe el usuario Bull
    cur.execute("SELECT id, username, password_hash, rol FROM usuarios WHERE username = 'Bull'")
    row = cur.fetchone()
    
    if row:
        user_id, username, password_hash, rol = row
        print(f"[OK] Usuario Bull encontrado (ID: {user_id}, Rol: {rol})")
        print(f"Hash actual: {password_hash[:20]}...")
        print()
        
        # Probar autenticación con la contraseña actual
        print("Probando autenticación con 'Bull1243' (sin punto)...")
        user_data = autenticar(db_path, "Bull", "Bull1243")
        if user_data:
            print("[OK] La contraseña 'Bull1243' funciona correctamente")
            return True
        else:
            print("[ERROR] La contraseña 'Bull1243' NO funciona")
            print()
            print("Actualizando contraseña a 'Bull1243'...")
            
            # Actualizar contraseña
            new_hash = _hash_password("Bull1243")
            from datetime import datetime
            cur.execute("""
                UPDATE usuarios 
                SET password_hash = ?, updated_at = ?
                WHERE id = ?
            """, (new_hash, datetime.now().isoformat(), user_id))
            conn.commit()
            
            print(f"[OK] Contraseña actualizada")
            print(f"Nuevo hash: {new_hash[:20]}...")
            print()
            
            # Probar de nuevo
            print("Probando autenticación con la nueva contraseña...")
            user_data = autenticar(db_path, "Bull", "Bull1243")
            if user_data:
                print("[OK] La nueva contraseña funciona correctamente")
                return True
            else:
                print("[ERROR] La nueva contraseña NO funciona")
                return False
    else:
        print("[ERROR] Usuario Bull no encontrado")
        print("Creando usuario Bull...")
        
        # Crear usuario Bull
        password_hash = _hash_password("Bull1243")
        from datetime import datetime
        from bull_bar.infra.auth import RolUsuario
        now = datetime.now().isoformat()
        cur.execute("""
            INSERT INTO usuarios (username, password_hash, rol, nombre_completo, debe_cambiar_password, activo, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, ("Bull", password_hash, RolUsuario.ADMIN.value, "Administrador", 0, 1, now))
        conn.commit()
        
        print("[OK] Usuario Bull creado con contraseña 'Bull1243'")
        
        # Probar autenticación
        user_data = autenticar(db_path, "Bull", "Bull1243")
        if user_data:
            print("[OK] La contraseña funciona correctamente")
            return True
        else:
            print("[ERROR] La contraseña NO funciona después de crearla")
            return False
    
    conn.close()

if __name__ == "__main__":
    print("=" * 60)
    print("Verificar y Actualizar Usuario Bull")
    print("=" * 60)
    print()
    
    if verificar_usuario_bull():
        print()
        print("=" * 60)
        print("[OK] Proceso completado exitosamente")
        print("=" * 60)
        print()
        print("Credenciales:")
        print("  Usuario: Bull")
        print("  Contraseña: Bull1243")
        print()
    else:
        print()
        print("=" * 60)
        print("[ERROR] Hubo un problema")
        print("=" * 60)
        sys.exit(1)

