#!/bin/bash

echo "========================================"
echo "Iniciando Bull Bar API"
echo "========================================"
echo ""

# Cambiar al directorio del script
cd "$(dirname "$0")"

echo "Directorio actual: $(pwd)"
echo ""

# Verificar si existe el entorno virtual (opcional)
if [ -f "venv/bin/activate" ]; then
    echo "Activando entorno virtual..."
    source venv/bin/activate
else
    echo "No se encontró entorno virtual. Usando Python global."
fi

echo ""
echo "Instalando/verificando dependencias..."
pip install -q -r bull_bar/api/requirements.txt

echo ""
echo "========================================"
echo "Iniciando servidor FastAPI..."
echo "========================================"
echo ""
echo "La API estará disponible en: http://localhost:8000"
echo "Documentación: http://localhost:8000/docs"
echo ""
echo "Presiona Ctrl+C para detener el servidor"
echo ""

python -m uvicorn bull_bar.api.main:app --reload --host 0.0.0.0 --port 8000
