# 🚀 Guía Rápida: Cómo Ejecutar la API de Bull Bar

## Opción 1: Usando el Script (Más Fácil) ⚡

### Windows:
Simplemente ejecuta:
```bash
start_api.bat
```

### Linux/Mac:
```bash
chmod +x start_api.sh
./start_api.sh
```

El script automáticamente:
- ✅ Instala las dependencias necesarias
- ✅ Inicia el servidor en http://localhost:8000
- ✅ Abre la documentación interactiva

---

## Opción 2: Manual (Paso a Paso) 📝

### Paso 1: Instalar Dependencias

Abre una terminal en el directorio raíz del proyecto (`Sistema_Bull`) y ejecuta:

```bash
pip install -r bull_bar/api/requirements.txt
```

**Dependencias que se instalan:**
- `fastapi` - Framework web
- `uvicorn` - Servidor ASGI
- `pydantic-settings` - Configuración
- `passlib[bcrypt]` - Hashing de contraseñas
- `python-jose[cryptography]` - JWT

### Paso 2: Ejecutar el Servidor

Desde el directorio raíz del proyecto:

```bash
python -m uvicorn bull_bar.api.main:app --reload
```

O si prefieres especificar host y puerto:

```bash
python -m uvicorn bull_bar.api.main:app --reload --host 0.0.0.0 --port 8000
```

### Paso 3: Verificar que Funciona

Abre tu navegador y ve a:

- **Documentación Interactiva (Swagger)**: http://localhost:8000/docs
- **Documentación Alternativa (ReDoc)**: http://localhost:8000/redoc
- **Health Check**: http://localhost:8000/health

---

## 🧪 Probar la API

### 1. Health Check (Sin autenticación)

```bash
curl http://localhost:8000/health
```

Deberías ver:
```json
{"status":"ok"}
```

### 2. Login

```bash
curl -X POST "http://localhost:8000/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin&password=admin"
```

Respuesta:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

**Usuarios por defecto:**
- `admin/admin` (rol: ADMIN)
- `user/user` (rol: USUARIO)

### 3. Consultar Stock (Requiere autenticación)

```bash
# Primero obtén el token del login anterior
TOKEN="tu-token-aqui"

curl -X GET "http://localhost:8000/stock/insumos" \
  -H "Authorization: Bearer $TOKEN"
```

---

## 📋 Usando la Documentación Interactiva

La forma más fácil de probar la API es usando Swagger UI:

1. Ve a http://localhost:8000/docs
2. Haz clic en el botón **"Authorize"** 🔓 (arriba a la derecha)
3. Ingresa:
   - Username: `admin`
   - Password: `admin`
4. Haz clic en **"Authorize"** y luego **"Close"**
5. Ahora puedes probar todos los endpoints haciendo clic en "Try it out"

---

## ⚠️ Solución de Problemas

### Error: "ModuleNotFoundError: No module named 'bull_bar'"

**Solución:** Asegúrate de estar en el directorio raíz del proyecto (`Sistema_Bull`), no dentro de `bull_bar`.

```bash
# Verifica que estás aquí:
cd C:\Users\nicol\Desktop\Sistema_Bull\Sistema_Bull
```

### Error: "Database locked"

**Solución:** La base de datos SQLite puede estar siendo usada por la UI local. Cierra la aplicación de escritorio antes de ejecutar la API, o usa una base de datos diferente.

### Error: "Port 8000 already in use"

**Solución:** Usa otro puerto:

```bash
python -m uvicorn bull_bar.api.main:app --reload --port 8001
```

### Error al instalar dependencias

**Solución:** Usa un entorno virtual:

```bash
# Crear entorno virtual
python -m venv venv

# Activar (Windows)
venv\Scripts\activate

# Activar (Linux/Mac)
source venv/bin/activate

# Instalar dependencias
pip install -r bull_bar/api/requirements.txt
```

---

## 🔧 Configuración Avanzada

### Variables de Entorno

Crea un archivo `.env` en el directorio raíz:

```env
JWT_SECRET=mi-secret-key-super-segura
DEBUG=True
SQLITE_PATH=./bullbar.sqlite
CORS_ORIGINS=["http://localhost:3000"]
```

### Cambiar Puerto

```bash
python -m uvicorn bull_bar.api.main:app --reload --port 8080
```

---

## 📚 Próximos Pasos

1. ✅ Probar los endpoints desde Swagger UI
2. ✅ Crear un frontend que consuma la API
3. ✅ Configurar variables de entorno para producción
4. ✅ Considerar migrar a PostgreSQL para producción

---

## 💡 Tips

- **Auto-reload**: El flag `--reload` hace que el servidor se reinicie automáticamente cuando cambias código
- **Documentación**: Siempre disponible en `/docs` y `/redoc`
- **Logs**: Los errores aparecen en la consola donde ejecutaste el servidor
- **Base de datos**: La API usa la misma DB que la UI local (`bullbar.sqlite`)

---

¿Problemas? Revisa los logs en la consola donde ejecutaste el servidor.
