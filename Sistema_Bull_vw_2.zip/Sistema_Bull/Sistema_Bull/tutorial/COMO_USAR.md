# 🚀 Cómo Usar el Sistema Bull Bar - Guía Completa

## ⚠️ IMPORTANTE: Dos Opciones Disponibles

### Opción A: Solo API (Sin Frontend) - ⭐ RECOMENDADO si no tienes Node.js
**Ver archivo:** `USAR_SOLO_API.md`

### Opción B: API + Frontend Web (Requiere Node.js)
**Sigue esta guía**

---

## 📋 Pasos para Iniciar el Sistema Completo

### Requisito Previo: Node.js

Si no tienes Node.js instalado:
1. Descarga desde: https://nodejs.org/ (versión LTS)
2. Instala y reinicia tu terminal
3. Verifica con: `node --version` y `npm --version`

**Ver archivo:** `INSTALAR_NODEJS.md` para más detalles

---

### Paso 1: Iniciar la API (Backend)

Abre una **terminal** (PowerShell o CMD) en el directorio:
```
C:\Users\nicol\Desktop\Sistema_Bull\Sistema_Bull
```

Ejecuta:
```bash
python run_api.py
```

**Espera a ver este mensaje:**
```
✅ Módulo bull_bar importado correctamente
🚀 Iniciando Bull Bar API
INFO:     Uvicorn running on http://0.0.0.0:8000
```

✅ **¡La API está lista!** (NO cierres esta ventana)

---

### Paso 2: Iniciar el Frontend (Web)

Abre una **NUEVA terminal** en el mismo directorio:
```
C:\Users\nicol\Desktop\Sistema_Bull\Sistema_Bull
```

Ejecuta:
```bash
cd Sistema_Bull\frontend
npm install
npm run dev
```

**Nota:** El frontend está en `Sistema_Bull\frontend`, no directamente en `frontend`

**Espera a ver este mensaje:**
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
```

✅ **¡El frontend está listo!**

---

## 🌐 Acceder al Sistema

### 1. Abre tu navegador

Ve a: **http://localhost:3000**

### 2. Página de Login

Verás la pantalla de login. Ingresa:

**Para ADMIN:**
- Usuario: `admin`
- Contraseña: `admin`

**Para USUARIO:**
- Usuario: `user`
- Contraseña: `user`

### 3. Haz clic en "Iniciar Sesión"

Te llevará al **Dashboard** principal.

---

## 📱 Navegación del Sistema

Una vez dentro, verás un menú superior con:

- **Dashboard** - Estadísticas generales
- **Stock** - Ver stock de insumos y barritas
- **Movimientos** - Compras, ventas, ajustes
- **Producción** - Registrar producción
- **Recetas** - Ver recetas
- **Lotes** - Gestionar lotes de barritas
- **Aprobaciones** - Solo visible para ADMIN

---

## 🎯 Funcionalidades Principales

### Stock
- Ver insumos disponibles
- Ver barritas disponibles
- Cambiar entre tabs

### Movimientos
- **Compra**: Registrar compras de insumos
- **Venta**: Registrar ventas
- **Ajuste**: Ajustar stock (requiere aprobación si es negativo)

### Producción
- Registrar producción
- Agregar insumos consumidos
- Especificar producto final
- Si eres USUARIO, requiere aprobación de ADMIN

### Aprobaciones (Solo ADMIN)
- Ver solicitudes pendientes
- Aprobar o rechazar solicitudes
- Las solicitudes aprobadas ejecutan el movimiento

---

## ⚠️ Notas Importantes

1. **Mantén ambas terminales abiertas** mientras uses el sistema
2. **La API debe estar corriendo** antes de iniciar el frontend
3. **Si cierras una terminal**, esa parte del sistema dejará de funcionar
4. **Para salir**: Presiona `Ctrl+C` en las terminales

---

## 🐛 Si Algo No Funciona

### Error: "Cannot connect to API"
- Verifica que la API esté corriendo (Terminal 1)
- Revisa que esté en el puerto 8000

### Error: "Module not found" en frontend
- Ejecuta `npm install` en el directorio `frontend`

### El frontend no carga
- Verifica que esté en http://localhost:3000
- Revisa la consola del navegador (F12)

---

## 🎉 ¡Listo!

Ya puedes usar el sistema completo desde tu navegador web.

