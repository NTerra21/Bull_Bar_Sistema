# 📦 Instalar Node.js (Requisito para el Frontend)

## ⚠️ Problema Detectado

Node.js no está instalado en tu sistema. Necesitas instalarlo para ejecutar el frontend.

## 🔽 Cómo Instalar Node.js

### Opción 1: Descarga Directa (Recomendado)

1. Ve a: **https://nodejs.org/**
2. Descarga la versión **LTS** (Long Term Support)
3. Ejecuta el instalador
4. Sigue el asistente (acepta todo por defecto)
5. **Reinicia tu terminal** después de instalar

### Opción 2: Usando Chocolatey (Si lo tienes instalado)

```powershell
choco install nodejs-lts
```

## ✅ Verificar Instalación

Después de instalar, abre una **nueva terminal** y ejecuta:

```bash
node --version
npm --version
```

Deberías ver números de versión (ej: `v20.x.x` y `10.x.x`)

## 🚀 Después de Instalar Node.js

Una vez instalado Node.js, podrás ejecutar:

```bash
cd Sistema_Bull\frontend
npm install
npm run dev
```

---

## 📝 Nota

El frontend es **opcional**. Si solo quieres usar la API directamente, puedes:
- Usar la documentación interactiva en http://localhost:8000/docs
- Usar herramientas como Postman o curl
- Crear tu propio frontend más adelante

