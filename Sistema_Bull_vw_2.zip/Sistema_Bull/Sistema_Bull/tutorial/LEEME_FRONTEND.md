# 🎨 Frontend Web - Bull Bar

## ✅ Sistema Completo Creado

He creado un **frontend web completo** con React + Vite que consume la API.

## 🚀 Inicio Rápido

### Opción 1: Script Automático (Recomendado)

```bash
iniciar_sistema.bat
```

Este script:
- ✅ Inicia la API en el puerto 8000
- ✅ Instala dependencias del frontend (si es necesario)
- ✅ Inicia el frontend en el puerto 3000

### Opción 2: Manual

**Terminal 1 - API:**
```bash
python run_api.py
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm install
npm run dev
```

## 📍 URLs

- **Frontend**: http://localhost:3000
- **API**: http://localhost:8000
- **Documentación API**: http://localhost:8000/docs

## 🔐 Login

Usuarios por defecto:
- **admin/admin** (rol: ADMIN)
- **user/user** (rol: USUARIO)

## ✨ Funcionalidades Implementadas

### ✅ Autenticación
- Login con JWT
- Rutas protegidas
- Manejo de roles
- Logout

### ✅ Dashboard
- Estadísticas generales
- Resumen de stock y lotes

### ✅ Stock
- Visualización de insumos
- Visualización de barritas
- Tabs para alternar

### ✅ Movimientos
- **Compra**: Registrar compras
- **Venta**: Registrar ventas
- **Ajuste**: Ajustes de stock (con aprobación si es necesario)

### ✅ Producción
- Registrar producción
- Consumos y producto final
- Sistema de aprobaciones

### ✅ Recetas
- Listar recetas activas/inactivas
- Ver detalles

### ✅ Lotes
- Listar lotes activos/finalizados
- Finalizar lotes

### ✅ Aprobaciones (Solo ADMIN)
- Ver solicitudes pendientes
- Aprobar/Rechazar solicitudes

## 📁 Estructura

```
frontend/
├── src/
│   ├── components/     # Componentes reutilizables
│   ├── contexts/       # Context API (Auth)
│   ├── pages/          # Páginas principales
│   ├── services/       # Cliente API
│   └── App.jsx         # App principal
└── package.json
```

## 🎨 Diseño

- Diseño moderno y limpio
- Responsive (se adapta a móviles)
- Navegación intuitiva
- Mensajes de error/success claros

## 🔧 Tecnologías

- **React 18** - Framework UI
- **Vite** - Build tool (rápido)
- **React Router** - Navegación
- **Axios** - Cliente HTTP
- **CSS** - Estilos (sin dependencias externas)

## 📝 Próximos Pasos Sugeridos

1. **Mejorar formularios**: Agregar validación y autocompletado
2. **Búsqueda y filtros**: Para stock, lotes, etc.
3. **Notificaciones**: Toast notifications para feedback
4. **Gráficos**: Agregar gráficos en el dashboard
5. **Exportar datos**: Funcionalidad de exportar a Excel/PDF

## 🐛 Solución de Problemas

### "Cannot connect to API"
- Verifica que la API esté corriendo en el puerto 8000
- Revisa la consola del navegador para ver errores

### "Module not found"
- Ejecuta `npm install` en el directorio `frontend`

### Puerto 3000 ocupado
- Vite usará automáticamente el siguiente puerto disponible (3001, 3002, etc.)

---

¡El sistema está completo y funcional! 🎉
