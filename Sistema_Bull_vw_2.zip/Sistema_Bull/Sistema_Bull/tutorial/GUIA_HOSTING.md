# Guía de Hosting - Sistema Bull Bar

## Opciones de Hosting

### 1. 🏠 Hosting Local (Red LAN) - RECOMENDADO PARA PRUEBAS

**Ventajas:**
- ✅ Gratis
- ✅ Rápido de configurar
- ✅ Control total
- ✅ No requiere servicios externos

**Desventajas:**
- ❌ Solo accesible en tu red local
- ❌ Necesitas tener la computadora encendida

#### Pasos:

1. **Configurar la API para aceptar conexiones externas:**

   Edita `bull_bar/api/settings.py` o crea un archivo `.env`:
   ```env
   CORS_ORIGINS=["*"]
   ```

2. **Ejecutar la API en modo público:**
   ```bash
   # En lugar de localhost, usar 0.0.0.0
   uvicorn bull_bar.api.main:app --host 0.0.0.0 --port 8000
   ```

3. **Obtener tu IP local:**
   - Windows: `ipconfig` (busca "IPv4 Address")
   - Linux/Mac: `ifconfig` o `ip addr`

4. **Actualizar el frontend:**
   - Edita `web/shared/api.js`
   - Cambia `const API_BASE = 'http://localhost:8000';`
   - Por: `const API_BASE = 'http://TU_IP_LOCAL:8000';` (ej: `http://192.168.1.100:8000`)

5. **Servir el frontend:**
   ```bash
   # Desde la carpeta web/
   python -m http.server 8080
   ```

6. **Acceder desde otros dispositivos:**
   - URL: `http://TU_IP_LOCAL:8080`
   - Ejemplo: `http://192.168.1.100:8080`

---

### 2. ☁️ Hosting en la Nube (Accesible desde Internet)

#### Opción A: Railway.app (Recomendado - Gratis con límites)

**Backend (API):**
1. Crear cuenta en [Railway.app](https://railway.app)
2. Conectar tu repositorio GitHub
3. Configurar variables de entorno:
   - `JWT_SECRET`: Genera una clave secreta
   - `CORS_ORIGINS`: URL de tu frontend
4. Railway detectará automáticamente que es Python/FastAPI

**Frontend:**
1. Usar [Netlify](https://netlify.com) o [Vercel](https://vercel.com)
2. Subir carpeta `web/`
3. Configurar variable de entorno:
   - `VITE_API_URL` o editar `api.js` con la URL de Railway

#### Opción B: Render.com (Gratis con límites)

Similar a Railway, con plan gratuito que se "duerme" después de inactividad.

#### Opción C: PythonAnywhere (Gratis para principiantes)

1. Crear cuenta en [PythonAnywhere](https://www.pythonanywhere.com)
2. Subir tu código
3. Configurar aplicación web
4. Servir frontend desde carpeta estática

---

### 3. 🖥️ Servidor Propio/VPS

Si tienes un servidor o VPS (DigitalOcean, AWS, etc.):

1. Instalar Python, pip
2. Clonar repositorio
3. Instalar dependencias: `pip install -r bull_bar/api/requirements.txt`
4. Configurar nginx como proxy reverso
5. Usar PM2 o systemd para mantener la API corriendo

---

## Configuración Rápida para Hosting Local

### Script para Windows (iniciar_servidor_local.bat):

```batch
@echo off
echo Iniciando servidor local...
echo.

REM Obtener IP local
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
    set IP=%%a
    goto :found
)
:found
set IP=%IP:~1%
echo Tu IP local es: %IP%
echo.

REM Iniciar API
start "API Server" cmd /k "cd /d %~dp0 && python scripts\run_api.py"

REM Esperar un momento
timeout /t 3 /nobreak >nul

REM Iniciar servidor web
start "Web Server" cmd /k "cd /d %~dp0\web && python -m http.server 8080"

echo.
echo ========================================
echo Servidores iniciados!
echo.
echo Frontend: http://%IP%:8080
echo API: http://%IP%:8000
echo.
echo Presiona cualquier tecla para cerrar...
pause >nul
```

### Script para Linux/Mac (iniciar_servidor_local.sh):

```bash
#!/bin/bash

# Obtener IP local
IP=$(hostname -I | awk '{print $1}')

echo "Iniciando servidor local..."
echo "Tu IP local es: $IP"
echo ""

# Iniciar API en background
cd "$(dirname "$0")"
python3 scripts/run_api.py &
API_PID=$!

# Esperar un momento
sleep 3

# Iniciar servidor web en background
cd web
python3 -m http.server 8080 &
WEB_PID=$!

echo ""
echo "========================================"
echo "Servidores iniciados!"
echo ""
echo "Frontend: http://$IP:8080"
echo "API: http://$IP:8000"
echo ""
echo "Presiona Ctrl+C para detener..."
echo ""

# Esperar señal de interrupción
trap "kill $API_PID $WEB_PID; exit" INT TERM
wait
```

---

## Variables de Entorno Recomendadas

Crea un archivo `.env` en la raíz del proyecto:

```env
# API
JWT_SECRET=tu-clave-secreta-muy-segura-aqui
CORS_ORIGINS=["*"]
DEBUG=False

# Database (opcional, si quieres cambiar la ubicación)
SQLITE_PATH=bullbar.sqlite
```

---

## Seguridad para Producción

⚠️ **IMPORTANTE:** Antes de hostear públicamente:

1. ✅ Cambiar `JWT_SECRET` por una clave segura
2. ✅ Configurar `CORS_ORIGINS` con dominios específicos (no `["*"]`)
3. ✅ Usar HTTPS (certificado SSL)
4. ✅ Cambiar contraseñas por defecto
5. ✅ Configurar firewall
6. ✅ Hacer backups de la base de datos

---

## Próximos Pasos

1. **Para pruebas locales:** Usa la Opción 1 (Hosting Local)
2. **Para acceso desde internet:** Usa Railway + Netlify/Vercel
3. **Para producción:** Considera un VPS con dominio propio

¿Necesitas ayuda con alguna opción específica?

