import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Stock from './pages/Stock'
import Movimientos from './pages/Movimientos'
import Produccion from './pages/Produccion'
import Recetas from './pages/Recetas'
import Lotes from './pages/Lotes'
import Aprobaciones from './pages/Aprobaciones'
import PrivateRoute from './components/PrivateRoute'
import Layout from './components/Layout'

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <PrivateRoute>
                <Layout>
                  <Dashboard />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route
            path="/stock"
            element={
              <PrivateRoute>
                <Layout>
                  <Stock />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route
            path="/movimientos"
            element={
              <PrivateRoute>
                <Layout>
                  <Movimientos />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route
            path="/produccion"
            element={
              <PrivateRoute>
                <Layout>
                  <Produccion />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route
            path="/recetas"
            element={
              <PrivateRoute>
                <Layout>
                  <Recetas />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route
            path="/lotes"
            element={
              <PrivateRoute>
                <Layout>
                  <Lotes />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route
            path="/aprobaciones"
            element={
              <PrivateRoute requiredRole="ADMIN">
                <Layout>
                  <Aprobaciones />
                </Layout>
              </PrivateRoute>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  )
}

export default App
