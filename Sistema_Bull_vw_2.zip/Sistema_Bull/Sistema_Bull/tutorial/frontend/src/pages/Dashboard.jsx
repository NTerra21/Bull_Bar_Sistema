import { useEffect, useState } from 'react'
import api from '../services/api'
import './Dashboard.css'

const Dashboard = () => {
  const [stats, setStats] = useState({
    insumos: 0,
    barritas: 0,
    lotesActivos: 0,
    aprobacionesPendientes: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadStats()
  }, [])

  const loadStats = async () => {
    try {
      const [insumosRes, barritasRes, lotesRes, aprobacionesRes] = await Promise.all([
        api.get('/stock/insumos').catch(() => ({ data: [] })),
        api.get('/stock/barritas').catch(() => ({ data: [] })),
        api.get('/lotes?estado=activos').catch(() => ({ data: [] })),
        api.get('/aprobaciones?estado=pendiente').catch(() => ({ data: [] })),
      ])

      const totalInsumos = insumosRes.data.reduce((sum, item) => sum + item.cantidad, 0)
      const totalBarritas = barritasRes.data.reduce((sum, item) => sum + item.cantidad, 0)

      setStats({
        insumos: totalInsumos,
        barritas: totalBarritas,
        lotesActivos: lotesRes.data.length,
        aprobacionesPendientes: aprobacionesRes.data.length,
      })
    } catch (error) {
      console.error('Error cargando estadísticas:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div>Cargando estadísticas...</div>
  }

  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <div className="stats-grid">
        <div className="stat-card">
          <h3>Stock Insumos</h3>
          <p className="stat-value">{stats.insumos.toFixed(2)} kg</p>
        </div>
        <div className="stat-card">
          <h3>Stock Barritas</h3>
          <p className="stat-value">{stats.barritas.toFixed(0)} unidades</p>
        </div>
        <div className="stat-card">
          <h3>Lotes Activos</h3>
          <p className="stat-value">{stats.lotesActivos}</p>
        </div>
        <div className="stat-card">
          <h3>Aprobaciones Pendientes</h3>
          <p className="stat-value">{stats.aprobacionesPendientes}</p>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
