import { useEffect, useState } from 'react'
import api from '../services/api'
import './Aprobaciones.css'

const Aprobaciones = () => {
  const [aprobaciones, setAprobaciones] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('pendiente')

  useEffect(() => {
    loadAprobaciones()
  }, [activeTab])

  const loadAprobaciones = async () => {
    try {
      const estado = activeTab === 'pendiente' ? 'pendiente' : activeTab === 'aprobada' ? 'aprobada' : 'rechazada'
      const response = await api.get(`/aprobaciones?estado=${estado}`)
      setAprobaciones(response.data)
    } catch (error) {
      console.error('Error cargando aprobaciones:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAprobar = async (id) => {
    if (!confirm('¿Estás seguro de aprobar esta solicitud?')) return

    try {
      await api.post(`/aprobaciones/${id}/aprobar`, { motivo: 'Aprobado' })
      loadAprobaciones()
      alert('Solicitud aprobada y ejecutada')
    } catch (error) {
      alert(error.response?.data?.detail || 'Error al aprobar solicitud')
    }
  }

  const handleRechazar = async (id) => {
    const motivo = prompt('Ingrese el motivo del rechazo:')
    if (!motivo) return

    try {
      await api.post(`/aprobaciones/${id}/rechazar`, { motivo })
      loadAprobaciones()
      alert('Solicitud rechazada')
    } catch (error) {
      alert(error.response?.data?.detail || 'Error al rechazar solicitud')
    }
  }

  if (loading) {
    return <div>Cargando aprobaciones...</div>
  }

  return (
    <div className="aprobaciones-page">
      <h1>Aprobaciones</h1>
      <div className="tabs">
        <button
          className={activeTab === 'pendiente' ? 'active' : ''}
          onClick={() => setActiveTab('pendiente')}
        >
          Pendientes
        </button>
        <button
          className={activeTab === 'aprobada' ? 'active' : ''}
          onClick={() => setActiveTab('aprobada')}
        >
          Aprobadas
        </button>
        <button
          className={activeTab === 'rechazada' ? 'active' : ''}
          onClick={() => setActiveTab('rechazada')}
        >
          Rechazadas
        </button>
      </div>
      <div className="card">
        <h2>
          Solicitudes {activeTab === 'pendiente' ? 'Pendientes' : activeTab === 'aprobada' ? 'Aprobadas' : 'Rechazadas'}
        </h2>
        {aprobaciones.length === 0 ? (
          <p>No hay solicitudes {activeTab === 'pendiente' ? 'pendientes' : activeTab === 'aprobada' ? 'aprobadas' : 'rechazadas'}</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Tipo</th>
                <th>Usuario</th>
                <th>Fecha</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {aprobaciones.map((aprob) => (
                <tr key={aprob.id}>
                  <td>{aprob.id.substring(0, 8)}...</td>
                  <td>{aprob.tipo}</td>
                  <td>{aprob.usuario_creador_nombre || aprob.usuario_creador_id}</td>
                  <td>{new Date(aprob.timestamp_creacion).toLocaleString()}</td>
                  <td>
                    <span className={`badge badge-${aprob.estado === 'APROBADA' ? 'success' : aprob.estado === 'RECHAZADA' ? 'danger' : 'warning'}`}>
                      {aprob.estado}
                    </span>
                  </td>
                  <td>
                    {aprob.estado === 'PENDIENTE' && (
                      <>
                        <button
                          className="btn btn-success"
                          onClick={() => handleAprobar(aprob.id)}
                          style={{ marginRight: '0.5rem' }}
                        >
                          Aprobar
                        </button>
                        <button
                          className="btn btn-danger"
                          onClick={() => handleRechazar(aprob.id)}
                        >
                          Rechazar
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

export default Aprobaciones
