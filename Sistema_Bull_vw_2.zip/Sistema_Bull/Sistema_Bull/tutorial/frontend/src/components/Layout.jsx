import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import './Layout.css'

const Layout = ({ children }) => {
  const { user, logout, isAdmin } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const isActive = (path) => location.pathname === path

  return (
    <div className="layout">
      <nav className="navbar">
        <div className="navbar-brand">
          <h1>🐂 Bull Bar</h1>
        </div>
        <div className="navbar-menu">
          <Link to="/" className={isActive('/') ? 'active' : ''}>
            Dashboard
          </Link>
          <Link to="/stock" className={isActive('/stock') ? 'active' : ''}>
            Stock
          </Link>
          <Link to="/movimientos" className={isActive('/movimientos') ? 'active' : ''}>
            Movimientos
          </Link>
          <Link to="/produccion" className={isActive('/produccion') ? 'active' : ''}>
            Producción
          </Link>
          <Link to="/recetas" className={isActive('/recetas') ? 'active' : ''}>
            Recetas
          </Link>
          <Link to="/lotes" className={isActive('/lotes') ? 'active' : ''}>
            Lotes
          </Link>
          {isAdmin && (
            <Link to="/aprobaciones" className={isActive('/aprobaciones') ? 'active' : ''}>
              Aprobaciones
            </Link>
          )}
        </div>
        <div className="navbar-user">
          <span>{user?.username}</span>
          <span className="badge badge-info">{user?.rol}</span>
          <button onClick={handleLogout} className="btn btn-secondary">
            Salir
          </button>
        </div>
      </nav>
      <main className="main-content">{children}</main>
    </div>
  )
}

export default Layout
