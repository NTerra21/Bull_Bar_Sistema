# Bull Bar Frontend

Frontend web para el sistema Bull Bar, construido con React + Vite.

## Instalación

```bash
cd frontend
npm install
```

## Desarrollo

```bash
npm run dev
```

El frontend estará disponible en http://localhost:3000

## Build para Producción

```bash
npm run build
```

Los archivos se generarán en la carpeta `dist/`.

## Estructura

```
frontend/
├── src/
│   ├── components/     # Componentes reutilizables
│   ├── contexts/       # Context API (Auth)
│   ├── pages/          # Páginas principales
│   ├── services/       # Cliente API
│   └── App.jsx         # Componente principal
├── index.html
└── vite.config.js      # Configuración de Vite
```

## Configuración

El frontend está configurado para conectarse a la API en `http://localhost:8000` mediante un proxy en desarrollo.

Para cambiar la URL de la API, edita `vite.config.js`.
