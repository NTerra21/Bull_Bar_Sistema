#!/usr/bin/env python
"""
Script para abrir el sistema web Bull Bar en el navegador.
Verifica que la API esté corriendo antes de abrir.
"""
import webbrowser
import os
import sys
import time
from pathlib import Path
import urllib.request
import urllib.error

def check_api_running():
    """Verifica si la API está corriendo."""
    try:
        response = urllib.request.urlopen('http://localhost:8000/health', timeout=2)
        return response.status == 200
    except (urllib.error.URLError, OSError):
        return False

def open_web_system():
    """Abre el sistema web en el navegador."""
    # Obtener la ruta del archivo HTML
    script_dir = Path(__file__).parent.absolute()
    html_file = script_dir / "web" / "index.html"
    
    # Verificar que existe
    if not html_file.exists():
        print("ERROR: No se encuentra el archivo index.html")
        print(f"   Buscado en: {html_file}")
        return False
    
    # Verificar API
    print("Verificando que la API este corriendo...")
    if not check_api_running():
        print("ADVERTENCIA: La API no esta corriendo en http://localhost:8000")
        print("")
        print("   Para iniciar la API, ejecuta en otra terminal:")
        print("   python run_api.py")
        print("")
        respuesta = input("   Quieres continuar de todas formas? (s/n): ")
        if respuesta.lower() != 's':
            print("   Operacion cancelada.")
            return False
    else:
        print("OK - API esta corriendo")
    
    # Convertir a URL file://
    html_path = html_file.as_uri()
    
    print("")
    print("=" * 60)
    print("Abriendo Sistema Bull Bar Web")
    print("=" * 60)
    print(f"Archivo: {html_file}")
    print(f"URL: {html_path}")
    print("")
    print("Si el navegador no se abre automaticamente,")
    print("copia esta ruta y abrela manualmente:")
    print(f"   {html_path}")
    print("=" * 60)
    print("")
    
    # Abrir en el navegador
    try:
        webbrowser.open(html_path)
        print("Sistema web abierto en el navegador")
        print("")
        print("Login:")
        print("   Usuario: admin")
        print("   Password: admin")
        return True
    except Exception as e:
        print(f"Error al abrir el navegador: {e}")
        print("")
        print("   Abre manualmente el archivo:")
        print(f"   {html_file}")
        return False

if __name__ == "__main__":
    try:
        open_web_system()
        print("")
        input("Presiona Enter para cerrar...")
    except (EOFError, KeyboardInterrupt):
        # Si se ejecuta sin terminal interactiva, no esperar input
        pass

