# Sistema_Bull (esqueleto inicial)

Este zip trae un esqueleto **modular** en Python con:
- Núcleo (core): modelos + enums
- Stock: ledger de movimientos (confirmados y pendientes)
- Compra/Venta: servicios
- Producción: flujo rápido vs guiado (pendiente → confirmar)
- Infra: repositorios en memoria (para pruebas rápidas)
- App: demo por consola

## Ejecutar demo
```bash
python -m bull_bar.app.main
```

## Idea base
**No se edita stock directo.** El stock se calcula por **MovimientosStock**.
