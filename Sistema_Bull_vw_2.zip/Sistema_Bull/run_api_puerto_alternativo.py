#!/usr/bin/env python
"""
Script para ejecutar la API de Bull Bar en un puerto alternativo (8001).
Útil si el puerto 8000 está ocupado.
"""
import sys
import os
from pathlib import Path

# Obtener el directorio raíz del proyecto
ROOT_DIR = Path(__file__).parent.absolute()
BULL_BAR_DIR = ROOT_DIR / "Sistema_Bull"

if not BULL_BAR_DIR.exists():
    BULL_BAR_DIR = ROOT_DIR

if str(BULL_BAR_DIR) not in sys.path:
    sys.path.insert(0, str(BULL_BAR_DIR))

os.environ["PYTHONPATH"] = str(BULL_BAR_DIR) + os.pathsep + os.environ.get("PYTHONPATH", "")

try:
    from bull_bar.api.main import app
    print("✅ Módulo bull_bar importado correctamente")
except ImportError as e:
    print(f"❌ Error importando bull_bar: {e}")
    sys.exit(1)

if __name__ == "__main__":
    import uvicorn
    
    PORT = 8001  # Puerto alternativo
    
    print("=" * 60)
    print("🚀 Iniciando Bull Bar API (Puerto Alternativo)")
    print("=" * 60)
    print(f"📁 Directorio: {BULL_BAR_DIR}")
    print(f"🐍 Python: {sys.version.split()[0]}")
    print()
    print(f"🌐 Servidor: http://localhost:{PORT}")
    print(f"📚 Documentación: http://localhost:{PORT}/docs")
    print(f"💚 Health Check: http://localhost:{PORT}/health")
    print()
    print("Presiona Ctrl+C para detener el servidor")
    print("=" * 60)
    print()
    
    try:
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=PORT,
            reload=False,
            log_level="info"
        )
    except KeyboardInterrupt:
        print("\n\n👋 Servidor detenido. ¡Hasta luego!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

