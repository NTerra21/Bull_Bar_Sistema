# Tests UI movidos aquí. Ejecutar con:
#   py -m tests.ui.run_tests
