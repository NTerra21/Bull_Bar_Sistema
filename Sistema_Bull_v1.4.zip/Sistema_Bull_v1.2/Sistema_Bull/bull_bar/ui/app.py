import tkinter as tk
from tkinter import ttk, messagebox
from uuid import uuid4
import os
import sys

# ============================================
# CONFIGURACIÓN DE RUTAS - DEBE SER LO PRIMERO
# ============================================
# Asegurar que el directorio raíz del proyecto esté en sys.path
# Esto permite que Python encuentre el módulo 'bull_bar'
_this_file = os.path.abspath(__file__)
_project_root = os.path.abspath(os.path.join(os.path.dirname(_this_file), "..", ".."))

if _project_root not in sys.path:
    sys.path.insert(0, _project_root)
    print(f"[DEBUG] app.py: Añadido al sys.path: {_project_root}")

# ============================================
# TESTIGO 1: Inicio del módulo
# ============================================
print("[DEBUG] app.py: Iniciando importaciones...")
print(f"[DEBUG] app.py: __file__ = {_this_file}")
print(f"[DEBUG] app.py: project_root = {_project_root}")
print(f"[DEBUG] app.py: Directorio actual = {os.getcwd()}")
print(f"[DEBUG] app.py: sys.path[0:3] = {sys.path[0:3]}")

# ============================================
# Importaciones del core
# ============================================
print("[DEBUG] app.py: Importando módulos del core...")
try:
    from bull_bar.stock.service import StockLedger
    print("[DEBUG] app.py: [OK] StockLedger importado")
except Exception as e:
    print(f"[DEBUG] app.py: [ERROR] Error importando StockLedger: {e}")
    raise

try:
    from bull_bar.compra_venta.services import PurchaseService, SaleService
    print("[DEBUG] app.py: [OK] PurchaseService, SaleService importados")
except Exception as e:
    print(f"[DEBUG] app.py: [ERROR] Error importando PurchaseService/SaleService: {e}")
    raise

try:
    from bull_bar.produccion.services import ProductionService
    print("[DEBUG] app.py: [OK] ProductionService importado")
except Exception as e:
    print(f"[DEBUG] app.py: [ERROR] Error importando ProductionService: {e}")
    raise

try:
    from bull_bar.core.enums import ClienteProveedor as ClienteProveedorTipo
    from bull_bar.core.models import Producto, Deposito, ClienteProveedor as ClienteProveedorModel
    print("[DEBUG] app.py: [OK] Core models importados")
except Exception as e:
    print(f"[DEBUG] app.py: [ERROR] Error importando core models: {e}")
    raise

# ============================================
# Importaciones de tabs y ventanas
# ============================================
print("[DEBUG] app.py: Importando tabs y ventanas...")
try:
    from bull_bar.ui.pages.movimientos_page import MovimientosPage
    print("[DEBUG] app.py: [OK] MovimientosPage importado")
except Exception as e:
    print(f"[DEBUG] app.py: [ERROR] Error importando MovimientosPage: {e}")
    raise

try:
    from bull_bar.ui.pages.produccion_page import ProduccionPage
    print("[DEBUG] app.py: [OK] ProduccionPage importado")
except Exception as e:
    print(f"[DEBUG] app.py: [ERROR] Error importando ProduccionPage: {e}")
    raise

try:
    from bull_bar.ui.windows.recetas_window import RecetasWindow
    print("[DEBUG] app.py: [OK] RecetasWindow importado")
except Exception as e:
    print(f"[DEBUG] app.py: [ERROR] Error importando RecetasWindow: {e}")
    raise

try:
    from bull_bar.ui.windows.stock_window import StockWindow
    print("[DEBUG] app.py: [OK] StockWindow importado")
except Exception as e:
    print(f"[DEBUG] app.py: [ERROR] Error importando StockWindow: {e}")
    raise

# Importación de create_historial_button con manejo de errores
try:
    from bull_bar.ui.panels.historial_panel import create_historial_button
    print("[DEBUG] app.py: [OK] create_historial_button importado")
except ImportError as e:
    print(f"[DEBUG] app.py: [WARN] Error importando create_historial_button: {e}, usando función dummy")
    # Si falla la importación, crear una función dummy
    def create_historial_button(parent, ctx, text="Ver Historial"):
        import tkinter as tk
        from tkinter import ttk
        btn = ttk.Button(parent, text=text, command=lambda: None)
        return btn

print("[DEBUG] app.py: Todas las importaciones completadas")


def build_ctx():
    print("[DEBUG] build_ctx: Iniciando construcción del contexto...")
    ledger = StockLedger()
    print("[DEBUG] build_ctx: StockLedger creado")
    
    # DB: path absoluto para que no dependa del "working directory"
    # Desde bull_bar/ui/app.py -> .. -> bull_bar -> .. -> Sistema_Bull (raíz)
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    db_path = os.path.join(project_root, "bullbar.sqlite")
    
    print(f"[DEBUG] build_ctx: project_root = {project_root}")
    print(f"[DEBUG] build_ctx: db_path = {db_path}")
    print(f"[DEBUG] build_ctx: db_path existe? {os.path.exists(db_path)}")
    
    purchase_svc = PurchaseService(ledger, db_path=db_path)
    sale_svc = SaleService(ledger, db_path=db_path)
    prod_svc = ProductionService(ledger, db_path=db_path)

    depo = Deposito(id=str(uuid4()), nombre="Deposito Principal")
    prov = ClienteProveedorModel(
        id=str(uuid4()),
        tipo=ClienteProveedorTipo.PROVEEDOR,
        razon_social="Proveedor X",
    )
    cli = ClienteProveedorModel(
        id=str(uuid4()),
        tipo=ClienteProveedorTipo.CLIENTE,
        razon_social="Cliente Y",
    )

    from bull_bar.infra.sqlite_recetas import list_products
    from bull_bar.stock.adjustment import StockAdjustmentService

    products = {}
    for p in list_products(db_path):
        prod = Producto(
            id=p.get("uuid") or str(uuid4()),
            codigo=p.get("codigo"),
            nombre=p.get("nombre"),
            unidad_medida="u",
        )
        if prod.codigo:
            products[prod.codigo] = prod

    # NOTA: No se crean ajustes automáticos al iniciar.
    # Los ajustes solo se registran cuando el usuario los realiza explícitamente.

    return {
        "ledger": ledger,
        "purchase_service": purchase_svc,
        "sale_service": sale_svc,
        "production_service": prod_svc,
        "depo": depo,
        "prov": prov,
        "cli": cli,
        "products": products,
        "db_path": db_path,
        "pending_orders": [],
    }

def _load_logo_photoimage(logo_path: str, max_height: int = 48):
    """
    Carga un PNG/GIF con Tkinter y lo achica (aprox) usando subsample.
    No usa PIL.
    """
    try:
        from tkinter import PhotoImage
        if not logo_path or not os.path.exists(logo_path):
            return None

        img = PhotoImage(file=logo_path)
        h = img.height()
        if h <= 0:
            return img

        # factor entero para bajar hasta max_height
        factor = max(1, int(h / max_height))
        if factor > 1:
            img = img.subsample(factor, factor)

        return img
    except Exception:
        return None


def _write_simple_error_log(error: Exception, context: str = ""):
    """Escribe un error simple al log sin depender de error_logger."""
    try:
        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        log_path = os.path.join(project_root, "error_log.txt")
        from datetime import datetime
        import traceback
        
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write(f"FECHA Y HORA: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 80 + "\n")
            if context:
                f.write(f"CONTEXTO: {context}\n")
                f.write("-" * 80 + "\n")
            f.write(f"ERROR: {type(error).__name__}: {str(error)}\n")
            f.write("-" * 80 + "\n")
            f.write("TRACEBACK:\n")
            f.write("".join(traceback.format_exception(type(error), error, error.__traceback__)))
            f.write("\n" + "=" * 80 + "\n\n")
    except:
        pass  # Si falla el logging, no hacer nada


def main():
    print("[DEBUG] main: ========================================")
    print("[DEBUG] main: INICIANDO APLICACIÓN")
    print("[DEBUG] main: ========================================")
    print(f"[DEBUG] main: Directorio de trabajo actual: {os.getcwd()}")
    print(f"[DEBUG] main: __file__ = {__file__}")
    
    # Capturar errores de inicialización básica
    print("[DEBUG] main: Creando ventana principal Tk...")
    try:
        root = tk.Tk()
        root.title("Bull Bar")
        print("[DEBUG] main: [OK] Ventana principal Tk creada")
    except Exception as e:
        print(f"[DEBUG] main: [ERROR] Error creando ventana: {e}")
        _write_simple_error_log(e, "Creando ventana principal Tk")
        print(f"Error crítico al crear ventana: {e}")
        return
    
    # Obtener db_path
    print("[DEBUG] main: Calculando ruta de base de datos...")
    try:
        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        db_path = os.path.join(project_root, "bullbar.sqlite")
        print(f"[DEBUG] main: project_root = {project_root}")
        print(f"[DEBUG] main: db_path = {db_path}")
        print(f"[DEBUG] main: db_path existe? {os.path.exists(db_path)}")
    except Exception as e:
        print(f"[DEBUG] main: [ERROR] Error obteniendo ruta de BD: {e}")
        _write_simple_error_log(e, "Obteniendo ruta de base de datos")
        from tkinter import messagebox
        messagebox.showerror("Error", f"Error obteniendo ruta de BD:\n{str(e)}\n\nRevisa error_log.txt")
        root.destroy()
        return
    
    # Inicializar base de datos y crear usuario admin si no existe
    print("[DEBUG] main: Inicializando base de datos...")
    try:
        from bull_bar.infra.auth import _ensure
        print("[DEBUG] main: [OK] Módulo auth importado")
        _ensure(db_path)
        print("[DEBUG] main: [OK] Base de datos inicializada")
    except Exception as e:
        print(f"[DEBUG] main: [ERROR] Error inicializando BD: {e}")
        _write_simple_error_log(e, "Inicializando base de datos al iniciar aplicación")
        try:
            from bull_bar.infra.error_logger import log_error
            log_error(e, context="Inicializando base de datos al iniciar aplicación", 
                     extra_info={"db_path": db_path})
        except:
            pass  # Si error_logger falla, ya se escribió con _write_simple_error_log
        from tkinter import messagebox
        messagebox.showerror("Error", f"Error inicializando base de datos:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")
        root.destroy()
        return
    
    # Variable para almacenar usuario autenticado
    usuario_autenticado = {"rol": "USUARIO"}  # Default
    print(f"[DEBUG] main: Usuario por defecto: {usuario_autenticado}")
    
    def on_login_success(usuario: dict):
        """Callback cuando el login es exitoso."""
        print(f"[DEBUG] on_login_success: Usuario autenticado: {usuario.get('username', 'N/A')}")
        nonlocal usuario_autenticado
        usuario_autenticado = usuario
        
        # IMPORTANTE: Mostrar la ventana principal ANTES de construir la UI
        print("[DEBUG] on_login_success: Mostrando ventana principal...")
        try:
            root.deiconify()
            root.update()
            root.update_idletasks()
            print("[DEBUG] on_login_success: [OK] Ventana principal mostrada")
        except Exception as e:
            print(f"[ERROR] on_login_success: Error mostrando ventana: {e}")
            import traceback
            traceback.print_exc()
        
        print("[DEBUG] on_login_success: Construyendo UI principal...")
        try:
            _build_main_ui(root, usuario_autenticado, db_path)
            print("[DEBUG] on_login_success: [OK] UI principal construida")
        except Exception as e:
            print(f"[ERROR] on_login_success: Error construyendo UI: {e}")
            import traceback
            traceback.print_exc()
            from tkinter import messagebox
            messagebox.showerror("Error", f"Error al construir la interfaz:\n{str(e)}\n\nRevisa la consola para más detalles.")
            return
        
        # Asegurar que la ventana esté visible y enfocada
        print("[DEBUG] on_login_success: Forzando visibilidad de ventana principal...")
        try:
            root.lift()
            root.focus_force()
            root.attributes('-topmost', True)  # Traer al frente temporalmente
            root.update()
            root.update_idletasks()
            root.attributes('-topmost', False)  # Quitar topmost después
            root.update()
            
            # Verificar visibilidad
            is_viewable = root.winfo_viewable()
            print(f"[DEBUG] on_login_success: root.winfo_viewable() = {is_viewable}")
            if not is_viewable:
                print("[DEBUG] on_login_success: [WARN] Ventana no es viewable, intentando corregir...")
                root.deiconify()
                root.lift()
                root.update()
        except Exception as e:
            print(f"[ERROR] on_login_success: Error forzando visibilidad: {e}")
            import traceback
            traceback.print_exc()
        
        print("[DEBUG] on_login_success: [OK] Ventana principal visible y enfocada")
    
    # Mostrar login
    print("[DEBUG] main: Importando LoginWindow...")
    try:
        from bull_bar.ui.windows.login_window import LoginWindow
        print("[DEBUG] main: [OK] LoginWindow importado")
        
        # IMPORTANTE: NO ocultar root hasta después de crear login_win
        # Crear ventana de login PRIMERO
        print("[DEBUG] main: Creando ventana de login...")
        login_win = LoginWindow(root, db_path, on_login_success)
        print("[DEBUG] main: [OK] Ventana de login creada")
        
        # AHORA ocultar la ventana principal
        print("[DEBUG] main: Ocultando ventana principal...")
        root.withdraw()
        print("[DEBUG] main: [OK] Ventana principal ocultada")
        
        # Si se cierra el login sin autenticar, cerrar app
        def on_login_close():
            print("[DEBUG] on_login_close: Ventana de login cerrada")
            if not usuario_autenticado.get("id"):
                print("[DEBUG] on_login_close: Usuario no autenticado, cerrando aplicación...")
                root.destroy()
            else:
                print("[DEBUG] on_login_close: Usuario ya autenticado, no hacer nada")
        
        login_win.protocol("WM_DELETE_WINDOW", on_login_close)
        print("[DEBUG] main: [OK] Protocolo WM_DELETE_WINDOW configurado")
        
        # Asegurar que la ventana de login sea visible
        print("[DEBUG] main: Forzando visibilidad de ventana de login...")
        # Forzar actualización y visibilidad
        root.update()
        root.update_idletasks()
        login_win.update()
        login_win.update_idletasks()
        
        # Múltiples intentos para asegurar visibilidad
        login_win.deiconify()
        login_win.lift()
        login_win.focus_force()
        login_win.attributes('-topmost', True)
        login_win.update()
        login_win.update_idletasks()
        login_win.attributes('-topmost', False)
        
        # Verificar que la ventana sea visible
        try:
            visible = login_win.winfo_viewable()
            print(f"[DEBUG] main: Ventana de login es visible? {visible}")
            if not visible:
                print("[DEBUG] main: [WARN] Ventana no es visible, intentando forzar...")
                login_win.deiconify()
                login_win.lift()
                login_win.focus_force()
        except Exception as e:
            print(f"[DEBUG] main: [WARN] Error verificando visibilidad: {e}")
        
        print("[DEBUG] main: [OK] Ventana de login configurada y debería ser visible")
        
    except Exception as e:
        _write_simple_error_log(e, "Iniciando ventana de login")
        try:
            from bull_bar.infra.error_logger import log_error
            log_error(e, context="Iniciando ventana de login", 
                     extra_info={"db_path": db_path})
        except:
            pass  # Si error_logger falla, ya se escribió con _write_simple_error_log
        # Intentar mostrar error en ventana si es posible
        try:
            root.deiconify()
            from tkinter import messagebox
            messagebox.showerror("Error", f"No se pudo iniciar la aplicación:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")
        except:
            pass
        root.destroy()
        return
    
    # Iniciar el loop principal
    print("[DEBUG] main: ========================================")
    print("[DEBUG] main: INICIANDO MAINLOOP (la aplicación está lista)")
    print("[DEBUG] main: ========================================")
    try:
        root.mainloop()
        print("[DEBUG] main: Mainloop terminado normalmente")
    except KeyboardInterrupt:
        print("[DEBUG] main: Interrupción por teclado (Ctrl+C)")
        pass
    except Exception as e:
        print(f"[DEBUG] main: [ERROR] Error en mainloop: {e}")
        import traceback
        traceback.print_exc()
        _write_simple_error_log(e, "En el loop principal de la aplicación (mainloop)")
        try:
            from bull_bar.infra.error_logger import log_error
            log_error(e, context="En el loop principal de la aplicación (mainloop)")
        except:
            pass


def _build_main_ui(root, usuario: dict, db_path: str):
    """Construye la UI principal después del login."""
    print("[DEBUG] _build_main_ui: ========================================")
    print("[DEBUG] _build_main_ui: CONSTRUYENDO UI PRINCIPAL")
    print("[DEBUG] _build_main_ui: ========================================")
    print(f"[DEBUG] _build_main_ui: Usuario: {usuario.get('username', 'N/A')}")
    print(f"[DEBUG] _build_main_ui: db_path: {db_path}")
    
    # Limpiar ventana si ya tenía contenido
    for widget in root.winfo_children():
        widget.destroy()
    
    root.title("Bull Bar")
    print("[DEBUG] _build_main_ui: [OK] Ventana limpiada y título configurado")

    # --- ICONO (plumita) ---
    print("[DEBUG] _build_main_ui: Buscando iconos...")
    icon_ico = os.path.join(os.path.dirname(__file__), "..", "img", "Bull_Bar.ico")
    icon_png = os.path.join(os.path.dirname(__file__), "..", "img", "Bull_Bar.png")
    print(f"[DEBUG] _build_main_ui: icon_ico = {icon_ico} (existe: {os.path.exists(icon_ico)})")
    print(f"[DEBUG] _build_main_ui: icon_png = {icon_png} (existe: {os.path.exists(icon_png)})")

    try:
        if os.path.exists(icon_ico):
            root.iconbitmap(icon_ico)  # mejor para Windows/taskbar
            print("[DEBUG] _build_main_ui: [OK] Icono .ico cargado")
        elif os.path.exists(icon_png):
            img_icon = tk.PhotoImage(file=icon_png)
            root.iconphoto(True, img_icon)
            root._img_icon = img_icon  # mantener referencia
            print("[DEBUG] _build_main_ui: [OK] Icono .png cargado")
        else:
            print("[DEBUG] _build_main_ui: [WARN] No se encontró ningún icono")
    except Exception as e:
        print(f"[DEBUG] _build_main_ui: [ERROR] Error cargando icono: {e}")
        pass


    # --- Contexto (servicios / db path) ---
    print("[DEBUG] _build_main_ui: Construyendo contexto...")
    ctx = build_ctx()
    ctx["usuario_actual"] = usuario  # Agregar usuario al contexto
    print("[DEBUG] _build_main_ui: [OK] Contexto construido")

    from bull_bar.infra.auth import tiene_permiso, RolUsuario
    
    # =========================
    # ESTRUCTURA PRINCIPAL CON GRID (Single-Window + Page Router)
    # =========================
    # Configurar root para usar grid
    root.grid_rowconfigure(0, weight=0)  # navbar_frame (no expande)
    root.grid_rowconfigure(1, weight=1)  # content_container (expande)
    root.grid_columnconfigure(0, weight=1)
    
    # =========================
    # NAVBAR FRAME (row 0)
    # =========================
    navbar_frame = tk.Frame(root)
    navbar_frame.grid(row=0, column=0, sticky="ew", padx=6, pady=6)
    navbar_frame.grid_columnconfigure(1, weight=1)  # Para que el espacio entre logo y usuario se expanda
    
    # --- Logo + Título ---
    title = tk.Label(navbar_frame, text="Bull Bar", font=("Helvetica", 18, "bold"))
    
    print("[DEBUG] _build_main_ui: Buscando logo...")
    logo_candidates = [
        os.path.join(os.path.dirname(__file__), "..", "img", "Bull_Bar.png"),
        os.path.join(os.path.dirname(__file__), "..", "img", "Bull_Bar.gif"),
        os.path.join(os.path.dirname(__file__), "..", "img", "bull_bar_logo.png"),
        os.path.join(os.path.dirname(__file__), "..", "img", "logo.png"),
    ]
    for i, candidate in enumerate(logo_candidates):
        exists = os.path.exists(candidate)
        print(f"[DEBUG] _build_main_ui: logo_candidate[{i}] = {candidate} (existe: {exists})")
    
    logo_path = next((p for p in logo_candidates if os.path.exists(p)), "")
    print(f"[DEBUG] _build_main_ui: logo_path seleccionado = {logo_path}")

    logo_img = _load_logo_photoimage(logo_path, max_height=48)
    if logo_img:
        title.config(image=logo_img, compound="left")
        title.image = logo_img  # MUY importante: mantener referencia
        print("[DEBUG] _build_main_ui: [OK] Logo cargado")
    else:
        print("[DEBUG] _build_main_ui: [WARN] No se pudo cargar el logo")

    title.grid(row=0, column=0, sticky="w", padx=(4, 20))
    
    # --- Botones de navegación ---
    btns = tk.Frame(navbar_frame)
    btns.grid(row=0, column=1, sticky="w", padx=(0, 20))
    
    # --- Panel derecho: Usuario + Avisos ---
    header_right_frame = tk.Frame(navbar_frame)
    header_right_frame.grid(row=0, column=2, sticky="e", padx=10)
    
    # Mostrar usuario actual
    user_label = tk.Label(header_right_frame, text=f"Usuario: {usuario.get('username', 'N/A')} ({usuario.get('rol', 'N/A')})", 
                         font=("Helvetica", 9), foreground="gray")
    user_label.pack(anchor="e", pady=(0, 4))
    
    # Panel de avisos
    notices_frame = ttk.Frame(header_right_frame)
    notices_frame.pack(anchor="e", fill="x")
    
    # Cargar ícono de exclamación para avisos (si existe)
    notice_icon = None
    if usuario.get("rol") == RolUsuario.ADMIN.value:
        try:
            icon_path = os.path.join(os.path.dirname(__file__), "..", "..", "img", "exclamacion.png")
            if os.path.exists(icon_path):
                notice_icon = tk.PhotoImage(file=icon_path)
                # Reducir tamaño si es muy grande (16px)
                if notice_icon.width() > 16 or notice_icon.height() > 16:
                    factor = max(1, int(max(notice_icon.width(), notice_icon.height()) / 16))
                    notice_icon = notice_icon.subsample(factor, factor)
                # Guardar referencia
                root._notice_icon = notice_icon
        except Exception as e:
            print(f"[DEBUG] _build_main_ui: No se pudo cargar ícono para avisos: {e}")
    
    # Variable para el texto de avisos
    notice_var = tk.StringVar(value="Sin avisos")
    
    # Frame para el label de avisos (permite agregar ícono)
    notice_content_frame = tk.Frame(notices_frame)
    notice_content_frame.pack(anchor="e")
    
    # Label de avisos (sin ícono inicialmente)
    notice_label = ttk.Label(notice_content_frame, textvariable=notice_var, font=("Helvetica", 8), 
                            foreground="gray", wraplength=200, justify="right", cursor="hand2")
    notice_label.pack(anchor="e")
    
    # Variable para saber si hay pendientes (para hacer clickeable)
    tiene_pendientes = tk.BooleanVar(value=False)
    
    # Función para navegar a Aprobaciones
    def ir_a_aprobaciones(event=None):
        """Navega a la pestaña de Aprobaciones en Movimientos."""
        if tiene_pendientes.get():
            show_movimientos()
            # Si la página de movimientos ya existe, seleccionar pestaña Aprobaciones
            if "movimientos" in pages:
                try:
                    movimientos_page = pages["movimientos"]
                    if hasattr(movimientos_page, 'movimientos_notebook'):
                        # Buscar el índice de la pestaña Aprobaciones
                        notebook = movimientos_page.movimientos_notebook
                        for i in range(notebook.index("end")):
                            tab_text = notebook.tab(i, "text")
                            if "Aprobaciones" in tab_text:
                                notebook.select(i)
                                break
                except Exception as e:
                    print(f"[ERROR] ir_a_aprobaciones: Error: {e}")
    
    # Bind click en el label de avisos
    notice_label.bind("<Button-1>", ir_a_aprobaciones)
    
    # Función para actualizar avisos
    def update_notices():
        """Actualiza el panel de avisos con información de pendientes."""
        if usuario.get("rol") != RolUsuario.ADMIN.value:
            notice_var.set("Sin avisos")
            tiene_pendientes.set(False)
            notice_label.config(cursor="arrow")
            return
        
        avisos = []
        count_pendientes = 0
        
        try:
            from bull_bar.infra.sqlite_produccion_pendientes import contar_pendientes
            count_pendientes = contar_pendientes(ctx["db_path"], estado="PENDIENTE_APROBACION")
            
            if count_pendientes > 0:
                aviso_texto = f"⚠ Aprobaciones pendientes: {count_pendientes}"
                avisos.append(aviso_texto)
                tiene_pendientes.set(True)
        except Exception as e:
            print(f"[ERROR] update_notices: Error contando pendientes: {e}")
            tiene_pendientes.set(False)
        
        # Si hay avisos, mostrarlos (máximo 3 líneas)
        if avisos:
            texto_final = "\n".join(avisos[:3])  # Máximo 3 líneas
            notice_var.set(texto_final)
            # Cambiar color a naranja/amarillo si hay avisos
            notice_label.config(foreground="#d97706", cursor="hand2")
            
            # Agregar ícono si existe y no está ya agregado
            if notice_icon and not hasattr(notice_content_frame, '_icon_added'):
                # Crear label con ícono
                icon_label = ttk.Label(notice_content_frame, image=notice_icon)
                icon_label.pack(side="right", padx=(0, 4))
                icon_label.image = notice_icon  # Mantener referencia
                notice_content_frame._icon_added = True
                # Reordenar: ícono a la izquierda, texto a la derecha
                notice_label.pack_forget()
                notice_label.pack(side="right")
        else:
            notice_var.set("Sin avisos")
            notice_label.config(foreground="gray", cursor="arrow")
            tiene_pendientes.set(False)
            # Remover ícono si existe
            if hasattr(notice_content_frame, '_icon_added'):
                for widget in notice_content_frame.winfo_children():
                    if isinstance(widget, ttk.Label) and hasattr(widget, 'image'):
                        widget.destroy()
                delattr(notice_content_frame, '_icon_added')
    
    # Actualizar avisos inicialmente
    update_notices()
    
    # Exponer función para que pueda ser llamada desde otras partes
    root.update_notices = update_notices
    
    # =========================
    # CONTENT CONTAINER (row 1) - Todas las páginas se apilan aquí
    # =========================
    content_container = ttk.Frame(root)
    content_container.grid(row=1, column=0, sticky="nsew")
    content_container.grid_rowconfigure(0, weight=1)
    content_container.grid_columnconfigure(0, weight=1)
    
    # =========================
    # PAGE ROUTER - Sistema de páginas apiladas con tkraise
    # =========================
    pages: dict[str, ttk.Frame] = {}
    
    def show_page(page_name: str):
        """Muestra la página especificada usando tkraise (stack de páginas)."""
        
        # Crear la página primero si no existe
        if page_name not in pages:
            print(f"[DEBUG] _build_main_ui: Creando página {page_name}...")
            try:
                if page_name == "movimientos":
                    # MovimientosPage usa Notebook interno (igual estética que Stock)
                    page = MovimientosPage(content_container, ctx)
                    page.grid(row=0, column=0, sticky="nsew")
                    
                elif page_name == "produccion":
                    # ProduccionPage usa Notebook interno (igual estética que Stock y Movimientos)
                    page = ProduccionPage(content_container, ctx)
                    page.grid(row=0, column=0, sticky="nsew")
                    
                elif page_name == "stock":
                    # Crear página como Frame hijo directo de content_container
                    page = ttk.Frame(content_container)
                    page.grid(row=0, column=0, sticky="nsew")
                    page.grid_rowconfigure(0, weight=1)
                    page.grid_columnconfigure(0, weight=1)
                    
                    # Stock con notebook interno
                    stock_notebook = ttk.Notebook(page)
                    stock_notebook.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
                    stock_notebook.grid_rowconfigure(0, weight=1)
                    stock_notebook.grid_columnconfigure(0, weight=1)
                    
                    # Agregar todas las sub-pestañas de Stock
                    from bull_bar.ui.tabs.stock_tab import StockTab
                    from bull_bar.ui.tabs.stock_barritas_resumen_tab import StockBarritasResumenTab
                    from bull_bar.ui.tabs.lote_barritas_tab import LoteBarritasTab
                    from bull_bar.ui.tabs.movimientos_stock_tab import MovimientosStockTab
                    from bull_bar.ui.tabs.ajuste_stock_tab_integrado import AjusteStockTabIntegrado
                    
                    # Stock Insumos
                    insumos_tab = StockTab(stock_notebook, ctx)
                    try:
                        stock_notebook.tab(insumos_tab.frame, text="Stock Insumos")
                    except Exception:
                        pass
                    
                    # Stock Barritas
                    resumen = StockBarritasResumenTab(stock_notebook, ctx)
                    stock_notebook.add(resumen, text="Stock Barritas")
                    
                    # Lote Barritas
                    lotes = LoteBarritasTab(stock_notebook, ctx)
                    stock_notebook.add(lotes, text="Lote Barritas")
                    
                    # Movimientos (Compras/Ventas) - solo si tiene permiso
                    if tiene_permiso(usuario, "ver", "compras") or tiene_permiso(usuario, "ver", "ventas"):
                        movimientos_stock = MovimientosStockTab(stock_notebook, ctx)
                        stock_notebook.add(movimientos_stock, text="Compras/Ventas")
                    
                    # Ajuste Stock - solo si tiene permiso
                    if tiene_permiso(usuario, "crear", "ajuste_stock"):
                        ajuste = AjusteStockTabIntegrado(stock_notebook, ctx)
                        stock_notebook.add(ajuste, text="Ajuste Stock")
                    
                    # Callback para doble click en resumen
                    resumen.set_open_lotes_callback(lambda sku: (lotes.set_sku_filter(sku), stock_notebook.select(lotes)))
                    
                elif page_name == "recetas":
                    # RecetasPanel ya es un ttk.Frame, usarlo directamente como página
                    # El panel usa pack internamente, pero lo colocamos con grid en content_container
                    from bull_bar.ui.panels.recetas_panel import RecetasPanel
                    page = RecetasPanel(content_container, ctx)
                    page.grid(row=0, column=0, sticky="nsew")
                    
                elif page_name == "historial":
                    # HistorialPanel ya es un ttk.Frame, usarlo directamente como página
                    # El panel ahora usa grid internamente, compatible con content_container
                    print(f"[DEBUG] show_page: Creando HistorialPanel...")
                    from bull_bar.ui.panels.historial_panel import HistorialPanel
                    try:
                        print(f"[DEBUG] show_page: Instanciando HistorialPanel...")
                        page = HistorialPanel(content_container, ctx)
                        print(f"[DEBUG] show_page: HistorialPanel instanciado, configurando grid...")
                        page.grid(row=0, column=0, sticky="nsew")
                        print(f"[DEBUG] show_page: HistorialPanel creado y configurado con grid exitosamente")
                    except Exception as e:
                        print(f"[ERROR] Error al crear HistorialPanel: {e}")
                        import traceback
                        traceback.print_exc()
                        raise
                
                elif page_name == "usuarios":
                    # UsuariosPage usa Notebook interno (igual estética que Stock y Movimientos)
                    from bull_bar.ui.pages.usuarios_page import UsuariosPage
                    page = UsuariosPage(content_container, ctx)
                    page.grid(row=0, column=0, sticky="nsew")
                
                pages[page_name] = page
                print(f"[DEBUG] _build_main_ui: [OK] Página {page_name} creada")
            except Exception as e:
                print(f"[DEBUG] _build_main_ui: [ERROR] Error creando página {page_name}: {e}")
                import traceback
                traceback.print_exc()
                return
        
        # Mostrar la página usando tkraise (todas están en la misma celda 0,0)
        if page_name in pages:
            print(f"[DEBUG] show_page: Página {page_name} existe en pages, llamando tkraise()...")
            pages[page_name].tkraise()
            print(f"[DEBUG] show_page: [OK] Página {page_name} mostrada (tkraise)")
            # Forzar actualización de la UI
            root.update_idletasks()
            print(f"[DEBUG] show_page: UI actualizada")
        else:
            print(f"[DEBUG] show_page: [ERROR] Página {page_name} NO existe en pages. Páginas disponibles: {list(pages.keys())}")
    
    # Funciones para cada botón de navegación
    def show_movimientos():
        if tiene_permiso(usuario, "crear", "compras") or tiene_permiso(usuario, "crear", "ventas"):
            show_page("movimientos")
            # Actualizar badge y avisos después de entrar a Movimientos (solo ADMIN)
            if usuario.get("rol") == RolUsuario.ADMIN.value:
                update_pending_badge()
                update_notices()
    
    def show_produccion():
        permiso = tiene_permiso(usuario, "crear", "produccion")
        print(f"[DEBUG] show_produccion: Usuario rol = {usuario.get('rol')}, tiene_permiso = {permiso}")
        if permiso:
            try:
                show_page("produccion")
            except Exception as e:
                print(f"[ERROR] Error al mostrar producción: {e}")
                import traceback
                traceback.print_exc()
                messagebox.showerror("Error", f"Error al abrir Producción:\n{str(e)}")
        else:
            print(f"[DEBUG] show_produccion: Usuario no tiene permiso para crear producción")
            messagebox.showwarning("Sin permiso", "No tienes permiso para acceder a Producción.")
    
    def show_stock():
        show_page("stock")
    
    def show_recetas():
        show_page("recetas")
    
    def show_historial():
        print(f"[DEBUG] show_historial: Llamado")
        print(f"[DEBUG] show_historial: Usuario rol = {usuario.get('rol')}")
        permiso = tiene_permiso(usuario, "ver", "historial")
        print(f"[DEBUG] show_historial: tiene_permiso = {permiso}")
        if permiso:
            try:
                print(f"[DEBUG] show_historial: Llamando show_page('historial')")
                show_page("historial")
                print(f"[DEBUG] show_historial: show_page completado")
            except Exception as e:
                print(f"[ERROR] Error al mostrar historial: {e}")
                import traceback
                traceback.print_exc()
                messagebox.showerror("Error", f"Error al abrir Historial:\n{str(e)}")
        else:
            print(f"[DEBUG] show_historial: Usuario no tiene permiso para ver historial")
            messagebox.showwarning("Sin permiso", "No tienes permiso para ver el historial.")
    
    def show_usuarios():
        if usuario.get("rol") == RolUsuario.ADMIN.value:
            show_page("usuarios")
    
    # Cargar ícono de exclamación para badge de pendientes (solo ADMIN)
    img_exclamacion = None
    if usuario.get("rol") == RolUsuario.ADMIN.value:
        try:
            # os ya está importado globalmente, no necesitamos importarlo de nuevo
            icon_path = os.path.join(os.path.dirname(__file__), "..", "..", "img", "exclamacion.png")
            if os.path.exists(icon_path):
                img_exclamacion = tk.PhotoImage(file=icon_path)
                # Reducir tamaño si es muy grande (16-20px)
                if img_exclamacion.width() > 20 or img_exclamacion.height() > 20:
                    factor = max(1, int(max(img_exclamacion.width(), img_exclamacion.height()) / 18))
                    img_exclamacion = img_exclamacion.subsample(factor, factor)
                # Guardar referencia para que no se pierda
                root._img_exclamacion = img_exclamacion
                print(f"[DEBUG] _build_main_ui: Ícono exclamación cargado ({img_exclamacion.width()}x{img_exclamacion.height()})")
        except Exception as e:
            print(f"[DEBUG] _build_main_ui: No se pudo cargar ícono exclamación: {e}")
    
    # Botones en la barra de navegación
    btn_movimientos = tk.Button(btns, text="Movimientos", command=show_movimientos)
    btn_movimientos.pack(side="left", padx=4)
    tk.Button(btns, text="Producción", command=show_produccion).pack(side="left", padx=4)
    tk.Button(btns, text="Ver Stock", command=show_stock).pack(side="left", padx=4)
    tk.Button(btns, text="Ver Recetas", command=show_recetas).pack(side="left", padx=4)
    
    # Botón historial solo si tiene permiso
    permiso_historial = tiene_permiso(usuario, "ver", "historial")
    print(f"[DEBUG] _build_main_ui: permiso_historial = {permiso_historial} para usuario {usuario.get('username', 'N/A')}")
    if permiso_historial:
        btn_historial = tk.Button(btns, text="Ver Historial", command=show_historial)
        btn_historial.pack(side="left", padx=4)
        print(f"[DEBUG] _build_main_ui: Botón 'Ver Historial' creado")
    else:
        print(f"[DEBUG] _build_main_ui: Usuario no tiene permiso, botón 'Ver Historial' NO creado")
    
    # Botón gestión usuarios solo para admin
    if usuario.get("rol") == RolUsuario.ADMIN.value:
        tk.Button(btns, text="Usuarios", command=show_usuarios).pack(side="left", padx=4)
    
    # Función para actualizar badge de pendientes (solo ADMIN)
    def update_pending_badge():
        """Actualiza el badge de alerta en el botón Movimientos si hay pendientes."""
        if usuario.get("rol") != RolUsuario.ADMIN.value:
            return
        
        try:
            from bull_bar.infra.sqlite_produccion_pendientes import contar_pendientes
            count = contar_pendientes(ctx["db_path"], estado="PENDIENTE_APROBACION")
            
            if count > 0 and img_exclamacion:
                # Mostrar badge con ícono y contador
                btn_movimientos.config(
                    text=f"Movimientos ({count})",
                    image=img_exclamacion,
                    compound="left"
                )
                print(f"[DEBUG] update_pending_badge: Badge actualizado con {count} pendientes")
            else:
                # Quitar badge, volver al texto normal
                btn_movimientos.config(
                    text="Movimientos",
                    image="",
                    compound=""
                )
                print(f"[DEBUG] update_pending_badge: Badge removido (count={count})")
        except Exception as e:
            print(f"[ERROR] update_pending_badge: Error: {e}")
            import traceback
            traceback.print_exc()
    
    # Actualizar badge al iniciar (solo ADMIN)
    if usuario.get("rol") == RolUsuario.ADMIN.value:
        update_pending_badge()
    
    # Actualizar avisos al iniciar (solo ADMIN)
    if usuario.get("rol") == RolUsuario.ADMIN.value:
        update_notices()
    
    # Mostrar página por defecto si tiene permiso
    if tiene_permiso(usuario, "crear", "compras") or tiene_permiso(usuario, "crear", "ventas"):
        show_page("movimientos")
    elif tiene_permiso(usuario, "crear", "produccion"):
        show_page("produccion")
    else:
        show_page("stock")
    
    # Exponer funciones para que puedan ser llamadas desde otras partes
    root.update_pending_badge = update_pending_badge
    root.update_notices = update_notices

    # =========================
    # VENTANA PRINCIPAL
    # =========================
    # Configurar tamaño y posición de la ventana
    root.geometry("1000x720")
    root.minsize(800, 600)  # Tamaño mínimo
    
    # Centrar ventana en la pantalla
    try:
        root.update_idletasks()
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        window_width = 1000
        window_height = 720
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        root.geometry(f"{window_width}x{window_height}+{x}+{y}")
        print(f"[DEBUG] _build_main_ui: Ventana centrada en ({x}, {y})")
    except Exception as e:
        print(f"[DEBUG] _build_main_ui: [WARN] Error centrando ventana: {e}")
    
    print("[DEBUG] _build_main_ui: [OK] UI principal construida completamente")
    
    # Asegurar que la ventana esté visible y actualizada
    print("[DEBUG] _build_main_ui: Forzando visibilidad final...")
    try:
        root.deiconify()  # Asegurar que esté visible
        root.update()
        root.update_idletasks()
        root.lift()
        root.focus_force()
        # Forzar que esté al frente temporalmente
        root.attributes('-topmost', True)
        root.update()
        root.attributes('-topmost', False)
        root.update()
        
        # Verificar que los widgets estén visibles
        try:
            if navbar_frame.winfo_viewable():
                print("[DEBUG] _build_main_ui: navbar_frame es visible")
            if content_container.winfo_viewable():
                print("[DEBUG] _build_main_ui: content_container es visible")
        except:
            pass
    except Exception as e:
        print(f"[ERROR] _build_main_ui: Error forzando visibilidad: {e}")
        import traceback
        traceback.print_exc()
    
    print("[DEBUG] _build_main_ui: [OK] Ventana principal lista y visible")
    # NO llamar root.mainloop() aquí porque ya se llama en main()



if __name__ == "__main__":
    main()
