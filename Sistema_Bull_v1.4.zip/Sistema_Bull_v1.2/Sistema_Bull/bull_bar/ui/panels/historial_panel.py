"""
Panel reutilizable de Historial/Movimientos con filtros.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from datetime import datetime, date
from typing import Optional, Callable

from bull_bar.infra.audit import get_audit_logs


class HistorialPanel(ttk.Frame):
    """
    Panel reutilizable para mostrar historial/movimientos con filtros.
    
    Uso:
        panel = HistorialPanel(parent, ctx)
        panel.pack(fill="both", expand=True)
    """
    
    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        # Configurar grid para que se expanda correctamente cuando se usa con grid()
        self.grid_rowconfigure(2, weight=1)  # tree_frame está en row 2
        self.grid_columnconfigure(0, weight=1)
        self._build_ui()
        self.refresh()
    
    def _build_ui(self):
        # Botón ver historial completo arriba a la derecha
        top_bar = ttk.Frame(self)
        top_bar.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 0))
        top_bar.columnconfigure(0, weight=1)
        self.btn_ver_historial = ttk.Button(top_bar, text="Ver Historial Completo", command=self._show_full_history)
        self.btn_ver_historial.grid(row=0, column=1, sticky="e")
        
        # Barra de filtros
        filters = ttk.LabelFrame(self, text="Filtros", padding=8)
        filters.grid(row=1, column=0, sticky="ew", padx=8, pady=8)
        
        # Módulo
        ttk.Label(filters, text="Módulo:").grid(row=0, column=0, sticky="w", padx=(0, 4))
        self.filter_modulo = ttk.Combobox(
            filters,
            values=["", "stock", "compras", "ventas", "produccion", "recetas"],
            width=15,
            state="readonly"
        )
        self.filter_modulo.set("")
        self.filter_modulo.grid(row=0, column=1, padx=(0, 10))
        
        # Entidad tipo
        ttk.Label(filters, text="Tipo:").grid(row=0, column=2, sticky="w", padx=(0, 4))
        self.filter_tipo = ttk.Combobox(
            filters,
            values=["", "Producto", "Documento", "Lote", "Receta"],
            width=15,
            state="readonly"
        )
        self.filter_tipo.set("")
        self.filter_tipo.grid(row=0, column=3, padx=(0, 10))
        
        # Usuario
        ttk.Label(filters, text="Usuario:").grid(row=0, column=4, sticky="w", padx=(0, 4))
        self.filter_usuario = ttk.Entry(filters, width=15)
        self.filter_usuario.grid(row=0, column=5, padx=(0, 10))
        
        # Fecha desde
        ttk.Label(filters, text="Desde:").grid(row=1, column=0, sticky="w", padx=(0, 4), pady=(6, 0))
        self.filter_fecha_desde = ttk.Entry(filters, width=15)
        self.filter_fecha_desde.grid(row=1, column=1, padx=(0, 10), pady=(6, 0))
        
        # Fecha hasta
        ttk.Label(filters, text="Hasta:").grid(row=1, column=2, sticky="w", padx=(0, 4), pady=(6, 0))
        self.filter_fecha_hasta = ttk.Entry(filters, width=15)
        self.filter_fecha_hasta.grid(row=1, column=3, padx=(0, 10), pady=(6, 0))
        
        # Botones
        btn_frame = ttk.Frame(filters)
        btn_frame.grid(row=1, column=4, columnspan=2, pady=(6, 0))
        ttk.Button(btn_frame, text="Filtrar", command=self.refresh).pack(side="left", padx=4)
        ttk.Button(btn_frame, text="Limpiar", command=self._clear_filters).pack(side="left", padx=4)
        
        # Tabla de resultados con scrollbar
        tree_frame = ttk.Frame(self)
        tree_frame.grid(row=2, column=0, sticky="nsew", padx=8, pady=8)
        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)
        
        cols = ("timestamp", "usuario", "accion", "modulo", "entidad_tipo", "entidad_id", "detalles")
        self.tree = ttk.Treeview(tree_frame, columns=cols, show="headings", selectmode="browse")
        
        self.tree.heading("timestamp", text="Fecha/Hora")
        self.tree.heading("usuario", text="Usuario")
        self.tree.heading("accion", text="Acción")
        self.tree.heading("modulo", text="Módulo")
        self.tree.heading("entidad_tipo", text="Tipo")
        self.tree.heading("entidad_id", text="ID Entidad")
        self.tree.heading("detalles", text="Detalles")
        
        self.tree.column("timestamp", width=150)
        self.tree.column("usuario", width=120)
        self.tree.column("accion", width=150)
        self.tree.column("modulo", width=100)
        self.tree.column("entidad_tipo", width=100)
        self.tree.column("entidad_id", width=150)
        self.tree.column("detalles", width=300, stretch=True)
        
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        
        # Scrollbar
        scroll = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        
        self.tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=(0, 8))
        scroll.pack(side="right", fill="y", padx=(0, 8), pady=(0, 8))
    
    def _clear_filters(self):
        """Limpia todos los filtros."""
        self.filter_modulo.set("")
        self.filter_tipo.set("")
        self.filter_usuario.delete(0, "end")
        self.filter_fecha_desde.delete(0, "end")
        self.filter_fecha_hasta.delete(0, "end")
        self.refresh()
    
    def refresh(self):
        """Refresca la tabla con los filtros aplicados."""
        # Limpiar tabla
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        
        # Obtener filtros
        modulo = self.filter_modulo.get().strip() or None
        entidad_tipo = self.filter_tipo.get().strip() or None
        usuario = self.filter_usuario.get().strip() or None
        fecha_desde = self.filter_fecha_desde.get().strip() or None
        fecha_hasta = self.filter_fecha_hasta.get().strip() or None
        
        # Obtener logs
        logs = get_audit_logs(
            self.ctx["db_path"],
            modulo=modulo,
            entidad_tipo=entidad_tipo,
            usuario=usuario,
            fecha_desde=fecha_desde,
            fecha_hasta=fecha_hasta,
            limit=1000,
        )
        
        # Mostrar en tabla
        for log in logs:
            timestamp = log.get("timestamp", "")
            if timestamp:
                try:
                    dt = datetime.fromisoformat(timestamp)
                    timestamp = dt.strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    pass
            
            detalles = ""
            if log.get("antes") or log.get("despues"):
                detalles = f"Antes: {log.get('antes', 'N/A')[:50]}... | Después: {log.get('despues', 'N/A')[:50]}..."
            
            self.tree.insert("", "end", values=(
                timestamp,
                log.get("usuario", ""),
                log.get("accion", ""),
                log.get("modulo", ""),
                log.get("entidad_tipo", ""),
                log.get("entidad_id", ""),
                detalles,
            ))
    
    def _show_full_history(self):
        """Muestra ventana con historial completo."""
        win = tk.Toplevel(self)
        win.title("Historial Completo")
        win.geometry("1200x600")
        win.transient(self)
        
        panel = HistorialPanel(win, self.ctx)
        panel.pack(fill="both", expand=True, padx=8, pady=8)
        
        win.grab_set()
        win.wait_window(win)


def create_historial_button(parent, ctx, text: str = "Ver Historial") -> ttk.Button:
    """
    Crea un botón reutilizable para abrir el historial.
    
    Args:
        parent: Widget padre
        ctx: Contexto de la aplicación
        text: Texto del botón
    
    Returns:
        Botón configurado
    """
    def open_historial():
        win = tk.Toplevel(parent)
        win.title("Historial / Movimientos")
        win.geometry("1200x700")
        win.transient(parent)
        
        panel = HistorialPanel(win, ctx)
        panel.pack(fill="both", expand=True, padx=8, pady=8)
        
        win.grab_set()
        win.wait_window(win)
    
    return ttk.Button(parent, text=text, command=open_historial)

