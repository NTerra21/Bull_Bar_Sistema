import tkinter as tk
from tkinter import ttk, messagebox

class RemitoTab:
    def __init__(self, notebook, ctx):
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="Remito")
        ttk.Label(frame, text="Pendiente: remito de venta").pack(padx=8, pady=8)
        ttk.Button(frame, text="Acción dummy", command=lambda: messagebox.showinfo("Info", "Pendiente implementar")).pack(pady=6)
