"""
Contenedor de pestañas de Stock para el notebook principal.
Agrupa todas las pestañas relacionadas con Stock en una sola pestaña del notebook principal.
"""
import tkinter as tk
from tkinter import ttk

# Importaciones con manejo de errores
try:
    from bull_bar.ui.tabs.stock_tab import StockTab
except ImportError as e:
    raise ImportError(f"Error importando StockTab: {e}")

try:
    from bull_bar.ui.tabs.stock_barritas_resumen_tab import StockBarritasResumenTab
except ImportError as e:
    raise ImportError(f"Error importando StockBarritasResumenTab: {e}")

try:
    from bull_bar.ui.tabs.lote_barritas_tab import LoteBarritasTab
except ImportError as e:
    raise ImportError(f"Error importando LoteBarritasTab: {e}")

try:
    from bull_bar.ui.tabs.ajuste_stock_tab_integrado import AjusteStockTabIntegrado
except ImportError as e:
    raise ImportError(f"Error importando AjusteStockTabIntegrado: {e}")

try:
    from bull_bar.ui.tabs.movimientos_stock_tab import MovimientosStockTab
except ImportError as e:
    raise ImportError(f"Error importando MovimientosStockTab: {e}")


class StockContainerTab:
    """
    Contenedor que agrupa todas las pestañas de Stock en el notebook principal.
    Similar a StockWindow pero integrado en el notebook principal.
    """
    def __init__(self, notebook, ctx):
        self.ctx = ctx
        self.notebook = notebook
        
        # Frame principal que se agrega al notebook
        self.frame = ttk.Frame(notebook)
        notebook.add(self.frame, text="Stock")
        
        # Notebook interno para las sub-pestañas de Stock
        self.internal_notebook = ttk.Notebook(self.frame)
        self.internal_notebook.pack(fill="both", expand=True, padx=6, pady=6)
        
        # 1) Stock Insumos
        insumos_tab = StockTab(self.internal_notebook, ctx)
        # StockTab ya agrega su propio frame al notebook, cambiar texto
        try:
            self.internal_notebook.tab(insumos_tab.frame, text="Stock Insumos")
        except Exception:
            pass
        
        # 2) Stock Barritas (resumen por SKU)
        resumen = StockBarritasResumenTab(self.internal_notebook, ctx)
        self.internal_notebook.add(resumen, text="Stock Barritas")
        
        # 3) Lote Barritas (por lote + alternar activos/finalizados)
        lotes = LoteBarritasTab(self.internal_notebook, ctx)
        self.internal_notebook.add(lotes, text="Lote Barritas")
        
        # 4) Movimientos (Compras/Ventas) - solo si tiene permiso
        from bull_bar.infra.auth import tiene_permiso
        usuario = ctx.get("usuario_actual", {})
        
        if tiene_permiso(usuario, "ver", "compras") or tiene_permiso(usuario, "ver", "ventas"):
            movimientos = MovimientosStockTab(self.internal_notebook, ctx)
            self.internal_notebook.add(movimientos, text="Compras/Ventas")
        
        # 5) Ajuste de Stock - solo si tiene permiso
        if tiene_permiso(usuario, "crear", "ajuste_stock"):
            ajuste = AjusteStockTabIntegrado(self.internal_notebook, ctx)
            self.internal_notebook.add(ajuste, text="Ajuste Stock")
        
        # Doble click en resumen -> filtra lotes por SKU y cambia de pestaña
        resumen.set_open_lotes_callback(lambda sku: (lotes.set_sku_filter(sku), self.internal_notebook.select(lotes)))
