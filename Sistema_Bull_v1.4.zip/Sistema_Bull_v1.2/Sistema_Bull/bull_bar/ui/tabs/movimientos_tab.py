import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from bull_bar.core.models import DocumentoItem
from uuid import uuid4
from datetime import datetime

class MovimientosTab:
    def __init__(self, notebook, ctx):
        self.ctx = ctx
        self.frame = ttk.Frame(notebook)
        notebook.add(self.frame, text="Movimientos")

        # Container para el contenido (definir primero para usarlo en los botones)
        container = ttk.Frame(self.frame)
        self.container = container
        
        # Título "Movimientos" (donde está marcado en rojo)
        title_frame = ttk.Frame(self.frame)
        title_frame.pack(fill="x", padx=6, pady=6)
        
        # Título "Movimientos"
        ttk.Label(title_frame, text="Movimientos", font=("Helvetica", 12, "bold")).pack(side="left")
        
        # Botones de sub-navegación a la derecha del título
        menu = ttk.Frame(title_frame)
        menu.pack(side="left", padx=(20, 0))
        
        ttk.Button(menu, text="Compra / Entrada", command=lambda: self.show_compra(self.container)).pack(side="left", padx=4)
        ttk.Button(menu, text="Venta o Generar Venta", command=lambda: self.show_venta(self.container)).pack(side="left", padx=4)
        ttk.Button(menu, text="Remito", command=lambda: self.show_remito(self.container)).pack(side="left", padx=4)

        # Container para el contenido (empaquetar al final para que quede debajo)
        container.pack(fill="both", expand=True, padx=6, pady=6)
        
        # Mostrar compra por defecto
        self.show_compra(container)

    def _clear(self):
        for w in self.container.winfo_children():
            w.destroy()

    # Compra panel (separado: modo manual / subir archivo futuro)
    def show_compra(self, parent):
        self._clear()
        f = ttk.Frame(parent)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="Compra / Entrada de Insumos", font=("Helvetica", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0,6))

        # modo: manual factura o subir archivo (próximamente)
        modo_var = tk.StringVar(value="manual")
        ttk.Radiobutton(f, text="Manual (factura)", variable=modo_var, value="manual").grid(row=1, column=0, sticky="w")
        ttk.Radiobutton(f, text="Subir archivo (próximamente)", variable=modo_var, value="file").grid(row=1, column=1, sticky="w")

        ttk.Label(f, text="Código producto (insumo)").grid(row=2, column=0, sticky="w")
        codigo_entry = ttk.Entry(f); codigo_entry.grid(row=2, column=1, sticky="ew")
        ttk.Label(f, text="Descripción").grid(row=3, column=0, sticky="w")
        desc_entry = ttk.Entry(f); desc_entry.grid(row=3, column=1, sticky="ew")
        ttk.Label(f, text="Cantidad").grid(row=4, column=0, sticky="w")
        cant_entry = ttk.Entry(f); cant_entry.grid(row=4, column=1, sticky="ew")
        ttk.Label(f, text="Número de factura (opcional)").grid(row=5, column=0, sticky="w")
        factura_entry = ttk.Entry(f); factura_entry.grid(row=5, column=1, sticky="ew")

        f.columnconfigure(1, weight=1)

        def subir_archivo():
            messagebox.showinfo("Próximamente", "La funcionalidad de subir archivo estará disponible próximamente.")
        def registrar():
            codigo = codigo_entry.get().strip()
            descripcion = desc_entry.get().strip() or codigo
            try:
                cantidad = float(cant_entry.get())
            except Exception:
                messagebox.showerror("Error", "Cantidad inválida"); return
            if modo_var.get() == "file":
                # sólo mostrador por ahora
                subir_archivo(); return
            prod = self.ctx["products"].get(codigo)
            if not prod:
                from bull_bar.core.models import Producto
                prod = Producto(id=str(uuid4()), codigo=codigo, nombre=descripcion, unidad_medida="u")
                self.ctx["products"][codigo] = prod
            item = DocumentoItem(producto_id=prod.id, descripcion=descripcion, cantidad=cantidad)
            try:
                numero = f"C-{uuid4().hex[:6]}"
                self.ctx["purchase_service"].registrar_compra_recibida(
                    numero=numero,
                    ClienteProveedor_id=self.ctx["prov"].id,
                    deposito_id=self.ctx["depo"].id,
                    items=[item],
                )
                messagebox.showinfo("OK", f"Compra registrada: {numero}")
            except Exception as e:
                messagebox.showerror("Error registro", str(e))

        ttk.Button(f, text="Registrar compra (recibido)", command=registrar).grid(row=6, column=0, columnspan=2, pady=8)
        ttk.Button(f, text="Subir archivo", command=subir_archivo).grid(row=6, column=2, padx=6)

    # Venta panel (simplificado)
    def show_venta(self, parent):
        self._clear()
        f = ttk.Frame(parent)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="Venta", font=("Helvetica", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0,6))
        ttk.Label(f, text="Producto (codigo)").grid(row=1, column=0, sticky="w")
        codigo = ttk.Entry(f); codigo.grid(row=1, column=1, sticky="ew")
        ttk.Label(f, text="Cantidad").grid(row=2, column=0, sticky="w")
        cantidad = ttk.Entry(f); cantidad.grid(row=2, column=1, sticky="ew")
        f.columnconfigure(1, weight=1)

        def intentar():
            cod = codigo.get().strip()
            try:
                cant = float(cantidad.get())
            except Exception:
                messagebox.showerror("Error", "Cantidad inválida"); return
            prod = self.ctx["products"].get(cod)
            if not prod:
                messagebox.showerror("Error", "Producto no encontrado en catálogo"); return
            numero = f"V-{uuid4().hex[:6]}"
            doc_venta, movs, faltantes = self.ctx["sale_service"].intentar_venta(
                numero=numero,
                ClienteProveedor_id=self.ctx["cli"].id,
                deposito_id=self.ctx["depo"].id,
                items=[DocumentoItem(producto_id=prod.id, descripcion=prod.nombre, cantidad=cant)],
            )
            if faltantes:
                # crear orden pendiente real en ctx
                order = {
                    "id": uuid4().hex,
                    "numero": numero,
                    "producto_codigo": cod,
                    "cantidad_solicitada": cant,
                    "cliente_id": self.ctx["cli"].id,
                    "deposito_id": self.ctx["depo"].id,
                    "estado": "PENDIENTE",
                    "faltantes": faltantes,
                    "created_at": datetime.now().isoformat(),
                }
                self.ctx.setdefault("pending_orders", []).append(order)
                messagebox.showinfo("Pendiente", f"Orden PENDIENTE creada: {order['id']}")
            else:
                messagebox.showinfo("Venta OK", f"Venta {numero} realizada")

        ttk.Button(f, text="Intentar vender", command=intentar).grid(row=3, column=0, columnspan=2, pady=8)

    # Remito / placeholder
    def show_remito(self, parent):
        self._clear()
        f = ttk.Frame(parent)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="Remito / Despacho (pendiente de implementación)", font=("Helvetica", 12, "bold")).pack(anchor="w", pady=(0,6), padx=6)
        ttk.Label(f, text="Aquí se gestionarán remitos de venta y despacho.").pack(anchor="w", padx=6, pady=4)
        ttk.Button(f, text="Acción dummy", command=lambda: messagebox.showinfo("Info", "Pendiente implementar")).pack(pady=8)
