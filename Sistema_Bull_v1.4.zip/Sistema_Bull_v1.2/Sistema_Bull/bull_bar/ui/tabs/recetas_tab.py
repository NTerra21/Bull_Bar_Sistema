import tkinter as tk
from tkinter import ttk, messagebox

from bull_bar.infra.sqlite_recetas import (
    list_recetas,
    get_receta_items,
    list_products,
    update_product_detail,
)

from bull_bar.ui.utils.tree_sort import TreeSortController
from bull_bar.ui.utils.delayed_deselect import DelayedDeselect


class RecetasTab:
    def __init__(self, notebook, ctx):
        self.ctx = ctx
        self.main_notebook = notebook
        self.root = notebook.winfo_toplevel()

        self.frame = ttk.Frame(notebook)
        notebook.add(self.frame, text="Recetas")

        # Sub-notebook (Activas / Inactivas / Nueva)
        self.subnb = ttk.Notebook(self.frame)
        self.subnb.pack(fill="both", expand=True, padx=6, pady=6)

        self.tab_active = ttk.Frame(self.subnb)
        self.tab_inactive = ttk.Frame(self.subnb)
        self.tab_new = ttk.Frame(self.subnb)

        self.subnb.add(self.tab_active, text="Recetas Activas")
        self.subnb.add(self.tab_inactive, text="Recetas Inactivas")
        self.subnb.add(self.tab_new, text="Crear Receta Nueva")

        # cache productos
        self._prod_cache = {}
        self._load_products_cache()

        # Panels
        self.ui_active = self._build_panel(self.tab_active, mode="active")
        self.ui_inactive = self._build_panel(self.tab_inactive, mode="inactive")
        self._build_new_tab(self.tab_new)

        # Data
        self._refresh_all()

    # ------------------------------------------------------------
    # Build UI panels
    # ------------------------------------------------------------
    def _build_panel(self, parent, mode: str):
        parent.columnconfigure(1, weight=1)
        parent.rowconfigure(0, weight=1)

        left = ttk.Frame(parent)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 10))
        right = ttk.Frame(parent)
        right.grid(row=0, column=1, sticky="nsew")

        right.columnconfigure(0, weight=1)
        right.rowconfigure(3, weight=1)

        # Left list
        ttk.Label(left, text="Recetas").pack(anchor="w")
        lb = tk.Listbox(left, height=20)
        lb.pack(fill="y", expand=True)
        lb.bind("<<ListboxSelect>>", lambda e: self._show_detalle(mode))

        left_btns = ttk.Frame(left)
        left_btns.pack(fill="x", pady=(8, 0))

        btn_refresh = ttk.Button(left_btns, text="Refrescar", command=self._refresh_all)
        btn_refresh.pack(fill="x")

        # “Editar” (antes era Re-subir…)
        btn_edit = ttk.Button(left_btns, text="Editar", command=lambda: self._editar_receta(mode))
        btn_edit.pack(fill="x", pady=(6, 0))

        # Right header
        lbl_title = ttk.Label(right, text="Seleccione una receta…", font=("Segoe UI", 11, "bold"))
        lbl_title.grid(row=0, column=0, sticky="w", pady=(0, 4))

        lbl_info = ttk.Label(right, text="", foreground="#666")
        lbl_info.grid(row=1, column=0, sticky="w", pady=(0, 6))

        actions = ttk.Frame(right)
        actions.grid(row=2, column=0, sticky="we", pady=(0, 6))
        actions.columnconfigure(0, weight=1)

        btn_ver_prod = ttk.Button(actions, text="Ver producto", command=lambda: self._open_product_selected(mode))
        btn_ver_prod.pack(side="right")

        # Tree ingredientes
        cols = ("codigo", "nombre", "porcentaje", "stock_conf", "stock_pend")
        tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")

        # Guardamos el código, pero lo ocultamos
        tree.heading("codigo", text="Código")
        tree.column("codigo", width=0, minwidth=0, stretch=False)

        tree.column("nombre", width=520, stretch=True)
        tree.column("porcentaje", width=90, anchor="e", stretch=False)
        tree.column("stock_conf", width=90, anchor="e", stretch=False)
        tree.column("stock_pend", width=90, anchor="e", stretch=False)  # ✅ no se estira feo

        tree.pack_forget()
        tree.grid(row=3, column=0, sticky="nsew")

        yscroll = ttk.Scrollbar(right, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=yscroll.set)
        yscroll.grid(row=3, column=1, sticky="ns")

        # Sort helper
        sorter = TreeSortController(
            tree=tree,
            base_headings={
                "nombre": "Nombre",
                "porcentaje": "% uso",
                "stock_conf": "Stock",
                "stock_pend": "Pendiente",
            },
            numeric_cols={"porcentaje", "stock_conf", "stock_pend"},
        )
        sorter.install()

        # Deselect helper (tardío) — solo activo cuando estás en este sub-tab
        deselect = DelayedDeselect(
            root=self.root,
            tree=tree,
            is_active=lambda m=mode: self._is_panel_active(m),
            clear_selection=lambda t=tree: t.selection_remove(t.selection()),
            exempt_widgets=[btn_ver_prod, btn_refresh, btn_edit],
            delay_click_ms=80,
            delay_focusout_ms=250,
        )

        # Enter / Double click -> ver producto
        tree.bind("<Return>", lambda e: self._open_product_selected(mode))
        tree.bind("<Double-1>", lambda e: self._on_tree_double_click(e, mode, deselect))

        return {
            "lb": lb,
            "lbl_title": lbl_title,
            "lbl_info": lbl_info,
            "tree": tree,
            "btn_ver": btn_ver_prod,
            "btn_edit": btn_edit,
            "btn_refresh": btn_refresh,
            "sorter": sorter,
            "deselect": deselect,
        }

    def _build_new_tab(self, parent):
        parent.columnconfigure(0, weight=1)

        box = ttk.Frame(parent, padding=10)
        box.grid(row=0, column=0, sticky="nwe")

        box.columnconfigure(1, weight=1)

        ttk.Label(box, text="Crear Receta Nueva", font=("Segoe UI", 11, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10)
        )

        ttk.Label(box, text="Nombre:").grid(row=1, column=0, sticky="e", padx=(0, 8), pady=4)
        self.new_name = ttk.Entry(box)
        self.new_name.grid(row=1, column=1, sticky="we", pady=4)

        ttk.Label(box, text="(Opcional) Basada en:").grid(row=2, column=0, sticky="e", padx=(0, 8), pady=4)
        self.new_base = ttk.Combobox(box, state="readonly", values=[])
        self.new_base.grid(row=2, column=1, sticky="we", pady=4)

        ttk.Button(box, text="Crear", command=self._crear_receta).grid(row=3, column=0, columnspan=2, sticky="e", pady=(10, 0))

        ttk.Label(
            parent,
            text="Nota: Crear/Duplicar/Inactivar depende de tu DB. Por ahora queda como placeholder.",
            foreground="#666",
        ).grid(row=1, column=0, sticky="w", padx=10, pady=(6, 0))

    # ------------------------------------------------------------
    # Active checks
    # ------------------------------------------------------------
    def _is_panel_active(self, mode: str) -> bool:
        # Recetas tab visible en el notebook principal
        try:
            main_ok = (self.main_notebook.select() == str(self.frame))
        except Exception:
            main_ok = False

        if not main_ok:
            return False

        # sub-tab activo correcto
        try:
            current_sub = self.subnb.select()
        except Exception:
            return False

        if mode == "active":
            return current_sub == str(self.tab_active)
        return current_sub == str(self.tab_inactive)

    # ------------------------------------------------------------
    # Data refresh
    # ------------------------------------------------------------
    def _load_products_cache(self):
        self._prod_cache.clear()
        for p in list_products(self.ctx["db_path"]) or []:
            codigo = (p.get("codigo") or "").strip()
            self._prod_cache[codigo] = {
                "marca": (p.get("marca") or "").strip(),
                "nombre": (p.get("nombre") or "").strip(),
                "uuid": p.get("uuid") or "",
                "precio": p.get("precio"),
            }

    def _refresh_all(self):
        self._load_products_cache()

        recetas_all = list_recetas(self.ctx["db_path"]) or []
        recetas_active = list(recetas_all)
        recetas_inactive = []  # hasta que exista flag DB

        self.ui_active["lb"].delete(0, "end")
        for r in recetas_active:
            self.ui_active["lb"].insert("end", r)

        self.ui_inactive["lb"].delete(0, "end")
        for r in recetas_inactive:
            self.ui_inactive["lb"].insert("end", r)

        self.new_base["values"] = recetas_active

        self._show_detalle("active")
        self._show_detalle("inactive")

    # ------------------------------------------------------------
    # Mostrar ingredientes
    # ------------------------------------------------------------
    def _show_detalle(self, mode: str):
        ui = self.ui_active if mode == "active" else self.ui_inactive

        sel = ui["lb"].curselection()
        if not sel:
            return

        receta = ui["lb"].get(sel[0])
        items = get_receta_items(self.ctx["db_path"], receta) or []

        ui["lbl_title"].config(text=f"Receta: {receta}")
        ui["lbl_info"].config(text=f"Ingredientes: {len(items)}")

        tree = ui["tree"]
        for iid in tree.get_children():
            tree.delete(iid)

        depo_id = self.ctx["depo"].id
        ledger = self.ctx["ledger"]
        has_pend = hasattr(ledger, "stock_pendiente")

        for it in items:
            codigo = (it.get("producto_codigo") or "").strip()
            porcentaje = it.get("porcentaje")

            pdata = self._prod_cache.get(codigo, {})
            marca = pdata.get("marca", "")
            nombre = pdata.get("nombre", "") or codigo
            display = f"{marca} - {nombre}" if marca else nombre

            # id producto para ledger
            prod_obj = self.ctx.get("products", {}).get(codigo)
            prod_id = pdata.get("uuid") or (prod_obj.id if prod_obj else "")

            stock_conf_str = "N/A"
            stock_pend_str = "0.00"
            try:
                stock_conf = ledger.stock_confirmado(depo_id, prod_id)
                stock_conf_str = f"{float(stock_conf):.2f}"
                if has_pend:
                    stock_pend = ledger.stock_pendiente(depo_id, prod_id)
                    stock_pend_str = f"{float(stock_pend):.2f}"
            except Exception:
                pass

            porc_str = "" if porcentaje is None else f"{float(porcentaje):.2f}"

            tree.insert("", "end", values=(codigo, display, porc_str, stock_conf_str, stock_pend_str))

        # reset sort “original”
        ui["sorter"].set_original_order()
        ui["sorter"].reset()

    # ------------------------------------------------------------
    # Double click -> ver producto
    # ------------------------------------------------------------
    def _on_tree_double_click(self, event, mode: str, deselect: DelayedDeselect):
        deselect.cancel()
        ui = self.ui_active if mode == "active" else self.ui_inactive
        tree = ui["tree"]

        row_id = tree.identify_row(event.y)
        if not row_id:
            return

        tree.selection_set(row_id)
        tree.focus(row_id)
        self._open_product_selected(mode)

    # ------------------------------------------------------------
    # Ver producto (detalle)
    # ------------------------------------------------------------
    def _open_product_selected(self, mode: str):
        ui = self.ui_active if mode == "active" else self.ui_inactive
        tree = ui["tree"]

        sel = tree.selection()
        if not sel:
            return

        values = tree.item(sel[0], "values")
        if not values or len(values) < 1:
            return

        codigo = values[0]
        pdata = self._prod_cache.get(codigo)
        if not pdata:
            messagebox.showerror("Error", "No se encontró el producto en la DB")
            return

        self._open_product_detail_window(codigo, pdata)

    def _open_product_detail_window(self, codigo: str, pdata: dict):
        depo_id = self.ctx["depo"].id
        ledger = self.ctx["ledger"]
        has_pend = hasattr(ledger, "stock_pendiente")

        prod_obj = self.ctx.get("products", {}).get(codigo)
        prod_id = pdata.get("uuid") or (prod_obj.id if prod_obj else "")

        stock_conf_str = "N/A"
        stock_pend_str = "0.00"
        try:
            stock_conf = ledger.stock_confirmado(depo_id, prod_id)
            stock_conf_str = f"{float(stock_conf):.2f}"
            if has_pend:
                stock_pend = ledger.stock_pendiente(depo_id, prod_id)
                stock_pend_str = f"{float(stock_pend):.2f}"
        except Exception:
            pass

        win = tk.Toplevel(self.root)
        win.title(f"Detalle - {codigo}")
        win.transient(self.root)

        container = ttk.Frame(win, padding=10)
        container.pack(fill="both", expand=True)
        container.columnconfigure(1, weight=1)

        def row(label, widget, r):
            ttk.Label(container, text=label).grid(row=r, column=0, sticky="e", padx=(0, 8), pady=4)
            widget.grid(row=r, column=1, sticky="we", pady=4)

        var_codigo = tk.StringVar(value=codigo)
        var_marca = tk.StringVar(value=pdata.get("marca", ""))
        var_nombre = tk.StringVar(value=pdata.get("nombre", ""))
        var_precio = tk.StringVar(value="" if pdata.get("precio") is None else f"{float(pdata.get('precio')):.2f}")
        var_stock = tk.StringVar(value=stock_conf_str)
        var_pend = tk.StringVar(value=stock_pend_str)

        row("Código:", ttk.Entry(container, textvariable=var_codigo, state="readonly"), 0)
        row("Marca:", ttk.Entry(container, textvariable=var_marca), 1)
        row("Nombre:", ttk.Entry(container, textvariable=var_nombre), 2)
        row("Precio / kg:", ttk.Entry(container, textvariable=var_precio), 3)
        row("Stock (confirmado):", ttk.Entry(container, textvariable=var_stock, state="readonly"), 4)
        row("Stock (pendiente):", ttk.Entry(container, textvariable=var_pend, state="readonly"), 5)

        ttk.Separator(container).grid(row=6, column=0, columnspan=2, sticky="we", pady=(10, 8))

        def save():
            marca = var_marca.get().strip()
            nombre = var_nombre.get().strip()

            precio_txt = var_precio.get().strip()
            if precio_txt == "":
                precio_val = None
            else:
                try:
                    precio_val = float(precio_txt)
                except Exception:
                    messagebox.showerror("Error", "Precio inválido")
                    return

            ok = update_product_detail(self.ctx["db_path"], codigo, marca=marca, nombre=nombre, precio=precio_val)
            if not ok:
                messagebox.showerror("Error", "No se pudo guardar en la DB")
                return

            self._refresh_all()
            win.destroy()

        btns = ttk.Frame(container)
        btns.grid(row=7, column=0, columnspan=2, sticky="e")
        ttk.Button(btns, text="Guardar", command=save).pack(side="right", padx=(6, 0))
        ttk.Button(btns, text="Cerrar", command=win.destroy).pack(side="right")

        win.grab_set()
        win.wait_window(win)

    # ------------------------------------------------------------
    # Edit / Create (placeholder)
    # ------------------------------------------------------------
    def _editar_receta(self, mode: str):
        ui = self.ui_active if mode == "active" else self.ui_inactive
        sel = ui["lb"].curselection()
        if not sel:
            return
        receta = ui["lb"].get(sel[0])

        messagebox.showinfo(
            "Editar (pendiente)",
            f"Editar receta: {receta}\n\n(Implementación: duplicar receta y pasar la vieja a inactiva, según diagrama.)",
        )

    def _crear_receta(self):
        nombre = self.new_name.get().strip()
        base = self.new_base.get().strip()

        if not nombre:
            messagebox.showerror("Error", "Ingrese un nombre de receta.")
            return

        messagebox.showinfo(
            "Crear (pendiente)",
            f"Crear receta: {nombre}\nBasada en: {base if base else '(vacía)'}\n\n(Falta implementación DB de creación/duplicación.)",
        )
