import tkinter as tk
from tkinter import ttk, messagebox

from bull_bar.core.models import DocumentoItem
from uuid import uuid4

class CompraTab:
    def __init__(self, notebook, ctx):
        self.ctx = ctx
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="Cargar Compra/Entrada de Insumos")

        ttk.Label(frame, text="Código producto (insumo)").grid(row=0, column=0, sticky="w")
        self.codigo_entry = ttk.Entry(frame)
        self.codigo_entry.grid(row=0, column=1, sticky="ew")

        ttk.Label(frame, text="Descripción").grid(row=1, column=0, sticky="w")
        self.desc_entry = ttk.Entry(frame)
        self.desc_entry.grid(row=1, column=1, sticky="ew")

        ttk.Label(frame, text="Cantidad").grid(row=2, column=0, sticky="w")
        self.cant_entry = ttk.Entry(frame)
        self.cant_entry.grid(row=2, column=1, sticky="ew")

        reg_btn = ttk.Button(frame, text="Registrar compra (recibido)", command=self.registrar)
        reg_btn.grid(row=3, column=0, columnspan=2, pady=8)

        frame.columnconfigure(1, weight=1)

    def registrar(self):
        codigo = self.codigo_entry.get().strip()
        descripcion = self.desc_entry.get().strip() or codigo
        try:
            cantidad = float(self.cant_entry.get())
        except Exception:
            messagebox.showerror("Error", "Cantidad inválida")
            return

        prod = self.ctx["products"].get(codigo)
        # si no existe, crear un Producto temporal local (no persistido)
        if not prod:
            # usar id generado, pero services/ledger trabajan por ids
            from bull_bar.core.models import Producto
            prod = Producto(id=str(uuid4()), codigo=codigo, nombre=descripcion, unidad_medida="u")
            self.ctx["products"][codigo] = prod

        item = DocumentoItem(producto_id=prod.id, descripcion=descripcion, cantidad=cantidad)
        try:
            numero = f"C-{uuid4().hex[:6]}"
            self.ctx["purchase_service"].registrar_compra_recibida(
                numero=numero,
                ClienteProveedor_id=self.ctx["prov"].id,
                deposito_id=self.ctx["depo"].id,
                items=[item],
            )
            messagebox.showinfo("OK", f"Compra registrada: {numero}")
        except Exception as e:
            from bull_bar.infra.error_logger import log_error
            log_error(e, context="Registrando compra recibida", 
                     extra_info={"numero": numero, "producto_codigo": codigo, "cantidad": cant})
            messagebox.showerror("Error registro", f"{str(e)}\n\nRevisa error_log.txt para más detalles.")
