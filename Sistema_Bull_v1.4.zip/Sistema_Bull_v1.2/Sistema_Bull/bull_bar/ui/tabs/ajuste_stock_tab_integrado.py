"""
Tab de ajuste de stock integrado (para usar en StockWindow).
"""
import tkinter as tk
from tkinter import ttk, messagebox
from bull_bar.stock.adjustment import StockAdjustmentService


class AjusteStockTabIntegrado(ttk.Frame):
    """Tab de ajuste de stock para usar dentro de StockWindow."""
    
    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        self.adjust_svc = StockAdjustmentService(self.ctx["ledger"], db_path=self.ctx.get("db_path"))
        self._build_ui()
    
    def _build_ui(self):
        # Título
        ttk.Label(self, text="Ajuste de Stock", font=("Helvetica", 12, "bold")).pack(pady=(10, 15))
        
        # Formulario
        form = ttk.Frame(self, padding=20)
        form.pack(fill="both", expand=True)
        form.columnconfigure(1, weight=1)
        
        ttk.Label(form, text="Producto (código):").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=8)
        self.codigo = ttk.Entry(form, width=30)
        self.codigo.grid(row=0, column=1, sticky="ew", pady=8)
        
        ttk.Label(form, text="Cantidad (+/-):").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=8)
        self.cantidad = ttk.Entry(form, width=30)
        self.cantidad.grid(row=1, column=1, sticky="ew", pady=8)
        
        ttk.Label(form, text="Motivo:").grid(row=2, column=0, sticky="w", padx=(0, 10), pady=8)
        self.motivo = ttk.Entry(form, width=30)
        self.motivo.grid(row=2, column=1, sticky="ew", pady=8)
        
        # Botones
        btn_frame = ttk.Frame(form)
        btn_frame.grid(row=3, column=0, columnspan=2, pady=(20, 0))
        
        ttk.Button(btn_frame, text="Aplicar Ajuste", command=self.aplicar).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Limpiar", command=self.limpiar).pack(side="left", padx=5)
    
    def aplicar(self):
        codigo = self.codigo.get().strip()
        if not codigo:
            messagebox.showerror("Error", "Ingrese un código de producto")
            return
        
        try:
            cantidad = float(self.cantidad.get())
        except Exception:
            messagebox.showerror("Error", "Cantidad inválida")
            return
        
        prod = self.ctx["products"].get(codigo)
        if not prod:
            messagebox.showerror("Error", "Producto no encontrado")
            return
        
        motivo = self.motivo.get().strip() or "Ajuste manual"
        try:
            self.adjust_svc.apply_adjustment(
                self.ctx["depo"].id, 
                prod.id, 
                cantidad, 
                motivo,
                usuario="Usuario"  # TODO: obtener usuario real
            )
            messagebox.showinfo("OK", "Ajuste aplicado correctamente")
            self.limpiar()
        except Exception as e:
            from bull_bar.infra.error_logger import log_error
            log_error(e, context="Aplicando ajuste de stock", 
                     extra_info={"codigo": codigo, "cantidad": cantidad, "motivo": motivo})
            messagebox.showerror("Error ajuste", f"{str(e)}\n\nRevisa error_log.txt para más detalles.")
    
    def limpiar(self):
        self.codigo.delete(0, "end")
        self.cantidad.delete(0, "end")
        self.motivo.delete(0, "end")

