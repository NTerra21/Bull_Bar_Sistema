"""
Módulo de páginas principales de la aplicación.
Cada página es un Frame independiente que se muestra en el content_container.
"""
