"""
Página principal de Movimientos con sub-tabs en la barra superior.
Implementa Compra/Entrada, Venta o Generar Venta, y Remito como sub-páginas.
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from bull_bar.core.models import DocumentoItem
from uuid import uuid4
from datetime import datetime


class MovimientosPage(ttk.Frame):
    """
    Página principal de Movimientos con Notebook interno (igual estética que Stock).
    Contiene las pestañas: Compra / Entrada, Venta o Generar Venta, y Remito.
    """
    
    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        self.db_path = ctx["db_path"]
        
        # Configurar grid para la página completa (igual que Stock)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # =========================
        # NOTEBOOK INTERNO (igual estética que Stock)
        # =========================
        movimientos_notebook = ttk.Notebook(self)
        movimientos_notebook.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        movimientos_notebook.grid_rowconfigure(0, weight=1)
        movimientos_notebook.grid_columnconfigure(0, weight=1)
        
        # Crear las pestañas
        compra_page = self._create_compra_page(movimientos_notebook)
        movimientos_notebook.add(compra_page, text="Compra / Entrada")
        
        venta_page = self._create_venta_page(movimientos_notebook)
        movimientos_notebook.add(venta_page, text="Venta o Generar Venta")
        
        remito_page = self._create_remito_page(movimientos_notebook)
        movimientos_notebook.add(remito_page, text="Remito")
        
        # Pestaña de Aprobaciones (solo para ADMIN)
        usuario_actual = ctx.get("usuario_actual", {})
        from bull_bar.infra.auth import RolUsuario
        if usuario_actual.get("rol") == RolUsuario.ADMIN.value:
            aprobaciones_page = self._create_aprobaciones_page(movimientos_notebook)
            # Cargar ícono de exclamación para badge
            self._img_exclamacion = None
            try:
                import os
                import tkinter as tk
                icon_path = os.path.join(os.path.dirname(__file__), "..", "..", "..", "img", "exclamacion.png")
                if os.path.exists(icon_path):
                    self._img_exclamacion = tk.PhotoImage(file=icon_path)
                    # Reducir tamaño si es muy grande (16-20px)
                    if self._img_exclamacion.width() > 20 or self._img_exclamacion.height() > 20:
                        factor = max(1, int(max(self._img_exclamacion.width(), self._img_exclamacion.height()) / 18))
                        self._img_exclamacion = self._img_exclamacion.subsample(factor, factor)
            except Exception as e:
                print(f"[DEBUG] MovimientosPage: No se pudo cargar ícono exclamación: {e}")
            
            # Agregar pestaña (el badge se actualizará después)
            movimientos_notebook.add(aprobaciones_page, text="Aprobaciones")
            
            # Guardar referencia al notebook para poder refrescar cuando se seleccione la pestaña
            self.movimientos_notebook = movimientos_notebook
            self.aprobaciones_page = aprobaciones_page
            
            # Función para actualizar badge de la pestaña
            def update_aprobaciones_badge():
                """Actualiza el badge de la pestaña Aprobaciones."""
                try:
                    from bull_bar.infra.sqlite_produccion_pendientes import contar_pendientes
                    count = contar_pendientes(self.db_path, estado="PENDIENTE_APROBACION")
                    
                    if count > 0:
                        # Mostrar badge con símbolo y contador (ttk.Notebook no soporta image directamente)
                        movimientos_notebook.tab(aprobaciones_page, text=f"⚠ Aprobaciones ({count})")
                    else:
                        # Quitar badge, volver al texto normal
                        movimientos_notebook.tab(aprobaciones_page, text="Aprobaciones")
                except Exception as e:
                    print(f"[ERROR] update_aprobaciones_badge: Error: {e}")
            
            # Actualizar badge inicialmente
            update_aprobaciones_badge()
            
            # Guardar función para poder llamarla desde otros métodos
            self.update_aprobaciones_badge = update_aprobaciones_badge
            
            # Bind para refrescar cuando se seleccione la pestaña de Aprobaciones
            def on_tab_changed(event):
                selected = movimientos_notebook.index(movimientos_notebook.select())
                if selected == movimientos_notebook.index(aprobaciones_page):
                    self._refresh_aprobaciones()
            movimientos_notebook.bind("<<NotebookTabChanged>>", on_tab_changed)
    
    def _create_compra_page(self, parent) -> ttk.Frame:
        """Crea la sub-página de Compra / Entrada."""
        page = ttk.Frame(parent)
        page.pack(fill="both", expand=True)
        
        # Frame interno con el contenido
        f = ttk.Frame(page)
        f.pack(fill="both", expand=True, padx=6, pady=6)
        f.grid_columnconfigure(1, weight=1)
        
        ttk.Label(f, text="Compra / Entrada de Insumos", 
                 font=("Helvetica", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0,6))
        
        # modo: manual factura o subir archivo (próximamente)
        modo_var = tk.StringVar(value="manual")
        ttk.Radiobutton(f, text="Manual (factura)", variable=modo_var, value="manual").grid(row=1, column=0, sticky="w")
        ttk.Radiobutton(f, text="Subir archivo (próximamente)", variable=modo_var, value="file").grid(row=1, column=1, sticky="w")
        
        ttk.Label(f, text="Código producto (insumo)").grid(row=2, column=0, sticky="w")
        codigo_entry = ttk.Entry(f)
        codigo_entry.grid(row=2, column=1, sticky="ew")
        
        ttk.Label(f, text="Descripción").grid(row=3, column=0, sticky="w")
        desc_entry = ttk.Entry(f)
        desc_entry.grid(row=3, column=1, sticky="ew")
        
        ttk.Label(f, text="Cantidad").grid(row=4, column=0, sticky="w")
        cant_entry = ttk.Entry(f)
        cant_entry.grid(row=4, column=1, sticky="ew")
        
        ttk.Label(f, text="Número de factura (opcional)").grid(row=5, column=0, sticky="w")
        factura_entry = ttk.Entry(f)
        factura_entry.grid(row=5, column=1, sticky="ew")
        
        def subir_archivo():
            messagebox.showinfo("Próximamente", "La funcionalidad de subir archivo estará disponible próximamente.")
        
        def registrar():
            codigo = codigo_entry.get().strip()
            descripcion = desc_entry.get().strip() or codigo
            try:
                cantidad = float(cant_entry.get())
            except Exception:
                messagebox.showerror("Error", "Cantidad inválida")
                return
            if modo_var.get() == "file":
                subir_archivo()
                return
            prod = self.ctx["products"].get(codigo)
            if not prod:
                from bull_bar.core.models import Producto
                prod = Producto(id=str(uuid4()), codigo=codigo, nombre=descripcion, unidad_medida="u")
                self.ctx["products"][codigo] = prod
            item = DocumentoItem(producto_id=prod.id, descripcion=descripcion, cantidad=cantidad)
            try:
                numero = f"C-{uuid4().hex[:6]}"
                self.ctx["purchase_service"].registrar_compra_recibida(
                    numero=numero,
                    ClienteProveedor_id=self.ctx["prov"].id,
                    deposito_id=self.ctx["depo"].id,
                    items=[item],
                )
                messagebox.showinfo("OK", f"Compra registrada: {numero}")
            except Exception as e:
                messagebox.showerror("Error registro", str(e))
        
        ttk.Button(f, text="Registrar compra (recibido)", command=registrar).grid(row=6, column=0, columnspan=2, pady=8)
        ttk.Button(f, text="Subir archivo", command=subir_archivo).grid(row=6, column=2, padx=6)
        
        return page
    
    def _create_venta_page(self, parent) -> ttk.Frame:
        """Crea la sub-página de Venta o Generar Venta."""
        page = ttk.Frame(parent)
        page.pack(fill="both", expand=True)
        
        # Frame interno con el contenido
        f = ttk.Frame(page)
        f.pack(fill="both", expand=True, padx=6, pady=6)
        f.grid_columnconfigure(1, weight=1)
        
        ttk.Label(f, text="Venta", font=("Helvetica", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0,6))
        ttk.Label(f, text="Producto (codigo)").grid(row=1, column=0, sticky="w")
        codigo = ttk.Entry(f)
        codigo.grid(row=1, column=1, sticky="ew")
        ttk.Label(f, text="Cantidad").grid(row=2, column=0, sticky="w")
        cantidad = ttk.Entry(f)
        cantidad.grid(row=2, column=1, sticky="ew")
        
        def intentar():
            cod = codigo.get().strip()
            try:
                cant = float(cantidad.get())
            except Exception:
                messagebox.showerror("Error", "Cantidad inválida")
                return
            prod = self.ctx["products"].get(cod)
            if not prod:
                messagebox.showerror("Error", "Producto no encontrado en catálogo")
                return
            numero = f"V-{uuid4().hex[:6]}"
            doc_venta, movs, faltantes = self.ctx["sale_service"].intentar_venta(
                numero=numero,
                ClienteProveedor_id=self.ctx["cli"].id,
                deposito_id=self.ctx["depo"].id,
                items=[DocumentoItem(producto_id=prod.id, descripcion=prod.nombre, cantidad=cant)],
            )
            if faltantes:
                # crear orden pendiente real en ctx
                order = {
                    "id": uuid4().hex,
                    "numero": numero,
                    "producto_codigo": cod,
                    "cantidad_solicitada": cant,
                    "cliente_id": self.ctx["cli"].id,
                    "deposito_id": self.ctx["depo"].id,
                    "estado": "PENDIENTE",
                    "faltantes": faltantes,
                    "created_at": datetime.now().isoformat(),
                }
                self.ctx.setdefault("pending_orders", []).append(order)
                messagebox.showinfo("Pendiente", f"Orden PENDIENTE creada: {order['id']}")
            else:
                messagebox.showinfo("Venta OK", f"Venta {numero} realizada")
        
        ttk.Button(f, text="Intentar vender", command=intentar).grid(row=3, column=0, columnspan=2, pady=8)
        
        return page
    
    def _create_remito_page(self, parent) -> ttk.Frame:
        """Crea la sub-página de Remito."""
        page = ttk.Frame(parent)
        page.pack(fill="both", expand=True)
        
        # Frame interno con el contenido
        f = ttk.Frame(page)
        f.pack(fill="both", expand=True, padx=6, pady=6)
        
        ttk.Label(f, text="Remito / Despacho (pendiente de implementación)", 
                 font=("Helvetica", 12, "bold")).pack(anchor="w", pady=(0,6))
        ttk.Label(f, text="Aquí se gestionarán remitos de venta y despacho.").pack(anchor="w", pady=4)
        ttk.Button(f, text="Acción dummy", 
                  command=lambda: messagebox.showinfo("Info", "Pendiente implementar")).pack(pady=8)
        
        return page
    
    def _create_aprobaciones_page(self, parent) -> ttk.Frame:
        """Crea la pestaña de Aprobaciones para ADMIN."""
        page = ttk.Frame(parent)
        page.pack(fill="both", expand=True)
        
        # Configurar grid
        page.grid_rowconfigure(0, weight=1)
        page.grid_columnconfigure(0, weight=1)
        
        # Frame principal
        main_frame = ttk.Frame(page, padding=10)
        main_frame.pack(fill="both", expand=True)
        main_frame.grid_rowconfigure(1, weight=1)
        main_frame.grid_columnconfigure(0, weight=1)
        
        # Barra superior con botón refrescar
        top_bar = ttk.Frame(main_frame)
        top_bar.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        
        ttk.Label(top_bar, text="Movimientos Pendientes de Aprobación", 
                 font=("Helvetica", 12, "bold")).pack(side="left")
        
        ttk.Button(top_bar, text="Refrescar", command=self._refresh_aprobaciones).pack(side="right", padx=5)
        
        # Treeview con scrollbar
        tree_frame = ttk.Frame(main_frame)
        tree_frame.grid(row=1, column=0, sticky="nsew")
        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)
        
        # Columnas del treeview
        cols = ("alerta", "id", "receta", "mezcla_kg", "usuario_creador", "fecha_creacion", "estado")
        self.aprobaciones_tree = ttk.Treeview(tree_frame, columns=cols, show="headings", selectmode="browse")
        
        # Configurar columnas
        self.aprobaciones_tree.heading("alerta", text="⚠")
        self.aprobaciones_tree.column("alerta", width=30, stretch=False)
        
        self.aprobaciones_tree.heading("id", text="ID")
        self.aprobaciones_tree.column("id", width=100, stretch=False)
        
        self.aprobaciones_tree.heading("receta", text="Receta")
        self.aprobaciones_tree.column("receta", width=150)
        
        self.aprobaciones_tree.heading("mezcla_kg", text="Mezcla (kg)")
        self.aprobaciones_tree.column("mezcla_kg", width=100, stretch=False)
        
        self.aprobaciones_tree.heading("usuario_creador", text="Creado por")
        self.aprobaciones_tree.column("usuario_creador", width=150)
        
        self.aprobaciones_tree.heading("fecha_creacion", text="Fecha creación")
        self.aprobaciones_tree.column("fecha_creacion", width=180)
        
        self.aprobaciones_tree.heading("estado", text="Estado")
        self.aprobaciones_tree.column("estado", width=150)
        
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.aprobaciones_tree.yview)
        self.aprobaciones_tree.configure(yscrollcommand=scrollbar.set)
        
        self.aprobaciones_tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        
        # Cargar ícono de alerta si existe
        self.alerta_icon = None
        try:
            import os
            icon_path = os.path.join(os.path.dirname(__file__), "..", "..", "img", "exclamacion.png")
            if os.path.exists(icon_path):
                self.alerta_icon = tk.PhotoImage(file=icon_path)
                # Reducir tamaño si es muy grande
                if self.alerta_icon.width() > 20 or self.alerta_icon.height() > 20:
                    factor = max(1, int(max(self.alerta_icon.width(), self.alerta_icon.height()) / 20))
                    self.alerta_icon = self.alerta_icon.subsample(factor, factor)
        except Exception as e:
            print(f"[DEBUG] No se pudo cargar ícono de alerta: {e}")
        
        # Botones de acción (abajo)
        action_frame = ttk.Frame(main_frame)
        action_frame.grid(row=2, column=0, sticky="e", pady=(10, 0))
        
        self.btn_aprobar = ttk.Button(action_frame, text="Aprobar", command=self._aprobar_seleccionado, state="disabled")
        self.btn_aprobar.pack(side="left", padx=5)
        
        self.btn_denegar = ttk.Button(action_frame, text="Denegar", command=self._denegar_seleccionado, state="disabled")
        self.btn_denegar.pack(side="left", padx=5)
        
        # Habilitar/deshabilitar botones según selección
        self.aprobaciones_tree.bind("<<TreeviewSelect>>", self._on_seleccion_aprobacion)
        
        # Cargar pendientes inicialmente
        self._refresh_aprobaciones()
        
        # Actualizar badge después de refrescar
        if hasattr(self, 'update_aprobaciones_badge'):
            self.update_aprobaciones_badge()
        
        return page
    
    def _refresh_aprobaciones(self):
        """Refresca la lista de movimientos pendientes."""
        # Limpiar treeview
        for item in self.aprobaciones_tree.get_children():
            self.aprobaciones_tree.delete(item)
        
        try:
            from bull_bar.infra.sqlite_produccion_pendientes import listar_pendientes
            
            # Solo mostrar pendientes de aprobación
            pendientes = listar_pendientes(self.db_path, estado="PENDIENTE_APROBACION")
            
            for pendiente in pendientes:
                # Ícono de alerta: usar "⚠" como texto (el ícono se puede agregar después si es necesario)
                alerta_val = "⚠"
                
                # Formatear fecha
                fecha_str = pendiente.get("timestamp_creacion", "")
                if fecha_str:
                    try:
                        fecha_dt = datetime.fromisoformat(fecha_str.replace("Z", "+00:00"))
                        fecha_str = fecha_dt.strftime("%Y-%m-%d %H:%M")
                    except:
                        fecha_str = fecha_str[:19] if len(fecha_str) > 19 else fecha_str
                
                item_id = self.aprobaciones_tree.insert("", "end", values=(
                    alerta_val,
                    pendiente.get("id", "")[:8],  # Mostrar solo primeros 8 caracteres
                    pendiente.get("receta_codigo", ""),
                    f"{pendiente.get('mezcla_kg', 0):.1f}",
                    pendiente.get("usuario_creador_nombre", ""),
                    fecha_str,
                    pendiente.get("estado", ""),
                ), tags=("pendiente",))
                
                # Guardar ID completo en el item (usando una columna oculta o el primer valor)
                self.aprobaciones_tree.set(item_id, "id", pendiente.get("id", ""))
            
            # Configurar tag para fondo amarillo (si es posible)
            try:
                self.aprobaciones_tree.tag_configure("pendiente", background="#fff9c4")
            except:
                pass
            
            # Actualizar badge de la pestaña después de refrescar
            if hasattr(self, 'update_aprobaciones_badge'):
                self.update_aprobaciones_badge()
            
            # Actualizar avisos del header después de refrescar
            root = self.winfo_toplevel()
            if hasattr(root, 'update_notices'):
                root.update_notices()
                
        except Exception as e:
            messagebox.showerror("Error", f"Error al cargar pendientes: {str(e)}")
    
    def _on_seleccion_aprobacion(self, event):
        """Habilita/deshabilita botones según la selección."""
        selection = self.aprobaciones_tree.selection()
        if selection:
            estado = self.aprobaciones_tree.item(selection[0], "values")[6]  # columna estado
            if estado == "PENDIENTE_APROBACION":
                self.btn_aprobar.config(state="normal")
                self.btn_denegar.config(state="normal")
            else:
                self.btn_aprobar.config(state="disabled")
                self.btn_denegar.config(state="disabled")
        else:
            self.btn_aprobar.config(state="disabled")
            self.btn_denegar.config(state="disabled")
    
    def _aprobar_seleccionado(self):
        """Aprueba el movimiento pendiente seleccionado."""
        selection = self.aprobaciones_tree.selection()
        if not selection:
            return
        
        # Obtener ID completo del pendiente
        item_id = selection[0]
        pendiente_id = self.aprobaciones_tree.set(item_id, "id")
        
        try:
            from bull_bar.infra.sqlite_produccion_pendientes import obtener_pendiente, aprobar_pendiente
            
            # Obtener datos del pendiente
            pendiente = obtener_pendiente(self.db_path, pendiente_id)
            if not pendiente:
                messagebox.showerror("Error", "Pendiente no encontrado")
                return
            
            # Convertir consumos JSON a DocumentoItem
            consumos = []
            for consumo_data in pendiente.get("consumos", []):
                producto_codigo = consumo_data.get("producto_codigo", "")
                cantidad_kg = consumo_data.get("cantidad_kg", 0)
                
                prod_obj = self.ctx["products"].get(producto_codigo)
                if not prod_obj:
                    from bull_bar.core.models import Producto
                    from bull_bar.infra.sqlite_recetas import get_producto_nombre
                    nombre_prod = get_producto_nombre(self.db_path, producto_codigo) or producto_codigo
                    prod_obj = Producto(id=str(uuid4()), codigo=producto_codigo, nombre=nombre_prod, unidad_medida="kg")
                    self.ctx["products"][producto_codigo] = prod_obj
                
                consumos.append(DocumentoItem(
                    producto_id=prod_obj.id,
                    descripcion=prod_obj.nombre,
                    cantidad=cantidad_kg
                ))
            
            # Preparar producto final
            producto_final_codigo = f"PROD-{pendiente.get('receta_codigo', '')}"
            prod_final_obj = self.ctx["products"].get(producto_final_codigo)
            if not prod_final_obj:
                from bull_bar.core.models import Producto
                prod_final_obj = Producto(
                    id=str(uuid4()),
                    codigo=producto_final_codigo,
                    nombre=pendiente.get("receta_nombre", producto_final_codigo),
                    unidad_medida="u"
                )
                self.ctx["products"][producto_final_codigo] = prod_final_obj
            
            producto_final = DocumentoItem(
                producto_id=prod_final_obj.id,
                descripcion=prod_final_obj.nombre,
                cantidad=1.0
            )
            
            # Registrar producción (aplica stock)
            numero = f"P-{pendiente.get('receta_codigo', '')}-{int(pendiente.get('mezcla_kg', 0))}-{uuid4().hex[:4]}"
            doc, movs = self.ctx["production_service"].registrar_remito_produccion_rapido(
                numero=numero,
                deposito_id=self.ctx["depo"].id,
                consumos=consumos,
                producto_final=producto_final,
                usuario=self.ctx.get("usuario_actual", {}).get("username", "ADMIN")
            )
            
            # Actualizar pendiente como aprobado
            aprobar_pendiente(
                db_path=self.db_path,
                pendiente_id=pendiente_id,
                usuario_aprobador_id=self.ctx.get("usuario_actual", {}).get("id", ""),
                usuario_aprobador_nombre=self.ctx.get("usuario_actual", {}).get("username", "ADMIN"),
                documento_id=doc.id
            )
            
            messagebox.showinfo("Aprobado", f"Producción {numero} aprobada y stock actualizado.")
            # Refrescar la lista de aprobaciones
            self._refresh_aprobaciones()
            # Actualizar badge de la pestaña
            if hasattr(self, 'update_aprobaciones_badge'):
                self.update_aprobaciones_badge()
            # Actualizar badge del botón principal y avisos (si existen)
            root = self.winfo_toplevel()
            if hasattr(root, 'update_pending_badge'):
                root.update_pending_badge()
            if hasattr(root, 'update_notices'):
                root.update_notices()
            # Deshabilitar botones después de aprobar
            self.btn_aprobar.config(state="disabled")
            self.btn_denegar.config(state="disabled")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al aprobar: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def _denegar_seleccionado(self):
        """Deniega el movimiento pendiente seleccionado."""
        selection = self.aprobaciones_tree.selection()
        if not selection:
            return
        
        # Obtener ID completo del pendiente
        item_id = selection[0]
        pendiente_id = self.aprobaciones_tree.set(item_id, "id")
        
        # Pedir motivo
        from tkinter import simpledialog
        motivo = simpledialog.askstring(
            "Denegar Producción",
            "Ingrese el motivo de la denegación:",
            parent=self.winfo_toplevel()
        )
        
        if not motivo:
            return
        
        try:
            from bull_bar.infra.sqlite_produccion_pendientes import denegar_pendiente
            
            denegar_pendiente(
                db_path=self.db_path,
                pendiente_id=pendiente_id,
                usuario_aprobador_id=self.ctx.get("usuario_actual", {}).get("id", ""),
                usuario_aprobador_nombre=self.ctx.get("usuario_actual", {}).get("username", "ADMIN"),
                motivo=motivo
            )
            
            messagebox.showinfo("Denegado", "Producción denegada correctamente.")
            # Refrescar la lista de aprobaciones
            self._refresh_aprobaciones()
            # Actualizar badge de la pestaña
            if hasattr(self, 'update_aprobaciones_badge'):
                self.update_aprobaciones_badge()
            # Actualizar badge del botón principal y avisos (si existen)
            root = self.winfo_toplevel()
            if hasattr(root, 'update_pending_badge'):
                root.update_pending_badge()
            if hasattr(root, 'update_notices'):
                root.update_notices()
            # Deshabilitar botones después de denegar
            self.btn_aprobar.config(state="disabled")
            self.btn_denegar.config(state="disabled")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al denegar: {str(e)}")
