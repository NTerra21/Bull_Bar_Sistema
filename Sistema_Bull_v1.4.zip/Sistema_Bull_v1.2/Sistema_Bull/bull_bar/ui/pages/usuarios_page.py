"""
Página principal de Usuarios con Notebook interno (igual estética que Stock y Movimientos).
Contiene pestañas: Lista de Usuarios y Detalle (se abre al seleccionar un usuario).
"""
import tkinter as tk
from tkinter import ttk, messagebox
from bull_bar.infra.auth import listar_usuarios, crear_usuario


class UsuariosPage(ttk.Frame):
    """
    Página principal de Usuarios con Notebook interno.
    Contiene las pestañas: Lista de Usuarios y Detalle.
    """
    
    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        self.db_path = ctx["db_path"]
        self.usuario_actual = ctx.get("usuario_actual", {})
        
        # Configurar grid para la página completa (igual que Stock y Movimientos)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # =========================
        # NOTEBOOK INTERNO (igual estética que Stock y Movimientos)
        # =========================
        usuarios_notebook = ttk.Notebook(self)
        usuarios_notebook.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        usuarios_notebook.grid_rowconfigure(0, weight=1)
        usuarios_notebook.grid_columnconfigure(0, weight=1)
        
        # Crear la pestaña de lista
        lista_page = self._create_lista_page(usuarios_notebook)
        usuarios_notebook.add(lista_page, text="Lista de Usuarios")
    
    def _create_lista_page(self, parent) -> ttk.Frame:
        """Crea la pestaña de Lista de Usuarios."""
        page = ttk.Frame(parent)
        page.pack(fill="both", expand=True)
        
        # Barra superior
        top = ttk.Frame(page, padding=10)
        top.pack(fill="x")
        
        ttk.Label(top, text="Gestión de Usuarios", font=("Helvetica", 14, "bold")).pack(side="left")
        ttk.Button(top, text="Nuevo Usuario", command=self._nuevo_usuario).pack(side="right", padx=5)
        ttk.Button(top, text="Refrescar", command=self._refresh_lista).pack(side="right", padx=5)
        ttk.Button(top, text="Detalle", command=self._mostrar_detalle).pack(side="right", padx=5)
        
        # Frame para treeview y scrollbar
        tree_frame = ttk.Frame(page)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Lista de usuarios
        cols = ("username", "rol", "nombre_completo", "email", "activo", "last_login")
        self.tree = ttk.Treeview(tree_frame, columns=cols, show="headings", selectmode="browse")
        
        self.tree.heading("username", text="Usuario")
        self.tree.heading("rol", text="Rol")
        self.tree.heading("nombre_completo", text="Nombre")
        self.tree.heading("email", text="Email")
        self.tree.heading("activo", text="Activo")
        self.tree.heading("last_login", text="Último Login")
        
        self.tree.column("username", width=120)
        self.tree.column("rol", width=100)
        self.tree.column("nombre_completo", width=200)
        self.tree.column("email", width=150)
        self.tree.column("activo", width=80)
        self.tree.column("last_login", width=150)
        
        scroll = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        
        # Doble click o Enter para ver detalle
        self.tree.bind("<Double-1>", lambda e: self._mostrar_detalle())
        self.tree.bind("<Return>", lambda e: self._mostrar_detalle())
        
        # Cargar lista inicial
        self._refresh_lista()
        
        return page
    
    def _refresh_lista(self):
        """Refresca la lista de usuarios."""
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        
        usuarios = listar_usuarios(self.db_path)
        for u in usuarios:
            self.tree.insert("", "end", values=(
                u["username"],
                u["rol"],
                u["nombre_completo"] or "",
                u["email"] or "",
                "Sí" if u["activo"] else "No",
                u["last_login"][:19] if u["last_login"] else "",
            ))
    
    def _mostrar_detalle(self):
        """Muestra el detalle del usuario seleccionado en una ventana flotante (Toplevel)."""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Advertencia", "Seleccione un usuario para ver su detalle")
            return
        
        values = self.tree.item(selection[0], "values")
        username = values[0]
        
        # Obtener datos completos del usuario
        usuarios = listar_usuarios(self.db_path)
        usuario_data = next((u for u in usuarios if u["username"] == username), None)
        
        if not usuario_data:
            messagebox.showerror("Error", "Usuario no encontrado")
            return
        
        # Crear ventana flotante de detalle (como en Stock)
        self._open_detalle_window(usuario_data)
    
    def _open_detalle_window(self, usuario_data: dict):
        """Abre una ventana flotante (Toplevel) con el detalle del usuario."""
        root = self.winfo_toplevel()
        win = tk.Toplevel(root)
        win.title(f"Detalle - {usuario_data['username']}")
        win.transient(root)
        win.geometry("600x500")
        
        container = ttk.Frame(win, padding=20)
        container.pack(fill="both", expand=True)
        container.columnconfigure(1, weight=1)
        
        # Título
        ttk.Label(container, text=f"Detalle del Usuario: {usuario_data['username']}", 
                 font=("Helvetica", 14, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 20))
        
        # Información del usuario
        row = 1
        ttk.Label(container, text="Usuario:", font=("Helvetica", 10, "bold")).grid(row=row, column=0, sticky="e", padx=(0, 10), pady=5)
        ttk.Label(container, text=usuario_data["username"]).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ttk.Label(container, text="Rol:", font=("Helvetica", 10, "bold")).grid(row=row, column=0, sticky="e", padx=(0, 10), pady=5)
        ttk.Label(container, text=usuario_data["rol"]).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ttk.Label(container, text="Nombre completo:", font=("Helvetica", 10, "bold")).grid(row=row, column=0, sticky="e", padx=(0, 10), pady=5)
        ttk.Label(container, text=usuario_data.get("nombre_completo") or "(No especificado)").grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ttk.Label(container, text="Email:", font=("Helvetica", 10, "bold")).grid(row=row, column=0, sticky="e", padx=(0, 10), pady=5)
        ttk.Label(container, text=usuario_data.get("email") or "(No especificado)").grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ttk.Label(container, text="Estado:", font=("Helvetica", 10, "bold")).grid(row=row, column=0, sticky="e", padx=(0, 10), pady=5)
        estado_texto = "Activo" if usuario_data.get("activo", True) else "Inactivo"
        ttk.Label(container, text=estado_texto).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ttk.Label(container, text="Último login:", font=("Helvetica", 10, "bold")).grid(row=row, column=0, sticky="e", padx=(0, 10), pady=5)
        last_login = usuario_data.get("last_login", "")
        if last_login:
            ttk.Label(container, text=last_login[:19]).grid(row=row, column=1, sticky="w", pady=5)
        else:
            ttk.Label(container, text="Nunca", foreground="gray").grid(row=row, column=1, sticky="w", pady=5)
        
        # Botón cerrar
        btn_frame = ttk.Frame(container)
        btn_frame.grid(row=row+1, column=0, columnspan=2, pady=(20, 0))
        
        ttk.Button(btn_frame, text="Cerrar", command=win.destroy).pack(side="left", padx=5)
        
        # Centrar ventana
        win.update_idletasks()
        x = (win.winfo_screenwidth() // 2) - (win.winfo_width() // 2)
        y = (win.winfo_screenheight() // 2) - (win.winfo_height() // 2)
        win.geometry(f"+{x}+{y}")
        
        win.lift()
        try:
            win.focus_force()
        except:
            pass
    
    def _nuevo_usuario(self):
        """Abre ventana para crear nuevo usuario."""
        win = tk.Toplevel(self.winfo_toplevel())
        win.title("Nuevo Usuario")
        win.geometry("400x350")
        win.transient(self.winfo_toplevel())
        win.grab_set()
        
        container = ttk.Frame(win, padding=20)
        container.pack(fill="both", expand=True)
        container.columnconfigure(1, weight=1)
        
        ttk.Label(container, text="Usuario:").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=5)
        entry_user = ttk.Entry(container)
        entry_user.grid(row=0, column=1, sticky="ew", pady=5)
        
        ttk.Label(container, text="Rol:").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=5)
        combo_rol = ttk.Combobox(container, values=["ADMIN", "GERENTE", "USUARIO"], state="readonly")
        combo_rol.set("USUARIO")
        combo_rol.grid(row=1, column=1, sticky="ew", pady=5)
        
        ttk.Label(container, text="Nombre completo:").grid(row=2, column=0, sticky="w", padx=(0, 10), pady=5)
        entry_nombre = ttk.Entry(container)
        entry_nombre.grid(row=2, column=1, sticky="ew", pady=5)
        
        ttk.Label(container, text="Email:").grid(row=3, column=0, sticky="w", padx=(0, 10), pady=5)
        entry_email = ttk.Entry(container)
        entry_email.grid(row=3, column=1, sticky="ew", pady=5)
        
        ttk.Label(container, text="Nota: La contraseña inicial será igual al usuario.", 
                 foreground="gray", font=("Helvetica", 9)).grid(row=4, column=0, columnspan=2, pady=(10, 0))
        
        def crear():
            username = entry_user.get().strip()
            rol = combo_rol.get()
            nombre = entry_nombre.get().strip()
            email = entry_email.get().strip()
            
            if not username:
                messagebox.showerror("Error", "Ingrese un usuario")
                return
            
            ok, msg = crear_usuario(self.db_path, username, rol, nombre or None, email or None)
            if ok:
                messagebox.showinfo("Éxito", msg)
                win.destroy()
                self._refresh_lista()
            else:
                messagebox.showerror("Error", msg)
        
        btn_frame = ttk.Frame(container)
        btn_frame.grid(row=5, column=0, columnspan=2, pady=(20, 0))
        ttk.Button(btn_frame, text="Crear", command=crear).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Cancelar", command=win.destroy).pack(side="left", padx=5)
