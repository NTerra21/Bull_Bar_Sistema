"""
Página principal de Producción con flujo tipo wizard por pasos.
Implementa selección de receta, confirmación, mezcla y checklist de insumos.
"""
import tkinter as tk
from tkinter import ttk, messagebox
from bull_bar.core.models import DocumentoItem
from bull_bar.infra.sqlite_recetas import list_recetas, get_receta_items, get_producto_nombre
from uuid import uuid4
from datetime import datetime
import sqlite3


class ProduccionPage(ttk.Frame):
    """
    Página principal de Producción con flujo tipo wizard por pasos.
    Paso 0: Selección de receta
    Paso 1: Confirmación de receta
    Paso 2: Selección de mezcla
    Paso 3: Checklist de insumos
    """
    
    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        self.db_path = ctx["db_path"]
        
        # Estado interno del wizard
        self.paso_actual = 0  # 0: selección receta, 1: confirmación receta, 2: mezcla, 3: checklist
        self.receta_seleccionada = None  # código de receta seleccionada
        self.receta_nombre = None  # nombre de la receta
        self.mezcla_confirmada = None  # cantidad de mezcla confirmada
        self.checklist_items = []  # Lista de (var, item_data) para acceder a los checkboxes
        self.usuario_actual = ctx.get("usuario_actual", {})
        
        # Configurar grid para la página completa (igual que Stock y Movimientos)
        self.grid_rowconfigure(1, weight=1)  # checklist_frame expande
        self.grid_columnconfigure(0, weight=1)
        
        # =========================
        # NOTEBOOK INTERNO (igual estética que Stock y Movimientos)
        # =========================
        produccion_notebook = ttk.Notebook(self)
        produccion_notebook.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        produccion_notebook.grid_rowconfigure(0, weight=1)
        produccion_notebook.grid_columnconfigure(0, weight=1)
        
        # Crear la pestaña principal
        main_page = self._create_main_page(produccion_notebook)
        produccion_notebook.add(main_page, text="Producción")
    
    def _get_recetas_con_nombres(self):
        """Obtiene lista de recetas con sus códigos y nombres."""
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            # Intentar obtener de tabla recetas con nombre
            try:
                cur.execute("SELECT codigo, nombre FROM recetas ORDER BY codigo")
                rows = cur.fetchall()
                conn.close()
                return [(r[0], r[1] or r[0]) for r in rows]  # Si no hay nombre, usar código
            except:
                # Si no existe columna nombre, solo códigos
                codigos = list_recetas(self.db_path, active=True)
                conn.close()
                return [(c, c) for c in codigos]  # código como nombre también
        except Exception:
            return []
    
    def _create_main_page(self, parent) -> ttk.Frame:
        """Crea la pestaña principal de producción con flujo tipo wizard."""
        page = ttk.Frame(parent)
        page.pack(fill="both", expand=True)
        
        # Configurar grid de la página (checklist debe ocupar TODO el espacio disponible)
        page.grid_rowconfigure(1, weight=1)  # checklist_frame expande verticalmente
        page.grid_columnconfigure(0, weight=1)  # checklist_frame expande horizontalmente
        
        # =========================
        # BARRA SUPERIOR: Resumen compacto + Navegación
        # =========================
        top_bar = ttk.Frame(page, padding=5)
        top_bar.grid(row=0, column=0, sticky="ew")
        top_bar.columnconfigure(0, weight=1)
        
        # Resumen compacto (inicialmente oculto)
        self.resumen_frame = ttk.Frame(top_bar)
        self.resumen_frame.grid(row=0, column=0, sticky="w")
        
        self.resumen_receta_label = ttk.Label(self.resumen_frame, text="", font=("Helvetica", 9))
        self.resumen_receta_label.pack(side="left", padx=(0, 15))
        
        self.resumen_mezcla_label = ttk.Label(self.resumen_frame, text="", font=("Helvetica", 9))
        self.resumen_mezcla_label.pack(side="left")
        
        # Botones de navegación (siempre visibles)
        nav_frame = ttk.Frame(top_bar)
        nav_frame.grid(row=0, column=1, sticky="e")
        
        self.btn_retroceder = ttk.Button(nav_frame, text="← Retroceder", command=self._retroceder, state="disabled")
        self.btn_retroceder.pack(side="left", padx=5)
        
        self.btn_cancelar = ttk.Button(nav_frame, text="Cancelar", command=self._cancelar)
        self.btn_cancelar.pack(side="left", padx=5)
        
        # =========================
        # PASO 0: Selección de receta
        # =========================
        self.recipe_frame = ttk.LabelFrame(page, text="Seleccioná receta:", padding=15)
        self.recipe_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        self.recipe_frame.columnconfigure(0, weight=1)
        
        # Frame para botones de recetas (con wrap)
        recetas_buttons_frame = ttk.Frame(self.recipe_frame)
        recetas_buttons_frame.grid(row=0, column=0, sticky="ew")
        
        # Obtener recetas y crear botones
        recetas = self._get_recetas_con_nombres()
        self.receta_buttons = []
        for idx, (codigo, nombre) in enumerate(recetas):
            btn = ttk.Button(
                recetas_buttons_frame, 
                text=f"{codigo}\n{nombre}",
                command=lambda c=codigo, n=nombre: self._seleccionar_receta(c, n),
                width=20
            )
            # Organizar en grid (4 columnas)
            row = idx // 4
            col = idx % 4
            btn.grid(row=row, column=col, padx=5, pady=5, sticky="ew")
            self.receta_buttons.append(btn)
            recetas_buttons_frame.columnconfigure(col, weight=1)
        
        # Label de confirmación y botón confirmar (inicialmente oculto)
        self.confirmacion_frame = ttk.Frame(self.recipe_frame)
        self.confirmacion_frame.grid(row=1, column=0, pady=(15, 0))
        
        self.confirmacion_label = ttk.Label(
            self.confirmacion_frame, 
            text="", 
            font=("Helvetica", 10, "bold"),
            foreground="green"
        )
        self.confirmacion_label.pack(side="left", padx=(0, 10))
        
        self.btn_confirmar_receta = ttk.Button(
            self.confirmacion_frame, 
            text="Confirmar receta", 
            command=self._confirmar_receta,
            state="disabled"
        )
        self.btn_confirmar_receta.pack(side="left")
        
        # Inicialmente oculto
        self.confirmacion_frame.grid_remove()
        
        # =========================
        # PASO 2: Mezcla (kg)
        # =========================
        self.mix_frame = ttk.LabelFrame(page, text="Mezcla (kg):", padding=15)
        self.mix_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=10)
        self.mix_frame.columnconfigure(0, weight=1)
        
        # Botones 10/20/30/40
        btn_frame = ttk.Frame(self.mix_frame)
        btn_frame.grid(row=0, column=0, sticky="w", pady=(0, 10))
        
        self.mezcla_buttons = []
        for val in (10, 20, 30, 40):
            btn = ttk.Button(
                btn_frame, 
                text=str(val), 
                command=lambda v=val: self._set_mezcla(v),
                state="disabled"
            )
            btn.pack(side="left", padx=2)
            self.mezcla_buttons.append((btn, val))
        
        # Input manual
        input_frame = ttk.Frame(self.mix_frame)
        input_frame.grid(row=1, column=0, sticky="w", pady=(0, 10))
        
        ttk.Label(input_frame, text="Cantidad (kg):").pack(side="left", padx=(0, 5))
        self.mezcla_entry = ttk.Entry(input_frame, width=10)
        self.mezcla_entry.pack(side="left")
        self.mezcla_entry.config(state="disabled")
        
        # Validar solo números al escribir
        self.mezcla_entry.bind("<KeyRelease>", self._validar_mezcla_input)
        
        # Botón confirmar mezcla (inicialmente oculto)
        self.btn_confirmar_mezcla = ttk.Button(
            self.mix_frame, 
            text="Confirmar mezcla", 
            command=self._confirmar_mezcla,
            state="disabled"
        )
        self.btn_confirmar_mezcla.grid(row=2, column=0, pady=(10, 0))
        
        # Inicialmente oculto
        self.mix_frame.grid_remove()
        
        # =========================
        # PASO 3: Checklist de insumos (ocupa TODO el espacio disponible)
        # =========================
        self.checklist_frame = ttk.LabelFrame(page, text="Checklist de insumos:", padding=10)
        self.checklist_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        # Configurar weights para que el checklist_frame ocupe todo el espacio
        self.checklist_frame.columnconfigure(0, weight=1)
        self.checklist_frame.rowconfigure(0, weight=1)  # Scroll frame expande (checklist)
        self.checklist_frame.rowconfigure(1, weight=0)  # Botón finalizar no expande
        
        # Frame con scrollbar para checklist
        checklist_scroll_frame = ttk.Frame(self.checklist_frame)
        checklist_scroll_frame.grid(row=0, column=0, sticky="nsew")
        checklist_scroll_frame.columnconfigure(0, weight=1)
        checklist_scroll_frame.rowconfigure(0, weight=1)
        
        # Canvas para scroll
        self.checklist_canvas = tk.Canvas(checklist_scroll_frame)
        scrollbar = ttk.Scrollbar(checklist_scroll_frame, orient="vertical", command=self.checklist_canvas.yview)
        self.checklist_inner_frame = ttk.Frame(self.checklist_canvas)
        
        def on_frame_configure(event):
            """Actualiza el scrollregion cuando el frame cambia de tamaño."""
            self.checklist_canvas.configure(scrollregion=self.checklist_canvas.bbox("all"))
        
        self.checklist_inner_frame.bind("<Configure>", on_frame_configure)
        
        canvas_window = self.checklist_canvas.create_window((0, 0), window=self.checklist_inner_frame, anchor="nw")
        
        def on_canvas_configure(event):
            """Ajusta el ancho del frame interno al ancho del canvas."""
            canvas_width = event.width
            self.checklist_canvas.itemconfig(canvas_window, width=canvas_width)
        
        self.checklist_canvas.bind("<Configure>", on_canvas_configure)
        self.checklist_canvas.configure(yscrollcommand=scrollbar.set)
        
        # Habilitar scroll con rueda del mouse (Windows y Linux)
        def on_mousewheel(event):
            if event.num == 4 or event.delta > 0:
                self.checklist_canvas.yview_scroll(-1, "units")
            elif event.num == 5 or event.delta < 0:
                self.checklist_canvas.yview_scroll(1, "units")
        
        # Windows y Mac
        self.checklist_canvas.bind_all("<MouseWheel>", on_mousewheel)
        # Linux
        self.checklist_canvas.bind_all("<Button-4>", on_mousewheel)
        self.checklist_canvas.bind_all("<Button-5>", on_mousewheel)
        
        self.checklist_canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        
        # Botón Finalizar (abajo a la derecha)
        btn_finalizar_frame = ttk.Frame(self.checklist_frame)
        btn_finalizar_frame.grid(row=1, column=0, sticky="e", pady=(10, 0))
        
        self.btn_finalizar = ttk.Button(
            btn_finalizar_frame,
            text="Finalizar",
            command=self._finalizar_produccion,
            state="disabled"
        )
        self.btn_finalizar.pack(side="right", padx=5)
        
        # Inicialmente oculto
        self.checklist_frame.grid_remove()
        
        # Estado inicial: mostrar solo recipe_frame
        self._mostrar_paso(0)
        
        return page
    
    def _mostrar_paso(self, paso: int):
        """Muestra/oculta frames según el paso actual del wizard."""
        self.paso_actual = paso
        
        # Ocultar todos los frames
        self.recipe_frame.grid_remove()
        self.mix_frame.grid_remove()
        self.checklist_frame.grid_remove()
        self.confirmacion_frame.grid_remove()
        self.resumen_frame.grid_remove()
        
        # Actualizar botón retroceder
        if paso == 0:
            self.btn_retroceder.config(state="disabled")
        else:
            self.btn_retroceder.config(state="normal")
        
        # Mostrar frames según el paso
        if paso == 0:
            # Paso 0: Solo selección de receta
            self.recipe_frame.grid()
        elif paso == 1:
            # Paso 1: Confirmación de receta (receta_frame visible con confirmación)
            self.recipe_frame.grid()
            self.confirmacion_frame.grid()
        elif paso == 2:
            # Paso 2: Mezcla
            self.resumen_frame.grid()
            self.mix_frame.grid()
        elif paso == 3:
            # Paso 3: Checklist (ocupa máximo espacio)
            self.resumen_frame.grid()
            self.checklist_frame.grid()
    
    def _seleccionar_receta(self, codigo: str, nombre: str):
        """Selecciona una receta y muestra confirmación (Paso 1)."""
        self.receta_seleccionada = codigo
        self.receta_nombre = nombre
        
        # Mostrar confirmación
        self.confirmacion_label.config(text=f"✓ Receta '{codigo}' seleccionada")
        self.confirmacion_frame.grid()
        self.btn_confirmar_receta.config(state="normal")
        
        # Cambiar a paso 1
        self._mostrar_paso(1)
    
    def _confirmar_receta(self):
        """Confirma la receta seleccionada y avanza al paso 2 (mezcla)."""
        if not self.receta_seleccionada:
            return
        
        # Ocultar recipe_frame completamente
        self.recipe_frame.grid_remove()
        
        # Mostrar resumen compacto
        self.resumen_receta_label.config(text=f"Receta: {self.receta_seleccionada}")
        self.resumen_mezcla_label.config(text="")
        
        # Habilitar controles de mezcla
        for btn, _ in self.mezcla_buttons:
            btn.config(state="normal")
        self.mezcla_entry.config(state="normal")
        
        # Limpiar mezcla
        self.mezcla_entry.delete(0, "end")
        self.mezcla_confirmada = None
        
        # Cambiar a paso 2
        self._mostrar_paso(2)
    
    def _set_mezcla(self, valor: int):
        """Establece la cantidad de mezcla desde un botón."""
        if self.paso_actual != 2:
            return
        
        self.mezcla_entry.delete(0, "end")
        self.mezcla_entry.insert(0, str(valor))
        self._validar_mezcla_para_confirmar()
    
    def _validar_mezcla_input(self, event):
        """Valida que el input solo contenga números y habilita confirmar si es válido."""
        current = self.mezcla_entry.get()
        # Filtrar solo dígitos
        filtered = ''.join(filter(str.isdigit, current))
        if filtered != current:
            # Si cambió, actualizar
            cursor_pos = self.mezcla_entry.index(tk.INSERT)
            self.mezcla_entry.delete(0, "end")
            self.mezcla_entry.insert(0, filtered)
            # Restaurar posición del cursor
            try:
                self.mezcla_entry.icursor(min(cursor_pos - 1, len(filtered)))
            except:
                pass
        
        self._validar_mezcla_para_confirmar()
    
    def _validar_mezcla_para_confirmar(self):
        """Valida la mezcla y habilita/deshabilita el botón confirmar."""
        mezcla_str = self.mezcla_entry.get().strip()
        if mezcla_str:
            try:
                valor = int(mezcla_str)
                if valor >= 1:
                    self.btn_confirmar_mezcla.config(state="normal")
                else:
                    self.btn_confirmar_mezcla.config(state="disabled")
            except:
                self.btn_confirmar_mezcla.config(state="disabled")
        else:
            self.btn_confirmar_mezcla.config(state="disabled")
    
    def _confirmar_mezcla(self):
        """Confirma la mezcla y avanza al paso 3 (checklist)."""
        mezcla_str = self.mezcla_entry.get().strip()
        if not mezcla_str:
            return
        
        try:
            mezcla = int(mezcla_str)
            if mezcla < 1:
                return
        except:
            return
        
        self.mezcla_confirmada = mezcla
        
        # Ocultar mix_frame completamente
        self.mix_frame.grid_remove()
        
        # Actualizar resumen
        self.resumen_receta_label.config(text=f"Receta: {self.receta_seleccionada}")
        self.resumen_mezcla_label.config(text=f"Mezcla: {mezcla} kg")
        
        # Calcular y mostrar checklist
        self._calcular_y_mostrar_checklist()
        
        # Cambiar a paso 3
        self._mostrar_paso(3)
    
    def _calcular_y_mostrar_checklist(self):
        """Calcula y muestra el checklist de insumos basado en la receta y mezcla confirmada."""
        if not self.receta_seleccionada or not self.mezcla_confirmada:
            return
        
        # Obtener items de la receta
        items = get_receta_items(self.db_path, self.receta_seleccionada)
        if not items:
            return
        
        # Limpiar checklist anterior
        for widget in self.checklist_inner_frame.winfo_children():
            widget.destroy()
        
        # Ordenar items (sólidos primero, luego líquidos/cremas)
        def is_solid(item):
            codigo = (item.get("producto_codigo") or "").upper()
            return not any(k in codigo for k in ("LIQ", "CREM", "CREMA", "ACEITE", "LECHE"))
        
        items_sorted = sorted(items, key=lambda it: 0 if is_solid(it) else 1)
        
        # Crear checklist (todos desmarcados inicialmente)
        self.checklist_items = []
        for idx, item in enumerate(items_sorted):
            producto_codigo = item.get("producto_codigo", "")
            porcentaje = float(item.get("porcentaje", 0))
            cantidad_calc = self.mezcla_confirmada * (porcentaje / 100.0)
            
            # Obtener nombre del producto
            nombre_producto = get_producto_nombre(self.db_path, producto_codigo) or producto_codigo
            
            # Checkbox con información (inicia desmarcado)
            var = tk.BooleanVar(value=False)
            texto = f"{producto_codigo} - {nombre_producto} | {porcentaje}% → {cantidad_calc:.3f} kg"
            cb = ttk.Checkbutton(
                self.checklist_inner_frame, 
                text=texto, 
                variable=var
            )
            cb.grid(row=idx, column=0, sticky="w", padx=4, pady=2)
            
            # Guardar referencia para acceder después
            self.checklist_items.append((var, item, cantidad_calc))
        
        # Habilitar botón Finalizar
        self.btn_finalizar.config(state="normal")
    
    def _retroceder(self):
        """Retrocede un paso en el wizard."""
        if self.paso_actual == 2:
            # Volver a paso 1 (mostrar receta con confirmación)
            self._mostrar_paso(1)
            self.confirmacion_label.config(text=f"✓ Receta '{self.receta_seleccionada}' seleccionada")
            self.confirmacion_frame.grid()
            self.btn_confirmar_receta.config(state="normal")
        elif self.paso_actual == 3:
            # Volver a paso 2 (mostrar mezcla)
            self._mostrar_paso(2)
            # Mantener valor de mezcla si existe
            if self.mezcla_confirmada:
                self.mezcla_entry.delete(0, "end")
                self.mezcla_entry.insert(0, str(self.mezcla_confirmada))
                self._validar_mezcla_para_confirmar()
            self.mezcla_confirmada = None  # Resetear confirmación
    
    def _finalizar_produccion(self):
        """Finaliza la producción según el rol del usuario."""
        if not self.receta_seleccionada or not self.mezcla_confirmada:
            return
        
        # Obtener rol del usuario
        rol_usuario = self.usuario_actual.get("rol", "USUARIO")
        from bull_bar.infra.auth import RolUsuario
        
        # Preparar consumos
        consumos = []
        for var, item, cantidad_calc in self.checklist_items:
            producto_codigo = item.get("producto_codigo", "")
            prod_obj = self.ctx["products"].get(producto_codigo)
            if not prod_obj:
                from bull_bar.core.models import Producto
                nombre_prod = get_producto_nombre(self.db_path, producto_codigo) or producto_codigo
                prod_obj = Producto(id=str(uuid4()), codigo=producto_codigo, nombre=nombre_prod, unidad_medida="kg")
                self.ctx["products"][producto_codigo] = prod_obj
            
            consumos.append(DocumentoItem(
                producto_id=prod_obj.id,
                descripcion=prod_obj.nombre,
                cantidad=cantidad_calc
            ))
        
        # Preparar producto final (por ahora usar código de receta como código de producto)
        producto_final_codigo = f"PROD-{self.receta_seleccionada}"
        prod_final_obj = self.ctx["products"].get(producto_final_codigo)
        if not prod_final_obj:
            from bull_bar.core.models import Producto
            prod_final_obj = Producto(
                id=str(uuid4()),
                codigo=producto_final_codigo,
                nombre=self.receta_nombre or self.receta_seleccionada,
                unidad_medida="u"
            )
            self.ctx["products"][producto_final_codigo] = prod_final_obj
        
        producto_final = DocumentoItem(
            producto_id=prod_final_obj.id,
            descripcion=prod_final_obj.nombre,
            cantidad=1.0  # Cantidad de unidades producidas (por ahora 1)
        )
        
        if rol_usuario == RolUsuario.ADMIN.value:
            # ADMIN: Aplicar consumo de stock inmediato
            try:
                numero = f"P-{self.receta_seleccionada}-{int(self.mezcla_confirmada)}-{uuid4().hex[:4]}"
                self.ctx["production_service"].registrar_remito_produccion_rapido(
                    numero=numero,
                    deposito_id=self.ctx["depo"].id,
                    consumos=consumos,
                    producto_final=producto_final,
                    usuario=self.usuario_actual.get("username", "ADMIN")
                )
                messagebox.showinfo("Producción registrada", f"Producción {numero} registrada y stock actualizado.")
                self._cancelar()
            except Exception as e:
                messagebox.showerror("Error", f"Error al registrar producción: {str(e)}")
        else:
            # USUARIO: Crear movimiento pendiente
            try:
                from bull_bar.infra.sqlite_produccion_pendientes import crear_pendiente
                
                # Preparar consumos para JSON
                consumos_json = []
                for var, item, cantidad_calc in self.checklist_items:
                    producto_codigo = item.get("producto_codigo", "")
                    consumos_json.append({
                        "producto_codigo": producto_codigo,
                        "cantidad_kg": cantidad_calc
                    })
                
                crear_pendiente(
                    db_path=self.db_path,
                    receta_codigo=self.receta_seleccionada,
                    receta_nombre=self.receta_nombre or self.receta_seleccionada,
                    mezcla_kg=self.mezcla_confirmada,
                    consumos=consumos_json,
                    usuario_creador_id=self.usuario_actual.get("id", ""),
                    usuario_creador_nombre=self.usuario_actual.get("username", "USUARIO")
                )
                
                messagebox.showinfo(
                    "Producción enviada a aprobación",
                    "La producción ha sido enviada para aprobación. Un administrador la revisará."
                )
                self._cancelar()
            except Exception as e:
                messagebox.showerror("Error", f"Error al crear movimiento pendiente: {str(e)}")
    
    def _cancelar(self):
        """Cancela todo y vuelve al paso 0."""
        # Limpiar estado
        self.receta_seleccionada = None
        self.receta_nombre = None
        self.mezcla_confirmada = None
        self.checklist_items = []
        
        # Limpiar UI
        self.mezcla_entry.delete(0, "end")
        for widget in self.checklist_inner_frame.winfo_children():
            widget.destroy()
        
        # Ocultar confirmación
        self.confirmacion_frame.grid_remove()
        self.btn_confirmar_receta.config(state="disabled")
        
        # Deshabilitar controles
        for btn, _ in self.mezcla_buttons:
            btn.config(state="disabled")
        self.mezcla_entry.config(state="disabled")
        self.btn_confirmar_mezcla.config(state="disabled")
        self.btn_finalizar.config(state="disabled")
        
        # Volver a paso 0
        self._mostrar_paso(0)
