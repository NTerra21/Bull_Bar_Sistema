from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from ..core.enums import TipoMovimiento, EstadoMovimiento


@dataclass(frozen=True)
class MovimientoStock:
    id: str
    fecha: datetime
    producto_id: str
    deposito_id: str
    tipo: TipoMovimiento
    cantidad: float
    origen_documento_id: str
    estado: EstadoMovimiento = EstadoMovimiento.CONFIRMADO

    def signed_qty(self) -> float:
        return float(self.cantidad) if self.tipo == TipoMovimiento.ENTRADA else -float(self.cantidad)
