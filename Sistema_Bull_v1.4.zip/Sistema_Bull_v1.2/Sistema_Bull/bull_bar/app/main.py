from __future__ import annotations

from uuid import uuid4

from bull_bar.core.enums import ClienteProveedor as ClienteProveedorTipo
from bull_bar.core.models import Producto, Deposito, ClienteProveedor as ClienteProveedorModel, DocumentoItem
from bull_bar.stock.service import StockLedger
from bull_bar.compra_venta.services import PurchaseService, SaleService
from bull_bar.produccion.services import ProductionService


# Nueva función para uso por UI: ejecuta el flujo y devuelve un dict con logs, stocks, documentos y faltantes
def get_demo_for_ui() -> dict:
    ledger = StockLedger()
    compras = PurchaseService(ledger)
    ventas = SaleService(ledger)
    produccion = ProductionService(ledger)

    result: dict = {"logs": [], "stocks": {}, "documentos": [], "faltantes": []}

    # Datos base
    depo = Deposito(id=str(uuid4()), nombre="Deposito Principal")
    prov = ClienteProveedorModel(id=str(uuid4()), tipo=ClienteProveedorTipo.PROVEEDOR, razon_social="Proveedor X")
    cli = ClienteProveedorModel(id=str(uuid4()), tipo=ClienteProveedorTipo.CLIENTE, razon_social="Cliente Y")

    ins_avena = Producto(id=str(uuid4()), codigo="INS-AVENA", nombre="Avena", unidad_medida="kg")
    barrita = Producto(id=str(uuid4()), codigo="PROD-BARRITA", nombre="Barrita Tal", unidad_medida="u")

    result["logs"].append("== 1) Compra recibida (entra insumo) ==")
    doc_compra, movs = compras.registrar_compra_recibida(
        numero="C-0001",
        ClienteProveedor_id=prov.id,
        deposito_id=depo.id,
        items=[DocumentoItem(producto_id=ins_avena.id, descripcion="Avena", cantidad=30.0)],
    )
    result["stocks"][(depo.id, ins_avena.id)] = ledger.stock_confirmado(depo.id, ins_avena.id)

    result["logs"].append("== 2) Producción RÁPIDA (descuenta al toque) ==")
    doc_prod, movs_prod = produccion.registrar_remito_produccion_rapido(
        numero="P-0001",
        deposito_id=depo.id,
        consumos=[DocumentoItem(producto_id=ins_avena.id, descripcion="Avena usada", cantidad=10.0)],
        producto_final=DocumentoItem(producto_id=barrita.id, descripcion="Barrita Tal", cantidad=100.0),
    )
    result["stocks"][(depo.id, ins_avena.id)] = ledger.stock_confirmado(depo.id, ins_avena.id)
    result["stocks"][(depo.id, barrita.id)] = ledger.stock_confirmado(depo.id, barrita.id)

    result["logs"].append("== 3) Venta con stock insuficiente -> PENDIENTE_STOCK ==")
    doc_venta, movs_venta, faltantes = ventas.intentar_venta(
        numero="V-0001",
        ClienteProveedor_id=cli.id,
        deposito_id=depo.id,
        items=[DocumentoItem(producto_id=barrita.id, descripcion="Barrita Tal", cantidad=150.0)],
    )
    result["documentos"].append({"venta": doc_venta, "movs": movs_venta})
    result["faltantes"].extend(faltantes or [])
    if faltantes:
        result["logs"].append(f"Faltantes: {faltantes}")

    result["logs"].append("== 4) Venta ajustada a disponible (100) ==")
    doc_venta2, movs_venta2, faltantes2 = ventas.intentar_venta(
        numero="V-0002",
        ClienteProveedor_id=cli.id,
        deposito_id=depo.id,
        items=[DocumentoItem(producto_id=barrita.id, descripcion="Barrita Tal", cantidad=100.0)],
    )
    result["documentos"].append({"venta": doc_venta2, "movs": movs_venta2})
    result["faltantes"].extend(faltantes2 or [])
    result["stocks"][(depo.id, barrita.id)] = ledger.stock_confirmado(depo.id, barrita.id)

    return result


def main():
    """Ejecuta el demo y muestra un resumen compacto por consola."""
    try:
        res = get_demo_for_ui()
    except Exception as e:
        print("Error ejecutando demo:", e)
        return
    print("== Demo resumen ==")
    for l in res.get("logs", []):
        print(" -", l)
    print("\nStocks confirmados:")
    for (_depo, prod_id), qty in res.get("stocks", {}).items():
        print(f"  producto={prod_id} => {qty}")
    if res.get("faltantes"):
        print("\nFaltantes:", res.get("faltantes"))


if __name__ == "__main__":
    # 1) UI nueva
    try:
        from bull_bar.ui.app import main as ui_main
        ui_main()
    except Exception as e:
        # 2) UI vieja (infra.ui)
        try:
            from bull_bar.infra.ui import main as old_ui_main
            old_ui_main()
        except Exception:
            # 3) demo consola
            print("Error abriendo UI:", repr(e))
            main()

