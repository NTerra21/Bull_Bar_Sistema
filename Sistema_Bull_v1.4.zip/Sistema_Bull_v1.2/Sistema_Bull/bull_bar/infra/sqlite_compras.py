"""
Funciones para gestionar lotes de compra (para mostrar en detalle de producto).
"""
from __future__ import annotations

import sqlite3
from datetime import datetime
from typing import Optional

from .sqlite_db import connect, init_schema


def _ensure(db_path: str) -> sqlite3.Connection:
    conn = connect(db_path)
    init_schema(conn)
    return conn


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def registrar_lote_compra(
    db_path: str,
    producto_id: str,
    documento_id: str,
    documento_numero: str,
    cantidad: float,
    *,
    fecha_compra: Optional[str] = None,
    fecha_vencimiento: Optional[str] = None,
    precio_unitario: Optional[float] = None,
    deposito: Optional[str] = None,
    comprobante: Optional[str] = None,
    ruta_archivo: Optional[str] = None,
) -> bool:
    """Registra un lote de compra asociado a un producto."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        fecha_compra = fecha_compra or _now_iso()
        
        # Verificar si existen las columnas nuevas
        cur.execute("PRAGMA table_info(compra_lotes)")
        columns = [col[1] for col in cur.fetchall()]
        has_precio = "precio_unitario" in columns
        has_ruta = "ruta_archivo" in columns
        
        if has_precio and has_ruta:
            cur.execute("""
            INSERT INTO compra_lotes 
            (producto_id, documento_id, documento_numero, fecha_compra, fecha_vencimiento, 
             cantidad, precio_unitario, deposito, comprobante, ruta_archivo, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                producto_id,
                documento_id,
                documento_numero,
                fecha_compra,
                fecha_vencimiento,
                float(cantidad),
                precio_unitario,
                deposito,
                comprobante,
                ruta_archivo,
                _now_iso(),
            ))
        else:
            # Versión sin columnas nuevas (compatibilidad)
            cur.execute("""
            INSERT INTO compra_lotes 
            (producto_id, documento_id, documento_numero, fecha_compra, fecha_vencimiento, 
             cantidad, deposito, comprobante, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                producto_id,
                documento_id,
                documento_numero,
                fecha_compra,
                fecha_vencimiento,
                float(cantidad),
                deposito,
                comprobante,
                _now_iso(),
            ))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error registrando lote de compra: {e}")
        return False


def listar_lotes_compra(
    db_path: str,
    producto_id: str,
) -> list[dict]:
    """Lista todos los lotes de compra de un producto."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        # Verificar columnas disponibles
        cur.execute("PRAGMA table_info(compra_lotes)")
        columns = [col[1] for col in cur.fetchall()]
        has_precio = "precio_unitario" in columns
        has_ruta = "ruta_archivo" in columns
        
        if has_precio and has_ruta:
            cur.execute("""
            SELECT id, producto_id, documento_id, documento_numero, fecha_compra, 
                   fecha_vencimiento, cantidad, precio_unitario, deposito, comprobante, ruta_archivo, created_at
            FROM compra_lotes
            WHERE producto_id = ?
            ORDER BY fecha_compra DESC
            """, (producto_id,))
            
            rows = []
            for r in cur.fetchall():
                rows.append({
                    "id": r[0],
                    "producto_id": r[1],
                    "documento_id": r[2],
                    "documento_numero": r[3],
                    "fecha_compra": r[4],
                    "fecha_vencimiento": r[5],
                    "cantidad": float(r[6]),
                    "precio_unitario": float(r[7]) if r[7] is not None else None,
                    "deposito": r[8],
                    "comprobante": r[9],
                    "ruta_archivo": r[10],
                    "created_at": r[11],
                })
        else:
            cur.execute("""
            SELECT id, producto_id, documento_id, documento_numero, fecha_compra, 
                   fecha_vencimiento, cantidad, deposito, comprobante, created_at
            FROM compra_lotes
            WHERE producto_id = ?
            ORDER BY fecha_compra DESC
            """, (producto_id,))
            
            rows = []
            for r in cur.fetchall():
                rows.append({
                    "id": r[0],
                    "producto_id": r[1],
                    "documento_id": r[2],
                    "documento_numero": r[3],
                    "fecha_compra": r[4],
                    "fecha_vencimiento": r[5],
                    "cantidad": float(r[6]),
                    "precio_unitario": None,
                    "deposito": r[7],
                    "comprobante": r[8],
                    "ruta_archivo": None,
                    "created_at": r[9],
                })
        
        conn.close()
        return rows
    except Exception as e:
        print(f"Error listando lotes de compra: {e}")
        return []

