from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Generic, List, Optional, TypeVar

T = TypeVar("T")


@dataclass
class InMemoryRepo(Generic[T]):
    """
    Repositorio simple en memoria.
    Sirve para prototipar sin DB (tests y demos rápidas).
    """
    data: Dict[str, T] = field(default_factory=dict)

    def add(self, obj_id: str, obj: T) -> None:
        self.data[obj_id] = obj

    def get(self, obj_id: str) -> Optional[T]:
        return self.data.get(obj_id)

    def all(self) -> List[T]:
        return list(self.data.values())
