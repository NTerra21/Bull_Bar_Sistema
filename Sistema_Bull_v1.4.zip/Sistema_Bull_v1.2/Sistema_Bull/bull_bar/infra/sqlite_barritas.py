from __future__ import annotations

import sqlite3
from datetime import datetime

from .sqlite_db import connect, init_schema


def _ensure(db_path: str) -> sqlite3.Connection:
    conn = connect(db_path)
    init_schema(conn)
    return conn


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def list_lotes(db_path: str, *, q: str = "") -> list[dict]:
    """Lista lotes (producto terminado). Filtro simple por sku/nombre/lote."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        q = (q or "").strip().upper()

        if q:
            cur.execute(
                "SELECT lote_id, sku, nombre, cantidad_total, cantidad_vendida, cantidad_disponible, "
                "fecha_produccion, fecha_vencimiento, deposito, estado, notas, created_at, updated_at "
                "FROM barritas_lotes "
                "WHERE UPPER(lote_id) LIKE ? OR UPPER(sku) LIKE ? OR UPPER(COALESCE(nombre,'')) LIKE ? "
                "ORDER BY fecha_vencimiento ASC, lote_id ASC",
                (f"%{q}%", f"%{q}%", f"%{q}%"),
            )
        else:
            cur.execute(
                "SELECT lote_id, sku, nombre, cantidad_total, cantidad_vendida, cantidad_disponible, "
                "fecha_produccion, fecha_vencimiento, deposito, estado, notas, created_at, updated_at "
                "FROM barritas_lotes ORDER BY fecha_vencimiento ASC, lote_id ASC"
            )

        rows = []
        for r in cur.fetchall():
            rows.append(
                {
                    "lote_id": r[0],
                    "sku": r[1],
                    "nombre": r[2] or "",
                    "cantidad_total": float(r[3] or 0),
                    "cantidad_vendida": float(r[4] or 0),
                    "cantidad_disponible": float(r[5] or 0),
                    "fecha_produccion": r[6] or "",
                    "fecha_vencimiento": r[7] or "",
                    "deposito": r[8] or "",
                    "estado": r[9] or "",
                    "notas": r[10] or "",
                    "created_at": r[11] or "",
                    "updated_at": r[12] or "",
                }
            )
        conn.close()
        return rows
    except Exception:
        return []


def upsert_lote(
    db_path: str,
    *,
    lote_id: str,
    sku: str,
    nombre: str = "",
    cantidad_total: float = 0.0,
    cantidad_vendida: float = 0.0,
    cantidad_disponible: float | None = None,
    fecha_produccion: str = "",
    fecha_vencimiento: str = "",
    deposito: str = "",
    estado: str = "DISPONIBLE",
    notas: str = "",
) -> bool:
    """Crea o actualiza un lote.

    - Si cantidad_disponible es None => se recalcula como total - vendida.
    """
    try:
        lote_id = lote_id.strip()
        sku = sku.strip()
        if not lote_id or not sku:
            return False

        if cantidad_disponible is None:
            cantidad_disponible = float(cantidad_total) - float(cantidad_vendida)
        now = _now_iso()

        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM barritas_lotes WHERE lote_id=?", (lote_id,))
        exists = cur.fetchone() is not None

        if exists:
            cur.execute(
                "UPDATE barritas_lotes SET sku=?, nombre=?, cantidad_total=?, cantidad_vendida=?, cantidad_disponible=?, "
                "fecha_produccion=?, fecha_vencimiento=?, deposito=?, estado=?, notas=?, updated_at=? WHERE lote_id=?",
                (
                    sku,
                    nombre,
                    float(cantidad_total),
                    float(cantidad_vendida),
                    float(cantidad_disponible),
                    fecha_produccion,
                    fecha_vencimiento,
                    deposito,
                    estado,
                    notas,
                    now,
                    lote_id,
                ),
            )
        else:
            cur.execute(
                "INSERT INTO barritas_lotes (lote_id, sku, nombre, cantidad_total, cantidad_vendida, cantidad_disponible, "
                "fecha_produccion, fecha_vencimiento, deposito, estado, notas, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    lote_id,
                    sku,
                    nombre,
                    float(cantidad_total),
                    float(cantidad_vendida),
                    float(cantidad_disponible),
                    fecha_produccion,
                    fecha_vencimiento,
                    deposito,
                    estado,
                    notas,
                    now,
                    now,
                ),
            )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def delete_lote(db_path: str, lote_id: str) -> bool:
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("DELETE FROM barritas_lotes WHERE lote_id=?", (lote_id,))
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False
