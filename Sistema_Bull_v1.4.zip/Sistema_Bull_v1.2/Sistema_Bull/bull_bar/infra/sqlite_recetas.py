from __future__ import annotations

import sqlite3
from datetime import datetime

from .sqlite_db import connect, init_schema


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _ensure(db_path: str) -> sqlite3.Connection:
    conn = connect(db_path)
    init_schema(conn)
    _ensure_migrations(conn)
    return conn


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,))
    return cur.fetchone() is not None


def _column_exists(conn: sqlite3.Connection, table: str, col: str) -> bool:
    cur = conn.cursor()
    cur.execute(f"PRAGMA table_info({table})")
    return any(r[1] == col for r in cur.fetchall())


def _ensure_migrations(conn: sqlite3.Connection) -> None:
    """Migraciones suaves para DBs viejas (con versionado)."""
    cur = conn.cursor()

    # 1) Crear tabla receta_versions si no existe
    if not _table_exists(conn, "receta_versions"):
        cur.execute("""
        CREATE TABLE IF NOT EXISTS receta_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            receta_codigo TEXT NOT NULL,
            version INTEGER NOT NULL,
            created_at TEXT,
            updated_at TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            inactivated_at TEXT,
            UNIQUE(receta_codigo, version)
        )
        """)

    # 2) receta_items: agregar receta_version si falta
    if _table_exists(conn, "receta_items") and not _column_exists(conn, "receta_items", "receta_version"):
        cur.execute("ALTER TABLE receta_items ADD COLUMN receta_version INTEGER DEFAULT 1")

    # 3) receta_items: NULL -> 1
    if _table_exists(conn, "receta_items"):
        cur.execute("UPDATE receta_items SET receta_version = 1 WHERE receta_version IS NULL")

    # 4) Poblar versiones base (v1 activa) para recetas existentes
    if _table_exists(conn, "recetas"):
        cur.execute("SELECT codigo FROM recetas")
        recetas = [r[0] for r in cur.fetchall()]
        now = _now_iso()

        for codigo in recetas:
            cur.execute("SELECT 1 FROM receta_versions WHERE receta_codigo=? LIMIT 1", (codigo,))
            if cur.fetchone() is None:
                cur.execute(
                    "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
                    "VALUES (?, 1, ?, ?, 1, NULL)",
                    (codigo, now, now),
                )

    conn.commit()



# ------------------------------------------------------------
# Productos
# ------------------------------------------------------------

def list_products(db_path: str):
    """Devuelve productos soportando columnas extra si existiesen (marca, etc.)."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()

        cur.execute("PRAGMA table_info(products)")
        cols = [r[1] for r in cur.fetchall()]

        select_cols = ["codigo", "nombre", "uuid", "precio"]
        if "marca" in cols:
            select_cols.insert(1, "marca")

        cur.execute(f"SELECT {', '.join(select_cols)} FROM products")
        rows = []
        for r in cur.fetchall():
            d = {}
            for idx, c in enumerate(select_cols):
                d[c] = r[idx]
            if "marca" not in d:
                d["marca"] = ""
            rows.append(d)

        conn.close()
        return rows
    except Exception:
        return []


def update_product_detail(
    db_path: str,
    producto_codigo: str,
    *,
    marca: str | None = None,
    nombre: str | None = None,
    precio: float | None = None,
) -> bool:
    """Actualiza marca/nombre/precio si existen esas columnas."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(products)")
        cols = {r[1] for r in cur.fetchall()}

        sets = []
        params = []

        if nombre is not None and "nombre" in cols:
            sets.append("nombre = ?")
            params.append(nombre)
        if precio is not None and "precio" in cols:
            sets.append("precio = ?")
            params.append(precio)
        if marca is not None and "marca" in cols:
            sets.append("marca = ?")
            params.append(marca)

        if not sets:
            conn.close()
            return True

        params.append(producto_codigo)
        cur.execute(f"UPDATE products SET {', '.join(sets)} WHERE codigo = ?", tuple(params))
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


# ------------------------------------------------------------
# Compat helpers (para UI)
# ------------------------------------------------------------

def list_recetas(db_path: str, *, active: bool | None = True) -> list[str]:
    """Lista códigos de recetas.

    - active=True: solo recetas cuya versión activa está marcada.
    - active=False: solo versiones inactivas (devuelve códigos con al menos 1 versión inactiva).
    - active=None: todas.

    NOTA: esta función existe por compatibilidad, porque algunas pantallas
    (Producción / RecetasTab vieja) esperan `list_recetas`.
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()

        # Si existe la tabla de versiones, usala
        if _table_exists(conn, "receta_versions"):
            if active is None:
                cur.execute("SELECT DISTINCT receta_codigo FROM receta_versions ORDER BY receta_codigo")
            else:
                cur.execute(
                    "SELECT DISTINCT receta_codigo FROM receta_versions WHERE is_active=? ORDER BY receta_codigo",
                    (1 if active else 0,),
                )
            rows = [r[0] for r in cur.fetchall()]
            conn.close()
            return rows

        # Fallback: tabla recetas sin activas/inactivas
        cur.execute("SELECT codigo FROM recetas ORDER BY codigo")
        rows = [r[0] for r in cur.fetchall()]
        conn.close()
        return rows
    except Exception:
        return []


def get_producto_nombre(db_path: str, producto_codigo: str) -> str | None:
    """Devuelve el nombre del producto desde la tabla `products` (si existe)."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("SELECT nombre FROM products WHERE codigo = ?", (producto_codigo,))
        row = cur.fetchone()
        conn.close()
        if not row:
            return None
        return row[0]
    except Exception:
        return None


# ------------------------------------------------------------
# Recetas (versionadas)
# ------------------------------------------------------------

def list_receta_versions(db_path: str, *, active: bool | None = True):
    """active=True solo activas, False solo inactivas, None todas."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()

        if active is None:
            cur.execute(
                "SELECT receta_codigo, version, created_at, updated_at, is_active, inactivated_at "
                "FROM receta_versions ORDER BY receta_codigo, version DESC"
            )
        else:
            cur.execute(
                "SELECT receta_codigo, version, created_at, updated_at, is_active, inactivated_at "
                "FROM receta_versions WHERE is_active = ? ORDER BY receta_codigo, version DESC",
                (1 if active else 0,),
            )

        rows = [
            {
                "codigo": r[0],
                "version": int(r[1]),
                "created_at": r[2],
                "updated_at": r[3],
                "is_active": bool(r[4]),
                "inactivated_at": r[5],
            }
            for r in cur.fetchall()
        ]
        conn.close()
        return rows
    except Exception:
        return []


def get_active_version(db_path: str, receta_codigo: str) -> int:
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute(
            "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
            (receta_codigo,),
        )
        row = cur.fetchone()
        if row:
            conn.close()
            return int(row[0])

        cur.execute("SELECT MAX(version) FROM receta_versions WHERE receta_codigo=?", (receta_codigo,))
        row = cur.fetchone()
        conn.close()
        return int(row[0] or 1)
    except Exception:
        return 1


def get_receta_version_meta(db_path: str, receta_codigo: str, version: int):
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute(
            "SELECT created_at, updated_at, is_active, inactivated_at FROM receta_versions WHERE receta_codigo=? AND version=?",
            (receta_codigo, int(version)),
        )
        row = cur.fetchone()
        conn.close()
        if not row:
            return None
        return {
            "codigo": receta_codigo,
            "version": int(version),
            "created_at": row[0],
            "updated_at": row[1],
            "is_active": bool(row[2]),
            "inactivated_at": row[3],
        }
    except Exception:
        return None


def get_receta_items(db_path: str, receta_codigo: str, version: int | None = None):
    try:
        if version is None:
            version = get_active_version(db_path, receta_codigo)
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute(
            "SELECT producto_codigo, porcentaje FROM receta_items WHERE receta_codigo=? AND receta_version=?",
            (receta_codigo, int(version)),
        )
        rows = [{"producto_codigo": r[0], "porcentaje": r[1]} for r in cur.fetchall()]
        conn.close()
        return rows
    except Exception:
        return []


def bump_receta_version(db_path: str, receta_codigo: str) -> int | None:
    """Crea una nueva versión activa duplicando items de la versión activa actual."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        cur.execute(
            "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
            (receta_codigo,),
        )
        row = cur.fetchone()
        if row:
            old_v = int(row[0])
        else:
            cur.execute(
                "SELECT COALESCE(MAX(version), 1) FROM receta_versions WHERE receta_codigo=?",
                (receta_codigo,),
            )
            old_v = int(cur.fetchone()[0] or 1)

        cur.execute("SELECT COALESCE(MAX(version), 0) FROM receta_versions WHERE receta_codigo=?", (receta_codigo,))
        maxv = int(cur.fetchone()[0] or 0)
        new_v = maxv + 1

        cur.execute(
            "UPDATE receta_versions SET is_active=0, updated_at=?, inactivated_at=? WHERE receta_codigo=? AND is_active=1",
            (now, now, receta_codigo),
        )

        cur.execute(
            "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
            "VALUES (?, ?, ?, ?, 1, NULL)",
            (receta_codigo, new_v, now, now),
        )

        cur.execute(
            "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
            "SELECT receta_codigo, ?, producto_codigo, porcentaje FROM receta_items "
            "WHERE receta_codigo=? AND receta_version=?",
            (new_v, receta_codigo, int(old_v)),
        )

        conn.commit()
        conn.close()
        return new_v
    except Exception:
        return None


def create_receta(db_path: str, receta_codigo: str, *, base_codigo: str | None = None) -> bool:
    """Crea receta nueva (v1 activa). Si base_codigo, copia items desde su versión activa."""
    try:
        receta_codigo = receta_codigo.strip().upper()
        base_codigo = base_codigo.strip().upper() if base_codigo else None

        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        cur.execute("INSERT INTO recetas (codigo, nombre) VALUES (?, ?)", (receta_codigo, receta_codigo))

        cur.execute(
            "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
            "VALUES (?, 1, ?, ?, 1, NULL)",
            (receta_codigo, now, now),
        )

        if base_codigo:
            cur.execute(
                "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
                (base_codigo,),
            )
            row = cur.fetchone()
            base_v = int(row[0]) if row else 1

            cur.execute(
                "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
                "SELECT ?, 1, producto_codigo, porcentaje FROM receta_items WHERE receta_codigo=? AND receta_version=?",
                (receta_codigo, base_codigo, base_v),
            )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False
    
def set_receta_active_version(db_path: str, receta_codigo: str, version: int) -> bool:
    """Activa una versión y desactiva la que esté activa actualmente para esa receta."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        # inactivar la activa (si existe)
        cur.execute(
            "UPDATE receta_versions SET is_active=0, updated_at=?, inactivated_at=? "
            "WHERE receta_codigo=? AND is_active=1",
            (now, now, receta_codigo),
        )

        # activar la seleccionada
        cur.execute(
            "UPDATE receta_versions SET is_active=1, updated_at=?, inactivated_at=NULL "
            "WHERE receta_codigo=? AND version=?",
            (now, receta_codigo, int(version)),
        )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def replace_receta_items(db_path: str, receta_codigo: str, version: int, items: list[dict]) -> bool:
    """Reemplaza todos los items de una receta/versión."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        cur.execute(
            "DELETE FROM receta_items WHERE receta_codigo=? AND receta_version=?",
            (receta_codigo, int(version)),
        )

        for it in items:
            prod = (it.get("producto_codigo") or "").strip()
            if not prod:
                continue
            porc = float(it.get("porcentaje") or 0.0)
            cur.execute(
                "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
                "VALUES (?, ?, ?, ?)",
                (receta_codigo, int(version), prod, porc),
            )

        cur.execute(
            "UPDATE receta_versions SET updated_at=? WHERE receta_codigo=? AND version=?",
            (now, receta_codigo, int(version)),
        )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False

def create_receta_named(db_path: str, receta_codigo: str, nombre: str, *, base_codigo: str | None = None) -> bool:
    """Crea receta nueva v1 activa, guardando nombre (si tu tabla recetas tiene columna nombre)."""
    try:
        receta_codigo = receta_codigo.strip().upper()
        nombre = (nombre or "").strip()
        base_codigo = base_codigo.strip().upper() if base_codigo else None

        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        # recetas(codigo, nombre)
        cur.execute("INSERT INTO recetas (codigo, nombre) VALUES (?, ?)", (receta_codigo, nombre or receta_codigo))

        cur.execute(
            "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
            "VALUES (?, 1, ?, ?, 1, NULL)",
            (receta_codigo, now, now),
        )

        if base_codigo:
            cur.execute(
                "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
                (base_codigo,),
            )
            row = cur.fetchone()
            base_v = int(row[0]) if row else 1

            cur.execute(
                "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
                "SELECT ?, 1, producto_codigo, porcentaje FROM receta_items WHERE receta_codigo=? AND receta_version=?",
                (receta_codigo, base_codigo, base_v),
            )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False

def create_new_version_from_items(db_path: str, receta_codigo: str, items: list[dict]) -> int | None:
    """
    Crea una NUEVA versión (v+1) con los items editados.
    Solo al final desactiva la versión activa anterior.
    Si algo falla, hace rollback y NO cambia nada.
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        # Version activa actual
        cur.execute(
            "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
            (receta_codigo,),
        )
        row = cur.fetchone()
        old_v = int(row[0]) if row else 1

        # Nuevo número de versión
        cur.execute("SELECT COALESCE(MAX(version), 0) FROM receta_versions WHERE receta_codigo=?", (receta_codigo,))
        new_v = int(cur.fetchone()[0] or 0) + 1

        # Crear nueva versión (activa)
        cur.execute(
            "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
            "VALUES (?, ?, ?, ?, 1, NULL)",
            (receta_codigo, new_v, now, now),
        )

        # Insertar items editados (SIN tocar la versión vieja)
        for it in items:
            prod = (it.get("producto_codigo") or "").strip()
            if not prod:
                continue
            porc = float(it.get("porcentaje") or 0.0)
            cur.execute(
                "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
                "VALUES (?, ?, ?, ?)",
                (receta_codigo, new_v, prod, porc),
            )

        # Recién acá: desactivar la versión vieja
        cur.execute(
            "UPDATE receta_versions SET is_active=0, updated_at=?, inactivated_at=? "
            "WHERE receta_codigo=? AND version=?",
            (now, now, receta_codigo, old_v),
        )

        conn.commit()
        conn.close()
        return new_v
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass
        return None
