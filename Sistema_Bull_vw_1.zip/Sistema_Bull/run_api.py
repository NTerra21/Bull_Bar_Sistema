#!/usr/bin/env python
"""
Script para ejecutar la API de Bull Bar.
Configura el PYTHONPATH correctamente antes de iniciar uvicorn.
"""
import sys
import os
from pathlib import Path

# Obtener el directorio raíz del proyecto (donde está este script)
ROOT_DIR = Path(__file__).parent.absolute()

# El módulo bull_bar está en Sistema_Bull/bull_bar/
# Agregar el directorio que contiene bull_bar al PYTHONPATH
BULL_BAR_DIR = ROOT_DIR / "Sistema_Bull"

# Verificar que existe
if not BULL_BAR_DIR.exists():
    # Si no existe, intentar el directorio actual
    BULL_BAR_DIR = ROOT_DIR

# Agregar al PYTHONPATH
if str(BULL_BAR_DIR) not in sys.path:
    sys.path.insert(0, str(BULL_BAR_DIR))

# Configurar variable de entorno también (para subprocesos)
os.environ["PYTHONPATH"] = str(BULL_BAR_DIR) + os.pathsep + os.environ.get("PYTHONPATH", "")

# Verificar que podemos importar
try:
    from bull_bar.api.main import app
    print("✅ Módulo bull_bar importado correctamente")
except ImportError as e:
    print(f"❌ Error importando bull_bar: {e}")
    print(f"📁 Directorio actual: {os.getcwd()}")
    print(f"📁 ROOT_DIR: {ROOT_DIR}")
    print(f"📁 sys.path: {sys.path[:3]}")
    sys.exit(1)

# Ahora ejecutar uvicorn
if __name__ == "__main__":
    import uvicorn
    
    print("=" * 60)
    print("🚀 Iniciando Bull Bar API")
    print("=" * 60)
    print(f"📁 Directorio: {BULL_BAR_DIR}")
    print(f"🐍 Python: {sys.version.split()[0]}")
    print()
    print("🌐 Servidor: http://localhost:8000")
    print("📚 Documentación: http://localhost:8000/docs")
    print("💚 Health Check: http://localhost:8000/health")
    print()
    print("Presiona Ctrl+C para detener el servidor")
    print("=" * 60)
    print()
    
    try:
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=8000,
            reload=False,  # Sin reload para evitar problemas con path
            log_level="info"
        )
    except KeyboardInterrupt:
        print("\n\n👋 Servidor detenido. ¡Hasta luego!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

