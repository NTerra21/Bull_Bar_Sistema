// ===== DASHBOARD =====
async function loadDashboard() {
    try {
        const [insumos, barritas, lotes, aprobaciones] = await Promise.all([
            apiCall('/stock/insumos').catch(() => []),
            apiCall('/stock/barritas').catch(() => []),
            apiCall('/lotes?estado=activos').catch(() => []),
            apiCall('/aprobaciones?estado=pendiente').catch(() => []),
        ]);

        const totalInsumos = insumos.reduce((sum, item) => sum + (item.cantidad || 0), 0);
        const totalBarritas = barritas.reduce((sum, item) => sum + (item.cantidad || 0), 0);

        document.getElementById('stat-insumos').textContent = totalInsumos.toFixed(2) + ' kg';
        document.getElementById('stat-barritas').textContent = totalBarritas.toFixed(0) + ' unidades';
        document.getElementById('stat-lotes').textContent = lotes.length || 0;
        document.getElementById('stat-aprobaciones').textContent = aprobaciones.length || 0;
    } catch (error) {
        console.error('Error cargando dashboard:', error);
    }
}

