// Configuración de la API
// IMPORTANTE: config.js debe cargarse ANTES de este script en index.html
let API_BASE = 'http://localhost:8000';

// Intentar cargar configuración desde config.js (debe estar definido por config.js)
if (typeof window !== 'undefined' && typeof window.API_BASE !== 'undefined') {
    API_BASE = window.API_BASE;
    console.log('✅ Usando API_BASE de config.js:', API_BASE);
} else {
    console.warn('⚠️ window.API_BASE no está definido. Usando valor por defecto:', API_BASE);
    console.warn('⚠️ Verifica que config.js se cargue ANTES de app.js en index.html');
    // Intentar definir desde config.js si existe pero no se cargó
    if (typeof window !== 'undefined') {
        window.API_BASE = API_BASE;
    }
}

// Estado global
let currentUser = null;
let currentToken = null;

// ===== UTILIDADES =====
function showError(message) {
    const errorDiv = document.getElementById('login-error');
    if (errorDiv) {
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
    } else {
        alert(message);
    }
}

function showMessage(elementId, message, type = 'success') {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = `<div class="message message-${type}">${message}</div>`;
        setTimeout(() => {
            element.innerHTML = '';
        }, 5000);
    }
}

async function apiCall(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
    };

    if (currentToken) {
        headers['Authorization'] = `Bearer ${currentToken}`;
    }

    try {
        const response = await fetch(url, {
            ...options,
            headers,
        });

        if (response.status === 401) {
            logout();
            return null;
        }

        if (!response.ok) {
            const error = await response.json().catch(() => ({ detail: 'Error desconocido' }));
            throw new Error(error.detail || `Error ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// ===== AUTENTICACIÓN =====
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    if (!loginForm) {
        console.error('No se encontró el formulario de login');
        return;
    }

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('login-error');
        errorDiv.style.display = 'none';

        console.log('Intentando login con:', { username, API_BASE });

        try {
            const formData = new URLSearchParams();
            formData.append('username', username);
            formData.append('password', password);

            console.log('Enviando request a:', `${API_BASE}/auth/login`);

            const response = await fetch(`${API_BASE}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData,
            });

            console.log('Response status:', response.status);

            if (!response.ok) {
                const error = await response.json().catch(() => ({ detail: 'Usuario o contraseña incorrectos' }));
                console.error('Error en login:', error);
                showError(error.detail || 'Error al iniciar sesión');
                return;
            }

            const data = await response.json();
            console.log('Token recibido:', data.access_token ? 'OK' : 'ERROR');
            currentToken = data.access_token;

            // Obtener información del usuario
            const userResponse = await fetch(`${API_BASE}/auth/me`, {
                headers: {
                    'Authorization': `Bearer ${currentToken}`,
                },
            });

            console.log('User info response status:', userResponse.status);

            if (userResponse.ok) {
                currentUser = await userResponse.json();
                console.log('Usuario autenticado:', currentUser);
                showMainScreen();
            } else {
                const errorText = await userResponse.text();
                console.error('Error obteniendo info usuario:', errorText);
                showError('Error al obtener información del usuario');
            }
        } catch (error) {
            console.error('Error completo:', error);
            let mensaje = '';
            
            // Verificar si es un error de conexión
            if (error.message.includes('Failed to fetch') || 
                error.message.includes('NetworkError') || 
                error.message.includes('Network request failed') ||
                error.name === 'TypeError') {
                mensaje = `❌ No se puede conectar con la API en ${API_BASE}\n\n` +
                         `🔧 Soluciones:\n` +
                         `1. Ejecuta: reiniciar_api.bat\n` +
                         `2. O manualmente: python scripts\\run_api.py\n` +
                         `3. Verifica que el puerto 8000 esté libre\n` +
                         `4. Revisa el firewall`;
            } else {
                mensaje = `Error: ${error.message}`;
            }
            
            showError(mensaje);
            
            // Intentar verificar el estado de la API
            fetch(`${API_BASE}/health`)
                .then(r => {
                    if (r.ok) {
                        return r.json();
                    }
                    throw new Error(`API responde con error: ${r.status}`);
                })
                .then(data => {
                    console.log('✅ API Health Check OK:', data);
                })
                .catch(e => {
                    console.error('❌ API no responde:', e);
                });
        }
    });
});

function logout() {
    currentToken = null;
    currentUser = null;
    document.getElementById('login-screen').classList.add('active');
    document.getElementById('main-screen').classList.remove('active');
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}

function showMainScreen() {
    console.log('showMainScreen() llamado');
    console.log('currentUser:', currentUser);
    
    try {
        const loginScreen = document.getElementById('login-screen');
        const mainScreen = document.getElementById('main-screen');
        
        if (!loginScreen || !mainScreen) {
            console.error('ERROR: No se encuentran las pantallas login-screen o main-screen');
            showError('Error: No se pueden encontrar los elementos de la interfaz');
            return;
        }
        
        loginScreen.classList.remove('active');
        mainScreen.classList.add('active');
        console.log('Pantallas cambiadas correctamente');
        
        // Mostrar información del usuario (con verificación de existencia)
        const userNameEl = document.getElementById('user-name');
        const userRoleEl = document.getElementById('user-role');
        
        if (userNameEl) {
            userNameEl.textContent = currentUser.username;
            console.log('user-name actualizado:', currentUser.username);
        } else {
            console.warn('No se encuentra elemento user-name');
        }
        
        if (userRoleEl) {
            userRoleEl.textContent = currentUser.rol;
            console.log('user-role actualizado:', currentUser.rol);
        } else {
            console.warn('No se encuentra elemento user-role');
        }
        
        // Mostrar/ocultar aprobaciones según el rol
        const navAprobaciones = document.getElementById('nav-aprobaciones');
        if (navAprobaciones && currentUser.rol === 'ADMIN') {
            navAprobaciones.style.display = 'block';
            console.log('nav-aprobaciones mostrado');
        } else if (navAprobaciones) {
            navAprobaciones.style.display = 'none';
        } else {
            console.warn('No se encuentra elemento nav-aprobaciones');
        }
        
        // Mostrar/ocultar pestañas según permisos (con verificación)
        const tabComprasVentas = document.getElementById('tab-compras-ventas');
        const tabAjuste = document.getElementById('tab-ajuste');
        const tabCrearReceta = document.getElementById('tab-crear-receta');
        
        if (tabComprasVentas) tabComprasVentas.style.display = 'inline-block';
        if (tabAjuste) tabAjuste.style.display = 'inline-block';
        if (tabCrearReceta) tabCrearReceta.style.display = 'inline-block';
        
        // Cargar dashboard (con verificación)
        if (typeof loadDashboard === 'function') {
            console.log('Cargando dashboard...');
            loadDashboard();
        } else {
            console.warn('loadDashboard no está definido');
        }
        
        if (typeof showPage === 'function') {
            console.log('Mostrando página dashboard...');
            showPage('dashboard');
        } else {
            console.warn('showPage no está definido');
        }
        
        console.log('showMainScreen() completado exitosamente');
    } catch (error) {
        console.error('ERROR en showMainScreen():', error);
        showError('Error al mostrar la pantalla principal: ' + error.message);
    }
}

// ===== NAVEGACIÓN =====
document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const page = btn.dataset.page;
        showPage(page);
        
        // Actualizar botones activos
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    });
});

function showPage(pageName) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const page = document.getElementById(`page-${pageName}`);
    if (page) {
        page.classList.add('active');
        loadPageContent(pageName);
        
        // Actualizar botones de navegación activos
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.page === pageName) {
                btn.classList.add('active');
            }
        });
    }
}

// Hacer showPage disponible globalmente para onclick
window.showPage = showPage;

function loadPageContent(pageName) {
    switch (pageName) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'stock':
            loadStock();
            break;
        case 'movimientos':
            loadMovimientos();
            break;
        case 'produccion':
            loadProduccion();
            break;
        case 'recetas':
            loadRecetas();
            break;
        case 'historial':
            loadHistorial();
            break;
        case 'aprobaciones':
            loadAprobaciones();
            break;
    }
}

// ===== DASHBOARD =====
async function loadDashboard() {
    try {
        const [insumos, barritas, lotes, aprobaciones] = await Promise.all([
            apiCall('/stock/insumos').catch(() => []),
            apiCall('/stock/barritas').catch(() => []),
            apiCall('/lotes?estado=activos').catch(() => []),
            apiCall('/aprobaciones?estado=pendiente').catch(() => []),
        ]);

        const totalInsumos = insumos.reduce((sum, item) => sum + (item.cantidad || 0), 0);
        const totalBarritas = barritas.reduce((sum, item) => sum + (item.cantidad || 0), 0);

        document.getElementById('stat-insumos').textContent = totalInsumos.toFixed(2) + ' kg';
        document.getElementById('stat-barritas').textContent = totalBarritas.toFixed(0) + ' unidades';
        document.getElementById('stat-lotes').textContent = lotes.length || 0;
        document.getElementById('stat-aprobaciones').textContent = aprobaciones.length || 0;
    } catch (error) {
        console.error('Error cargando dashboard:', error);
    }
}

// ===== STOCK =====
let currentStockTab = 'insumos';

document.querySelectorAll('#page-stock .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('#page-stock .tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentStockTab = btn.dataset.tab;
        loadStock();
    });
});

async function loadStock() {
    const content = document.getElementById('stock-content');
    content.innerHTML = '<p class="loading">Cargando...</p>';

    try {
        if (currentStockTab === 'insumos') {
            const data = await apiCall('/stock/insumos');
            if (!data || data.length === 0) {
                content.innerHTML = '<p>No hay insumos registrados</p>';
                return;
            }
            let html = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <h2>Stock de Insumos</h2>
                    <input type="text" id="stock-insumos-search" placeholder="Buscar..." class="input" style="width: 200px;" onkeyup="filtrarTablaStock('insumos')">
                </div>
                <table class="table" id="table-insumos">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Nombre</th>
                            <th>Cantidad</th>
                            <th>Unidad</th>
                            <th>Depósito</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            data.forEach(item => {
                html += `
                    <tr data-codigo="${item.id || ''}" data-nombre="${(item.nombre || 'N/A').toLowerCase()}">
                        <td>${item.id || 'N/A'}</td>
                        <td>${item.nombre || 'N/A'}</td>
                        <td>${(item.cantidad || 0).toFixed(2)}</td>
                        <td>${item.unidad || 'kg'}</td>
                        <td>${item.deposito || 'N/A'}</td>
                        <td><button class="btn btn-secondary" onclick="verDetalleStock('${item.id || ''}', 'insumo')">Detalle</button></td>
                    </tr>
                `;
            });
            html += `</tbody></table>`;
            content.innerHTML = html;
        } else if (currentStockTab === 'barritas') {
            // Obtener stock de barritas y lotes para calcular bultos
            const [stockData, lotes] = await Promise.all([
                apiCall('/stock/barritas').catch(() => []),
                apiCall('/lotes?estado=activos').catch(() => [])
            ]);
            
            if (!stockData || stockData.length === 0) {
                content.innerHTML = '<p>No hay barritas registradas</p>';
                return;
            }
            
            // Agrupar por SKU y calcular bultos con más información
            const bultosPorSKU = {};
            
            stockData.forEach(item => {
                // Intentar obtener SKU del nombre o código
                const sku = item.id?.replace('PROD-', '').replace('BARRITA-', '') || item.nombre?.split(' ')[0] || 'N/A';
                
                if (!bultosPorSKU[sku]) {
                    bultosPorSKU[sku] = {
                        sku: sku,
                        nombre: item.nombre || sku,
                        codigo: item.id || '',
                        totalBarritas: 0,
                        deposito: item.deposito || 'N/A',
                        lotes: [],
                        productos: []
                    };
                }
                
                bultosPorSKU[sku].totalBarritas += parseFloat(item.cantidad || 0);
                bultosPorSKU[sku].productos.push(item);
            });
            
            // Agregar información de lotes
            lotes.forEach(lote => {
                const sku = lote.sku || 'N/A';
                if (bultosPorSKU[sku]) {
                    bultosPorSKU[sku].lotes.push(lote);
                } else {
                    // Si hay un lote sin producto en stock, agregarlo
                    bultosPorSKU[sku] = {
                        sku: sku,
                        nombre: lote.nombre || sku,
                        codigo: '',
                        totalBarritas: parseFloat(lote.cantidad_disponible || 0),
                        deposito: lote.deposito || 'N/A',
                        lotes: [lote],
                        productos: []
                    };
                }
            });
            
            let html = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <h2>Stock de Barritas</h2>
                    <input type="text" id="stock-barritas-search" placeholder="Buscar por SKU o nombre..." class="input" style="width: 250px;" onkeyup="filtrarTablaStock('barritas')">
                </div>
                <table class="table" id="table-barritas">
                    <thead>
                        <tr>
                            <th>SKU</th>
                            <th>Nombre</th>
                            <th>Código</th>
                            <th>Cajas Grandes</th>
                            <th>Cajas Chicas</th>
                            <th>Barritas Sueltas</th>
                            <th>Total Barritas</th>
                            <th>Lotes</th>
                            <th>Depósito</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            Object.values(bultosPorSKU).forEach(skuData => {
                const bultos = calcularBultos(skuData.totalBarritas);
                const numLotes = skuData.lotes.length;
                
                html += `
                    <tr data-sku="${skuData.sku.toLowerCase()}" data-nombre="${(skuData.nombre || '').toLowerCase()}">
                        <td><strong>${skuData.sku}</strong></td>
                        <td>${skuData.nombre}</td>
                        <td>${skuData.codigo || 'N/A'}</td>
                        <td><strong>${bultos.cajasGrandes}</strong></td>
                        <td>${bultos.cajasChicas}</td>
                        <td>${bultos.barritasSueltas.toFixed(0)}</td>
                        <td><strong>${bultos.totalBarritas.toFixed(0)}</strong></td>
                        <td>${numLotes} ${numLotes === 1 ? 'lote' : 'lotes'}</td>
                        <td>${skuData.deposito}</td>
                        <td>
                            <button class="btn btn-secondary" onclick="verDetalleBultosCompleto('${skuData.sku}')" style="margin-right: 0.5rem;">Ver Detalle</button>
                            ${skuData.codigo ? `<button class="btn btn-secondary" onclick="verDetalleStock('${skuData.codigo}', 'barrita')">Producto</button>` : ''}
                        </td>
                    </tr>
                `;
            });
            
            html += `</tbody></table>`;
            content.innerHTML = html;
        } else if (currentStockTab === 'lotes') {
            await loadLotesInStock();
        } else if (currentStockTab === 'bultos') {
            await loadBultos();
        } else if (currentStockTab === 'ajuste') {
            await loadAjusteStock();
        }
    } catch (error) {
        content.innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
}

// Funciones de conversión de bultos
function barritasACajasGrandes(barritas) {
    return barritas / 120; // 1 caja grande = 120 barritas
}

function barritasACajasChicas(barritas) {
    return barritas / 12; // 1 caja chica = 12 barritas
}

function calcularBultos(barritas) {
    const total = parseFloat(barritas);
    const cajasGrandes = Math.floor(total / 120);
    const resto = total - (cajasGrandes * 120);
    const cajasChicas = Math.floor(resto / 12);
    const barritasSueltas = resto - (cajasChicas * 12);
    
    return {
        cajasGrandes: cajasGrandes,
        cajasChicas: cajasChicas,
        barritasSueltas: barritasSueltas,
        totalBarritas: total
    };
}

async function loadLotesInStock() {
    const content = document.getElementById('stock-content');
    try {
        const [activos, finalizados] = await Promise.all([
            apiCall('/lotes?estado=activos').catch(() => []),
            apiCall('/lotes?estado=finalizados').catch(() => [])
        ]);
        
        let html = `
            <div class="tabs" style="margin-top: 0;">
                <button class="tab-btn active" onclick="showLotesTab('activos')">Activos</button>
                <button class="tab-btn" onclick="showLotesTab('finalizados')">Finalizados</button>
            </div>
            <div id="lotes-stock-content">
                <h2>Lotes Activos</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Lote ID</th>
                            <th>SKU</th>
                            <th>Nombre</th>
                            <th>Cajas Grandes</th>
                            <th>Cajas Chicas</th>
                            <th>Barritas</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        if (activos.length === 0) {
            html += '<tr><td colspan="8">No hay lotes activos</td></tr>';
        } else {
            activos.forEach(lote => {
                const bultos = calcularBultos(lote.cantidad_disponible || 0);
                html += `
                    <tr>
                        <td>${lote.lote_id}</td>
                        <td>${lote.sku}</td>
                        <td>${lote.nombre || ''}</td>
                        <td>${bultos.cajasGrandes}</td>
                        <td>${bultos.cajasChicas}</td>
                        <td>${bultos.barritasSueltas.toFixed(0)}</td>
                        <td><span class="badge badge-success">${lote.estado}</span></td>
                        <td>
                            <button class="btn btn-secondary" onclick="verDetalleLote('${lote.lote_id}')" style="margin-right: 0.5rem;">Detalle</button>
                            <button class="btn btn-secondary" onclick="finalizarLote('${lote.lote_id}')">Finalizar</button>
                        </td>
                    </tr>
                `;
            });
        }
        html += `</tbody></table></div>`;
        content.innerHTML = html;
    } catch (error) {
        content.innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
}

async function loadBultos() {
    const content = document.getElementById('stock-content');
    try {
        const lotes = await apiCall('/lotes?estado=activos').catch(() => []);
        
        // Agrupar por SKU y sumar
        const bultosPorSKU = {};
        lotes.forEach(lote => {
            const sku = lote.sku || 'N/A';
            if (!bultosPorSKU[sku]) {
                bultosPorSKU[sku] = {
                    sku: sku,
                    nombre: lote.nombre || sku,
                    totalBarritas: 0,
                    lotes: []
                };
            }
            bultosPorSKU[sku].totalBarritas += parseFloat(lote.cantidad_disponible || 0);
            bultosPorSKU[sku].lotes.push(lote);
        });
        
        let html = `
            <h2>Stock de Bultos</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>SKU</th>
                        <th>Nombre</th>
                        <th>Cajas Grandes</th>
                        <th>Cajas Chicas</th>
                        <th>Barritas Sueltas</th>
                        <th>Total Barritas</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        Object.values(bultosPorSKU).forEach(skuData => {
            const bultos = calcularBultos(skuData.totalBarritas);
            html += `
                <tr>
                    <td>${skuData.sku}</td>
                    <td>${skuData.nombre}</td>
                    <td><strong>${bultos.cajasGrandes}</strong></td>
                    <td>${bultos.cajasChicas}</td>
                    <td>${bultos.barritasSueltas.toFixed(0)}</td>
                    <td>${bultos.totalBarritas.toFixed(0)}</td>
                    <td><button class="btn btn-secondary" onclick="verDetalleBultos('${skuData.sku}')">Ver Lotes</button></td>
                </tr>
            `;
        });
        
        html += `</tbody></table>`;
        content.innerHTML = html;
    } catch (error) {
        content.innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
}

function showLotesTab(tipo) {
    // Cambiar el estado de los botones de tabs
    document.querySelectorAll('#lotes-stock-content .tab-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.textContent.toLowerCase().includes(tipo)) {
            btn.classList.add('active');
        }
    });
    
    // Recargar los lotes con el tipo seleccionado
    loadLotesInStock();
}

// Función global para finalizar lotes (llamada desde HTML generado)
window.finalizarLote = async function(loteId) {
    if (!confirm('¿Estás seguro de finalizar este lote?')) return;

    try {
        await apiCall(`/lotes/${loteId}/finalizar`, {
            method: 'PATCH',
        });
        loadStock(); // Recargar la pestaña de stock
        loadDashboard(); // Actualizar dashboard
        alert('Lote finalizado correctamente');
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
};

// Función para filtrar tabla de stock
window.filtrarTablaStock = function(tipo) {
    const searchInput = document.getElementById(`stock-${tipo}-search`);
    const filter = searchInput.value.toLowerCase();
    const table = document.getElementById(`table-${tipo}`);
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        const codigo = row.getAttribute('data-codigo') || '';
        const nombre = row.getAttribute('data-nombre') || '';
        const sku = row.getAttribute('data-sku') || '';
        
        if (codigo.toLowerCase().includes(filter) || nombre.includes(filter) || sku.includes(filter)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    }
};

// Función para ver detalle completo de bultos (con más información)
window.verDetalleBultosCompleto = async function(sku) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'modal-detalle-bultos-completo';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 1000px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h2>Detalle Completo - ${sku}</h2>
                <button class="btn btn-secondary" onclick="cerrarModalDetalleBultosCompleto()">✕</button>
            </div>
            <div id="detalle-bultos-completo-content">
                <p class="loading">Cargando...</p>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    try {
        const [stockData, lotes] = await Promise.all([
            apiCall('/stock/barritas').catch(() => []),
            apiCall('/lotes?estado=activos').catch(() => [])
        ]);
        
        const lotesSKU = lotes.filter(l => l.sku === sku);
        const productosSKU = stockData.filter(p => {
            const prodSku = p.id?.replace('PROD-', '').replace('BARRITA-', '') || p.nombre?.split(' ')[0] || '';
            return prodSku === sku;
        });
        
        // Calcular totales
        let totalBarritas = 0;
        productosSKU.forEach(p => totalBarritas += parseFloat(p.cantidad || 0));
        lotesSKU.forEach(l => totalBarritas += parseFloat(l.cantidad_disponible || 0));
        
        const bultos = calcularBultos(totalBarritas);
        
        let html = `
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 2rem;">
                <div class="card" style="text-align: center; padding: 1rem;">
                    <h3 style="margin-bottom: 0.5rem; color: #6b7280; font-size: 0.9rem;">Cajas Grandes</h3>
                    <p style="font-size: 2rem; font-weight: bold; color: #007bff;">${bultos.cajasGrandes}</p>
                </div>
                <div class="card" style="text-align: center; padding: 1rem;">
                    <h3 style="margin-bottom: 0.5rem; color: #6b7280; font-size: 0.9rem;">Cajas Chicas</h3>
                    <p style="font-size: 2rem; font-weight: bold; color: #28a745;">${bultos.cajasChicas}</p>
                </div>
                <div class="card" style="text-align: center; padding: 1rem;">
                    <h3 style="margin-bottom: 0.5rem; color: #6b7280; font-size: 0.9rem;">Barritas Sueltas</h3>
                    <p style="font-size: 2rem; font-weight: bold; color: #ffc107;">${bultos.barritasSueltas.toFixed(0)}</p>
                </div>
                <div class="card" style="text-align: center; padding: 1rem;">
                    <h3 style="margin-bottom: 0.5rem; color: #6b7280; font-size: 0.9rem;">Total Barritas</h3>
                    <p style="font-size: 2rem; font-weight: bold; color: #dc3545;">${bultos.totalBarritas.toFixed(0)}</p>
                </div>
            </div>
            
            <h3 style="margin-bottom: 1rem;">Información del Producto</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 2rem;">
        `;
        
        if (productosSKU.length > 0) {
            productosSKU.forEach(prod => {
                html += `
                    <div class="card" style="padding: 1rem;">
                        <div><strong>Código:</strong> ${prod.id || 'N/A'}</div>
                        <div><strong>Nombre:</strong> ${prod.nombre || 'N/A'}</div>
                        <div><strong>Cantidad:</strong> ${(prod.cantidad || 0).toFixed(0)} ${prod.unidad || 'u'}</div>
                        <div><strong>Depósito:</strong> ${prod.deposito || 'N/A'}</div>
                    </div>
                `;
            });
        } else {
            html += `<div class="card" style="padding: 1rem;"><p>No hay información de producto registrada</p></div>`;
        }
        
        html += `</div>`;
        
        if (lotesSKU.length > 0) {
            html += `
                <h3 style="margin-bottom: 1rem;">Lotes (${lotesSKU.length})</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Lote ID</th>
                            <th>Nombre</th>
                            <th>Cajas Grandes</th>
                            <th>Cajas Chicas</th>
                            <th>Barritas</th>
                            <th>Total Barritas</th>
                            <th>Vencimiento</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            lotesSKU.forEach(lote => {
                const bultosLote = calcularBultos(lote.cantidad_disponible || 0);
                html += `
                    <tr>
                        <td>${lote.lote_id}</td>
                        <td>${lote.nombre || ''}</td>
                        <td><strong>${bultosLote.cajasGrandes}</strong></td>
                        <td>${bultosLote.cajasChicas}</td>
                        <td>${bultosLote.barritasSueltas.toFixed(0)}</td>
                        <td>${bultosLote.totalBarritas.toFixed(0)}</td>
                        <td>${lote.fecha_vencimiento || 'N/A'}</td>
                        <td><span class="badge badge-success">${lote.estado}</span></td>
                        <td><button class="btn btn-secondary" onclick="verDetalleLote('${lote.lote_id}'); cerrarModalDetalleBultosCompleto();">Ver Detalle</button></td>
                    </tr>
                `;
            });
            
            html += `</tbody></table>`;
        } else {
            html += `<p>No hay lotes registrados para este SKU</p>`;
        }
        
        document.getElementById('detalle-bultos-completo-content').innerHTML = html;
    } catch (error) {
        document.getElementById('detalle-bultos-completo-content').innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
};

window.cerrarModalDetalleBultosCompleto = function() {
    const modal = document.getElementById('modal-detalle-bultos-completo');
    if (modal) {
        modal.remove();
    }
};

// Función para ver detalle de stock
window.verDetalleStock = async function(productoId, tipo) {
    // Crear modal de detalle
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'modal-detalle-stock';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 800px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h2>Detalle de Producto</h2>
                <button class="btn btn-secondary" onclick="cerrarModalDetalle()">✕</button>
            </div>
            <div id="detalle-stock-content">
                <p class="loading">Cargando...</p>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    try {
        // Obtener información del producto
        const stockData = tipo === 'insumo' 
            ? await apiCall('/stock/insumos')
            : await apiCall('/stock/barritas');
        
        const producto = stockData.find(p => p.id === productoId);
        if (!producto) {
            document.getElementById('detalle-stock-content').innerHTML = '<p>Producto no encontrado</p>';
            return;
        }
        
        let html = `
            <div class="form-group">
                <label><strong>Código:</strong></label>
                <div>${producto.id || 'N/A'}</div>
            </div>
            <div class="form-group">
                <label><strong>Nombre:</strong></label>
                <div>${producto.nombre || 'N/A'}</div>
            </div>
            <div class="form-group">
                <label><strong>Cantidad:</strong></label>
                <div>${(producto.cantidad || 0).toFixed(tipo === 'insumo' ? 2 : 0)} ${producto.unidad || (tipo === 'insumo' ? 'kg' : 'u')}</div>
            </div>
            <div class="form-group">
                <label><strong>Depósito:</strong></label>
                <div>${producto.deposito || 'N/A'}</div>
            </div>
        `;
        
        // Si es barrita, mostrar también en bultos
        if (tipo === 'barrita') {
            const bultos = calcularBultos(producto.cantidad || 0);
            html += `
                <div class="form-group">
                    <label><strong>Bultos:</strong></label>
                    <div>
                        <strong>Cajas Grandes:</strong> ${bultos.cajasGrandes}<br>
                        <strong>Cajas Chicas:</strong> ${bultos.cajasChicas}<br>
                        <strong>Barritas Sueltas:</strong> ${bultos.barritasSueltas.toFixed(0)}
                    </div>
                </div>
            `;
        }
        
        document.getElementById('detalle-stock-content').innerHTML = html;
    } catch (error) {
        document.getElementById('detalle-stock-content').innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
};

window.cerrarModalDetalle = function() {
    const modal = document.getElementById('modal-detalle-stock');
    if (modal) {
        modal.remove();
    }
};

// Función para ver detalle de lote
window.verDetalleLote = async function(loteId) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'modal-detalle-lote';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 900px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h2>Detalle de Lote</h2>
                <button class="btn btn-secondary" onclick="cerrarModalDetalleLote()">✕</button>
            </div>
            <div id="detalle-lote-content">
                <p class="loading">Cargando...</p>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    try {
        const lotes = await apiCall('/lotes');
        const lote = lotes.find(l => l.lote_id === loteId);
        
        if (!lote) {
            document.getElementById('detalle-lote-content').innerHTML = '<p>Lote no encontrado</p>';
            return;
        }
        
        const bultosTotal = calcularBultos(lote.cantidad_total || 0);
        const bultosDisponible = calcularBultos(lote.cantidad_disponible || 0);
        const bultosVendido = calcularBultos(lote.cantidad_vendida || 0);
        
        let html = `
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label><strong>Lote ID:</strong></label>
                    <div>${lote.lote_id}</div>
                </div>
                <div class="form-group">
                    <label><strong>SKU:</strong></label>
                    <div>${lote.sku}</div>
                </div>
                <div class="form-group">
                    <label><strong>Nombre:</strong></label>
                    <div>${lote.nombre || ''}</div>
                </div>
                <div class="form-group">
                    <label><strong>Estado:</strong></label>
                    <div><span class="badge badge-success">${lote.estado}</span></div>
                </div>
                <div class="form-group">
                    <label><strong>Fecha Producción:</strong></label>
                    <div>${lote.fecha_produccion || 'N/A'}</div>
                </div>
                <div class="form-group">
                    <label><strong>Fecha Vencimiento:</strong></label>
                    <div>${lote.fecha_vencimiento || 'N/A'}</div>
                </div>
                <div class="form-group">
                    <label><strong>Depósito:</strong></label>
                    <div>${lote.deposito || 'N/A'}</div>
                </div>
            </div>
            
            <h3 style="margin-top: 1.5rem; margin-bottom: 1rem;">Cantidades Totales</h3>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-bottom: 1rem;">
                <div class="card">
                    <h4>Cajas Grandes</h4>
                    <p style="font-size: 1.5rem; font-weight: bold;">${bultosTotal.cajasGrandes}</p>
                </div>
                <div class="card">
                    <h4>Cajas Chicas</h4>
                    <p style="font-size: 1.5rem; font-weight: bold;">${bultosTotal.cajasChicas}</p>
                </div>
                <div class="card">
                    <h4>Barritas</h4>
                    <p style="font-size: 1.5rem; font-weight: bold;">${bultosTotal.barritasSueltas.toFixed(0)}</p>
                </div>
            </div>
            
            <h3 style="margin-top: 1.5rem; margin-bottom: 1rem;">Desglose</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Concepto</th>
                        <th>Cajas Grandes</th>
                        <th>Cajas Chicas</th>
                        <th>Barritas</th>
                        <th>Total Barritas</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Total Producido</strong></td>
                        <td>${bultosTotal.cajasGrandes}</td>
                        <td>${bultosTotal.cajasChicas}</td>
                        <td>${bultosTotal.barritasSueltas.toFixed(0)}</td>
                        <td>${bultosTotal.totalBarritas.toFixed(0)}</td>
                    </tr>
                    <tr>
                        <td><strong>Vendido</strong></td>
                        <td>${bultosVendido.cajasGrandes}</td>
                        <td>${bultosVendido.cajasChicas}</td>
                        <td>${bultosVendido.barritasSueltas.toFixed(0)}</td>
                        <td>${bultosVendido.totalBarritas.toFixed(0)}</td>
                    </tr>
                    <tr>
                        <td><strong>Disponible</strong></td>
                        <td><strong>${bultosDisponible.cajasGrandes}</strong></td>
                        <td>${bultosDisponible.cajasChicas}</td>
                        <td>${bultosDisponible.barritasSueltas.toFixed(0)}</td>
                        <td><strong>${bultosDisponible.totalBarritas.toFixed(0)}</strong></td>
                    </tr>
                </tbody>
            </table>
        `;
        
        if (lote.notas) {
            html += `
                <div class="form-group" style="margin-top: 1rem;">
                    <label><strong>Notas:</strong></label>
                    <div>${lote.notas}</div>
                </div>
            `;
        }
        
        document.getElementById('detalle-lote-content').innerHTML = html;
    } catch (error) {
        document.getElementById('detalle-lote-content').innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
};

window.cerrarModalDetalleLote = function() {
    const modal = document.getElementById('modal-detalle-lote');
    if (modal) {
        modal.remove();
    }
};

window.verDetalleBultos = async function(sku) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'modal-detalle-bultos';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 900px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h2>Lotes de ${sku}</h2>
                <button class="btn btn-secondary" onclick="cerrarModalDetalleBultos()">✕</button>
            </div>
            <div id="detalle-bultos-content">
                <p class="loading">Cargando...</p>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    try {
        const lotes = await apiCall('/lotes?estado=activos');
        const lotesSKU = lotes.filter(l => l.sku === sku);
        
        if (lotesSKU.length === 0) {
            document.getElementById('detalle-bultos-content').innerHTML = '<p>No hay lotes para este SKU</p>';
            return;
        }
        
        let html = `
            <table class="table">
                <thead>
                    <tr>
                        <th>Lote ID</th>
                        <th>Cajas Grandes</th>
                        <th>Cajas Chicas</th>
                        <th>Barritas</th>
                        <th>Total Barritas</th>
                        <th>Vencimiento</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        lotesSKU.forEach(lote => {
            const bultos = calcularBultos(lote.cantidad_disponible || 0);
            html += `
                <tr>
                    <td>${lote.lote_id}</td>
                    <td><strong>${bultos.cajasGrandes}</strong></td>
                    <td>${bultos.cajasChicas}</td>
                    <td>${bultos.barritasSueltas.toFixed(0)}</td>
                    <td>${bultos.totalBarritas.toFixed(0)}</td>
                    <td>${lote.fecha_vencimiento || 'N/A'}</td>
                    <td><button class="btn btn-secondary" onclick="verDetalleLote('${lote.lote_id}')">Detalle</button></td>
                </tr>
            `;
        });
        
        html += `</tbody></table>`;
        document.getElementById('detalle-bultos-content').innerHTML = html;
    } catch (error) {
        document.getElementById('detalle-bultos-content').innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
};

window.cerrarModalDetalleBultos = function() {
    const modal = document.getElementById('modal-detalle-bultos');
    if (modal) {
        modal.remove();
    }
};

async function loadAjusteStock() {
    const content = document.getElementById('stock-content');
    const isAdmin = currentUser.rol === 'ADMIN';
    content.innerHTML = `
        <h2>Ajuste de Stock</h2>
        ${!isAdmin ? '<div class="message message-warning">Los ajustes negativos requieren aprobación de un administrador.</div>' : ''}
        <form id="form-ajuste-stock">
            <div class="form-group">
                <label>ID Depósito</label>
                <input type="text" class="input" id="ajuste-stock-deposito" required>
            </div>
            <div class="form-group">
                <label>ID Producto</label>
                <input type="text" class="input" id="ajuste-stock-producto" required>
            </div>
            <div class="form-group">
                <label>Cantidad (positivo = entrada, negativo = salida)</label>
                <input type="number" step="0.01" class="input" id="ajuste-stock-cantidad" required>
            </div>
            <div class="form-group">
                <label>Motivo</label>
                <input type="text" class="input" id="ajuste-stock-motivo">
            </div>
            <button type="submit" class="btn btn-primary">Aplicar Ajuste</button>
        </form>
        <div id="ajuste-stock-message"></div>
    `;
    
    document.getElementById('form-ajuste-stock').addEventListener('submit', async (e) => {
        e.preventDefault();
        await registrarAjusteStock();
    });
}

async function registrarAjusteStock() {
    try {
        const data = await apiCall('/movimientos/ajuste', {
            method: 'POST',
            body: JSON.stringify({
                deposito_id: document.getElementById('ajuste-stock-deposito').value,
                producto_id: document.getElementById('ajuste-stock-producto').value,
                cantidad: parseFloat(document.getElementById('ajuste-stock-cantidad').value),
                motivo: document.getElementById('ajuste-stock-motivo').value,
            }),
        });

        if (data.requiere_aprobacion) {
            showMessage('ajuste-stock-message', 'Ajuste enviado para aprobación. Un administrador lo revisará.', 'warning');
        } else {
            showMessage('ajuste-stock-message', 'Ajuste aplicado correctamente', 'success');
        }

        document.getElementById('form-ajuste-stock').reset();
        loadDashboard();
    } catch (error) {
        showMessage('ajuste-stock-message', `Error: ${error.message}`, 'error');
    }
}

// ===== MOVIMIENTOS =====
let currentMovimientoTab = 'compra';

document.querySelectorAll('#page-movimientos .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('#page-movimientos .tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentMovimientoTab = btn.dataset.tab;
        loadMovimientos();
    });
});

function loadMovimientos() {
    const content = document.getElementById('movimientos-content');
    
    if (currentMovimientoTab === 'compra') {
        content.innerHTML = `
            <div class="card">
                <h2>Registrar Compra</h2>
                <form id="form-compra">
                    <div class="form-group">
                        <label>Número de Factura/Remito</label>
                        <input type="text" class="input" id="compra-numero" required>
                    </div>
                    <div class="form-group">
                        <label>ID Proveedor</label>
                        <input type="text" class="input" id="compra-proveedor" required>
                    </div>
                    <div class="form-group">
                        <label>ID Depósito</label>
                        <input type="text" class="input" id="compra-deposito" required>
                    </div>
                    <div class="form-group">
                        <label>Producto ID</label>
                        <input type="text" class="input" id="compra-producto" required>
                    </div>
                    <div class="form-group">
                        <label>Descripción</label>
                        <input type="text" class="input" id="compra-descripcion" required>
                    </div>
                    <div class="form-group">
                        <label>Cantidad</label>
                        <input type="number" step="0.01" class="input" id="compra-cantidad" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Registrar Compra</button>
                </form>
                <div id="compra-message"></div>
            </div>
        `;
        
        document.getElementById('form-compra').addEventListener('submit', async (e) => {
            e.preventDefault();
            await registrarCompra();
        });
    } else if (currentMovimientoTab === 'venta') {
        content.innerHTML = `
            <div class="card">
                <h2>Registrar Venta</h2>
                <form id="form-venta">
                    <div class="form-group">
                        <label>Número de Pedido/Remito</label>
                        <input type="text" class="input" id="venta-numero" required>
                    </div>
                    <div class="form-group">
                        <label>ID Cliente</label>
                        <input type="text" class="input" id="venta-cliente" required>
                    </div>
                    <div class="form-group">
                        <label>ID Depósito</label>
                        <input type="text" class="input" id="venta-deposito" required>
                    </div>
                    <div class="form-group">
                        <label>Producto ID</label>
                        <input type="text" class="input" id="venta-producto" required>
                    </div>
                    <div class="form-group">
                        <label>Descripción</label>
                        <input type="text" class="input" id="venta-descripcion" required>
                    </div>
                    <div class="form-group">
                        <label>Cantidad</label>
                        <input type="number" step="0.01" class="input" id="venta-cantidad" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Registrar Venta</button>
                </form>
                <div id="venta-message"></div>
            </div>
        `;
        
        document.getElementById('form-venta').addEventListener('submit', async (e) => {
            e.preventDefault();
            await registrarVenta();
        });
    } else if (currentMovimientoTab === 'remito') {
        content.innerHTML = `
            <div class="card">
                <h2>Remito</h2>
                <p>Funcionalidad de remito en desarrollo.</p>
            </div>
        `;
    }
}

async function registrarCompra() {
    try {
        const data = await apiCall('/movimientos/compra', {
            method: 'POST',
            body: JSON.stringify({
                numero: document.getElementById('compra-numero').value,
                proveedor_id: document.getElementById('compra-proveedor').value,
                deposito_id: document.getElementById('compra-deposito').value,
                items: [{
                    producto_id: document.getElementById('compra-producto').value,
                    descripcion: document.getElementById('compra-descripcion').value,
                    cantidad: parseFloat(document.getElementById('compra-cantidad').value),
                }],
            }),
        });

        showMessage('compra-message', 'Compra registrada correctamente', 'success');
        document.getElementById('form-compra').reset();
        loadDashboard();
    } catch (error) {
        showMessage('compra-message', `Error: ${error.message}`, 'error');
    }
}

async function registrarVenta() {
    try {
        const data = await apiCall('/movimientos/venta', {
            method: 'POST',
            body: JSON.stringify({
                numero: document.getElementById('venta-numero').value,
                cliente_id: document.getElementById('venta-cliente').value,
                deposito_id: document.getElementById('venta-deposito').value,
                items: [{
                    producto_id: document.getElementById('venta-producto').value,
                    descripcion: document.getElementById('venta-descripcion').value,
                    cantidad: parseFloat(document.getElementById('venta-cantidad').value),
                }],
            }),
        });

        showMessage('venta-message', 'Venta registrada correctamente', 'success');
        document.getElementById('form-venta').reset();
        loadDashboard();
    } catch (error) {
        showMessage('venta-message', `Error: ${error.message}`, 'error');
    }
}


// ===== PRODUCCIÓN =====
let produccionState = {
    paso: 0, // 0: elegir receta, 1: confirmar receta, 2: mezcla, 3: etapas
    recetaSeleccionada: null,
    recetaNombre: null,
    mezclaConfirmada: null,
    etapas: [],
    etapaActualIdx: 0,
    etapasCompletadas: new Set(),
    chocolateInfo: null,
    tabsEtapas: {} // {grupo: tabId}
};

function loadProduccion() {
    const content = document.getElementById('produccion-content');
    const tabsContainer = document.getElementById('produccion-tabs');
    const detallesPanel = document.getElementById('produccion-detalles');
    
    // Resetear estado
    produccionState = {
        paso: 0,
        recetaSeleccionada: null,
        recetaNombre: null,
        mezclaConfirmada: null,
        etapas: [],
        etapaActualIdx: 0,
        etapasCompletadas: new Set(),
        chocolateInfo: null,
        tabsEtapas: {}
    };
    
    // Ocultar detalles y tabs inicialmente
    detallesPanel.style.display = 'none';
    tabsContainer.style.display = 'none';
    
    // Mostrar pestaña de elegir receta
    mostrarElegirReceta();
}

function mostrarElegirReceta() {
    const content = document.getElementById('produccion-content');
    
    content.innerHTML = `
        <div class="card">
            <h2>Elegir Receta</h2>
            <div id="recetas-container" class="recetas-grid">
                <p class="loading">Cargando recetas...</p>
            </div>
            <div id="confirmacion-receta" style="display: none; margin-top: 1rem;">
                <div class="message message-success" id="confirmacion-mensaje"></div>
                <button class="btn btn-primary" id="btn-confirmar-receta" style="margin-top: 0.5rem;">Confirmar receta</button>
            </div>
        </div>
    `;
    
    // Cargar recetas
    cargarRecetas();
}

async function cargarRecetas() {
    try {
        const recetas = await apiCall('/recetas?estado=activas');
        const container = document.getElementById('recetas-container');
        
        if (!recetas || recetas.length === 0) {
            container.innerHTML = '<p>No hay recetas activas disponibles</p>';
            return;
        }
        
        container.innerHTML = '';
        recetas.forEach(receta => {
            const btn = document.createElement('button');
            btn.className = 'receta-btn';
            btn.innerHTML = `
                <div style="font-weight: 600; margin-bottom: 0.25rem;">${receta.codigo}</div>
                <div style="font-size: 0.875rem; color: #6b7280;">${receta.nombre || receta.codigo}</div>
            `;
            btn.onclick = () => seleccionarReceta(receta.codigo, receta.nombre || receta.codigo);
            container.appendChild(btn);
        });
    } catch (error) {
        document.getElementById('recetas-container').innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
}

function seleccionarReceta(codigo, nombre) {
    produccionState.recetaSeleccionada = codigo;
    produccionState.recetaNombre = nombre;
    
    // Marcar botón seleccionado
    document.querySelectorAll('.receta-btn').forEach(btn => btn.classList.remove('selected'));
    event.target.closest('.receta-btn')?.classList.add('selected');
    
    // Mostrar confirmación
    const confirmacion = document.getElementById('confirmacion-receta');
    const mensaje = document.getElementById('confirmacion-mensaje');
    mensaje.textContent = `✓ Receta '${codigo}' seleccionada`;
    confirmacion.style.display = 'block';
    
    // Habilitar botón confirmar
    document.getElementById('btn-confirmar-receta').onclick = confirmarReceta;
}

async function confirmarReceta() {
    if (!produccionState.recetaSeleccionada) return;
    
    // Actualizar panel de detalles
    actualizarPanelDetalles();
    document.getElementById('produccion-detalles').style.display = 'block';
    
    // Mostrar frame de mezcla
    mostrarFrameMezcla();
}

function mostrarFrameMezcla() {
    const content = document.getElementById('produccion-content');
    
    content.innerHTML = `
        <div class="card">
            <h2>Mezcla (kg)</h2>
            <div class="mezcla-buttons">
                <button class="mezcla-btn" onclick="setMezcla(10)">10</button>
                <button class="mezcla-btn" onclick="setMezcla(20)">20</button>
                <button class="mezcla-btn" onclick="setMezcla(30)">30</button>
                <button class="mezcla-btn" onclick="setMezcla(40)">40</button>
            </div>
            <div class="mezcla-input-group">
                <label>Cantidad (kg):</label>
                <input type="number" class="input" id="mezcla-input" style="width: 100px;" min="1" step="0.1">
            </div>
            <button class="btn btn-primary" id="btn-confirmar-mezcla" onclick="confirmarMezcla()">Confirmar mezcla</button>
        </div>
    `;
    
    produccionState.paso = 2;
}

window.setMezcla = function(valor) {
    document.getElementById('mezcla-input').value = valor;
    document.querySelectorAll('.mezcla-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
};

async function confirmarMezcla() {
    const mezclaInput = document.getElementById('mezcla-input');
    const mezcla = parseFloat(mezclaInput.value);
    
    if (!mezcla || mezcla < 1) {
        alert('Ingrese una cantidad válida de mezcla');
        return;
    }
    
    produccionState.mezclaConfirmada = mezcla;
    actualizarPanelDetalles();
    
    // Calcular y mostrar etapas
    await calcularYMostrarEtapas();
}

async function calcularYMostrarEtapas() {
    try {
        // Obtener recetas activas y buscar la seleccionada
        const recetas = await apiCall('/recetas?estado=activas');
        const recetaData = recetas.find(r => r.codigo === produccionState.recetaSeleccionada);
        
        if (!recetaData) {
            alert('No se pudo obtener la receta');
            return;
        }
        
        // Agrupar items por grupo_preparacion
        const itemsPorGrupo = {};
        recetaData.items.forEach(item => {
            const grupo = item.grupo_preparacion || 'OTROS';
            if (!itemsPorGrupo[grupo]) {
                itemsPorGrupo[grupo] = [];
            }
            itemsPorGrupo[grupo].push(item);
        });
        
        // Ordenar items dentro de cada grupo
        Object.keys(itemsPorGrupo).forEach(grupo => {
            itemsPorGrupo[grupo].sort((a, b) => {
                if (a.orden_grupo !== b.orden_grupo) {
                    return (a.orden_grupo || 0) - (b.orden_grupo || 0);
                }
                return (a.orden_item || 0) - (b.orden_item || 0);
            });
        });
        
        produccionState.itemsPorGrupo = itemsPorGrupo;
        
        // Crear pestañas de etapas
        crearTabsEtapas();
        
        // Mostrar primera etapa
        mostrarEtapaActual();
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

function crearTabsEtapas() {
    const tabsContainer = document.getElementById('produccion-tabs');
    tabsContainer.style.display = 'flex';
    
    // Limpiar tabs existentes (excepto "Elegir Receta")
    const elegirRecetaTab = tabsContainer.querySelector('[data-tab="elegir-receta"]');
    tabsContainer.innerHTML = '';
    if (elegirRecetaTab) {
        tabsContainer.appendChild(elegirRecetaTab);
    }
    
    // Mapeo de grupos de la BD a nombres de pestañas
    const grupoNames = {
        'SOLIDOS': 'Sólidos',
        'CHOCOLATE': 'Chocolate',
        'LIQUIDOS': 'Líquidos',
        'OTROS': 'Otros'
    };
    
    // Orden de grupos
    const ordenGrupos = ['SOLIDOS', 'CHOCOLATE', 'LIQUIDOS', 'OTROS'];
    
    ordenGrupos.forEach(grupoKey => {
        if (produccionState.itemsPorGrupo[grupoKey] && produccionState.itemsPorGrupo[grupoKey].length > 0) {
            const tabBtn = document.createElement('button');
            tabBtn.className = 'tab-btn';
            tabBtn.dataset.tab = grupoKey.toLowerCase();
            tabBtn.textContent = grupoNames[grupoKey] || grupoKey;
            tabBtn.onclick = () => mostrarTabEtapa(grupoKey);
            tabsContainer.appendChild(tabBtn);
            produccionState.tabsEtapas[grupoKey] = tabBtn;
        }
    });
    
    // Activar primera pestaña
    if (Object.keys(produccionState.tabsEtapas).length > 0) {
        const primeraTab = Object.keys(produccionState.tabsEtapas)[0];
        mostrarTabEtapa(primeraTab);
    }
}

function mostrarTabEtapa(grupoKey) {
    document.querySelectorAll('#produccion-tabs .tab-btn').forEach(btn => btn.classList.remove('active'));
    produccionState.tabsEtapas[grupoKey]?.classList.add('active');
    
    const content = document.getElementById('produccion-content');
    const items = produccionState.itemsPorGrupo[grupoKey] || [];
    
    const grupoNames = {
        'SOLIDOS': 'Sólidos',
        'CHOCOLATE': 'Chocolate',
        'LIQUIDOS': 'Líquidos',
        'OTROS': 'Otros'
    };
    
    let html = `
        <div class="card">
            <div class="etapa-navigation">
                <span class="etapa-subpaso">${grupoNames[grupoKey] || grupoKey}</span>
                <div>
                    <button class="btn btn-secondary" onclick="atrasEtapa('${grupoKey}')" id="btn-atras-etapa">← Atrás</button>
                    <button class="btn btn-primary" onclick="siguienteEtapa('${grupoKey}')" id="btn-siguiente-etapa" style="margin-left: 0.5rem;">Siguiente →</button>
                </div>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Cantidad</th>
                        <th>Unidad</th>
                        <th>%</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    if (items.length === 0) {
        html += '<tr><td colspan="5" style="text-align: center; padding: 2rem;">No hay items en este grupo</td></tr>';
    } else {
        items.forEach(item => {
            const cantidad = produccionState.mezclaConfirmada * (item.porcentaje || 0) / 100;
            html += `
                <tr>
                    <td>${item.producto_codigo || 'N/A'}</td>
                    <td>${item.producto_codigo || 'N/A'}</td>
                    <td>${cantidad.toFixed(3)}</td>
                    <td>kg</td>
                    <td>${(item.porcentaje || 0).toFixed(2)}</td>
                </tr>
            `;
        });
    }
    
    html += `
                </tbody>
            </table>
        </div>
    `;
    
    content.innerHTML = html;
}

function mostrarEtapaActual() {
    const grupos = Object.keys(produccionState.tabsEtapas);
    if (grupos.length > 0) {
        mostrarTabEtapa(grupos[0]);
    }
}

function actualizarPanelDetalles() {
    document.getElementById('detalle-receta').textContent = 
        produccionState.recetaSeleccionada 
            ? `${produccionState.recetaSeleccionada} - ${produccionState.recetaNombre}`
            : '—';
    
    document.getElementById('detalle-mezcla').textContent = 
        produccionState.mezclaConfirmada 
            ? `${produccionState.mezclaConfirmada.toFixed(2)} kg`
            : '—';
    
    // Chocolate y mezcla máxima se pueden agregar después
    document.getElementById('detalle-mezcla-max').textContent = '—';
}

window.atrasEtapa = function(grupoActual) {
    const grupos = Object.keys(produccionState.tabsEtapas);
    const idxActual = grupos.indexOf(grupoActual);
    if (idxActual > 0) {
        mostrarTabEtapa(grupos[idxActual - 1]);
    }
};

window.siguienteEtapa = function(grupoActual) {
    const grupos = Object.keys(produccionState.tabsEtapas);
    const idxActual = grupos.indexOf(grupoActual);
    if (idxActual < grupos.length - 1) {
        mostrarTabEtapa(grupos[idxActual + 1]);
    } else {
        // Última etapa - mostrar botón finalizar
        if (confirm('¿Finalizar producción y descontar stock?')) {
            finalizarProduccion();
        }
    }
};

async function finalizarProduccion() {
    try {
        // Preparar consumos desde todos los items
        const consumos = [];
        Object.values(produccionState.itemsPorGrupo).forEach(items => {
            items.forEach(item => {
                const cantidad = produccionState.mezclaConfirmada * (item.porcentaje || 0) / 100;
                consumos.push({
                    producto_id: item.producto_codigo, // Simplificado - debería ser ID real
                    descripcion: item.producto_codigo,
                    cantidad: cantidad
                });
            });
        });
        
        // Preparar producto final
        const productoFinal = {
            producto_id: `PROD-${produccionState.recetaSeleccionada}`,
            descripcion: produccionState.recetaNombre,
            cantidad: 1.0
        };
        
        const numero = `P-${produccionState.recetaSeleccionada}-${Date.now()}`;
        
        const data = await apiCall('/movimientos/produccion', {
            method: 'POST',
            body: JSON.stringify({
                numero: numero,
                deposito_id: '1', // Simplificado - debería obtener del contexto
                consumos: consumos,
                producto_final: productoFinal
            }),
        });

        if (data.requiere_aprobacion) {
            alert('Producción enviada para aprobación. Un administrador la revisará.');
        } else {
            alert('Producción registrada correctamente');
        }

        // Resetear y volver al inicio
        loadProduccion();
        loadDashboard();
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

// ===== RECETAS =====
let currentRecetaTab = 'activas';

document.querySelectorAll('#page-recetas .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('#page-recetas .tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentRecetaTab = btn.dataset.tab;
        loadRecetas();
    });
});

async function loadRecetas() {
    const content = document.getElementById('recetas-content');
    content.innerHTML = '<p class="loading">Cargando...</p>';

    try {
        if (currentRecetaTab === 'crear') {
            content.innerHTML = `
                <h2>Crear Receta Nueva</h2>
                <div class="card">
                    <p>Funcionalidad para crear recetas en desarrollo.</p>
                </div>
            `;
            return;
        }
        
        const estado = currentRecetaTab === 'activas' ? 'activas' : 'inactivas';
        const data = await apiCall(`/recetas?estado=${estado}`);

        if (!data || data.length === 0) {
            content.innerHTML = `<p>No hay recetas ${estado}</p>`;
            return;
        }

        let html = `
            <h2>Recetas ${estado === 'activas' ? 'Activas' : 'Inactivas'}</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Versión</th>
                        <th>Items</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
        `;

        data.forEach(receta => {
            html += `
                <tr>
                    <td>${receta.codigo}</td>
                    <td>${receta.nombre || receta.codigo}</td>
                    <td>${receta.version}</td>
                    <td>${receta.items.length}</td>
                    <td>
                        <span class="badge ${receta.is_active ? 'badge-success' : 'badge-warning'}">
                            ${receta.is_active ? 'Activa' : 'Inactiva'}
                        </span>
                    </td>
                </tr>
            `;
        });

        html += `
                </tbody>
            </table>
        `;

        content.innerHTML = html;
    } catch (error) {
        content.innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
}


async function finalizarLote(loteId) {
    if (!confirm('¿Estás seguro de finalizar este lote?')) return;

    try {
        await apiCall(`/lotes/${loteId}/finalizar`, {
            method: 'PATCH',
        });
        loadLotes();
        loadDashboard();
        alert('Lote finalizado correctamente');
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

// ===== APROBACIONES =====
let currentAprobacionTab = 'pendiente';

document.querySelectorAll('#page-aprobaciones .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('#page-aprobaciones .tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentAprobacionTab = btn.dataset.tab;
        loadAprobaciones();
    });
});

async function loadAprobaciones() {
    const content = document.getElementById('aprobaciones-content');
    content.innerHTML = '<p class="loading">Cargando...</p>';

    try {
        const estado = currentAprobacionTab;
        const data = await apiCall(`/aprobaciones?estado=${estado}`);

        if (!data || data.length === 0) {
            content.innerHTML = `<p>No hay solicitudes ${estado}</p>`;
            return;
        }

        let html = `
            <h2>Solicitudes ${estado === 'pendiente' ? 'Pendientes' : estado === 'aprobada' ? 'Aprobadas' : 'Rechazadas'}</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tipo</th>
                        <th>Usuario</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                        ${estado === 'pendiente' ? '<th>Acciones</th>' : ''}
                    </tr>
                </thead>
                <tbody>
        `;

        data.forEach(aprob => {
            html += `
                <tr>
                    <td>${aprob.id.substring(0, 8)}...</td>
                    <td>${aprob.tipo}</td>
                    <td>${aprob.usuario_creador_nombre || aprob.usuario_creador_id}</td>
                    <td>${new Date(aprob.timestamp_creacion).toLocaleString()}</td>
                    <td>
                        <span class="badge ${aprob.estado === 'APROBADA' ? 'badge-success' : aprob.estado === 'RECHAZADA' ? 'badge-danger' : 'badge-warning'}">
                            ${aprob.estado}
                        </span>
                    </td>
                    ${estado === 'pendiente' ? `
                    <td>
                        <button class="btn btn-success" onclick="aprobarSolicitud('${aprob.id}')" style="margin-right: 0.5rem;">Aprobar</button>
                        <button class="btn btn-danger" onclick="rechazarSolicitud('${aprob.id}')">Rechazar</button>
                    </td>
                    ` : ''}
                </tr>
            `;
        });

        html += `
                </tbody>
            </table>
        `;

        content.innerHTML = html;
    } catch (error) {
        content.innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
}

async function aprobarSolicitud(id) {
    if (!confirm('¿Estás seguro de aprobar esta solicitud?')) return;

    try {
        await apiCall(`/aprobaciones/${id}/aprobar`, {
            method: 'POST',
            body: JSON.stringify({ motivo: 'Aprobado' }),
        });
        loadAprobaciones();
        loadDashboard();
        alert('Solicitud aprobada y ejecutada');
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

async function rechazarSolicitud(id) {
    const motivo = prompt('Ingrese el motivo del rechazo:');
    if (!motivo) return;

    try {
        await apiCall(`/aprobaciones/${id}/rechazar`, {
            method: 'POST',
            body: JSON.stringify({ motivo }),
        });
        loadAprobaciones();
        alert('Solicitud rechazada');
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

// ===== HISTORIAL =====
let currentHistorialTab = 'compras';

document.querySelectorAll('#page-historial .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('#page-historial .tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentHistorialTab = btn.dataset.tab;
        loadHistorial();
    });
});

async function loadHistorial() {
    const content = document.getElementById('historial-content');
    content.innerHTML = '<p class="loading">Cargando...</p>';

    try {
        if (currentHistorialTab === 'compras') {
            // TODO: Implementar endpoint de compras
            content.innerHTML = `
                <h2>Historial de Compras</h2>
                <p>Funcionalidad en desarrollo. Aquí se mostrará el historial de compras con opciones para ver, editar y generar nuevos registros.</p>
            `;
        } else if (currentHistorialTab === 'ventas') {
            // TODO: Implementar endpoint de ventas
            content.innerHTML = `
                <h2>Historial de Ventas</h2>
                <p>Funcionalidad en desarrollo. Aquí se mostrará el historial de ventas con opciones para ver, editar y generar nuevos registros.</p>
            `;
        } else if (currentHistorialTab === 'ajustes') {
            // TODO: Implementar endpoint de ajustes
            content.innerHTML = `
                <h2>Historial de Ajustes</h2>
                <p>Funcionalidad en desarrollo. Aquí se mostrará el historial de ajustes de stock.</p>
            `;
        } else if (currentHistorialTab === 'producciones') {
            // TODO: Implementar endpoint de producciones
            content.innerHTML = `
                <h2>Historial de Producciones</h2>
                <p>Funcionalidad en desarrollo. Aquí se mostrará el historial de producciones.</p>
            `;
        }
    } catch (error) {
        content.innerHTML = `<p class="message message-error">Error: ${error.message}</p>`;
    }
}
