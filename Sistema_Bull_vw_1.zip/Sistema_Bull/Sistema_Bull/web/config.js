// Configuración de la API - SOLO LOCAL
// Versión simplificada para uso local únicamente

// URL base de la API - SIEMPRE localhost
const API_BASE = 'http://localhost:8000';

// Hacer disponible globalmente
window.API_BASE = API_BASE;
console.log('✅ API Base URL configurada (LOCAL):', API_BASE);
