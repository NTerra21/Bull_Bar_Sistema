# 🌐 Bull Bar - Versión Web (HTML/JavaScript Puro)

Esta es una versión del frontend que **NO requiere Node.js**. Es HTML + JavaScript puro que puedes abrir directamente en tu navegador.

## 🚀 Cómo Usar

### Paso 1: Asegúrate de que la API esté corriendo

```bash
python run_api.py
```

La API debe estar en: http://localhost:8000

### Paso 2: Abrir el sistema web

**Opción A: Desde el navegador directamente**
1. Abre tu navegador
2. Presiona `Ctrl+O` (o File → Open)
3. Navega a: `Sistema_Bull/web/index.html`
4. Abre el archivo

**Opción B: Usando el script**
```bash
ABRIR_SISTEMA_WEB.bat
```

**Opción C: Arrastrar y soltar**
- Arrastra el archivo `index.html` a tu navegador

### Paso 3: Login

- Usuario: `admin`
- Contraseña: `admin`

---

## ⚠️ Nota sobre CORS

Si el navegador bloquea las peticiones por CORS:

1. Abre el archivo `index.html` en un editor
2. Busca la línea: `const API_BASE = 'http://localhost:8000';`
3. Si la API está en otro puerto, cámbialo

O mejor aún, usa un servidor local simple:

```bash
# Desde el directorio web/
python -m http.server 8080
```

Luego abre: http://localhost:8080

---

## ✨ Funcionalidades

- ✅ Login con JWT
- ✅ Dashboard con estadísticas
- ✅ Stock (insumos y barritas)
- ✅ Movimientos (compra, venta, ajuste)
- ✅ Producción
- ✅ Recetas
- ✅ Lotes
- ✅ Aprobaciones (solo ADMIN)

---

## 🎯 Ventajas

- ✅ No requiere Node.js
- ✅ No requiere compilación
- ✅ Funciona directamente en el navegador
- ✅ Fácil de modificar
- ✅ No necesita instalación de dependencias

---

## 🔧 Solución de Problemas

### Error: "Failed to fetch" o CORS

La API debe tener CORS configurado. Verifica que en `bull_bar/api/settings.py`:
```python
CORS_ORIGINS: List[str] = ["*"]
```

### El sistema no carga

1. Verifica que la API esté corriendo: http://localhost:8000/health
2. Abre la consola del navegador (F12) para ver errores
3. Verifica que `API_BASE` en `app.js` apunte a la URL correcta

