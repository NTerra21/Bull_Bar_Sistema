# Solución Rápida - Error ERR_CONNECTION_REFUSED

## Problema
Al intentar iniciar sesión o acceder a la página, aparece el error `ERR_CONNECTION_REFUSED`.

## Causa
El servidor web (puerto 8080) o la API (puerto 8000) no están corriendo.

## Solución

### Opción 1: Reiniciar Todo (Recomendado)

Ejecuta:
```
iniciar.bat
```

Esto iniciará:
- La API en el puerto 8000
- El servidor web en el puerto 8080

### Opción 2: Solo Reiniciar el Servidor Web

Si la API está corriendo pero el servidor web se detuvo, ejecuta:
```
reiniciar_web.bat
```

### Opción 3: Verificar Estado

Para ver qué está corriendo, ejecuta:
```
ver_logs.bat
```

Este script mostrará el estado de los puertos.

## Verificar que Funciona

1. **API**: Abre en el navegador: `http://localhost:8000/health`
   - Deberías ver: `{"status":"ok"}`

2. **Servidor Web**: Abre en el navegador: `http://localhost:8080`
   - Deberías ver la pantalla de login

## Importante

- **NO cierres las ventanas** que se abren al ejecutar `iniciar.bat`
- Si cierras una ventana, ese servicio se detiene
- Para detener todo: ejecuta `detener.bat`

