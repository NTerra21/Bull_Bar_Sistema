"""
Sistema de auditoría: registra cambios importantes en el sistema.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime
from typing import Optional, Any
import json

from .sqlite_db import connect, init_schema


def _ensure(db_path: str) -> sqlite3.Connection:
    """Asegura que la conexión y esquema estén listos."""
    conn = connect(db_path)
    init_schema(conn)
    _ensure_audit_table(conn)
    return conn


def _ensure_audit_table(conn: sqlite3.Connection) -> None:
    """Crea la tabla de auditoría si no existe."""
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        usuario TEXT,
        accion TEXT NOT NULL,
        modulo TEXT,
        entidad_id TEXT,
        entidad_tipo TEXT,
        antes TEXT,
        despues TEXT,
        metadata TEXT,
        ip_address TEXT
    )
    """)
    conn.commit()


def log_audit(
    db_path: str,
    accion: str,
    *,
    usuario: Optional[str] = None,
    modulo: Optional[str] = None,
    entidad_id: Optional[str] = None,
    entidad_tipo: Optional[str] = None,
    antes: Optional[Any] = None,
    despues: Optional[Any] = None,
    metadata: Optional[dict] = None,
    ip_address: Optional[str] = None,
) -> bool:
    """
    Registra un evento de auditoría.
    
    Args:
        db_path: Ruta a la base de datos
        accion: Acción realizada (ej: "AJUSTE_STOCK", "COMPRA_REGISTRADA", "VENTA_REALIZADA")
        usuario: Usuario que realizó la acción
        modulo: Módulo donde ocurrió (ej: "stock", "compras", "ventas", "produccion", "recetas")
        entidad_id: ID de la entidad afectada
        entidad_tipo: Tipo de entidad (ej: "Producto", "Documento", "Lote")
        antes: Estado anterior (se serializa a JSON)
        despues: Estado nuevo (se serializa a JSON)
        metadata: Información adicional (dict, se serializa a JSON)
        ip_address: Dirección IP (opcional)
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        timestamp = datetime.now().isoformat()
        
        # Serializar objetos complejos a JSON
        antes_str = json.dumps(antes, default=str) if antes is not None else None
        despues_str = json.dumps(despues, default=str) if despues is not None else None
        metadata_str = json.dumps(metadata, default=str) if metadata is not None else None
        
        cur.execute("""
        INSERT INTO audit_log 
        (timestamp, usuario, accion, modulo, entidad_id, entidad_tipo, antes, despues, metadata, ip_address)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            timestamp,
            usuario,
            accion,
            modulo,
            entidad_id,
            entidad_tipo,
            antes_str,
            despues_str,
            metadata_str,
            ip_address,
        ))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error en auditoría: {e}")
        return False


def get_audit_logs(
    db_path: str,
    *,
    modulo: Optional[str] = None,
    entidad_tipo: Optional[str] = None,
    entidad_id: Optional[str] = None,
    usuario: Optional[str] = None,
    fecha_desde: Optional[str] = None,
    fecha_hasta: Optional[str] = None,
    limit: int = 1000,
) -> list[dict]:
    """
    Obtiene logs de auditoría con filtros opcionales.
    
    Retorna lista de dicts con: id, timestamp, usuario, accion, modulo, 
    entidad_id, entidad_tipo, antes, despues, metadata.
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        conditions = []
        params = []
        
        if modulo:
            conditions.append("modulo = ?")
            params.append(modulo)
        if entidad_tipo:
            conditions.append("entidad_tipo = ?")
            params.append(entidad_tipo)
        if entidad_id:
            conditions.append("entidad_id = ?")
            params.append(entidad_id)
        if usuario:
            conditions.append("usuario = ?")
            params.append(usuario)
        if fecha_desde:
            conditions.append("timestamp >= ?")
            params.append(fecha_desde)
        if fecha_hasta:
            conditions.append("timestamp <= ?")
            params.append(fecha_hasta)
        
        where_clause = " AND ".join(conditions) if conditions else "1=1"
        
        query = f"""
        SELECT id, timestamp, usuario, accion, modulo, entidad_id, entidad_tipo, 
               antes, despues, metadata, ip_address
        FROM audit_log
        WHERE {where_clause}
        ORDER BY timestamp DESC
        LIMIT ?
        """
        params.append(limit)
        
        cur.execute(query, params)
        rows = []
        for r in cur.fetchall():
            rows.append({
                "id": r[0],
                "timestamp": r[1],
                "usuario": r[2],
                "accion": r[3],
                "modulo": r[4],
                "entidad_id": r[5],
                "entidad_tipo": r[6],
                "antes": r[7],
                "despues": r[8],
                "metadata": r[9],
                "ip_address": r[10],
            })
        
        conn.close()
        return rows
    except Exception as e:
        print(f"Error obteniendo logs de auditoría: {e}")
        return []

