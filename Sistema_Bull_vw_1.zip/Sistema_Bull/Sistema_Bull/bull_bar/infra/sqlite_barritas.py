from __future__ import annotations

import sqlite3
from datetime import datetime

from .sqlite_db import connect, init_schema


def _ensure(db_path: str) -> sqlite3.Connection:
    conn = connect(db_path)
    init_schema(conn)
    return conn


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def list_lotes(db_path: str, *, q: str = "") -> list[dict]:
    """Lista lotes (producto terminado). Filtro simple por sku/nombre/lote."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        q = (q or "").strip().upper()
        
        # Verificar qué columnas existen
        cur.execute("PRAGMA table_info(barritas_lotes)")
        columns_info = cur.fetchall()
        column_names = [col[1] for col in columns_info]
        has_mezcla_kg = "mezcla_kg" in column_names
        has_cajas_grandes = "cajas_grandes" in column_names
        has_cajas_chicas = "cajas_chicas" in column_names

        # Construir SELECT dinámicamente
        select_fields = ["lote_id", "sku", "nombre", "cantidad_total", "cantidad_vendida", "cantidad_disponible",
                        "fecha_produccion", "fecha_vencimiento", "deposito", "estado", "notas"]
        
        if has_mezcla_kg:
            select_fields.append("mezcla_kg")
        if has_cajas_grandes:
            select_fields.append("cajas_grandes")
        if has_cajas_chicas:
            select_fields.append("cajas_chicas")
        
        select_fields.extend(["created_at", "updated_at"])
        select_sql = f"SELECT {', '.join(select_fields)} FROM barritas_lotes"
        
        if q:
            select_sql += " WHERE UPPER(lote_id) LIKE ? OR UPPER(sku) LIKE ? OR UPPER(COALESCE(nombre,'')) LIKE ?"
            select_sql += " ORDER BY fecha_vencimiento ASC, lote_id ASC"
            cur.execute(select_sql, (f"%{q}%", f"%{q}%", f"%{q}%"))
        else:
            select_sql += " ORDER BY fecha_vencimiento ASC, lote_id ASC"
            cur.execute(select_sql)

        rows = []
        for r in cur.fetchall():
            # Construir diccionario dinámicamente según las columnas disponibles
            row_dict = {
                "lote_id": r[0],
                "sku": r[1],
                "nombre": r[2] or "",
                "cantidad_total": float(r[3] or 0),
                "cantidad_vendida": float(r[4] or 0),
                "cantidad_disponible": float(r[5] or 0),
                "fecha_produccion": r[6] or "",
                "fecha_vencimiento": r[7] or "",
                "deposito": r[8] or "",
                "estado": r[9] or "",
                "notas": r[10] or "",
            }
            
            idx = 11
            if has_mezcla_kg:
                row_dict["mezcla_kg"] = float(r[idx]) if r[idx] is not None else None
                idx += 1
            else:
                row_dict["mezcla_kg"] = None
            
            if has_cajas_grandes:
                row_dict["cajas_grandes"] = float(r[idx]) if r[idx] is not None else None
                idx += 1
            else:
                # Calcular si no existe en BD
                from ...stock.bultos import barritas_a_cajas_grandes
                row_dict["cajas_grandes"] = barritas_a_cajas_grandes(row_dict["cantidad_total"])
            
            if has_cajas_chicas:
                row_dict["cajas_chicas"] = float(r[idx]) if r[idx] is not None else None
                idx += 1
            else:
                # Calcular si no existe en BD
                from ...stock.bultos import barritas_a_cajas_chicas
                row_dict["cajas_chicas"] = barritas_a_cajas_chicas(row_dict["cantidad_total"])
            
            # created_at y updated_at siempre están al final (últimas 2 columnas)
            row_dict["created_at"] = r[-2] or ""
            row_dict["updated_at"] = r[-1] or ""
            
            rows.append(row_dict)
        conn.close()
        return rows
    except Exception as e:
        print(f"[ERROR] list_lotes: {e}")
        import traceback
        traceback.print_exc()
        return []


def upsert_lote(
    db_path: str,
    *,
    lote_id: str,
    sku: str,
    nombre: str = "",
    cantidad_total: float = 0.0,
    cantidad_vendida: float = 0.0,
    cantidad_disponible: float | None = None,
    fecha_produccion: str = "",
    fecha_vencimiento: str = "",
    deposito: str = "",
    estado: str = "DISPONIBLE",
    notas: str = "",
    mezcla_kg: float | None = None,
) -> bool:
    """Crea o actualiza un lote.

    - Si cantidad_disponible es None => se recalcula como total - vendida.
    """
    try:
        lote_id = lote_id.strip()
        sku = sku.strip()
        if not lote_id or not sku:
            return False

        if cantidad_disponible is None:
            cantidad_disponible = float(cantidad_total) - float(cantidad_vendida)
        
        # Calcular cajas grandes y chicas automáticamente
        from ...stock.bultos import barritas_a_cajas_grandes, barritas_a_cajas_chicas
        cajas_grandes = barritas_a_cajas_grandes(float(cantidad_total))
        cajas_chicas = barritas_a_cajas_chicas(float(cantidad_total))
        
        now = _now_iso()

        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM barritas_lotes WHERE lote_id=?", (lote_id,))
        exists = cur.fetchone() is not None

        # Verificar si la columna mezcla_kg existe
        cur.execute("PRAGMA table_info(barritas_lotes)")
        columns_info = cur.fetchall()
        has_mezcla_kg = any(col[1] == "mezcla_kg" for col in columns_info)
        
        if exists:
            # Construir UPDATE dinámicamente según las columnas disponibles
            update_fields = ["sku=?", "nombre=?", "cantidad_total=?", "cantidad_vendida=?", "cantidad_disponible=?", 
                           "fecha_produccion=?", "fecha_vencimiento=?", "deposito=?", "estado=?", "notas=?"]
            update_values = [sku, nombre, float(cantidad_total), float(cantidad_vendida), float(cantidad_disponible),
                           fecha_produccion, fecha_vencimiento, deposito, estado, notas]
            
            if has_mezcla_kg:
                update_fields.append("mezcla_kg=?")
                update_values.append(float(mezcla_kg) if mezcla_kg is not None else None)
            
            if has_cajas_grandes:
                update_fields.append("cajas_grandes=?")
                update_values.append(cajas_grandes)
            
            if has_cajas_chicas:
                update_fields.append("cajas_chicas=?")
                update_values.append(cajas_chicas)
            
            update_fields.append("updated_at=?")
            update_values.append(now)
            update_values.append(lote_id)
            
            sql = f"UPDATE barritas_lotes SET {', '.join(update_fields)} WHERE lote_id=?"
            cur.execute(sql, tuple(update_values))
        else:
            # Construir INSERT dinámicamente según las columnas disponibles
            insert_fields = ["lote_id", "sku", "nombre", "cantidad_total", "cantidad_vendida", "cantidad_disponible",
                           "fecha_produccion", "fecha_vencimiento", "deposito", "estado", "notas"]
            insert_values = [lote_id, sku, nombre, float(cantidad_total), float(cantidad_vendida), float(cantidad_disponible),
                           fecha_produccion, fecha_vencimiento, deposito, estado, notas]
            placeholders = ["?"] * len(insert_fields)
            
            if has_mezcla_kg:
                insert_fields.append("mezcla_kg")
                insert_values.append(float(mezcla_kg) if mezcla_kg is not None else None)
                placeholders.append("?")
            
            if has_cajas_grandes:
                insert_fields.append("cajas_grandes")
                insert_values.append(cajas_grandes)
                placeholders.append("?")
            
            if has_cajas_chicas:
                insert_fields.append("cajas_chicas")
                insert_values.append(cajas_chicas)
                placeholders.append("?")
            
            insert_fields.extend(["created_at", "updated_at"])
            insert_values.extend([now, now])
            placeholders.extend(["?", "?"])
            
            sql = f"INSERT INTO barritas_lotes ({', '.join(insert_fields)}) VALUES ({', '.join(placeholders)})"
            cur.execute(sql, tuple(insert_values))

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def delete_lote(db_path: str, lote_id: str) -> bool:
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("DELETE FROM barritas_lotes WHERE lote_id=?", (lote_id,))
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def get_next_lote_number(db_path: str) -> str:
    """Genera el siguiente número de lote en formato Lote-N°xxx-xxx.
    
    Los primeros 3 dígitos suben 1 cuando el de la derecha llega a 999.
    Ejemplo: Lote-N°001-000, Lote-N°001-001, ..., Lote-N°001-999, Lote-N°002-000
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        # Buscar el último lote con formato Lote-N°xxx-xxx
        cur.execute("""
            SELECT lote_id FROM barritas_lotes 
            WHERE lote_id LIKE 'Lote-N°___-___'
            ORDER BY lote_id DESC
            LIMIT 1
        """)
        row = cur.fetchone()
        conn.close()
        
        if row:
            # Extraer números del último lote
            ultimo_lote = row[0]
            # Formato: "Lote-N°001-000"
            try:
                partes = ultimo_lote.replace("Lote-N°", "").split("-")
                if len(partes) == 2:
                    num_izq = int(partes[0])
                    num_der = int(partes[1])
                    
                    # Incrementar el número de la derecha
                    num_der += 1
                    
                    # Si llega a 1000, incrementar el de la izquierda y resetear el de la derecha
                    if num_der >= 1000:
                        num_izq += 1
                        num_der = 0
                    
                    return f"Lote-N°{num_izq:03d}-{num_der:03d}"
            except (ValueError, IndexError):
                pass
        
        # Si no hay lotes previos o hay error, empezar desde 001-000
        return "Lote-N°001-000"
    except Exception:
        # En caso de error, empezar desde 001-000
        return "Lote-N°001-000"
