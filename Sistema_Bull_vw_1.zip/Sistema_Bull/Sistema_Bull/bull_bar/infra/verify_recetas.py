from bull_bar.infra.sqlite_db import connect, init_schema
import sqlite3
import sys
from pathlib import Path

DB_DEFAULT = "bullbar.sqlite"

def verify(db_path: str = DB_DEFAULT) -> int:
    db_file = Path(db_path)
    if not db_file.exists():
        print(f"DB no existe: {db_path} (se creará con esquema de ejemplo).")
    conn = connect(db_path)
    init_schema(conn)
    cur = conn.cursor()

    # load products
    cur.execute("SELECT codigo FROM products")
    products = {r[0] for r in cur.fetchall()}

    # load recetas
    cur.execute("SELECT codigo FROM recetas")
    recetas = [r[0] for r in cur.fetchall()]

    missing = {}
    print(f"Recetas encontradas: {len(recetas)}")
    for rc in recetas:
        print(f"\nReceta: {rc}")
        cur.execute("SELECT producto_codigo, porcentaje FROM receta_items WHERE receta_codigo = ?", (rc,))
        rows = cur.fetchall()
        if not rows:
            print("  (sin ingredientes en DB)")
            continue
        for prod_codigo, porcentaje in rows:
            exists = prod_codigo in products
            status = "OK" if exists else "MISSING"
            print(f"  - {prod_codigo}: {porcentaje}% -> {status}")
            if not exists:
                missing.setdefault(rc, []).append(prod_codigo)

    if not recetas:
        print("\nNo hay recetas cargadas.")
    if missing:
        print("\nResumen: Ingredientes faltantes por receta:")
        for rc, prods in missing.items():
            print(f"  {rc}: {', '.join(prods)}")
        conn.close()
        return 2
    else:
        print("\nTodas las recetas tienen sus ingredientes registrados en la tabla products.")
        conn.close()
        return 0

def main():
    db_path = DB_DEFAULT
    # permitir pasar path como argumento
    if len(sys.argv) > 1:
        db_path = sys.argv[1]
    rc = verify(db_path)
    sys.exit(rc)

if __name__ == "__main__":
    main()
