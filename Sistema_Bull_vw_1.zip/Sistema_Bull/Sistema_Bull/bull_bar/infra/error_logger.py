"""
Sistema de logging de errores con información detallada.
"""
from __future__ import annotations

import traceback
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Any
import os


def get_error_log_path() -> str:
    """Obtiene la ruta del archivo de log de errores."""
    # Obtener la ruta del proyecto (asumiendo que estamos en bull_bar/infra/)
    project_root = Path(__file__).parent.parent.parent
    log_path = project_root / "error_log.txt"
    return str(log_path)


def format_error_info(
    error: Exception,
    context: Optional[str] = None,
    extra_info: Optional[dict[str, Any]] = None
) -> str:
    """
    Formatea la información del error de manera legible.
    
    Args:
        error: La excepción capturada
        context: Contexto adicional (ej: "Al guardar receta", "Al autenticar usuario")
        extra_info: Diccionario con información adicional
    
    Returns:
        String formateado con toda la información del error
    """
    lines = []
    
    # Fecha y hora
    now = datetime.now()
    lines.append("=" * 80)
    lines.append(f"FECHA Y HORA: {now.strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("=" * 80)
    
    # Contexto si se proporciona
    if context:
        lines.append(f"CONTEXTO: {context}")
        lines.append("-" * 80)
    
    # Tipo de error
    error_type = type(error).__name__
    error_msg = str(error)
    lines.append(f"TIPO DE ERROR: {error_type}")
    lines.append(f"MENSAJE: {error_msg}")
    lines.append("-" * 80)
    
    # Información del traceback
    tb = traceback.extract_tb(error.__traceback__)
    if tb:
        lines.append("UBICACIÓN DEL ERROR:")
        # Mostrar las últimas 5 líneas del traceback (las más relevantes)
        for frame in tb[-5:]:
            filename = frame.filename
            lineno = frame.lineno
            func_name = frame.name
            line_text = frame.line or "(sin código)"
            
            # Acortar la ruta del archivo si es muy larga
            try:
                # Intentar hacer la ruta relativa al proyecto
                project_root = Path(__file__).parent.parent.parent
                rel_path = Path(filename).relative_to(project_root)
                filename = str(rel_path)
            except (ValueError, AttributeError):
                # Si no se puede hacer relativa, usar el nombre del archivo
                filename = os.path.basename(filename)
            
            lines.append(f"  Archivo: {filename}")
            lines.append(f"  Línea: {lineno}")
            lines.append(f"  Función: {func_name}")
            lines.append(f"  Código: {line_text.strip()}")
            lines.append("")
    
    # Stack trace completo
    lines.append("STACK TRACE COMPLETO:")
    lines.append("-" * 80)
    tb_lines = traceback.format_exception(type(error), error, error.__traceback__)
    lines.extend([line.rstrip() for line in tb_lines])
    lines.append("-" * 80)
    
    # Información adicional
    if extra_info:
        lines.append("INFORMACIÓN ADICIONAL:")
        for key, value in extra_info.items():
            lines.append(f"  {key}: {value}")
        lines.append("-" * 80)
    
    lines.append("")  # Línea en blanco al final
    lines.append("")
    
    return "\n".join(lines)


def log_error(
    error: Exception,
    context: Optional[str] = None,
    extra_info: Optional[dict[str, Any]] = None,
    log_file: Optional[str] = None
) -> str:
    """
    Registra un error en el archivo de log.
    
    Args:
        error: La excepción a registrar
        context: Contexto donde ocurrió el error (ej: "Al guardar receta")
        extra_info: Diccionario con información adicional
        log_file: Ruta del archivo de log (opcional, usa el predeterminado si es None)
    
    Returns:
        Ruta del archivo de log donde se guardó el error
    """
    if log_file is None:
        log_file = get_error_log_path()
    
    try:
        error_text = format_error_info(error, context, extra_info)
        
        # Escribir al archivo (append mode)
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(error_text)
        
        return log_file
    except Exception as e:
        # Si falla el logging, intentar escribir a un archivo de emergencia
        try:
            emergency_log = Path(__file__).parent.parent.parent / "error_log_emergency.txt"
            with open(emergency_log, "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().isoformat()}: Error al escribir log: {e}\n")
                f.write(f"Error original: {error}\n")
        except:
            pass  # Si incluso esto falla, no hacer nada
        return log_file


def log_exception(
    context: Optional[str] = None,
    extra_info: Optional[dict[str, Any]] = None,
    reraise: bool = False
):
    """
    Decorador/context manager para capturar y registrar excepciones automáticamente.
    
    Uso como decorador:
        @log_exception(context="Al procesar compra")
        def procesar_compra():
            ...
    
    Uso como context manager:
        with log_exception(context="Al guardar datos"):
            ...
    """
    import functools
    
    class ExceptionLogger:
        def __init__(self, context: Optional[str] = None, extra_info: Optional[dict[str, Any]] = None, reraise: bool = False):
            self.context = context
            self.extra_info = extra_info or {}
            self.reraise = reraise
        
        def __enter__(self):
            return self
        
        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type is not None:
                log_error(exc_val, context=self.context, extra_info=self.extra_info)
                return not self.reraise  # Si reraise=True, no suprime la excepción
            return False
        
        def __call__(self, func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    # Agregar información de la función
                    func_info = {
                        "función": func.__name__,
                        "módulo": func.__module__,
                        **self.extra_info
                    }
                    log_error(e, context=self.context or f"En función {func.__name__}", extra_info=func_info)
                    if self.reraise:
                        raise
                    return None
            return wrapper
    
    return ExceptionLogger(context, extra_info, reraise)


def safe_execute(
    func,
    *args,
    context: Optional[str] = None,
    default_return: Any = None,
    extra_info: Optional[dict[str, Any]] = None,
    **kwargs
) -> Any:
    """
    Ejecuta una función de forma segura, capturando y registrando cualquier error.
    
    Args:
        func: Función a ejecutar
        *args: Argumentos posicionales para la función
        context: Contexto donde se ejecuta (ej: "Al guardar receta")
        default_return: Valor a retornar si hay un error
        extra_info: Información adicional para el log
        **kwargs: Argumentos con nombre para la función
    
    Returns:
        Resultado de la función o default_return si hay error
    """
    try:
        return func(*args, **kwargs)
    except Exception as e:
        func_info = {
            "función": func.__name__ if hasattr(func, '__name__') else str(func),
            **extra_info or {}
        }
        log_error(e, context=context or f"Al ejecutar {func.__name__}", extra_info=func_info)
        return default_return

