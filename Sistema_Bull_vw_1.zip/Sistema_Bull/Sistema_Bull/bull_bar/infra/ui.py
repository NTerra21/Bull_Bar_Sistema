from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path
from tkinter import Tk, StringVar, DoubleVar, messagebox
from tkinter import ttk
from uuid import uuid4
from datetime import datetime

from bull_bar.core.enums import TipoTercero
from bull_bar.core.models import Producto, Deposito, DocumentoItem, ParteComercial
from bull_bar.stock.service import StockLedger
from bull_bar.compra_venta.services import PurchaseService, SaleService
from bull_bar.produccion.services import ProductionService


DB_PATH = "bullbar.sqlite"


# -------------------------
# DB helpers (recetas)
# -------------------------
def db_connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def db_list_recetas(db_path: str) -> list[tuple[str, str]]:
    """[(codigo, nombre)]"""
    if not Path(db_path).exists():
        return []
    conn = db_connect(db_path)
    try:
        cur = conn.execute("SELECT codigo, nombre FROM recetas WHERE activo = 1 ORDER BY nombre;")
        return [(r[0], r[1]) for r in cur.fetchall()]
    finally:
        conn.close()


def db_get_receta_items(db_path: str, receta_codigo: str) -> list[tuple[str, float]]:
    """[(producto_codigo, porcentaje)]"""
    conn = db_connect(db_path)
    try:
        cur = conn.execute(
            """
            SELECT ri.producto_codigo, ri.porcentaje
            FROM receta_items ri
            JOIN recetas r ON r.id = ri.receta_id
            WHERE r.codigo = ?
            ORDER BY ri.orden ASC;
            """,
            (receta_codigo,),
        )
        return [(r[0], float(r[1])) for r in cur.fetchall()]
    finally:
        conn.close()


def db_get_producto_by_codigo(db_path: str, codigo: str) -> tuple[str, str]:
    """(producto_id_fake, nombre) -> como no tenemos productos en core DB real,
    vamos a usar el codigo como id estable.
    """
    conn = db_connect(db_path)
    try:
        cur = conn.execute("SELECT nombre FROM productos WHERE codigo = ?;", (codigo,))
        row = cur.fetchone()
        if not row:
            return codigo, codigo
        return codigo, row[0]
    finally:
        conn.close()


# -------------------------
# UI App
# -------------------------
class BullBarUI:
    def __init__(self, root: Tk):
        self.root = root
        self.root.title("Bull Bar - UI mínima")

        # Núcleo en memoria (por ahora)
        self.ledger = StockLedger()
        self.compras = PurchaseService(self.ledger)
        self.ventas = SaleService(self.ledger)
        self.produccion = ProductionService(self.ledger)

        # "Datos base" mínimos
        self.depo = Deposito(id="DEPO-PRINCIPAL", nombre="Depósito Principal")
        self.prov = ParteComercial(id="PROV-DEFAULT", tipo=TipoTercero.PROVEEDOR, razon_social="Proveedor Default")
        self.cli = ParteComercial(id="CLI-DEFAULT", tipo=TipoTercero.CLIENTE, razon_social="Cliente Default")

        # UI layout
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=8, pady=8)

        self._tab_compra()
        self._tab_produccion_rapida()
        self._tab_venta()
        self._tab_stock()

        self._refresh_recetas()

    # -------- Tabs --------
    def _tab_compra(self):
        frm = ttk.Frame(self.nb)
        self.nb.add(frm, text="Compra")

        self.compra_codigo = StringVar(value="INS-AGUA")
        self.compra_nombre = StringVar(value="Insumo")
        self.compra_cantidad = DoubleVar(value=1000.0)

        ttk.Label(frm, text="Código insumo (DB codigo):").grid(row=0, column=0, sticky="w", padx=6, pady=6)
        ttk.Entry(frm, textvariable=self.compra_codigo, width=30).grid(row=0, column=1, padx=6, pady=6)

        ttk.Label(frm, text="Descripción:").grid(row=1, column=0, sticky="w", padx=6, pady=6)
        ttk.Entry(frm, textvariable=self.compra_nombre, width=40).grid(row=1, column=1, padx=6, pady=6)

        ttk.Label(frm, text="Cantidad (g):").grid(row=2, column=0, sticky="w", padx=6, pady=6)
        ttk.Entry(frm, textvariable=self.compra_cantidad, width=20).grid(row=2, column=1, padx=6, pady=6, sticky="w")

        ttk.Button(frm, text="Registrar compra (RECIBIDO)", command=self._accion_compra).grid(
            row=3, column=0, columnspan=2, padx=6, pady=10, sticky="we"
        )

    def _tab_produccion_rapida(self):
        frm = ttk.Frame(self.nb)
        self.nb.add(frm, text="Producción (Rápido)")

        self.receta_sel = StringVar(value="")
        self.mezcla_kg = StringVar(value="10")
        self.prod_terminado_codigo = StringVar(value="PROD-BARRITA-CAKECREAM")
        self.prod_terminado_cant = DoubleVar(value=100.0)

        ttk.Label(frm, text="Receta:").grid(row=0, column=0, sticky="w", padx=6, pady=6)
        self.receta_combo = ttk.Combobox(frm, textvariable=self.receta_sel, state="readonly", width=40)
        self.receta_combo.grid(row=0, column=1, padx=6, pady=6, sticky="w")

        ttk.Label(frm, text="Mezcla (kg):").grid(row=1, column=0, sticky="w", padx=6, pady=6)
        self.mezcla_combo = ttk.Combobox(frm, textvariable=self.mezcla_kg, state="readonly", values=["10", "20", "30", "40"], width=10)
        self.mezcla_combo.grid(row=1, column=1, padx=6, pady=6, sticky="w")

        ttk.Separator(frm).grid(row=2, column=0, columnspan=2, sticky="we", padx=6, pady=10)

        ttk.Label(frm, text="Producto terminado (código):").grid(row=3, column=0, sticky="w", padx=6, pady=6)
        ttk.Entry(frm, textvariable=self.prod_terminado_codigo, width=30).grid(row=3, column=1, padx=6, pady=6, sticky="w")

        ttk.Label(frm, text="Cantidad terminada (u):").grid(row=4, column=0, sticky="w", padx=6, pady=6)
        ttk.Entry(frm, textvariable=self.prod_terminado_cant, width=15).grid(row=4, column=1, padx=6, pady=6, sticky="w")

        ttk.Button(frm, text="Registrar producción rápida (descuenta al toque)", command=self._accion_produccion_rapida).grid(
            row=5, column=0, columnspan=2, padx=6, pady=10, sticky="we"
        )

        self.txt_prod = ttk.Label(frm, text="Tip: esto usa los % desde la DB y calcula gramos para 10/20/30/40kg.")
        self.txt_prod.grid(row=6, column=0, columnspan=2, sticky="w", padx=6, pady=6)

    def _tab_venta(self):
        frm = ttk.Frame(self.nb)
        self.nb.add(frm, text="Venta")

        self.venta_prod_codigo = StringVar(value="PROD-BARRITA-CAKECREAM")
        self.venta_cantidad = DoubleVar(value=100.0)

        ttk.Label(frm, text="Producto (código):").grid(row=0, column=0, sticky="w", padx=6, pady=6)
        ttk.Entry(frm, textvariable=self.venta_prod_codigo, width=30).grid(row=0, column=1, padx=6, pady=6, sticky="w")

        ttk.Label(frm, text="Cantidad a vender (u):").grid(row=1, column=0, sticky="w", padx=6, pady=6)
        ttk.Entry(frm, textvariable=self.venta_cantidad, width=15).grid(row=1, column=1, padx=6, pady=6, sticky="w")

        ttk.Button(frm, text="Intentar vender", command=self._accion_venta).grid(
            row=2, column=0, columnspan=2, padx=6, pady=10, sticky="we"
        )

    def _tab_stock(self):
        frm = ttk.Frame(self.nb)
        self.nb.add(frm, text="Stock")

        self.stock_codigo = StringVar(value="INS-AGUA")
        self.lbl_stock = ttk.Label(frm, text="Stock confirmado: 0")

        ttk.Label(frm, text="Código producto (código):").grid(row=0, column=0, sticky="w", padx=6, pady=6)
        ttk.Entry(frm, textvariable=self.stock_codigo, width=30).grid(row=0, column=1, padx=6, pady=6, sticky="w")

        ttk.Button(frm, text="Consultar", command=self._accion_stock).grid(row=1, column=0, columnspan=2, padx=6, pady=10, sticky="we")
        self.lbl_stock.grid(row=2, column=0, columnspan=2, sticky="w", padx=6, pady=6)

    # -------- Actions --------
    def _accion_compra(self):
        codigo = self.compra_codigo.get().strip()
        nombre = self.compra_nombre.get().strip() or codigo
        cant = float(self.compra_cantidad.get())

        # Usamos "codigo" como id estable
        item = DocumentoItem(producto_id=codigo, descripcion=nombre, cantidad=cant)

        doc, movs = self.compras.registrar_compra_recibida(
            numero=f"C-{datetime.now().strftime('%H%M%S')}",
            tercero_id=self.prov.id,
            deposito_id=self.depo.id,
            items=[item],
        )
        messagebox.showinfo("OK", f"Compra registrada.\nMovimientos: {len(movs)}")
        self._accion_stock()

    def _accion_produccion_rapida(self):
        receta_codigo = self._receta_codigo_from_combo()
        if not receta_codigo:
            messagebox.showerror("Error", "No hay receta seleccionada (o no existe DB).")
            return

        mezcla_kg = float(self.mezcla_kg.get())
        total_g = mezcla_kg * 1000.0

        # items receta: (codigo_insumo, porcentaje)
        items = db_get_receta_items(DB_PATH, receta_codigo)
        if not items:
            messagebox.showerror("Error", f"No encontré items para la receta {receta_codigo}.")
            return

        consumos: list[DocumentoItem] = []
        for ins_codigo, pct in items:
            _pid, ins_nombre = db_get_producto_by_codigo(DB_PATH, ins_codigo)
            gramos = (pct / 100.0) * total_g
            consumos.append(DocumentoItem(producto_id=ins_codigo, descripcion=ins_nombre, cantidad=gramos))

        # producto terminado (simple)
        prod_codigo = self.prod_terminado_codigo.get().strip()
        prod_cant = float(self.prod_terminado_cant.get())
        prod_item = DocumentoItem(producto_id=prod_codigo, descripcion=prod_codigo, cantidad=prod_cant)

        doc, movs = self.produccion.registrar_remito_produccion_rapido(
            numero=f"P-{datetime.now().strftime('%H%M%S')}",
            deposito_id=self.depo.id,
            consumos=consumos,
            producto_final=prod_item,
        )

        messagebox.showinfo("OK", f"Producción rápida registrada.\nConsumos: {len(consumos)}\nMovimientos: {len(movs)}")
        self._accion_stock()

    def _accion_venta(self):
        prod_codigo = self.venta_prod_codigo.get().strip()
        cant = float(self.venta_cantidad.get())

        item = DocumentoItem(producto_id=prod_codigo, descripcion=prod_codigo, cantidad=cant)

        doc, movs, faltantes = self.ventas.intentar_venta(
            numero=f"V-{datetime.now().strftime('%H%M%S')}",
            tercero_id=self.cli.id,
            deposito_id=self.depo.id,
            items=[item],
        )

        if not faltantes:
            messagebox.showinfo("OK", f"Venta CONFIRMADA.\nMovimientos: {len(movs)}")
            self._accion_stock()
            return

        # Tu popup con opciones
        f = faltantes[0]
        disponible = f["disponible"]
        solicitado = f["solicitado"]

        msg = (
            f"No hay stock suficiente.\n\n"
            f"Producto: {prod_codigo}\n"
            f"Disponible: {disponible}\n"
            f"Solicitado: {solicitado}\n\n"
            f"¿Qué querés hacer?"
        )

        # 1) Crear orden pendiente (solo aviso)
        if messagebox.askyesno("Stock insuficiente", msg + "\n\nSí = Crear ORDEN PENDIENTE\nNo = Ver más opciones"):
            messagebox.showinfo("Orden pendiente", "Orden creada en PENDIENTE_STOCK.\n(Avisar: hay que producir/reponer)")
            return

        # 2) Ajustar a disponible
        if disponible > 0 and messagebox.askyesno("Ajustar", f"¿Querés ajustar la venta a {disponible}?"):
            self.venta_cantidad.set(float(disponible))
            # reintenta venta
            doc2, movs2, falt2 = self.ventas.intentar_venta(
                numero=f"V-{datetime.now().strftime('%H%M%S')}-AJ",
                tercero_id=self.cli.id,
                deposito_id=self.depo.id,
                items=[DocumentoItem(producto_id=prod_codigo, descripcion=prod_codigo, cantidad=float(disponible))],
            )
            if not falt2:
                messagebox.showinfo("OK", f"Venta ajustada CONFIRMADA.\nMovimientos: {len(movs2)}")
                self._accion_stock()
            else:
                messagebox.showerror("Error", "Sigue sin alcanzar stock (raro).")
            return

        # 3) Cancelar
        messagebox.showinfo("Cancelado", "Operación cancelada.")

    def _accion_stock(self):
        codigo = self.stock_codigo.get().strip()
        confirmado = self.ledger.stock_confirmado(self.depo.id, codigo)
        pendiente = self.ledger.stock_pendiente(self.depo.id, codigo)
        self.lbl_stock.config(text=f"Stock confirmado: {confirmado:.2f} | Pendiente: {pendiente:.2f}")

    # -------- helpers --------
    def _refresh_recetas(self):
        recetas = db_list_recetas(DB_PATH)  # [(codigo, nombre)]
        # combobox muestra "Nombre (CODIGO)"
        values = [f"{nombre} ({codigo})" for codigo, nombre in recetas]
        self.receta_combo["values"] = values
        if values:
            self.receta_combo.current(0)

    def _receta_codigo_from_combo(self) -> str:
        sel = self.receta_sel.get().strip()
        if "(" in sel and sel.endswith(")"):
            return sel.split("(")[-1][:-1]
        return ""


def main():
    root = Tk()
    # tema ttk "default"
    try:
        style = ttk.Style()
        style.theme_use("clam")
    except Exception:
        pass

    app = BullBarUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()