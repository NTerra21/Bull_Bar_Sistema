"""
Script para actualizar las credenciales del usuario admin.
Cambia de admin/admin a Bull/Bull1243 (sin punto)
"""
from __future__ import annotations

import sys
from pathlib import Path

# Agregar el directorio raíz al path
root_dir = Path(__file__).parent.parent.parent
sys.path.insert(0, str(root_dir))

from bull_bar.infra.auth import _hash_password, _ensure_users_table
from bull_bar.infra.sqlite_db import connect, init_schema


def actualizar_admin(db_path: str):
    """Actualiza el usuario admin a Bull con contraseña Bull1243."""
    conn = connect(db_path)
    init_schema(conn)
    _ensure_users_table(conn)
    
    cur = conn.cursor()
    
    # Verificar si ya existe Bull
    cur.execute("SELECT id FROM usuarios WHERE username = 'Bull'")
    bull_row = cur.fetchone()
    
    # Verificar si existe usuario "admin"
    cur.execute("SELECT id, username FROM usuarios WHERE username = 'admin'")
    admin_row = cur.fetchone()
    
    if bull_row:
        # Bull ya existe, actualizar su contraseña
        bull_id = bull_row[0]
        print(f"Actualizando contraseña del usuario Bull (ID: {bull_id})...")
        password_hash = _hash_password("Bull1243")
        from datetime import datetime
        cur.execute("""
            UPDATE usuarios 
            SET password_hash = ?, updated_at = ?
            WHERE id = ?
        """, (password_hash, datetime.now().isoformat(), bull_id))
        conn.commit()
        print("[OK] Contrasena de Bull actualizada correctamente")
        
        # Si existe admin, eliminarlo o renombrarlo
        if admin_row:
            admin_id = admin_row[0]
            print(f"Eliminando usuario admin antiguo (ID: {admin_id})...")
            cur.execute("DELETE FROM usuarios WHERE id = ?", (admin_id,))
            conn.commit()
            print("[OK] Usuario admin eliminado")
    elif admin_row:
        # Existe admin pero no Bull, actualizar admin a Bull
        admin_id = admin_row[0]
        print(f"Actualizando usuario admin (ID: {admin_id}) a Bull...")
        password_hash = _hash_password("Bull1243")
        from datetime import datetime
        cur.execute("""
            UPDATE usuarios 
            SET username = ?, password_hash = ?, updated_at = ?
            WHERE id = ?
        """, ("Bull", password_hash, datetime.now().isoformat(), admin_id))
        conn.commit()
        print("[OK] Usuario actualizado correctamente")
    else:
        # No existe ni admin ni Bull, crear Bull
        print("Creando nuevo usuario Bull...")
        password_hash = _hash_password("Bull1243")
        from datetime import datetime
        now = datetime.now().isoformat()
        from bull_bar.infra.auth import RolUsuario
        cur.execute("""
            INSERT INTO usuarios (username, password_hash, rol, nombre_completo, debe_cambiar_password, activo, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, ("Bull", password_hash, RolUsuario.ADMIN.value, "Administrador", 0, 1, now))
        conn.commit()
        print("[OK] Usuario Bull creado correctamente")
    
    conn.close()


if __name__ == "__main__":
    import sys
    from bull_bar.api.settings import get_db_path
    
    db_path = get_db_path()
    print(f"Actualizando credenciales en: {db_path}")
    actualizar_admin(db_path)
    print("\n✓ Proceso completado. Nuevas credenciales:")
    print("  Usuario: Bull")
    print("  Contraseña: Bull1243")

