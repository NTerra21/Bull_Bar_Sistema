# Bull Bar API - Documentación

API REST para gestión de stock, producción y movimientos de Bull Bar, construida con FastAPI.

## Instalación

### Dependencias

Instalar las dependencias necesarias:

```bash
pip install fastapi uvicorn[standard] pydantic-settings passlib[bcrypt] python-jose[cryptography]
```

O crear un archivo `requirements.txt`:

```
fastapi>=0.104.0
uvicorn[standard]>=0.24.0
pydantic-settings>=2.0.0
passlib[bcrypt]>=1.7.4
python-jose[cryptography]>=3.3.0
```

### Configuración

La aplicación busca la base de datos SQLite en la ruta configurada en `settings.py` (por defecto `bullbar.sqlite` en el directorio raíz del proyecto).

Para configurar variables de entorno, crear un archivo `.env`:

```env
JWT_SECRET=tu-secret-key-seguro-aqui
DEBUG=True
SQLITE_PATH=./bullbar.sqlite
CORS_ORIGINS=["http://localhost:3000","http://localhost:8080"]
```

## Ejecución

### Desarrollo (con auto-reload)

```bash
uvicorn bull_bar.api.main:app --reload
```

### Producción

```bash
uvicorn bull_bar.api.main:app --host 0.0.0.0 --port 8000
```

La API estará disponible en `http://localhost:8000`

## Documentación Interactiva

Una vez levantada la API, acceder a:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## Autenticación

### Usuarios por Defecto

Al iniciar la aplicación, se crean automáticamente dos usuarios:

- **admin/admin** (rol: ADMIN)
- **user/user** (rol: USUARIO)

**Nota**: Estos usuarios tienen la contraseña igual al username inicialmente. Se recomienda cambiarla en el primer login.

### Login

```bash
curl -X POST "http://localhost:8000/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin&password=admin"
```

Respuesta:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

### Uso del Token

Incluir el token en las peticiones:

```bash
curl -X GET "http://localhost:8000/stock/insumos" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

## Endpoints Principales

### Health Check

```bash
GET /health
```

### Stock

- `GET /stock/insumos` - Lista insumos con stock
- `GET /stock/barritas` - Lista barritas con stock

### Lotes

- `GET /lotes?estado=activos` - Lista lotes (filtro opcional: activos, finalizados)
- `POST /lotes` - Crea un nuevo lote
- `PATCH /lotes/{lote_id}/finalizar` - Finaliza un lote

### Movimientos

- `POST /movimientos/compra` - Registra una compra (no requiere aprobación)
- `POST /movimientos/venta` - Registra una venta (no requiere aprobación)
- `POST /movimientos/ajuste` - Registra un ajuste de stock
  - Si es negativo y el usuario es USUARIO → requiere aprobación
  - Si es ADMIN → se ejecuta directamente
- `POST /movimientos/produccion` - Registra una producción
  - Si el usuario es USUARIO → requiere aprobación
  - Si es ADMIN → se ejecuta directamente

### Aprobaciones (Solo ADMIN)

- `GET /aprobaciones?estado=pendiente` - Lista solicitudes pendientes
- `POST /aprobaciones/{id}/aprobar` - Aprueba una solicitud (ejecuta el movimiento)
- `POST /aprobaciones/{id}/rechazar` - Rechaza una solicitud

### Recetas

- `GET /recetas?estado=activas` - Lista recetas (filtro: activas, inactivas)
- `POST /recetas` - Crea una nueva receta (solo ADMIN)
- `PATCH /recetas/{codigo}` - Actualiza una receta (solo ADMIN)
- `PATCH /recetas/{codigo}/activar` - Activa una versión (solo ADMIN)
- `PATCH /recetas/{codigo}/inactivar` - Inactiva una receta (solo ADMIN)

## Sistema de Aprobaciones

### Acciones que Requieren Aprobación

1. **Ajuste negativo** (resta stock) - Solo para usuarios USUARIO
2. **Producción** - Solo para usuarios USUARIO

### Flujo de Aprobación

1. Usuario USUARIO crea un movimiento sensible (ajuste negativo o producción)
2. El sistema crea una solicitud en estado `PENDIENTE` y **NO impacta el stock**
3. ADMIN puede:
   - Ver todas las solicitudes pendientes: `GET /aprobaciones?estado=pendiente`
   - Aprobar: `POST /aprobaciones/{id}/aprobar` → **Ahora sí se ejecuta el movimiento y impacta stock**
   - Rechazar: `POST /aprobaciones/{id}/rechazar` → La solicitud queda rechazada, no se ejecuta

## Ejemplos de Uso

### 1. Consultar Stock de Insumos

```bash
TOKEN="tu-token-aqui"
curl -X GET "http://localhost:8000/stock/insumos" \
  -H "Authorization: Bearer $TOKEN"
```

### 2. Registrar una Compra

```bash
curl -X POST "http://localhost:8000/movimientos/compra" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "numero": "C-0001",
    "proveedor_id": "proveedor-uuid",
    "deposito_id": "deposito-uuid",
    "items": [
      {
        "producto_id": "producto-uuid",
        "descripcion": "Avena",
        "cantidad": 30.0
      }
    ]
  }'
```

### 3. Registrar una Producción (como USUARIO - requiere aprobación)

```bash
curl -X POST "http://localhost:8000/movimientos/produccion" \
  -H "Authorization: Bearer $TOKEN_USER" \
  -H "Content-Type: application/json" \
  -d '{
    "numero": "PROD-001",
    "deposito_id": "deposito-uuid",
    "consumos": [
      {
        "producto_id": "insumo-uuid",
        "descripcion": "Avena",
        "cantidad": 10.0
      }
    ],
    "producto_final": {
      "producto_id": "barrita-uuid",
      "descripcion": "Barrita X",
      "cantidad": 50.0
    }
  }'
```

Respuesta incluirá `"requiere_aprobacion": true` y `"aprobacion_id": "..."`

### 4. Aprobar una Solicitud (como ADMIN)

```bash
curl -X POST "http://localhost:8000/aprobaciones/{aprobacion_id}/aprobar" \
  -H "Authorization: Bearer $TOKEN_ADMIN" \
  -H "Content-Type: application/json" \
  -d '{
    "motivo": "Aprobado"
  }'
```

## Estructura del Proyecto

```
bull_bar/
  api/
    __init__.py
    main.py              # App FastAPI principal
    settings.py          # Configuración
    deps.py              # Dependencias (inyección de servicios)
    auth/
      __init__.py
      security.py        # JWT, verificación de contraseñas
      router.py          # Endpoints de auth
      models.py          # Modelos de auth
    routers/
      __init__.py
      health.py          # Health check
      stock.py           # Stock (insumos/barritas)
      lots.py            # Lotes de barritas
      movements.py       # Movimientos (compra/venta/ajuste/producción)
      approvals.py       # Aprobaciones (solo ADMIN)
      recipes.py         # Recetas
    schemas/
      __init__.py
      auth.py
      stock.py
      lots.py
      movements.py
      approvals.py
      recipes.py
```

## Notas Importantes

1. **No se rompe el core existente**: La API reutiliza los servicios y repositorios del core (`PurchaseService`, `SaleService`, `ProductionService`, `StockAdjustmentService`).

2. **UI Legacy sigue funcionando**: La UI local (tkinter) sigue funcionando independientemente.

3. **Base de datos compartida**: La API usa la misma base de datos SQLite que la UI local.

4. **Roles**:
   - **ADMIN**: Puede hacer todo, incluyendo aprobar/rechazar solicitudes
   - **USUARIO**: Puede crear movimientos, pero acciones sensibles requieren aprobación

5. **Stock**: El stock se calcula desde movimientos confirmados en el `StockLedger`. Los movimientos pendientes de aprobación NO impactan el stock hasta ser aprobados.

## Troubleshooting

### Error: "Module not found: bull_bar"

Asegurarse de ejecutar desde el directorio raíz del proyecto o agregar el path:

```bash
export PYTHONPATH="${PYTHONPATH}:$(pwd)"
```

### Error: "Database locked"

SQLite puede tener problemas de concurrencia. En producción, considerar migrar a PostgreSQL o MySQL.

### Error: "Token inválido"

Verificar que el token no haya expirado. El tiempo de expiración por defecto es 24 horas (configurable en `settings.py`).

## Próximos Pasos

- [ ] Agregar tests unitarios
- [ ] Implementar paginación en listados
- [ ] Agregar filtros avanzados
- [ ] Implementar rate limiting
- [ ] Agregar logging estructurado
- [ ] Migrar a base de datos relacional (PostgreSQL) para producción
