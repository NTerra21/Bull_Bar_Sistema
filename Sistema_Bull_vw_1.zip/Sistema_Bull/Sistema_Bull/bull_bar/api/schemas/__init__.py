"""
Schemas Pydantic para request/response.
"""
