"""
Schemas para endpoints de autenticación.
"""
from __future__ import annotations

from pydantic import BaseModel


class LoginRequest(BaseModel):
    """Schema para login (usado internamente por OAuth2PasswordRequestForm)."""
    username: str
    password: str


class UserResponse(BaseModel):
    """Schema de respuesta para usuario."""
    id: int
    username: str
    rol: str
    nombre_completo: str | None = None
    email: str | None = None
