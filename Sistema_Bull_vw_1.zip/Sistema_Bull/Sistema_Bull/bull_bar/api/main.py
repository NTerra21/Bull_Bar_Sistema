"""
Aplicación principal FastAPI para Bull Bar.
"""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .settings import settings
from .auth.router import router as auth_router
from .routers import (
    health,
    stock,
    lots,
    movements,
    approvals,
    recipes,
)

# Crear app FastAPI
app = FastAPI(
    title=settings.APP_NAME,
    description="API REST para gestión de stock, producción y movimientos de Bull Bar",
    version="1.0.0",
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir routers
app.include_router(health.router)
app.include_router(auth_router)
app.include_router(stock.router)
app.include_router(lots.router)
app.include_router(movements.router)
app.include_router(approvals.router)
app.include_router(recipes.router)


@app.on_event("startup")
async def startup_event():
    """
    Evento de inicio: inicializar DB y crear usuarios por defecto si no existen.
    """
    from .settings import get_db_path
    # Usar imports absolutos en lugar de relativos para evitar problemas con el top-level package
    from bull_bar.infra.auth import _ensure_users_table, _ensure_default_admin, crear_usuario, RolUsuario
    from datetime import datetime
    
    db_path = get_db_path()
    
    # Asegurar que la tabla de usuarios existe
    import sqlite3
    from bull_bar.infra.sqlite_db import connect, init_schema
    
    conn = connect(db_path)
    init_schema(conn)
    _ensure_users_table(conn)
    _ensure_default_admin(conn)
    
    # Crear usuarios por defecto si no existen (solo en dev)
    # Nota: crear_usuario crea usuarios con password = username inicialmente
    cur = conn.cursor()
    
    # Verificar si existe usuario "Bull" (admin)
    cur.execute("SELECT 1 FROM usuarios WHERE username = 'Bull'")
    if cur.fetchone() is None:
        # Crear usuario Bull con contraseña Bull1243
        from bull_bar.infra.auth import _hash_password
        password_hash = _hash_password("Bull1243")
        now = datetime.now().isoformat()
        cur.execute("""
            INSERT INTO usuarios (username, password_hash, rol, nombre_completo, debe_cambiar_password, activo, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, ("Bull", password_hash, RolUsuario.ADMIN.value, "Administrador", 0, 1, now))
        conn.commit()
    
    # Verificar si existe usuario "user"
    cur.execute("SELECT 1 FROM usuarios WHERE username = 'user'")
    if cur.fetchone() is None:
        crear_usuario(db_path, "user", rol=RolUsuario.USUARIO.value, nombre_completo="Usuario")
    
    conn.close()
    
    # Asegurar tabla de aprobaciones
    _ensure_approvals_table(db_path)


def _ensure_approvals_table(db_path: str):
    """Crea la tabla de aprobaciones si no existe."""
    import sqlite3
    from bull_bar.infra.sqlite_db import connect
    
    conn = connect(db_path)
    cur = conn.cursor()
    
    cur.execute("""
    CREATE TABLE IF NOT EXISTS approvals (
        id TEXT PRIMARY KEY,
        tipo TEXT NOT NULL,
        estado TEXT NOT NULL DEFAULT 'PENDIENTE',
        payload TEXT NOT NULL,
        usuario_creador_id TEXT NOT NULL,
        usuario_creador_nombre TEXT,
        timestamp_creacion TEXT NOT NULL,
        usuario_aprobador_id TEXT,
        usuario_aprobador_nombre TEXT,
        timestamp_aprobacion TEXT,
        motivo_denegacion TEXT,
        observaciones TEXT
    )
    """)
    
    conn.commit()
    conn.close()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=settings.DEBUG)
