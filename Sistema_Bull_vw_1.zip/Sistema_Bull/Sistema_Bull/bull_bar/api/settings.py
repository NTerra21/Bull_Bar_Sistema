"""
Configuración de la API usando pydantic-settings.
"""
from __future__ import annotations

from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Configuración de la aplicación."""
    
    # App
    APP_NAME: str = "Bull Bar API"
    DEBUG: bool = False
    
    # JWT
    JWT_SECRET: str = "change-this-secret-key-in-production-use-env-var"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 horas
    
    # CORS
    CORS_ORIGINS: List[str] = ["*"]  # En producción, especificar dominios
    
    # Database
    SQLITE_PATH: str = "bullbar.sqlite"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


def get_db_path() -> str:
    """
    Obtiene la ruta de la base de datos.
    Si SQLITE_PATH es relativa, la resuelve desde la raíz del proyecto.
    """
    settings = Settings()
    db_path = settings.SQLITE_PATH
    
    # Si es absoluta, usar directamente
    if Path(db_path).is_absolute():
        return db_path
    
    # Si es relativa, buscar desde la raíz del proyecto
    # El archivo settings.py está en: Sistema_Bull/bull_bar/api/settings.py
    # La DB está en: Sistema_Bull/bullbar.sqlite
    current_file = Path(__file__).resolve()
    # Subir 3 niveles: api -> bull_bar -> Sistema_Bull
    project_root = current_file.parent.parent.parent
    candidate = project_root / db_path
    
    # Si existe, usarlo; si no, crearlo en esa ubicación
    return str(candidate)


# Instancia global de settings
settings = Settings()
