"""
Router para endpoints de recetas.
"""
from __future__ import annotations

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from ..schemas.recipes import RecetaCreate, RecetaUpdate, RecetaResponse, RecetaItem
from ..deps import get_db_path_dep
from ..auth.router import get_current_user, require_role
from ..auth.models import User

router = APIRouter(prefix="/recetas", tags=["recetas"])


@router.get("", response_model=List[RecetaResponse])
async def list_recetas(
    estado: Optional[str] = Query("activas", description="Filtro por estado: activas, inactivas"),
    user: User = Depends(get_current_user),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Lista recetas.
    """
    from ...infra.sqlite_recetas import list_receta_versions, get_receta_items, get_receta_version_meta
    
    active = estado.lower() == "activas" if estado else True
    
    versions = list_receta_versions(db_path, active=active if estado else None)
    
    recetas = []
    for v in versions:
        items = get_receta_items(db_path, v["codigo"], v["version"])
        meta = get_receta_version_meta(db_path, v["codigo"], v["version"])
        
        recetas.append(RecetaResponse(
            codigo=v["codigo"],
            nombre=v["codigo"],  # Por ahora usamos el código como nombre
            version=v["version"],
            is_active=v["is_active"],
            items=[
                RecetaItem(
                    producto_codigo=it["producto_codigo"],
                    porcentaje=it["porcentaje"],
                    grupo_preparacion=it.get("grupo_preparacion"),
                    orden_grupo=it.get("orden_grupo"),
                    orden_item=it.get("orden_item"),
                )
                for it in items
            ],
            created_at=meta["created_at"] if meta else None,
            updated_at=meta["updated_at"] if meta else None,
        ))
    
    return recetas


@router.post("", response_model=RecetaResponse)
async def create_receta(
    receta: RecetaCreate,
    user: User = Depends(require_role(["ADMIN"])),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Crea una nueva receta. Solo ADMIN.
    """
    from ...infra.sqlite_recetas import create_receta_named, get_receta_items, get_active_version
    
    success = create_receta_named(
        db_path,
        receta.codigo,
        receta.nombre,
        base_codigo=receta.base_codigo,
    )
    
    if not success:
        raise HTTPException(status_code=400, detail="Error al crear la receta")
    
    # Si hay items, actualizarlos
    if receta.items:
        version = get_active_version(db_path, receta.codigo)
        items_dict = [
            {
                "producto_codigo": it.producto_codigo,
                "porcentaje": it.porcentaje,
                "grupo_preparacion": it.grupo_preparacion,
                "orden_grupo": it.orden_grupo,
                "orden_item": it.orden_item,
            }
            for it in receta.items
        ]
        
        from ...infra.sqlite_recetas import replace_receta_items
        replace_receta_items(db_path, receta.codigo, version, items_dict)
    
    # Obtener la receta creada
    version = get_active_version(db_path, receta.codigo)
    items = get_receta_items(db_path, receta.codigo, version)
    meta = get_receta_version_meta(db_path, receta.codigo, version)
    
    return RecetaResponse(
        codigo=receta.codigo,
        nombre=receta.nombre,
        version=version,
        is_active=True,
        items=[
            RecetaItem(
                producto_codigo=it["producto_codigo"],
                porcentaje=it["porcentaje"],
                grupo_preparacion=it.get("grupo_preparacion"),
                orden_grupo=it.get("orden_grupo"),
                orden_item=it.get("orden_item"),
            )
            for it in items
        ],
        created_at=meta["created_at"] if meta else None,
        updated_at=meta["updated_at"] if meta else None,
    )


@router.patch("/{receta_codigo}")
async def update_receta(
    receta_codigo: str,
    receta: RecetaUpdate,
    user: User = Depends(require_role(["ADMIN"])),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Actualiza una receta. Solo ADMIN.
    Crea una nueva versión con los cambios.
    """
    from ...infra.sqlite_recetas import get_active_version, create_new_version_from_items
    
    version_actual = get_active_version(db_path, receta_codigo)
    
    # Si hay items nuevos, crear nueva versión
    if receta.items:
        items_dict = [
            {
                "producto_codigo": it.producto_codigo,
                "porcentaje": it.porcentaje,
                "grupo_preparacion": it.grupo_preparacion,
                "orden_grupo": it.orden_grupo,
                "orden_item": it.orden_item,
            }
            for it in receta.items
        ]
        
        nueva_version = create_new_version_from_items(db_path, receta_codigo, items_dict)
        
        if nueva_version is None:
            raise HTTPException(status_code=400, detail="Error al actualizar la receta")
    
    return {"message": f"Receta {receta_codigo} actualizada"}


@router.patch("/{receta_codigo}/activar")
async def activar_receta(
    receta_codigo: str,
    version: int,
    user: User = Depends(require_role(["ADMIN"])),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Activa una versión específica de una receta. Solo ADMIN.
    """
    from ...infra.sqlite_recetas import set_receta_active_version
    
    success = set_receta_active_version(db_path, receta_codigo, version)
    
    if not success:
        raise HTTPException(status_code=400, detail="Error al activar la receta")
    
    return {"message": f"Versión {version} de receta {receta_codigo} activada"}


@router.patch("/{receta_codigo}/inactivar")
async def inactivar_receta(
    receta_codigo: str,
    user: User = Depends(require_role(["ADMIN"])),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Inactiva la versión activa de una receta. Solo ADMIN.
    """
    from ...infra.sqlite_recetas import get_active_version, bump_receta_version
    
    # Bump crea una nueva versión y desactiva la actual
    # Pero para inactivar sin crear nueva, necesitamos otra función
    # Por ahora, usamos bump que efectivamente inactiva la actual
    version_actual = get_active_version(db_path, receta_codigo)
    
    # Crear una versión dummy que luego se puede eliminar o simplemente marcar como inactiva
    # Por simplicidad, usamos bump que crea v+1 y desactiva la actual
    nueva_version = bump_receta_version(db_path, receta_codigo)
    
    if nueva_version is None:
        raise HTTPException(status_code=400, detail="Error al inactivar la receta")
    
    # Eliminar la nueva versión creada (solo queríamos inactivar)
    from ...infra.sqlite_recetas import replace_receta_items
    replace_receta_items(db_path, receta_codigo, nueva_version, [])
    
    return {"message": f"Receta {receta_codigo} inactivada"}
