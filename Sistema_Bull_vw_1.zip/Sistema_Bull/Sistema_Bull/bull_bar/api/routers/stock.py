"""
Router para endpoints de stock.
"""
from __future__ import annotations

from typing import List
from fastapi import APIRouter, Depends, HTTPException

from ..schemas.stock import StockItem
from ..deps import get_stock_ledger, get_db_path_dep, get_deposito, get_products
from ..auth.router import get_current_user
from ..auth.models import User

router = APIRouter(prefix="/stock", tags=["stock"])


@router.get("/insumos", response_model=List[StockItem])
async def get_insumos(
    user: User = Depends(get_current_user),
    ledger=Depends(get_stock_ledger),
    deposito=Depends(get_deposito),
    products=Depends(get_products),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Obtiene el stock de insumos (productos que no son barritas).
    """
    from ...infra.sqlite_recetas import list_products
    
    # Obtener todos los productos de la DB
    db_products = list_products(db_path)
    
    # Filtrar insumos (asumiendo que las barritas tienen un patrón específico en el código)
    # Por ahora, consideramos insumos a todos los productos que no empiecen con "PROD-" o "BARRITA-"
    insumos = []
    for p in db_products:
        codigo = p.get("codigo", "").upper()
        # Si no es una barrita, es un insumo
        if not (codigo.startswith("PROD-") or codigo.startswith("BARRITA-") or "BARRITA" in codigo):
            producto_id = p.get("uuid") or ""
            cantidad = ledger.stock_confirmado(deposito.id, producto_id)
            
            insumos.append(StockItem(
                id=producto_id,
                nombre=p.get("nombre", ""),
                unidad="kg",  # Por defecto kg para insumos
                cantidad=cantidad,
                deposito=deposito.nombre,
            ))
    
    return insumos


@router.get("/barritas", response_model=List[StockItem])
async def get_barritas(
    user: User = Depends(get_current_user),
    ledger=Depends(get_stock_ledger),
    deposito=Depends(get_deposito),
    products=Depends(get_products),
    db_path: str = Depends(get_db_path_dep),
):
    """
    Obtiene el stock de barritas (productos terminados).
    """
    from ...infra.sqlite_recetas import list_products
    
    # Obtener todos los productos de la DB
    db_products = list_products(db_path)
    
    # Filtrar barritas
    barritas = []
    for p in db_products:
        codigo = p.get("codigo", "").upper()
        # Si es una barrita
        if codigo.startswith("PROD-") or codigo.startswith("BARRITA-") or "BARRITA" in codigo:
            producto_id = p.get("uuid") or ""
            cantidad = ledger.stock_confirmado(deposito.id, producto_id)
            
            barritas.append(StockItem(
                id=producto_id,
                nombre=p.get("nombre", ""),
                unidad="u",  # Unidades para barritas
                cantidad=cantidad,
                deposito=deposito.nombre,
            ))
    
    return barritas
