from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterable, List
from uuid import uuid4

from ..core.enums import EstadoMovimiento, TipoMovimiento
from .models import MovimientoStock


@dataclass
class StockLedger:
    """Ledger simple: el stock se calcula desde movimientos.

    - CONFIRMADO: impacta stock real
    - PENDIENTE: 'stock en movimiento' (reservas/entradas pendientes)
    """
    movimientos: List[MovimientoStock] = field(default_factory=list)

    def add(self, mov: MovimientoStock) -> None:
        self.movimientos.append(mov)

    def add_many(self, movs: Iterable[MovimientoStock]) -> None:
        self.movimientos.extend(list(movs))

    def apply_adjustment(
        self,
        deposito_id: str,
        producto_id: str,
        cantidad: float,
        motivo: str = "",
    ) -> MovimientoStock:
        """Crea un movimiento CONFIRMADO de ajuste (+ entra / - sale)."""
        qty = float(cantidad)
        tipo = TipoMovimiento.ENTRADA if qty >= 0 else TipoMovimiento.SALIDA

        mov = MovimientoStock(
            id=str(uuid4()),
            fecha=datetime.now(),
            producto_id=producto_id,
            deposito_id=deposito_id,
            tipo=tipo,
            cantidad=abs(qty),
            origen_documento_id=f"AJUSTE|{motivo or 'manual'}",
            estado=EstadoMovimiento.CONFIRMADO,
        )
        self.add(mov)
        return mov

    def _iter(self, deposito_id: str, producto_id: str):
        for m in self.movimientos:
            if m.deposito_id == deposito_id and m.producto_id == producto_id:
                yield m

    def stock_confirmado(self, deposito_id: str, producto_id: str) -> float:
        total = 0.0
        for m in self._iter(deposito_id, producto_id):
            if m.estado == EstadoMovimiento.CONFIRMADO:
                total += m.signed_qty()
        return total

    def stock_pendiente(self, deposito_id: str, producto_id: str) -> float:
        total = 0.0
        for m in self._iter(deposito_id, producto_id):
            if m.estado == EstadoMovimiento.PENDIENTE:
                total += m.signed_qty()
        return total

    def stock_total(self, deposito_id: str, producto_id: str) -> float:
        # confirmado + pendiente (útil para ver todo)
        total = 0.0
        for m in self._iter(deposito_id, producto_id):
            total += m.signed_qty()
        return total
