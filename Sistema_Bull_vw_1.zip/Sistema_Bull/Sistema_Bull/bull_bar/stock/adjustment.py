class StockAdjustmentService:
    def __init__(self, ledger, db_path=None):
        self.ledger = ledger
        self.db_path = db_path

    def apply_adjustment(self, deposito_id: str, producto_id: str, cantidad: float, motivo: str = "", usuario: str = None):
        """
        Aplica un ajuste usando la API oficial del ledger.
        (StockLedger ahora trae apply_adjustment, así que esto funciona directo.)
        """
        if not hasattr(self.ledger, "apply_adjustment"):
            raise RuntimeError("Ledger no soporta apply_adjustment() con la API actual")

        # Obtener stock antes del ajuste
        stock_antes = self.ledger.stock_confirmado(deposito_id, producto_id)
        
        mov = self.ledger.apply_adjustment(deposito_id, producto_id, cantidad, motivo)
        
        # Obtener stock después del ajuste
        stock_despues = self.ledger.stock_confirmado(deposito_id, producto_id)
        
        # Registrar auditoría
        if self.db_path:
            try:
                from ..infra.audit import log_audit
                log_audit(
                    self.db_path,
                    "AJUSTE_STOCK",
                    usuario=usuario,
                    modulo="stock",
                    entidad_id=producto_id,
                    entidad_tipo="Producto",
                    antes={"stock": stock_antes},
                    despues={"stock": stock_despues, "ajuste": cantidad, "motivo": motivo},
                    metadata={"deposito_id": deposito_id, "movimiento_id": mov.id},
                )
            except Exception as e:
                print(f"Error en auditoría de ajuste: {e}")
        
        return mov
