"""
Quick tests for UI tabs. Ejecutar con:
    py -m tests.ui.run_tests
"""
import sys
import tkinter as tk
from tkinter import ttk
from bull_bar.ui.app import build_ctx
from bull_bar.ui.tabs.compra_tab import CompraTab
from bull_bar.ui.tabs.produccion_tab import ProduccionTab
from bull_bar.ui.tabs.venta_tab import VentaTab
from bull_bar.ui.tabs.stock_tab import StockTab
from bull_bar.ui.tabs.ajuste_stock_tab import AjusteStockTab
from bull_bar.infra.sqlite_db import connect, init_schema
from bull_bar.infra import sqlite_recetas

# parchear messagebox para que no bloquee durante tests
import tkinter.messagebox as messagebox
_original_info = messagebox.showinfo
_original_error = messagebox.showerror
_original_warn = messagebox.showwarning
messagebox.showinfo = lambda *a, **k: print("MSG.INFO:", a, k)
messagebox.showerror = lambda *a, **k: print("MSG.ERROR:", a, k)
messagebox.showwarning = lambda *a, **k: print("MSG.WARN:", a, k)

def main():
    # init DB minimal para recetas
    ctx = build_ctx()
    conn = connect(ctx["db_path"])
    init_schema(conn)
    conn.close()

    root = tk.Tk()
    root.withdraw()  # ocultar ventana principal
    notebook = ttk.Notebook(root)

    # instanciar tabs
    compra = CompraTab(notebook, ctx)
    produccion = ProduccionTab(notebook, ctx)
    venta = VentaTab(notebook, ctx)
    stock = StockTab(notebook, ctx)
    ajuste = AjusteStockTab(notebook, ctx)

    # Test Compra: registrar compra para PROD-BARRITA 100
    compra.codigo_entry.delete(0, 'end'); compra.codigo_entry.insert(0, "PROD-BARRITA")
    compra.desc_entry.delete(0, 'end'); compra.desc_entry.insert(0, "Barrita Tal")
    compra.cant_entry.delete(0, 'end'); compra.cant_entry.insert(0, "100")
    compra.registrar()
    try:
        prod_id = ctx["products"]["PROD-BARRITA"].id
        print("Compra registrada. Stocks:", ctx["ledger"].stock_confirmado(ctx["depo"].id, prod_id))
    except Exception:
        print("Compra registrada. Producto no encontrado en ctx['products'].'PROD-BARRITA'")

    # Test Producción: aseguro receta en DB y ejecuto
    recetas = sqlite_recetas.list_recetas(ctx["db_path"])
    if not recetas:
        print("No hay recetas, saltando test producción")
    else:
        produccion.receta_cb.set(recetas[0])
        produccion.mezcla_entry.delete(0, 'end'); produccion.mezcla_entry.insert(0, "10")
        produccion.prod_entry.delete(0, 'end'); produccion.prod_entry.insert(0, "PROD-BARRITA")
        produccion.cant_prod.delete(0, 'end'); produccion.cant_prod.insert(0, "50")
        produccion.build_checklist_for_receta(recetas[0])
        produccion.registrar_produccion()
        try:
            prod_id = ctx["products"]["PROD-BARRITA"].id
            print("Producción ejecutada. Stock barrita:", ctx["ledger"].stock_confirmado(ctx["depo"].id, prod_id))
        except Exception:
            print("Producción ejecutada. Producto no encontrado en ctx['products'].'PROD-BARRITA'")

    # Test Venta: intentar vender más de lo disponible para generar faltantes
    numero = "TEST-V-1"
    try:
        doc_venta, movs, faltantes = ctx["sale_service"].intentar_venta(
            numero=numero,
            ClienteProveedor_id=ctx["cli"].id,
            deposito_id=ctx["depo"].id,
            items=[ __import__('bull_bar.core.models', fromlist=['']).DocumentoItem(
                producto_id=ctx["products"]["PROD-BARRITA"].id, descripcion="Barrita", cantidad=1000.0)]
        )
        if faltantes:
            order = {"id": "test-"+numero, "numero": numero, "producto_codigo": "PROD-BARRITA", "cantidad_solicitada": 1000.0, "estado": "PENDIENTE"}
            ctx.setdefault("pending_orders", []).append(order)
            print("Orden pendiente creada en ctx:", order)
        else:
            print("Venta ejecutada sin faltantes.")
    except Exception as e:
        print("Error en test venta:", e)

    # Test Stock: consultar
    stock.listbox.insert(0, "PROD-BARRITA")
    stock.listbox.selection_set(0)
    stock._on_select()
    print("Stock tab texto:", stock.info.get("1.0", "end").strip())

    # Test Ajuste: aplicar +10
    ajuste.codigo.delete(0, 'end'); ajuste.codigo.insert(0, "PROD-BARRITA")
    ajuste.cantidad.delete(0, 'end'); ajuste.cantidad.insert(0, "10")
    ajuste.motivo.delete(0, 'end'); ajuste.motivo.insert(0, "Inventario")
    ajuste.aplicar()
    try:
        prod_id = ctx["products"]["PROD-BARRITA"].id
        print("Ajuste aplicado. Nuevo stock:", ctx["ledger"].stock_confirmado(ctx["depo"].id, prod_id))
    except Exception:
        print("Ajuste aplicado. Producto no encontrado en ctx['products'].'PROD-BARRITA'")

    print("\nTEST SUMMARY:")
    print(" pending_orders:", ctx.get("pending_orders"))
    print(" products:", list(ctx["products"].keys()))
    print("All tests executed (no GUI assertions).")

    # restaurar messagebox
    messagebox.showinfo = _original_info
    messagebox.showerror = _original_error
    messagebox.showwarning = _original_warn

if __name__ == "__main__":
    main()
