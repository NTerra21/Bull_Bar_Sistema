"""
Tests moved to tests/ui/run_tests.py
Run: py -m tests.ui.run_tests
This module is a stub to avoid import errors if referenced from legacy scripts.
"""
import sys
def main():
    print("UI tests have been moved to 'tests/ui'. Run with: py -m tests.ui.run_tests")
    return 0

if __name__ == "__main__":
    sys.exit(main())
