"""
Módulo auxiliar para la creación de pestañas (tabs) en Producción.
Separa la lógica de creación de UI de pestañas del flujo principal.
"""
import tkinter as tk
from tkinter import ttk
from bull_bar.infra.sqlite_recetas import get_producto_nombre


class ProduccionTabsBuilder:
    """Builder para crear las pestañas de producción."""
    
    def __init__(self, notebook, db_path, chocolate_tipo_seleccionado, mezcla_confirmada):
        """
        Args:
            notebook: ttk.Notebook donde se agregarán las pestañas
            db_path: Ruta a la base de datos
            chocolate_tipo_seleccionado: Tipo de chocolate seleccionado
            mezcla_confirmada: Cantidad de mezcla confirmada
        """
        self.notebook = notebook
        self.db_path = db_path
        self.chocolate_tipo_seleccionado = chocolate_tipo_seleccionado
        self.mezcla_confirmada = mezcla_confirmada
        self.etapas_trees = {}  # {grupo: treeview}
        self.etapa_subpaso_labels = {}  # {grupo: label}
        self.etapas_frames = {}  # {grupo: frame}
    
    def crear_tab_etapa(self, grupo: str, etapas_grupo: list) -> ttk.Frame:
        """Crea una pestaña para un grupo de etapas."""
        page = ttk.Frame(self.notebook)
        page.pack(fill="both", expand=True)
        
        page.grid_rowconfigure(1, weight=1)
        page.grid_columnconfigure(0, weight=1)
        
        # Frame para subpaso (ej: "Sólidos (1/3)")
        etapa_subpaso_frame = ttk.Frame(page)
        etapa_subpaso_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        
        etapa_subpaso_label = ttk.Label(
            etapa_subpaso_frame, 
            text="", 
            font=("Segoe UI", 10, "italic"),
            foreground="#666"
        )
        etapa_subpaso_label.grid(row=0, column=0, sticky="w")
        self.etapa_subpaso_labels[grupo] = etapa_subpaso_label
        
        # Tabla tipo stock
        tabla_frame = ttk.Frame(page)
        tabla_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        tabla_frame.columnconfigure(0, weight=1)
        tabla_frame.rowconfigure(0, weight=1)
        
        cols = ("codigo", "nombre", "cantidad", "unidad", "porcentaje")
        etapas_tree = ttk.Treeview(tabla_frame, columns=cols, show="headings", height=15)
        
        # Configurar columnas
        etapas_tree.heading("codigo", text="Código")
        etapas_tree.heading("nombre", text="Nombre")
        etapas_tree.heading("cantidad", text="Cantidad")
        etapas_tree.heading("unidad", text="Unidad")
        etapas_tree.heading("porcentaje", text="%")
        
        etapas_tree.column("codigo", width=150, anchor="w")
        etapas_tree.column("nombre", width=400, anchor="w")
        etapas_tree.column("cantidad", width=120, anchor="e")
        etapas_tree.column("unidad", width=80, anchor="c")
        etapas_tree.column("porcentaje", width=80, anchor="e")
        
        # Scrollbar
        tabla_scrollbar = ttk.Scrollbar(tabla_frame, orient="vertical", command=etapas_tree.yview)
        etapas_tree.configure(yscrollcommand=tabla_scrollbar.set)
        
        etapas_tree.grid(row=0, column=0, sticky="nsew")
        tabla_scrollbar.grid(row=0, column=1, sticky="ns")
        
        # Configurar fuente grande
        style = ttk.Style()
        style.configure("Treeview", font=("Segoe UI", 11))
        style.configure("Treeview.Heading", font=("Segoe UI", 11, "bold"))
        
        # Guardar referencia
        self.etapas_trees[grupo] = etapas_tree
        self.etapas_frames[grupo] = page
        
        return page
    
    def crear_tab_confirmacion(self, finalizar_callback) -> ttk.Frame:
        """Crea la pestaña de confirmación final."""
        page = ttk.Frame(self.notebook)
        page.pack(fill="both", expand=True)
        
        # Contenido de confirmación (resumen final, botón finalizar)
        ttk.Label(
            page, 
            text="Revisar y finalizar producción", 
            font=("Segoe UI", 12, "bold")
        ).pack(pady=20)
        
        # Botón finalizar
        btn_finalizar = ttk.Button(
            page,
            text="Finalizar producción",
            command=finalizar_callback,
            state="normal"
        )
        btn_finalizar.pack(pady=20)
        
        return page
    
    def llenar_pestana_etapas(self, grupo: str, etapas_grupo: list):
        """Llena una pestaña de etapas con sus datos correspondientes."""
        tree = self.etapas_trees.get(grupo)
        if not tree:
            return
        
        # Limpiar tabla
        for item in tree.get_children():
            tree.delete(item)
        
        # Llenar con todos los items de todas las etapas del grupo
        for etapa in etapas_grupo:
            for item_data in etapa["items"]:
                if item_data.get("es_chocolate"):
                    codigo = item_data.get("producto_codigo", "CHOCO")
                    nombre = f"Chocolate {self.chocolate_tipo_seleccionado or 'NEGRO'}"
                    cantidad = item_data.get("cantidad_kg", 0)
                    unidad = "kg"
                    porcentaje = ""
                else:
                    producto_codigo = item_data.get("producto_codigo", "")
                    porcentaje = float(item_data.get("porcentaje", 0))
                    cantidad = self.mezcla_confirmada * (porcentaje / 100.0)
                    
                    nombre = get_producto_nombre(self.db_path, producto_codigo) or producto_codigo
                    codigo = producto_codigo
                    unidad = "kg"
                    porcentaje = f"{porcentaje:.2f}"
                
                tree.insert("", "end", values=(
                    codigo,
                    nombre,
                    f"{cantidad:.3f}",
                    unidad,
                    porcentaje
                ))
