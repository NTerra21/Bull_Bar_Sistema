# bull_bar/ui/utils/delayed_deselect.py
from __future__ import annotations

from typing import Any, Callable, Iterable, Optional


def _is_descendant(w, ancestor) -> bool:
    while w is not None:
        if w == ancestor:
            return True
        w = getattr(w, "master", None)
    return False


class DelayedDeselect:
    """
    Desmarca selección del Treeview cuando clickeás fuera / vacío,
    pero usando after() para no pisar command() de botones.
    """

    def __init__(
        self,
        root: Any,                 # tk.Tk / tk.Toplevel
        tree: Any,                 # ttk.Treeview
        is_active: Callable[[], bool],
        clear_selection: Callable[[], None],
        exempt_widgets: Optional[Iterable[Any]] = None,
        delay_click_ms: int = 80,
        delay_focusout_ms: int = 250,
    ):
        self.root = root
        self.tree = tree
        self.is_active = is_active
        self.clear_selection = clear_selection
        self.exempt_widgets = list(exempt_widgets or [])
        self.delay_click_ms = delay_click_ms
        self.delay_focusout_ms = delay_focusout_ms

        self._job = None

        root.bind_all("<ButtonRelease-1>", self._on_release, add="+")
        root.bind("<FocusOut>", self._on_focus_out, add="+")
        root.bind("<FocusIn>", self._on_focus_in, add="+")

    def cancel(self):
        if self._job is not None:
            try:
                self.root.after_cancel(self._job)
            except Exception:
                pass
            self._job = None

    def schedule(self, delay_ms: int):
        self.cancel()

        def _do():
            self._job = None
            if self.is_active():
                self.clear_selection()

        self._job = self.root.after(delay_ms, _do)

    # ---------------- events ----------------
    def _on_focus_in(self, _event):
        self.cancel()

    def _on_focus_out(self, _event):
        if self.is_active():
            self.schedule(self.delay_focusout_ms)

    def _on_release(self, event):
        if not self.is_active():
            return

        w = event.widget

        # Si clic fue dentro de widgets “exentos” (Detalle/Refrescar/etc.), no desmarcar
        for ex in self.exempt_widgets:
            if _is_descendant(w, ex):
                self.cancel()
                return

        # Si clic fue dentro del tree: solo desmarcar si es "vacío" (no fila / heading / separador)
        if w == self.tree or _is_descendant(w, self.tree):
            x = event.x_root - self.tree.winfo_rootx()
            y = event.y_root - self.tree.winfo_rooty()

            row_id = self.tree.identify_row(y)
            region = self.tree.identify("region", x, y)

            if (not row_id) or (region in ("heading", "separator", "nothing")):
                self.schedule(self.delay_click_ms)
            else:
                self.cancel()
            return

        # Cualquier otro click (tabs, fondo, entry, etc.)
        self.schedule(self.delay_click_ms)
