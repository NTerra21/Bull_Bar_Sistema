# bull_bar/ui/utils/tree_sort.py
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Optional, Set, Any


@dataclass
class TreeSortController:
    tree: Any  # ttk.Treeview
    base_headings: Dict[str, str]
    numeric_cols: Set[str] = field(default_factory=set)

    # col -> 0 original, 1 asc, 2 desc
    sort_mode: Dict[str, int] = field(default_factory=dict)
    current_sort_col: Optional[str] = None
    current_sort_asc: bool = True
    original_order: list[str] = field(default_factory=list)

    def install(self) -> None:
        """Configura headings con flechas y comandos de sort."""
        for col in self.base_headings.keys():
            self.tree.heading(col, text=self._heading_text(col), command=lambda c=col: self.sort_by(c))

    def reset(self) -> None:
        """Resetea estado a neutro (↕)."""
        self.sort_mode = {k: 0 for k in self.base_headings.keys()}
        self.current_sort_col = None
        self.current_sort_asc = True
        self.install()

    def set_original_order(self) -> None:
        """Guarda el orden actual del tree como 'original'."""
        self.original_order = list(self.tree.get_children(""))

    def sort_by(self, col: str) -> None:
        """Ciclo: original -> asc -> desc -> original."""
        if self.current_sort_col != col:
            self.sort_mode = {k: 0 for k in self.base_headings.keys()}
            mode = 1
        else:
            mode = (self.sort_mode.get(col, 0) + 1) % 3

        self.sort_mode[col] = mode

        # Volver a original
        if mode == 0:
            self._restore_original_order()
            self.current_sort_col = None
            self.current_sort_asc = True
            self.install()
            return

        asc = (mode == 1)
        self._apply_sort(col=col, asc=asc)

        self.current_sort_col = col
        self.current_sort_asc = asc
        self.install()

    # ---------------- internal ----------------
    def _heading_text(self, col: str) -> str:
        base = self.base_headings.get(col, col)
        icon = "↕"
        if self.current_sort_col == col:
            icon = "▲" if self.current_sort_asc else "▼"
        return f"{base} {icon}"

    def _restore_original_order(self) -> None:
        current = set(self.tree.get_children(""))
        ordered = [iid for iid in self.original_order if iid in current]
        ordered += [iid for iid in current if iid not in ordered]
        for i, iid in enumerate(ordered):
            self.tree.move(iid, "", i)

    def _as_float(self, v) -> Optional[float]:
        try:
            if v is None:
                return None
            t = str(v).strip()
            if t == "" or t.upper() == "N/A":
                return None
            return float(t)
        except Exception:
            return None

    def _apply_sort(self, col: str, asc: bool) -> None:
        items = list(self.tree.get_children(""))
        col_idx = self.tree["columns"].index(col)

        def key_func(item_id: str):
            vals = self.tree.item(item_id, "values")
            v = vals[col_idx] if col_idx < len(vals) else ""

            if col in self.numeric_cols:
                fv = self._as_float(v)
                return (1, 0.0) if fv is None else (0, fv)

            return "" if v is None else str(v).strip().lower()

        items.sort(key=key_func, reverse=not asc)
        for i, iid in enumerate(items):
            self.tree.move(iid, "", i)
