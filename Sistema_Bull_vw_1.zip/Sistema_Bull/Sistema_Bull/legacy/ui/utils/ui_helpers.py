"""
Helpers reutilizables para UI: formatos, colores, fechas, tablas.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Optional


def parse_ymd(s: str) -> Optional[date]:
    """Parsea fecha en formato YYYY-MM-DD."""
    s = (s or "").strip()
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return None


def format_date(d: Optional[date]) -> str:
    """Formatea fecha a string ISO."""
    if not d:
        return ""
    return d.isoformat()


def get_vencimiento_alert_color(venc_date: Optional[date]) -> tuple[str, str]:
    """
    Retorna (texto_alerta, tag_color) según días hasta vencimiento.
    - <= 90 días: rojo (alert3)
    - <= 180 días: naranja (alert6)
    - <= 270 días: amarillo (alert9)
    - > 270 días: blanco (ok)
    """
    if not venc_date:
        return ("OK", "ok")
    
    days = (venc_date - date.today()).days
    if days <= 90:
        return ("3m", "alert3")
    if days <= 180:
        return ("6m", "alert6")
    if days <= 270:
        return ("9m", "alert9")
    return ("OK", "ok")


def configure_vencimiento_tags(tree):
    """Configura tags de colores para alertas de vencimiento en un Treeview."""
    tree.tag_configure("alert3", background="#ffcccc")  # rojo suave
    tree.tag_configure("alert6", background="#ffd9b3")  # naranja suave
    tree.tag_configure("alert9", background="#fff2b3")  # amarillo suave
    tree.tag_configure("ok", background="#ffffff")
    tree.tag_configure("final", background="#e6e6e6")  # finalizado


def format_cantidad(cant: float, decimals: int = 2) -> str:
    """Formatea cantidad numérica."""
    try:
        return f"{float(cant):.{decimals}f}"
    except Exception:
        return "0.00"


def format_cantidad_entera(cant: float) -> str:
    """Formatea cantidad como entero."""
    try:
        return f"{int(float(cant))}"
    except Exception:
        return "0"

