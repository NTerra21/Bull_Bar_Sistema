import tkinter as tk
from tkinter import ttk, messagebox
from bull_bar.stock.adjustment import StockAdjustmentService

class AjusteStockTab:
    def __init__(self, notebook, ctx):
        self.ctx = ctx
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="Ajuste Stock")

        ttk.Label(frame, text="Producto (codigo)").grid(row=0, column=0, sticky="w")
        self.codigo = ttk.Entry(frame); self.codigo.grid(row=0, column=1, sticky="ew")

        ttk.Label(frame, text="Cantidad (+/-)").grid(row=1, column=0, sticky="w")
        self.cantidad = ttk.Entry(frame); self.cantidad.grid(row=1, column=1, sticky="ew")

        ttk.Label(frame, text="Motivo").grid(row=2, column=0, sticky="w")
        self.motivo = ttk.Entry(frame); self.motivo.grid(row=2, column=1, sticky="ew")

        btn = ttk.Button(frame, text="Aplicar ajuste", command=self.aplicar)
        btn.grid(row=3, column=0, columnspan=2, pady=8)
        frame.columnconfigure(1, weight=1)

        self.adjust_svc = StockAdjustmentService(self.ctx["ledger"], db_path=self.ctx.get("db_path"))

    def aplicar(self):
        codigo = self.codigo.get().strip()
        try:
            cantidad = float(self.cantidad.get())
        except Exception:
            messagebox.showerror("Error", "Cantidad inválida")
            return
        prod = self.ctx["products"].get(codigo)
        if not prod:
            messagebox.showerror("Error", "Producto no encontrado")
            return
        motivo = self.motivo.get().strip() or "Ajuste manual"
        try:
            self.adjust_svc.apply_adjustment(
                self.ctx["depo"].id, 
                prod.id, 
                cantidad, 
                motivo,
                usuario="Usuario"  # TODO: obtener usuario real del sistema
            )
            messagebox.showinfo("OK", "Ajuste aplicado")
        except Exception as e:
            messagebox.showerror("Error ajuste", str(e))
