import tkinter as tk
from tkinter import ttk, messagebox
from bull_bar.core.models import DocumentoItem
from bull_bar.infra.sqlite_recetas import list_recetas, get_receta_items, get_producto_nombre
from uuid import uuid4
from datetime import datetime

class ProduccionTab:
    def __init__(self, notebook, ctx):
        self.ctx = ctx
        self.frame = ttk.Frame(notebook)
        notebook.add(self.frame, text="Producción")

        # Inline receta selector (no modal)
        ttk.Label(self.frame, text="Seleccionar receta:").grid(row=0, column=0, sticky="w")
        self.receta_cb = ttk.Combobox(self.frame, values=list_recetas(ctx["db_path"]))
        self.receta_cb.grid(row=0, column=1, sticky="ew")
        self.receta_cb.bind("<<ComboboxSelected>>", lambda e: self.on_receta_selected())

        # mezcla opciones rápidas + campo libre
        ttk.Label(self.frame, text="Mezcla (kg):").grid(row=1, column=0, sticky="w")
        btn_frame = ttk.Frame(self.frame); btn_frame.grid(row=1, column=1, sticky="w")
        for val in (10,20,30,40):
            ttk.Button(btn_frame, text=str(val), command=lambda v=val: self.set_mezcla(v)).pack(side="left", padx=2)
        self.mezcla_entry = ttk.Entry(self.frame, width=8); self.mezcla_entry.grid(row=1, column=2, sticky="w")
        self.mezcla_entry.insert(0, "10")

        # checklist area (hidden until receta seleccionada)
        self.check_frame = ttk.LabelFrame(self.frame, text="Checklist de insumos (ordenados)")
        self.check_frame.grid(row=2, column=0, columnspan=3, sticky="ew", pady=6)
        self.check_vars = []
        self.current_items = []

        # producción final: aparece después de presionar "Preparar producción"
        self.final_frame = ttk.LabelFrame(self.frame, text="Finalizar producción")
        self.final_frame.grid(row=3, column=0, columnspan=3, sticky="ew", pady=6)
        ttk.Label(self.final_frame, text="Producto terminado (codigo)").grid(row=0, column=0, sticky="w")
        self.prod_entry = ttk.Entry(self.final_frame); self.prod_entry.grid(row=0, column=1, sticky="ew")
        ttk.Label(self.final_frame, text="Cantidad terminado").grid(row=1, column=0, sticky="w")
        self.cant_prod = ttk.Entry(self.final_frame); self.cant_prod.grid(row=1, column=1, sticky="ew")
        ttk.Label(self.final_frame, text="Lote").grid(row=2, column=0, sticky="w")
        self.lote_entry = ttk.Entry(self.final_frame); self.lote_entry.grid(row=2, column=1, sticky="ew")
        ttk.Label(self.final_frame, text="Vencimiento (YYYY-MM-DD)").grid(row=3, column=0, sticky="w")
        self.venc_entry = ttk.Entry(self.final_frame); self.venc_entry.grid(row=3, column=1, sticky="ew")
        ttk.Button(self.final_frame, text="Registrar producción", command=self.registrar_produccion).grid(row=4, column=0, columnspan=2, pady=8)
        self.final_frame.columnconfigure(1, weight=1)
        self.final_frame.grid_remove()  # ocultar hasta que corresponda

        self.frame.columnconfigure(1, weight=1)

    def set_mezcla(self, v):
        self.mezcla_entry.delete(0, "end"); self.mezcla_entry.insert(0, str(v))
        # si ya hay receta seleccionada, recalcular checklist quantities display
        if self.receta_cb.get():
            self.build_checklist_for_receta(self.receta_cb.get())

    def on_receta_selected(self):
        receta = self.receta_cb.get()
        if receta:
            self.build_checklist_for_receta(receta)

    def build_checklist_for_receta(self, receta):
        # limpiar
        for w in self.check_frame.winfo_children():
            w.destroy()
        self.check_vars = []
        items = get_receta_items(self.ctx["db_path"], receta)
        # heurística: líquidos/cremas al final
        def is_solid(it):
            c = (it.get("producto_codigo") or "").upper()
            return not any(k in c for k in ("LIQ", "CREM", "CREMA", "ACEITE", "LECHE"))
        items_sorted = sorted(items, key=lambda it: 0 if is_solid(it) else 1)
        self.current_items = items_sorted
        mezcla = 0.0
        try:
            mezcla = float(self.mezcla_entry.get())
        except Exception:
            mezcla = 0.0
        for idx, it in enumerate(items_sorted):
            porcentaje = float(it.get("porcentaje", 0))
            cantidad_calc = mezcla * (porcentaje / 100.0)
            var = tk.BooleanVar(value=False)
            cb = ttk.Checkbutton(self.check_frame, text=f"{it.get('producto_codigo')} - {porcentaje}% -> {cantidad_calc:.3f}", variable=var)
            cb.grid(row=idx, column=0, sticky="w", padx=4, pady=2)
            self.check_vars.append((var, it))
        # una vez checklist armado, mostrar final_frame para completar datos de producto terminado
        self.final_frame.grid()

    def registrar_produccion(self):
        receta = self.receta_cb.get()
        if not receta:
            messagebox.showerror("Error", "Seleccione receta")
            return
        try:
            mezcla = float(self.mezcla_entry.get())
        except Exception:
            messagebox.showerror("Error", "Mezcla inválida"); return
        consumos = []
        for it in self.current_items:
            codigo = it.get("producto_codigo")
            porcentaje = float(it.get("porcentaje", 0))
            prod_obj = self.ctx["products"].get(codigo)
            if not prod_obj:
                prod_obj = self._create_temp_producto(codigo)
            cantidad = mezcla * (porcentaje / 100.0)
            consumos.append(DocumentoItem(producto_id=prod_obj.id, descripcion=prod_obj.nombre, cantidad=cantidad))
        terminado_codigo = self.prod_entry.get().strip()
        try:
            terminado_cant = float(self.cant_prod.get())
        except Exception:
            messagebox.showerror("Error", "Cantidad producto terminado inválida"); return
        prod_final = self.ctx["products"].get(terminado_codigo) or self._create_temp_producto(terminado_codigo, unidad="u")
        # aquí podríamos usar lote/venc; por ahora los incluimos en mensaje
        lote = self.lote_entry.get().strip()
        venc = self.venc_entry.get().strip()
        try:
            numero = f"P-{receta}-{int(mezcla)}-{uuid4().hex[:4]}"
            self.ctx["production_service"].registrar_remito_produccion_rapido(
                numero=numero,
                deposito_id=self.ctx["depo"].id,
                consumos=consumos,
                producto_final=DocumentoItem(producto_id=prod_final.id, descripcion=prod_final.nombre, cantidad=terminado_cant),
            )
            messagebox.showinfo("OK", f"Producción registrada: {numero}\nLote: {lote} Venc: {venc}")
            # limpiar UI
            self.receta_cb.set("")
            for _ in range(len(self.check_frame.winfo_children())): pass
            self.check_frame.destroy()
            self.check_frame = ttk.LabelFrame(self.frame, text="Checklist de insumos (ordenados)")
            self.check_frame.grid(row=2, column=0, columnspan=3, sticky="ew", pady=6)
            self.final_frame.grid_remove()
        except Exception as e:
            messagebox.showerror("Error producción", str(e))

    def _create_temp_producto(self, codigo, unidad="kg"):
        from bull_bar.core.models import Producto
        p = Producto(id=str(uuid4()), codigo=codigo, nombre=get_producto_nombre(self.ctx["db_path"], codigo) or codigo, unidad_medida=unidad)
        self.ctx["products"][codigo] = p
        return p
