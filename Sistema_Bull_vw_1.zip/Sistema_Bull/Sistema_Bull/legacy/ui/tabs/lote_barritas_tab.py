from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date, datetime

from bull_bar.infra.sqlite_barritas import list_lotes, upsert_lote, delete_lote
from bull_bar.infra.sqlite_recetas import get_receta_items, get_producto_nombre
from bull_bar.ui.utils.ui_helpers import parse_ymd, get_vencimiento_alert_color, configure_vencimiento_tags


class LoteBarritasTab(ttk.Frame):
    """Listado por lote. Alterna Activos / Finalizados."""

    def __init__(self, notebook, ctx):
        super().__init__(notebook)
        self.ctx = ctx

        self._sort_col = None
        self._sort_desc = False

        self.view_mode = tk.StringVar(value="ACTIVOS")  # ACTIVOS | FINALIZADOS

        self._build_ui()
        self.refresh()

    def set_sku_filter(self, sku: str):
        self.search.delete(0, "end")
        if sku:
            self.search.insert(0, sku)
        self.refresh()

    def _build_ui(self):
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=8)

        ttk.Label(top, text="Buscar:").pack(side="left")
        self.search = ttk.Entry(top)
        self.search.pack(side="left", fill="x", expand=True, padx=(6, 10))
        self.search.bind("<KeyRelease>", lambda e: self.refresh())

        # Toggle Activos / Finalizados
        self.view_mode = tk.StringVar(value="ACTIVOS")  # ACTIVOS | FINALIZADOS
        
        toggle_frame = ttk.Frame(self)
        toggle_frame.pack(fill="x", padx=8, pady=(0, 6))
        
        ttk.Radiobutton(
            toggle_frame,
            text="Activos",
            variable=self.view_mode,
            value="ACTIVOS",
            command=self.refresh
        ).pack(side="left", padx=(0, 10))
        
        ttk.Radiobutton(
            toggle_frame,
            text="Finalizados",
            variable=self.view_mode,
            value="FINALIZADOS",
            command=self.refresh
        ).pack(side="left")

        # Verificar permisos
        from bull_bar.infra.auth import tiene_permiso
        self.usuario = self.ctx.get("usuario_actual", {})
        self.puede_editar = tiene_permiso(self.usuario, "editar", "lotes")
        
        if self.puede_editar:
            ttk.Button(top, text="Agregar lote", command=self._add_lote).pack(side="right", padx=(6, 0))
            ttk.Button(top, text="Editar", command=self._edit_selected).pack(side="right")
        ttk.Button(top, text="Refrescar", command=self.refresh).pack(side="right", padx=(0, 6))

        legend = ttk.Frame(self)
        legend.pack(fill="x", padx=8, pady=(0, 6))
        ttk.Label(legend, text="Alertas por vencimiento:").pack(side="left")
        self._legend_chip(legend, "<= 3m", "#ffcccc").pack(side="left", padx=6)
        self._legend_chip(legend, "<= 6m", "#ffd9b3").pack(side="left", padx=6)
        self._legend_chip(legend, "<= 9m", "#fff2b3").pack(side="left", padx=6)
        self._legend_chip(legend, "> 9m", "#ffffff").pack(side="left", padx=6)

        cols = (
            "lote_id",
            "sku",
            "nombre",
            "cantidad_total",
            "cantidad_vendida",
            "cantidad_disponible",
            "fecha_vencimiento",
            "estado",
            "deposito",
        )
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")

        self._set_heading("lote_id", "Lote")
        self._set_heading("sku", "SKU")
        self._set_heading("nombre", "Producto")
        self._set_heading("cantidad_total", "Producidas")
        self._set_heading("cantidad_vendida", "Vendidas")
        self._set_heading("cantidad_disponible", "Disponibles")
        self._set_heading("fecha_vencimiento", "Vencimiento")
        self._set_heading("estado", "Estado")
        self._set_heading("deposito", "Depósito")

        self.tree.column("lote_id", width=150, stretch=False)
        self.tree.column("sku", width=140, stretch=False)
        self.tree.column("nombre", width=280, stretch=True)
        self.tree.column("cantidad_total", width=100, anchor="e", stretch=False)
        self.tree.column("cantidad_vendida", width=100, anchor="e", stretch=False)
        self.tree.column("cantidad_disponible", width=110, anchor="e", stretch=False)
        self.tree.column("fecha_vencimiento", width=120, stretch=False)
        self.tree.column("estado", width=140, stretch=False)
        self.tree.column("deposito", width=160, stretch=False)

        self.tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        if self.puede_editar:
            self.tree.bind("<Double-1>", lambda e: self._edit_selected())
            self.tree.bind("<Delete>", lambda e: self._delete_selected())

        # Configurar tags de colores usando helper
        configure_vencimiento_tags(self.tree)

        bottom = ttk.Frame(self)
        bottom.pack(fill="x", padx=8, pady=(0, 8))
        if self.puede_editar:
            ttk.Label(bottom, text="Tip: Doble click para editar. DEL para borrar.", foreground="#666").pack(side="left")
            ttk.Button(bottom, text="Borrar lote", command=self._delete_selected).pack(side="right")
        else:
            ttk.Label(bottom, text="Solo lectura - No tiene permisos para editar", foreground="gray").pack(side="left")

    def _legend_chip(self, parent, text: str, bg: str):
        lbl = tk.Label(parent, text=f"  {text}  ")
        lbl.configure(background=bg, borderwidth=1, relief="solid")
        return lbl

    def _set_heading(self, col: str, text: str):
        self.tree.heading(col, text=text, command=lambda c=col: self._toggle_sort(c))

    def _toggle_sort(self, col: str):
        if self._sort_col == col:
            self._sort_desc = not self._sort_desc
        else:
            self._sort_col = col
            self._sort_desc = False
        self.refresh()

    def _is_finalizado(self, estado: str, disponible: float, total: float = None) -> bool:
        """Determina si un lote está finalizado.
        
        Un lote NO está finalizado si:
        - cantidad_total es 0 o None (aún no se completó la producción)
        - cantidad_disponible > 0 (aún hay stock disponible)
        
        Un lote SÍ está finalizado si:
        - cantidad_disponible <= 0 Y cantidad_total > 0 (se produjo pero ya se vendió todo)
        - estado es VENDIDO_TOTAL, AGOTADO, o FINALIZADO
        """
        # Si total es 0 o None, NO está finalizado (aún no se completó la producción)
        if total is None or total <= 0:
            return False
        
        est = (estado or "").upper().strip()
        # Solo considerar finalizado si hay cantidad_total > 0 y (disponible <= 0 o estado finalizado)
        return (disponible <= 0.00001 and total > 0) or est in {"VENDIDO_TOTAL", "AGOTADO", "FINALIZADO"}

    def _row_tag_for(self, venc: str, estado: str, disponible: float, total: float = None) -> str:
        """Determina el tag de color según estado y vencimiento."""
        if self._is_finalizado(estado, disponible, total):
            return "final"
        d = parse_ymd(venc)
        _, tag = get_vencimiento_alert_color(d)
        return tag
    
    def _get_estado_lote(self, disponible: float, total: float) -> str:
        """Calcula el estado del lote: vendidas todas/parcial/sin vender."""
        if disponible <= 0.00001:
            return "Vendidas todas"
        if disponible < total:
            return "Parcial"
        return "Sin vender"

    def refresh(self):
        q = self.search.get().strip()
        rows = list_lotes(self.ctx["db_path"], q=q)

        # Filtrar por modo (Activos/Finalizados)
        mode = self.view_mode.get()
        filtered = []
        for r in rows:
            disp = float(r.get("cantidad_disponible") or 0)
            total = float(r.get("cantidad_total") or 0)
            fin = self._is_finalizado(r.get("estado"), disp, total)
            if mode == "ACTIVOS" and not fin:
                filtered.append(r)
            elif mode == "FINALIZADOS" and fin:
                filtered.append(r)
        rows = filtered

        if self._sort_col:
            key = self._sort_col

            def k(r):
                v = r.get(key)
                if key in {"cantidad_total", "cantidad_vendida", "cantidad_disponible"}:
                    try:
                        return float(v)
                    except Exception:
                        return 0.0
                if key == "fecha_vencimiento":
                    d = _parse_ymd(v or "")
                    return d or date.max
                return str(v or "").upper()

            rows = sorted(rows, key=k, reverse=self._sort_desc)

        for iid in self.tree.get_children():
            self.tree.delete(iid)

        for r in rows:
            disp = float(r.get("cantidad_disponible") or 0)
            total_raw = r.get("cantidad_total")
            # Si cantidad_total es None o 0, mostrar "Vacio" en lugar de "0"
            if total_raw is None or float(total_raw or 0) <= 0:
                total_display = "Vacio"
                total = 0.0
            else:
                total = float(total_raw)
                total_display = f"{total:.0f}"
            
            estado_calc = self._get_estado_lote(disp, total)
            tag = self._row_tag_for(r.get("fecha_vencimiento"), r.get("estado"), disp, total)
            self.tree.insert(
                "",
                "end",
                values=(
                    r.get("lote_id"),
                    r.get("sku"),
                    r.get("nombre"),
                    total_display,
                    f"{float(r.get('cantidad_vendida') or 0):.0f}",
                    f"{disp:.0f}",
                    r.get("fecha_vencimiento"),
                    estado_calc,
                    r.get("deposito"),
                ),
                tags=(tag,),
            )

        self._render_sort_arrows()

    def _render_sort_arrows(self):
        base = {
            "lote_id": "Lote",
            "sku": "SKU",
            "nombre": "Producto",
            "cantidad_total": "Producidas",
            "cantidad_vendida": "Vendidas",
            "cantidad_disponible": "Disponibles",
            "fecha_vencimiento": "Vencimiento",
            "estado": "Estado",
            "deposito": "Depósito",
        }
        for col, text in base.items():
            arrow = ""
            if self._sort_col == col:
                arrow = " ▼" if self._sort_desc else " ▲"
            self.tree.heading(col, text=text + arrow)

    def _selected_lote_id(self):
        sel = self.tree.selection()
        if not sel:
            return None
        vals = self.tree.item(sel[0], "values")
        return vals[0] if vals else None

    def _add_lote(self):
        if not self.puede_editar:
            from tkinter import messagebox
            messagebox.showwarning("Sin permisos", "No tiene permisos para agregar lotes")
            return
        self._open_editor(lote_id="")

    def _edit_selected(self):
        if not self.puede_editar:
            from tkinter import messagebox
            messagebox.showwarning("Sin permisos", "No tiene permisos para editar lotes")
            return
        lote_id = self._selected_lote_id()
        if not lote_id:
            return
        self._open_editor(lote_id=lote_id)

    def _delete_selected(self):
        if not self.puede_editar:
            from tkinter import messagebox
            messagebox.showwarning("Sin permisos", "No tiene permisos para borrar lotes")
            return
        lote_id = self._selected_lote_id()
        if not lote_id:
            return
        if not messagebox.askyesno("Confirmar", f"¿Borrar lote {lote_id}?"):
            return
            try:
                if not delete_lote(self.ctx["db_path"], lote_id):
                    messagebox.showerror("Error", "No se pudo borrar")
                    return
                self.refresh()
            except Exception as e:
                from bull_bar.infra.error_logger import log_error
                log_error(e, context="Borrando lote de barritas", extra_info={"lote_id": lote_id})
                messagebox.showerror("Error", f"Error al borrar lote:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")

    def _open_editor(self, *, lote_id: str):
        current = None
        if lote_id:
            for r in list_lotes(self.ctx["db_path"], q=lote_id):
                if r.get("lote_id") == lote_id:
                    current = r
                    break

        win = tk.Toplevel(self)
        win.title("Editar lote" if lote_id else "Nuevo lote")
        win.transient(self)

        frm = ttk.Frame(win, padding=10)
        frm.pack(fill="both", expand=True)
        frm.columnconfigure(1, weight=1)

        def row(r, label, widget):
            ttk.Label(frm, text=label).grid(row=r, column=0, sticky="e", padx=(0, 8), pady=4)
            widget.grid(row=r, column=1, sticky="we", pady=4)
            return widget

        v_lote = tk.StringVar(value=(current.get("lote_id") if current else lote_id) or "")
        v_sku = tk.StringVar(value=(current.get("sku") if current else ""))
        v_nombre = tk.StringVar(value=(current.get("nombre") if current else ""))
        v_total = tk.StringVar(value=(str(int(current.get("cantidad_total"))) if current else ""))
        v_vendida = tk.StringVar(value=(str(int(current.get("cantidad_vendida"))) if current else "0"))
        v_prod = tk.StringVar(value=(current.get("fecha_produccion") if current else ""))
        v_venc = tk.StringVar(value=(current.get("fecha_vencimiento") if current else ""))
        v_depo = tk.StringVar(value=(current.get("deposito") if current else self.ctx["depo"].nombre))
        v_estado = tk.StringVar(value=(current.get("estado") if current else "DISPONIBLE"))
        v_notas = tk.StringVar(value=(current.get("notas") if current else ""))
        mezcla_kg = current.get("mezcla_kg") if current else None

        # Campos readonly si no puede editar
        readonly_state = "readonly" if not self.puede_editar else "normal"
        
        e_lote = row(0, "Lote ID:", ttk.Entry(frm, textvariable=v_lote, state=readonly_state))
        e_sku = row(1, "SKU:", ttk.Entry(frm, textvariable=v_sku, state=readonly_state))
        row(2, "Nombre:", ttk.Entry(frm, textvariable=v_nombre, state=readonly_state))
        row(3, "Cantidad total:", ttk.Entry(frm, textvariable=v_total, state=readonly_state))
        row(4, "Cantidad vendida:", ttk.Entry(frm, textvariable=v_vendida, state=readonly_state))
        row(5, "Fecha producción (YYYY-MM-DD):", ttk.Entry(frm, textvariable=v_prod, state=readonly_state))
        row(6, "Fecha vencimiento (YYYY-MM-DD):", ttk.Entry(frm, textvariable=v_venc, state=readonly_state))
        row(7, "Depósito/Ubicación:", ttk.Entry(frm, textvariable=v_depo, state=readonly_state))

        estados = ["EN_PRODUCCION", "DISPONIBLE", "BLOQUEADO", "VENDIDO_TOTAL", "FINALIZADO"]
        cb = ttk.Combobox(frm, textvariable=v_estado, values=estados, state=readonly_state)
        row(8, "Estado:", cb)

        row(9, "Notas:", ttk.Entry(frm, textvariable=v_notas, state=readonly_state))
        
        # Mostrar cantidad de mezcla usada (solo lectura, informativo)
        if mezcla_kg is not None:
            v_mezcla = tk.StringVar(value=f"{mezcla_kg:.2f} kg")
            row(10, "Cantidad de Mezcla usada:", ttk.Entry(frm, textvariable=v_mezcla, state="readonly"))
            
            # Botón para ver insumos (solo si hay mezcla y SKU)
            if v_sku.get().strip():
                btn_insumos = ttk.Button(
                    frm,
                    text="Ver insumos de la mezcla",
                    command=lambda: self._mostrar_insumos_mezcla(v_sku.get().strip(), mezcla_kg, win)
                )
                btn_insumos.grid(row=11, column=0, columnspan=2, sticky="w", pady=(5, 0))
                row_num = 12
            else:
                row_num = 11
        else:
            row_num = 10

        def save():
            if not self.puede_editar:
                messagebox.showwarning("Sin permisos", "No tiene permisos para guardar lotes")
                return
            
            lid = v_lote.get().strip()
            sku = v_sku.get().strip()
            if not lid or not sku:
                messagebox.showerror("Error", "Lote ID y SKU son obligatorios")
                return
            try:
                total = float(v_total.get().strip() or 0)
                vend = float(v_vendida.get().strip() or 0)
            except Exception:
                messagebox.showerror("Error", "Cantidad inválida")
                return

            if v_prod.get().strip() and not _parse_ymd(v_prod.get()):
                messagebox.showerror("Error", "Fecha producción inválida (YYYY-MM-DD)")
                return
            if v_venc.get().strip() and not _parse_ymd(v_venc.get()):
                messagebox.showerror("Error", "Fecha vencimiento inválida (YYYY-MM-DD)")
                return

            disp = total - vend
            try:
                # Guardar estado anterior para auditoría (si es edición)
                estado_anterior = None
                if lote_id and current:
                    estado_anterior = {
                        "cantidad_total": current.get("cantidad_total", 0),
                        "cantidad_vendida": current.get("cantidad_vendida", 0),
                        "fecha_vencimiento": current.get("fecha_vencimiento", ""),
                        "estado": current.get("estado", ""),
                        "notas": current.get("notas", "")
                    }
                
                ok = upsert_lote(
                    self.ctx["db_path"],
                    lote_id=lid,
                    sku=sku,
                    nombre=v_nombre.get().strip(),
                    cantidad_total=total,
                    cantidad_vendida=vend,
                    cantidad_disponible=disp,
                    fecha_produccion=v_prod.get().strip(),
                    fecha_vencimiento=v_venc.get().strip(),
                    deposito=v_depo.get().strip(),
                    estado=v_estado.get().strip() or "DISPONIBLE",
                    notas=v_notas.get().strip(),
                )
                if not ok:
                    messagebox.showerror("Error", "No se pudo guardar")
                    return
                
                # Registrar auditoría
                try:
                    from bull_bar.infra.audit import log_audit
                    usuario_actual = self.ctx.get("usuario_actual", {})
                    username = usuario_actual.get("username", "USUARIO")
                    
                    estado_nuevo = {
                        "cantidad_total": total,
                        "cantidad_vendida": vend,
                        "fecha_vencimiento": v_venc.get().strip(),
                        "estado": v_estado.get().strip() or "DISPONIBLE",
                        "notas": v_notas.get().strip()
                    }
                    
                    accion = "LOTE_EDITADO" if lote_id and current else "LOTE_CREADO"
                    log_audit(
                        db_path=self.ctx["db_path"],
                        usuario=username,
                        accion=accion,
                        modulo="LOTES",
                        entidad_id=lid,
                        entidad_tipo="LOTE",
                        antes=estado_anterior,
                        despues=estado_nuevo,
                        metadata={"sku": sku, "nombre": v_nombre.get().strip()}
                    )
                except Exception as e:
                    print(f"[DEBUG] Error registrando auditoría: {e}")
                
                messagebox.showinfo("OK", "Lote guardado")
                win.destroy()  # Cerrar ventana automáticamente
                self.refresh()
            except Exception as e:
                from bull_bar.infra.error_logger import log_error
                log_error(e, context="Guardando lote de barritas", 
                         extra_info={"lote_id": lid, "sku": sku, "cantidad_total": total})
                messagebox.showerror("Error", f"Error al guardar lote:\n{str(e)}\n\nRevisa error_log.txt para más detalles.")

        btns = ttk.Frame(frm)
        btns.grid(row=row_num, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(btns, text="Guardar", command=save).pack(side="right", padx=(6, 0))
        ttk.Button(btns, text="Cancelar", command=win.destroy).pack(side="right")

        (e_lote if not lote_id else e_sku).focus()
        win.grab_set()
        win.wait_window(win)
    
    def _mostrar_insumos_mezcla(self, receta_codigo: str, mezcla_kg: float, parent_window):
        """Muestra una ventana con los insumos utilizados en la mezcla del lote."""
        if not receta_codigo or not mezcla_kg or mezcla_kg <= 0:
            messagebox.showwarning("Información incompleta", "No hay información de mezcla disponible para este lote.")
            return
        
        try:
            # Obtener items de la receta
            items_receta = get_receta_items(self.ctx["db_path"], receta_codigo)
            if not items_receta:
                messagebox.showwarning("Receta no encontrada", f"No se encontraron insumos para la receta {receta_codigo}.")
                return
            
            # Crear ventana
            win = tk.Toplevel(parent_window)
            win.title(f"Insumos de la mezcla - {receta_codigo}")
            win.transient(parent_window)
            win.geometry("700x500")
            
            # Frame principal
            main_frame = ttk.Frame(win, padding=10)
            main_frame.pack(fill="both", expand=True)
            
            # Título
            ttk.Label(
                main_frame,
                text=f"Insumos utilizados para {mezcla_kg:.2f} kg de mezcla",
                font=("Segoe UI", 11, "bold")
            ).pack(anchor="w", pady=(0, 10))
            
            # Treeview para mostrar insumos
            cols = ("codigo", "nombre", "cantidad", "unidad", "porcentaje")
            tree = ttk.Treeview(main_frame, columns=cols, show="headings", selectmode="browse")
            
            tree.heading("codigo", text="Código")
            tree.heading("nombre", text="Nombre")
            tree.heading("cantidad", text="Cantidad")
            tree.heading("unidad", text="Unidad")
            tree.heading("porcentaje", text="%")
            
            tree.column("codigo", width=120, stretch=False)
            tree.column("nombre", width=250, stretch=True)
            tree.column("cantidad", width=120, anchor="e", stretch=False)
            tree.column("unidad", width=80, stretch=False)
            tree.column("porcentaje", width=80, anchor="e", stretch=False)
            
            # Scrollbar
            scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=scrollbar.set)
            
            # Llenar treeview con insumos
            for item in items_receta:
                producto_codigo = item.get("producto_codigo", "")
                porcentaje = float(item.get("porcentaje", 0))
                
                # Calcular cantidad utilizada según la mezcla
                cantidad_kg = (mezcla_kg * porcentaje) / 100.0
                
                # Obtener nombre del producto
                nombre_producto = get_producto_nombre(self.ctx["db_path"], producto_codigo) or producto_codigo
                
                tree.insert("", "end", values=(
                    producto_codigo,
                    nombre_producto,
                    f"{cantidad_kg:.3f}",
                    "kg",
                    f"{porcentaje:.2f}%"
                ))
            
            tree.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            
            # Botón cerrar
            btn_frame = ttk.Frame(win, padding=10)
            btn_frame.pack(fill="x")
            ttk.Button(btn_frame, text="Cerrar", command=win.destroy).pack(side="right")
            
            # Centrar ventana
            win.update_idletasks()
            x = (win.winfo_screenwidth() // 2) - (win.winfo_width() // 2)
            y = (win.winfo_screenheight() // 2) - (win.winfo_height() // 2)
            win.geometry(f"+{x}+{y}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al mostrar insumos:\n{str(e)}")
            import traceback
            traceback.print_exc()
