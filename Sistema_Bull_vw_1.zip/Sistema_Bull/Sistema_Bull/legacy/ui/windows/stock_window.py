import tkinter as tk
from tkinter import ttk

# Importaciones con manejo de errores
try:
    from bull_bar.ui.tabs.stock_tab import StockTab
except ImportError as e:
    raise ImportError(f"Error importando StockTab: {e}")

try:
    from bull_bar.ui.tabs.stock_barritas_resumen_tab import StockBarritasResumenTab
except ImportError as e:
    raise ImportError(f"Error importando StockBarritasResumenTab: {e}")

try:
    from bull_bar.ui.tabs.lote_barritas_tab import LoteBarritasTab
except ImportError as e:
    raise ImportError(f"Error importando LoteBarritasTab: {e}")

try:
    from bull_bar.ui.tabs.ajuste_stock_tab_integrado import AjusteStockTabIntegrado
except ImportError as e:
    raise ImportError(f"Error importando AjusteStockTabIntegrado: {e}")

try:
    from bull_bar.ui.tabs.movimientos_stock_tab import MovimientosStockTab
except ImportError as e:
    raise ImportError(f"Error importando MovimientosStockTab: {e}")


class StockWindow(tk.Toplevel):
    def __init__(self, master, ctx):
        super().__init__(master)
        self.ctx = ctx
        self.title("Bull Bar - Stock")
        self.geometry("1100x720")
        self.minsize(980, 560)
        self.transient(master)

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=6, pady=6)

        # 1) Stock Insumos
        insumos_tab = StockTab(nb, ctx)               # StockTab crea y agrega su propio frame
        # StockTab ya agrega el frame al notebook con texto "Stock", cambiar a "Stock Insumos"
        try:
            # Usar el frame directamente para cambiar el texto del tab
            nb.tab(insumos_tab.frame, text="Stock Insumos")
        except Exception:
            pass

        # 2) Stock Barritas (resumen por SKU)
        resumen = StockBarritasResumenTab(nb, ctx)
        nb.add(resumen, text="Stock Barritas")

        # 3) Lote Barritas (por lote + alternar activos/finalizados)
        lotes = LoteBarritasTab(nb, ctx)
        nb.add(lotes, text="Lote Barritas")
        
        # 4) Movimientos (Compras/Ventas) - solo si tiene permiso
        from bull_bar.infra.auth import tiene_permiso
        usuario = ctx.get("usuario_actual", {})
        
        if tiene_permiso(usuario, "ver", "compras") or tiene_permiso(usuario, "ver", "ventas"):
            movimientos = MovimientosStockTab(nb, ctx)
            nb.add(movimientos, text="Compras/Ventas")
        
        # 5) Ajuste de Stock - solo si tiene permiso
        if tiene_permiso(usuario, "crear", "ajuste_stock"):
            ajuste = AjusteStockTabIntegrado(nb, ctx)
            nb.add(ajuste, text="Ajuste Stock")

        # Doble click en resumen -> filtra lotes por SKU y cambia de pestaña
        resumen.set_open_lotes_callback(lambda sku: (lotes.set_sku_filter(sku), nb.select(lotes)))

        self.lift()
        try:
            self.focus_force()
        except Exception:
            pass
