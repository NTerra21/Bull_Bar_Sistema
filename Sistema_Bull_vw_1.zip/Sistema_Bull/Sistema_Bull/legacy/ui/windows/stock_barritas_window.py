from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date, datetime

from bull_bar.infra.sqlite_barritas import list_lotes, upsert_lote, delete_lote


def _parse_ymd(s: str):
    s = (s or "").strip()
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return None


class StockBarritasWindow(tk.Toplevel):
    """Ventana: Stock de Barritas por Lote."""

    def __init__(self, master, ctx):
        super().__init__(master)
        self.ctx = ctx
        self.title("Bull Bar - Stock Barritas")
        self.geometry("1100x720")
        self.minsize(980, 560)
        self.transient(master)

        self._sort_col = None
        self._sort_desc = False

        self._build_ui()
        self.refresh()

    def _build_ui(self):
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=8)

        ttk.Label(top, text="Buscar:").pack(side="left")
        self.search = ttk.Entry(top)
        self.search.pack(side="left", fill="x", expand=True, padx=(6, 10))
        self.search.bind("<KeyRelease>", lambda e: self.refresh())

        ttk.Button(top, text="Agregar lote", command=self._add_lote).pack(side="right", padx=(6, 0))
        ttk.Button(top, text="Editar", command=self._edit_selected).pack(side="right")
        ttk.Button(top, text="Refrescar", command=self.refresh).pack(side="right", padx=(0, 6))

        legend = ttk.Frame(self)
        legend.pack(fill="x", padx=8, pady=(0, 6))
        ttk.Label(legend, text="Alertas por vencimiento:").pack(side="left")
        self._legend_chip(legend, "<= 3m", "alert3").pack(side="left", padx=6)
        self._legend_chip(legend, "<= 6m", "alert6").pack(side="left", padx=6)
        self._legend_chip(legend, "<= 9m", "alert9").pack(side="left", padx=6)
        self._legend_chip(legend, "> 9m", "ok").pack(side="left", padx=6)

        cols = (
            "lote_id", "sku", "nombre",
            "cantidad_total", "cantidad_vendida", "cantidad_disponible",
            "fecha_vencimiento", "estado", "deposito",
        )
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")

        self._set_heading("lote_id", "Lote")
        self._set_heading("sku", "SKU")
        self._set_heading("nombre", "Producto")
        self._set_heading("cantidad_total", "Producidas")
        self._set_heading("cantidad_vendida", "Vendidas")
        self._set_heading("cantidad_disponible", "Disponibles")
        self._set_heading("fecha_vencimiento", "Vencimiento")
        self._set_heading("estado", "Estado")
        self._set_heading("deposito", "Depósito")

        self.tree.column("lote_id", width=150, stretch=False)
        self.tree.column("sku", width=140, stretch=False)
        self.tree.column("nombre", width=280, stretch=True)
        self.tree.column("cantidad_total", width=100, anchor="e", stretch=False)
        self.tree.column("cantidad_vendida", width=100, anchor="e", stretch=False)
        self.tree.column("cantidad_disponible", width=110, anchor="e", stretch=False)
        self.tree.column("fecha_vencimiento", width=120, stretch=False)
        self.tree.column("estado", width=140, stretch=False)
        self.tree.column("deposito", width=160, stretch=False)

        self.tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        self.tree.bind("<Double-1>", lambda e: self._edit_selected())
        self.tree.bind("<Delete>", lambda e: self._delete_selected())

        # tags (colores)
        self.tree.tag_configure("alert3", background="#ffcccc")   # rojo suave
        self.tree.tag_configure("alert6", background="#ffd9b3")   # naranja suave
        self.tree.tag_configure("alert9", background="#fff2b3")   # amarillo suave
        self.tree.tag_configure("ok", background="#ffffff")
        self.tree.tag_configure("soldout", background="#e6e6e6")

        bottom = ttk.Frame(self)
        bottom.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Label(bottom, text="Tip: Doble click para editar. DEL para borrar lote.", foreground="#666").pack(side="left")
        ttk.Button(bottom, text="Borrar lote", command=self._delete_selected).pack(side="right")

    def _legend_chip(self, parent, text: str, tag: str):
        lbl = tk.Label(parent, text=f"  {text}  ")
        bg = {"alert3": "#ffcccc", "alert6": "#ffd9b3", "alert9": "#fff2b3", "ok": "#ffffff"}.get(tag, "#ffffff")
        lbl.configure(background=bg, borderwidth=1, relief="solid")
        return lbl

    def _set_heading(self, col: str, text: str):
        self.tree.heading(col, text=text, command=lambda c=col: self._toggle_sort(c))

    def _toggle_sort(self, col: str):
        if self._sort_col == col:
            self._sort_desc = not self._sort_desc
        else:
            self._sort_col = col
            self._sort_desc = False
        self.refresh()

    def _row_tag_for(self, venc: str, estado: str, disponible: float) -> str:
        if disponible <= 0.00001 or (estado or "").upper() in {"VENDIDO_TOTAL", "AGOTADO"}:
            return "soldout"

        d = _parse_ymd(venc)
        if not d:
            return "ok"

        days = (d - date.today()).days
        if days <= 90:
            return "alert3"
        if days <= 180:
            return "alert6"
        if days <= 270:
            return "alert9"
        return "ok"

    def refresh(self):
        q = self.search.get().strip()
        rows = list_lotes(self.ctx["db_path"], q=q)

        if self._sort_col:
            key = self._sort_col

            def k(r):
                v = r.get(key)
                if key in {"cantidad_total", "cantidad_vendida", "cantidad_disponible"}:
                    try:
                        return float(v)
                    except Exception:
                        return 0.0
                if key == "fecha_vencimiento":
                    d = _parse_ymd(v or "")
                    return d or date.max
                return str(v or "").upper()

            rows = sorted(rows, key=k, reverse=self._sort_desc)

        for iid in self.tree.get_children():
            self.tree.delete(iid)

        for r in rows:
            tag = self._row_tag_for(r.get("fecha_vencimiento"), r.get("estado"), float(r.get("cantidad_disponible") or 0))
            self.tree.insert(
                "",
                "end",
                values=(
                    r.get("lote_id"),
                    r.get("sku"),
                    r.get("nombre"),
                    f"{float(r.get('cantidad_total') or 0):.0f}",
                    f"{float(r.get('cantidad_vendida') or 0):.0f}",
                    f"{float(r.get('cantidad_disponible') or 0):.0f}",
                    r.get("fecha_vencimiento"),
                    r.get("estado"),
                    r.get("deposito"),
                ),
                tags=(tag,),
            )

        self._render_sort_arrows()

    def _render_sort_arrows(self):
        base = {
            "lote_id": "Lote", "sku": "SKU", "nombre": "Producto",
            "cantidad_total": "Producidas", "cantidad_vendida": "Vendidas", "cantidad_disponible": "Disponibles",
            "fecha_vencimiento": "Vencimiento", "estado": "Estado", "deposito": "Depósito",
        }
        for col, text in base.items():
            arrow = ""
            if self._sort_col == col:
                arrow = " ▼" if self._sort_desc else " ▲"
            self.tree.heading(col, text=text + arrow)

    def _selected_lote_id(self):
        sel = self.tree.selection()
        if not sel:
            return None
        vals = self.tree.item(sel[0], "values")
        return vals[0] if vals else None

    def _add_lote(self):
        self._open_editor(lote_id="")

    def _edit_selected(self):
        lote_id = self._selected_lote_id()
        if not lote_id:
            return
        self._open_editor(lote_id=lote_id)

    def _delete_selected(self):
        lote_id = self._selected_lote_id()
        if not lote_id:
            return
        if not messagebox.askyesno("Confirmar", f"¿Borrar lote {lote_id}?"):
            return
        if not delete_lote(self.ctx["db_path"], lote_id):
            messagebox.showerror("Error", "No se pudo borrar")
            return
        self.refresh()

    def _open_editor(self, *, lote_id: str):
        current = None
        if lote_id:
            for r in list_lotes(self.ctx["db_path"], q=lote_id):
                if r.get("lote_id") == lote_id:
                    current = r
                    break

        win = tk.Toplevel(self)
        win.title("Editar lote" if lote_id else "Nuevo lote")
        win.transient(self)
        frm = ttk.Frame(win, padding=10)
        frm.pack(fill="both", expand=True)
        frm.columnconfigure(1, weight=1)

        def row(r, label, widget):
            ttk.Label(frm, text=label).grid(row=r, column=0, sticky="e", padx=(0, 8), pady=4)
            widget.grid(row=r, column=1, sticky="we", pady=4)
            return widget

        v_lote = tk.StringVar(value=(current.get("lote_id") if current else lote_id) or "")
        v_sku = tk.StringVar(value=(current.get("sku") if current else ""))
        v_nombre = tk.StringVar(value=(current.get("nombre") if current else ""))
        v_total = tk.StringVar(value=(str(int(current.get("cantidad_total"))) if current else ""))
        v_vendida = tk.StringVar(value=(str(int(current.get("cantidad_vendida"))) if current else "0"))
        v_prod = tk.StringVar(value=(current.get("fecha_produccion") if current else ""))
        v_venc = tk.StringVar(value=(current.get("fecha_vencimiento") if current else ""))
        v_depo = tk.StringVar(value=(current.get("deposito") if current else self.ctx["depo"].nombre))
        v_estado = tk.StringVar(value=(current.get("estado") if current else "DISPONIBLE"))
        v_notas = tk.StringVar(value=(current.get("notas") if current else ""))

        e_lote = row(0, "Lote ID:", ttk.Entry(frm, textvariable=v_lote))
        e_sku = row(1, "SKU:", ttk.Entry(frm, textvariable=v_sku))
        row(2, "Nombre:", ttk.Entry(frm, textvariable=v_nombre))
        row(3, "Cantidad total:", ttk.Entry(frm, textvariable=v_total))
        row(4, "Cantidad vendida:", ttk.Entry(frm, textvariable=v_vendida))
        row(5, "Fecha producción (YYYY-MM-DD):", ttk.Entry(frm, textvariable=v_prod))
        row(6, "Fecha vencimiento (YYYY-MM-DD):", ttk.Entry(frm, textvariable=v_venc))
        row(7, "Depósito/Ubicación:", ttk.Entry(frm, textvariable=v_depo))

        estados = ["EN_PRODUCCION", "DISPONIBLE", "BLOQUEADO", "VENDIDO_TOTAL"]
        cb = ttk.Combobox(frm, textvariable=v_estado, values=estados, state="readonly")
        row(8, "Estado:", cb)

        row(9, "Notas:", ttk.Entry(frm, textvariable=v_notas))

        def save():
            lid = v_lote.get().strip()
            sku = v_sku.get().strip()
            if not lid or not sku:
                messagebox.showerror("Error", "Lote ID y SKU son obligatorios")
                return
            try:
                total = float(v_total.get().strip() or 0)
                vend = float(v_vendida.get().strip() or 0)
            except Exception:
                messagebox.showerror("Error", "Cantidad inválida")
                return
            if v_prod.get().strip() and not _parse_ymd(v_prod.get()):
                messagebox.showerror("Error", "Fecha producción inválida (use YYYY-MM-DD)")
                return
            if v_venc.get().strip() and not _parse_ymd(v_venc.get()):
                messagebox.showerror("Error", "Fecha vencimiento inválida (use YYYY-MM-DD)")
                return

            disp = total - vend
            ok = upsert_lote(
                self.ctx["db_path"],
                lote_id=lid,
                sku=sku,
                nombre=v_nombre.get().strip(),
                cantidad_total=total,
                cantidad_vendida=vend,
                cantidad_disponible=disp,
                fecha_produccion=v_prod.get().strip(),
                fecha_vencimiento=v_venc.get().strip(),
                deposito=v_depo.get().strip(),
                estado=v_estado.get().strip() or "DISPONIBLE",
                notas=v_notas.get().strip(),
            )
            if not ok:
                messagebox.showerror("Error", "No se pudo guardar")
                return
            win.destroy()
            self.refresh()

        btns = ttk.Frame(frm)
        btns.grid(row=10, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(btns, text="Guardar", command=save).pack(side="right", padx=(6, 0))
        ttk.Button(btns, text="Cancelar", command=win.destroy).pack(side="right")

        (e_lote if not lote_id else e_sku).focus()
        win.grab_set()
        win.wait_window(win)
