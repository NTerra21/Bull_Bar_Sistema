"""
Punto de entrada cuando se ejecuta como módulo: python -m bull_bar.ui

Este archivo permite ejecutar la aplicación usando:
    python -m bull_bar.ui

O desde los scripts .bat/.vbs que usan este formato.
"""
from __future__ import annotations

# ============================================
# TESTIGOS DE DEPURACIÓN - __main__.py
# ============================================
import os
import sys

print("[DEBUG] __main__.py: ========================================")
print("[DEBUG] __main__.py: INICIANDO DESDE MÓDULO")
print("[DEBUG] __main__.py: ========================================")
print(f"[DEBUG] __main__.py: __file__ = {__file__}")
print(f"[DEBUG] __main__.py: Directorio actual = {os.getcwd()}")

# Asegurar que el directorio raíz esté en sys.path
# Calcular la ruta raíz del proyecto
# Desde bull_bar/ui/__main__.py -> .. -> bull_bar -> .. -> Sistema_Bull (raíz)
_this_file = os.path.abspath(__file__)
_project_root = os.path.abspath(os.path.join(os.path.dirname(_this_file), "..", ".."))

print(f"[DEBUG] __main__.py: _this_file = {_this_file}")
print(f"[DEBUG] __main__.py: _project_root = {_project_root}")
print(f"[DEBUG] __main__.py: _project_root existe? {os.path.exists(_project_root)}")

# Añadir al sys.path si no está
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)
    print(f"[DEBUG] __main__.py: [OK] Añadido al sys.path: {_project_root}")
else:
    print(f"[DEBUG] __main__.py: [OK] _project_root ya está en sys.path")

print(f"[DEBUG] __main__.py: sys.path[0:3] = {sys.path[0:3]}")

# Importar y ejecutar main desde app.py
# app.py ya tiene su propia configuración de sys.path, pero esto asegura
# que funcione incluso si se ejecuta directamente como módulo
print("[DEBUG] __main__.py: Importando main desde bull_bar.ui.app...")
try:
    from bull_bar.ui.app import main
    print("[DEBUG] __main__.py: [OK] main importado correctamente")
except Exception as e:
    print(f"[DEBUG] __main__.py: [ERROR] Error importando main: {e}")
    import traceback
    traceback.print_exc()
    raise

print("[DEBUG] __main__.py: Ejecutando main()...")
if __name__ == "__main__":
    try:
        main()
        print("[DEBUG] __main__.py: [OK] main() terminó correctamente")
    except Exception as e:
        print(f"[DEBUG] __main__.py: [ERROR] Error ejecutando main(): {e}")
        import traceback
        traceback.print_exc()
        raise
