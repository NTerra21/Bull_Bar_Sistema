#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script para ejecutar la API de Bull Bar.
Configura el PYTHONPATH correctamente antes de iniciar uvicorn.
"""
import sys
import os
from pathlib import Path

# Obtener el directorio raíz del proyecto (un nivel arriba de scripts/)
# Este script está en Sistema_Bull/scripts/run_api.py
# La raíz es Sistema_Bull/
ROOT_DIR = Path(__file__).parent.parent.absolute()

# Cambiar al directorio raíz
os.chdir(ROOT_DIR)

# Agregar al PYTHONPATH
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# Configurar variable de entorno también (para subprocesos)
os.environ["PYTHONPATH"] = str(ROOT_DIR) + os.pathsep + os.environ.get("PYTHONPATH", "")

# Verificar que podemos importar
try:
    from bull_bar.api.main import app
    print("[OK] Modulo bull_bar importado correctamente")
except ImportError as e:
    print(f"[ERROR] Error importando bull_bar: {e}")
    print(f"[INFO] Directorio actual: {os.getcwd()}")
    print(f"[INFO] ROOT_DIR: {ROOT_DIR}")
    print(f"[INFO] sys.path (primeros 3): {sys.path[:3]}")
    print(f"[INFO] PYTHONPATH: {os.environ.get('PYTHONPATH', 'No definido')}")
    sys.exit(1)

# Ahora ejecutar uvicorn
if __name__ == "__main__":
    import uvicorn
    
    print("=" * 60)
    print("Iniciando Bull Bar API")
    print("=" * 60)
    print(f"Directorio: {ROOT_DIR}")
    print(f"Python: {sys.version.split()[0]}")
    print()
    print("Servidor: http://localhost:8000")
    print("Documentacion: http://localhost:8000/docs")
    print("Health Check: http://localhost:8000/health")
    print()
    print("Presiona Ctrl+C para detener el servidor")
    print("=" * 60)
    print()
    
    try:
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=8000,
            reload=False,  # Sin reload para evitar problemas con path
            log_level="info"
        )
    except KeyboardInterrupt:
        print("\n\n[OK] Servidor detenido. Hasta luego!")
    except Exception as e:
        print(f"\n[ERROR] Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

