"""
Script para actualizar las credenciales del usuario admin.
Cambia de admin/admin a Bull/Bull1243 (sin punto)
"""
import sys
from pathlib import Path

# Agregar el directorio raíz al path
root_dir = Path(__file__).parent
sys.path.insert(0, str(root_dir))

from bull_bar.infra.actualizar_admin import actualizar_admin
from bull_bar.api.settings import get_db_path

if __name__ == "__main__":
    db_path = get_db_path()
    print(f"Actualizando credenciales en: {db_path}")
    actualizar_admin(db_path)
    print("\n[OK] Proceso completado. Nuevas credenciales:")
    print("  Usuario: Bull")
    print("  Contrasena: Bull1243")

