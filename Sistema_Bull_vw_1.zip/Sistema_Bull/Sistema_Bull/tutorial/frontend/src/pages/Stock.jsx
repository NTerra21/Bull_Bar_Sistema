import { useEffect, useState } from 'react'
import api from '../services/api'
import './Stock.css'

const Stock = () => {
  const [insumos, setInsumos] = useState([])
  const [barritas, setBarritas] = useState([])
  const [activeTab, setActiveTab] = useState('insumos')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [insumosRes, barritasRes] = await Promise.all([
        api.get('/stock/insumos'),
        api.get('/stock/barritas'),
      ])
      setInsumos(insumosRes.data)
      setBarritas(barritasRes.data)
    } catch (error) {
      console.error('Error cargando stock:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div>Cargando stock...</div>
  }

  return (
    <div className="stock-page">
      <h1>Stock</h1>
      <div className="tabs">
        <button
          className={activeTab === 'insumos' ? 'active' : ''}
          onClick={() => setActiveTab('insumos')}
        >
          Insumos
        </button>
        <button
          className={activeTab === 'barritas' ? 'active' : ''}
          onClick={() => setActiveTab('barritas')}
        >
          Barritas
        </button>
      </div>
      <div className="stock-content">
        {activeTab === 'insumos' && (
          <div className="card">
            <h2>Stock de Insumos</h2>
            <table className="table">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Cantidad</th>
                  <th>Unidad</th>
                  <th>Depósito</th>
                </tr>
              </thead>
              <tbody>
                {insumos.length === 0 ? (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center' }}>
                      No hay insumos registrados
                    </td>
                  </tr>
                ) : (
                  insumos.map((item) => (
                    <tr key={item.id}>
                      <td>{item.nombre}</td>
                      <td>{item.cantidad.toFixed(2)}</td>
                      <td>{item.unidad}</td>
                      <td>{item.deposito || 'N/A'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
        {activeTab === 'barritas' && (
          <div className="card">
            <h2>Stock de Barritas</h2>
            <table className="table">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Cantidad</th>
                  <th>Unidad</th>
                  <th>Depósito</th>
                </tr>
              </thead>
              <tbody>
                {barritas.length === 0 ? (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center' }}>
                      No hay barritas registradas
                    </td>
                  </tr>
                ) : (
                  barritas.map((item) => (
                    <tr key={item.id}>
                      <td>{item.nombre}</td>
                      <td>{item.cantidad.toFixed(0)}</td>
                      <td>{item.unidad}</td>
                      <td>{item.deposito || 'N/A'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

export default Stock
