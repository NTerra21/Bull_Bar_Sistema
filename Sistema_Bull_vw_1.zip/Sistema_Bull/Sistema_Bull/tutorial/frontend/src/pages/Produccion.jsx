import { useState } from 'react'
import api from '../services/api'
import { useAuth } from '../contexts/AuthContext'
import './Produccion.css'

const Produccion = () => {
  const { isAdmin } = useAuth()
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState({ type: '', text: '' })
  const [produccion, setProduccion] = useState({
    numero: '',
    deposito_id: '',
    consumos: [{ producto_id: '', descripcion: '', cantidad: '' }],
    producto_final: { producto_id: '', descripcion: '', cantidad: '' },
  })

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setMessage({ type: '', text: '' })

    try {
      const payload = {
        ...produccion,
        consumos: produccion.consumos
          .filter((item) => item.producto_id && item.cantidad)
          .map((item) => ({
            ...item,
            cantidad: parseFloat(item.cantidad),
          })),
        producto_final: {
          ...produccion.producto_final,
          cantidad: parseFloat(produccion.producto_final.cantidad),
        },
      }

      const response = await api.post('/movimientos/produccion', payload)

      if (response.data.requiere_aprobacion) {
        setMessage({
          type: 'warning',
          text: 'Producción enviada para aprobación. Un administrador la revisará.',
        })
      } else {
        setMessage({ type: 'success', text: 'Producción registrada correctamente' })
      }

      setProduccion({
        numero: '',
        deposito_id: '',
        consumos: [{ producto_id: '', descripcion: '', cantidad: '' }],
        producto_final: { producto_id: '', descripcion: '', cantidad: '' },
      })
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.detail || 'Error al registrar producción',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="produccion-page">
      <h1>Producción</h1>
      {!isAdmin && (
        <div className="message message-warning">
          Las producciones requieren aprobación de un administrador.
        </div>
      )}
      {message.text && (
        <div className={`message message-${message.type}`}>{message.text}</div>
      )}
      <div className="card">
        <h2>Registrar Producción</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Número de Remito/Parte</label>
            <input
              type="text"
              value={produccion.numero}
              onChange={(e) => setProduccion({ ...produccion, numero: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>ID Depósito</label>
            <input
              type="text"
              value={produccion.deposito_id}
              onChange={(e) => setProduccion({ ...produccion, deposito_id: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>Insumos Consumidos</label>
            {produccion.consumos.map((item, index) => (
              <div key={index} className="item-row">
                <input
                  type="text"
                  placeholder="Producto ID"
                  value={item.producto_id}
                  onChange={(e) => {
                    const newConsumos = [...produccion.consumos]
                    newConsumos[index].producto_id = e.target.value
                    setProduccion({ ...produccion, consumos: newConsumos })
                  }}
                />
                <input
                  type="text"
                  placeholder="Descripción"
                  value={item.descripcion}
                  onChange={(e) => {
                    const newConsumos = [...produccion.consumos]
                    newConsumos[index].descripcion = e.target.value
                    setProduccion({ ...produccion, consumos: newConsumos })
                  }}
                />
                <input
                  type="number"
                  placeholder="Cantidad"
                  value={item.cantidad}
                  onChange={(e) => {
                    const newConsumos = [...produccion.consumos]
                    newConsumos[index].cantidad = e.target.value
                    setProduccion({ ...produccion, consumos: newConsumos })
                  }}
                />
              </div>
            ))}
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() =>
                setProduccion({
                  ...produccion,
                  consumos: [
                    ...produccion.consumos,
                    { producto_id: '', descripcion: '', cantidad: '' },
                  ],
                })
              }
            >
              + Agregar Insumo
            </button>
          </div>
          <div className="form-group">
            <label>Producto Final</label>
            <div className="item-row">
              <input
                type="text"
                placeholder="Producto ID"
                value={produccion.producto_final.producto_id}
                onChange={(e) =>
                  setProduccion({
                    ...produccion,
                    producto_final: { ...produccion.producto_final, producto_id: e.target.value },
                  })
                }
                required
              />
              <input
                type="text"
                placeholder="Descripción"
                value={produccion.producto_final.descripcion}
                onChange={(e) =>
                  setProduccion({
                    ...produccion,
                    producto_final: { ...produccion.producto_final, descripcion: e.target.value },
                  })
                }
                required
              />
              <input
                type="number"
                placeholder="Cantidad"
                value={produccion.producto_final.cantidad}
                onChange={(e) =>
                  setProduccion({
                    ...produccion,
                    producto_final: { ...produccion.producto_final, cantidad: e.target.value },
                  })
                }
                required
              />
            </div>
          </div>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? 'Registrando...' : 'Registrar Producción'}
          </button>
        </form>
      </div>
    </div>
  )
}

export default Produccion
