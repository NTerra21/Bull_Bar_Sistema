import { useEffect, useState } from 'react'
import api from '../services/api'
import './Lotes.css'

const Lotes = () => {
  const [lotes, setLotes] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('activos')

  useEffect(() => {
    loadLotes()
  }, [activeTab])

  const loadLotes = async () => {
    try {
      const estado = activeTab === 'activos' ? 'activos' : 'finalizados'
      const response = await api.get(`/lotes?estado=${estado}`)
      setLotes(response.data)
    } catch (error) {
      console.error('Error cargando lotes:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleFinalizar = async (loteId) => {
    if (!confirm('¿Estás seguro de finalizar este lote?')) return

    try {
      await api.patch(`/lotes/${loteId}/finalizar`)
      loadLotes()
    } catch (error) {
      alert(error.response?.data?.detail || 'Error al finalizar lote')
    }
  }

  if (loading) {
    return <div>Cargando lotes...</div>
  }

  return (
    <div className="lotes-page">
      <h1>Lotes de Barritas</h1>
      <div className="tabs">
        <button
          className={activeTab === 'activos' ? 'active' : ''}
          onClick={() => setActiveTab('activos')}
        >
          Activos
        </button>
        <button
          className={activeTab === 'finalizados' ? 'active' : ''}
          onClick={() => setActiveTab('finalizados')}
        >
          Finalizados
        </button>
      </div>
      <div className="card">
        <h2>Lotes {activeTab === 'activos' ? 'Activos' : 'Finalizados'}</h2>
        {lotes.length === 0 ? (
          <p>No hay lotes {activeTab === 'activos' ? 'activos' : 'finalizados'}</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Lote ID</th>
                <th>SKU</th>
                <th>Nombre</th>
                <th>Cantidad Total</th>
                <th>Cantidad Disponible</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {lotes.map((lote) => (
                <tr key={lote.lote_id}>
                  <td>{lote.lote_id}</td>
                  <td>{lote.sku}</td>
                  <td>{lote.nombre}</td>
                  <td>{lote.cantidad_total}</td>
                  <td>{lote.cantidad_disponible}</td>
                  <td>
                    <span className={`badge badge-${lote.estado === 'DISPONIBLE' ? 'success' : 'warning'}`}>
                      {lote.estado}
                    </span>
                  </td>
                  <td>
                    {activeTab === 'activos' && (
                      <button
                        className="btn btn-secondary"
                        onClick={() => handleFinalizar(lote.lote_id)}
                      >
                        Finalizar
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

export default Lotes
