import { useState } from 'react'
import api from '../services/api'
import { useAuth } from '../contexts/AuthContext'
import './Movimientos.css'

const Movimientos = () => {
  const { isAdmin } = useAuth()
  const [activeTab, setActiveTab] = useState('compra')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState({ type: '', text: '' })

  // Estados para formularios
  const [compra, setCompra] = useState({
    numero: '',
    proveedor_id: '',
    deposito_id: '',
    items: [{ producto_id: '', descripcion: '', cantidad: '' }],
  })

  const [venta, setVenta] = useState({
    numero: '',
    cliente_id: '',
    deposito_id: '',
    items: [{ producto_id: '', descripcion: '', cantidad: '' }],
  })

  const [ajuste, setAjuste] = useState({
    deposito_id: '',
    producto_id: '',
    cantidad: '',
    motivo: '',
  })

  const handleCompra = async (e) => {
    e.preventDefault()
    setLoading(true)
    setMessage({ type: '', text: '' })

    try {
      const payload = {
        ...compra,
        items: compra.items
          .filter((item) => item.producto_id && item.cantidad)
          .map((item) => ({
            ...item,
            cantidad: parseFloat(item.cantidad),
          })),
      }

      const response = await api.post('/movimientos/compra', payload)
      setMessage({ type: 'success', text: 'Compra registrada correctamente' })
      setCompra({
        numero: '',
        proveedor_id: '',
        deposito_id: '',
        items: [{ producto_id: '', descripcion: '', cantidad: '' }],
      })
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.detail || 'Error al registrar compra',
      })
    } finally {
      setLoading(false)
    }
  }

  const handleVenta = async (e) => {
    e.preventDefault()
    setLoading(true)
    setMessage({ type: '', text: '' })

    try {
      const payload = {
        ...venta,
        items: venta.items
          .filter((item) => item.producto_id && item.cantidad)
          .map((item) => ({
            ...item,
            cantidad: parseFloat(item.cantidad),
          })),
      }

      const response = await api.post('/movimientos/venta', payload)
      setMessage({ type: 'success', text: 'Venta registrada correctamente' })
      setVenta({
        numero: '',
        cliente_id: '',
        deposito_id: '',
        items: [{ producto_id: '', descripcion: '', cantidad: '' }],
      })
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.detail || 'Error al registrar venta',
      })
    } finally {
      setLoading(false)
    }
  }

  const handleAjuste = async (e) => {
    e.preventDefault()
    setLoading(true)
    setMessage({ type: '', text: '' })

    try {
      const payload = {
        ...ajuste,
        cantidad: parseFloat(ajuste.cantidad),
      }

      const response = await api.post('/movimientos/ajuste', payload)
      
      if (response.data.requiere_aprobacion) {
        setMessage({
          type: 'warning',
          text: 'Ajuste enviado para aprobación. Un administrador lo revisará.',
        })
      } else {
        setMessage({ type: 'success', text: 'Ajuste aplicado correctamente' })
      }

      setAjuste({
        deposito_id: '',
        producto_id: '',
        cantidad: '',
        motivo: '',
      })
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.detail || 'Error al aplicar ajuste',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="movimientos-page">
      <h1>Movimientos</h1>
      <div className="tabs">
        <button
          className={activeTab === 'compra' ? 'active' : ''}
          onClick={() => setActiveTab('compra')}
        >
          Compra
        </button>
        <button
          className={activeTab === 'venta' ? 'active' : ''}
          onClick={() => setActiveTab('venta')}
        >
          Venta
        </button>
        <button
          className={activeTab === 'ajuste' ? 'active' : ''}
          onClick={() => setActiveTab('ajuste')}
        >
          Ajuste Stock
        </button>
      </div>

      {message.text && (
        <div className={`message message-${message.type}`}>{message.text}</div>
      )}

      <div className="movimientos-content">
        {activeTab === 'compra' && (
          <div className="card">
            <h2>Registrar Compra</h2>
            <form onSubmit={handleCompra}>
              <div className="form-group">
                <label>Número de Factura/Remito</label>
                <input
                  type="text"
                  value={compra.numero}
                  onChange={(e) => setCompra({ ...compra, numero: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>ID Proveedor</label>
                <input
                  type="text"
                  value={compra.proveedor_id}
                  onChange={(e) => setCompra({ ...compra, proveedor_id: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>ID Depósito</label>
                <input
                  type="text"
                  value={compra.deposito_id}
                  onChange={(e) => setCompra({ ...compra, deposito_id: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Items</label>
                {compra.items.map((item, index) => (
                  <div key={index} className="item-row">
                    <input
                      type="text"
                      placeholder="Producto ID"
                      value={item.producto_id}
                      onChange={(e) => {
                        const newItems = [...compra.items]
                        newItems[index].producto_id = e.target.value
                        setCompra({ ...compra, items: newItems })
                      }}
                    />
                    <input
                      type="text"
                      placeholder="Descripción"
                      value={item.descripcion}
                      onChange={(e) => {
                        const newItems = [...compra.items]
                        newItems[index].descripcion = e.target.value
                        setCompra({ ...compra, items: newItems })
                      }}
                    />
                    <input
                      type="number"
                      placeholder="Cantidad"
                      value={item.cantidad}
                      onChange={(e) => {
                        const newItems = [...compra.items]
                        newItems[index].cantidad = e.target.value
                        setCompra({ ...compra, items: newItems })
                      }}
                    />
                  </div>
                ))}
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() =>
                    setCompra({
                      ...compra,
                      items: [...compra.items, { producto_id: '', descripcion: '', cantidad: '' }],
                    })
                  }
                >
                  + Agregar Item
                </button>
              </div>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Registrando...' : 'Registrar Compra'}
              </button>
            </form>
          </div>
        )}

        {activeTab === 'venta' && (
          <div className="card">
            <h2>Registrar Venta</h2>
            <form onSubmit={handleVenta}>
              <div className="form-group">
                <label>Número de Pedido/Remito</label>
                <input
                  type="text"
                  value={venta.numero}
                  onChange={(e) => setVenta({ ...venta, numero: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>ID Cliente</label>
                <input
                  type="text"
                  value={venta.cliente_id}
                  onChange={(e) => setVenta({ ...venta, cliente_id: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>ID Depósito</label>
                <input
                  type="text"
                  value={venta.deposito_id}
                  onChange={(e) => setVenta({ ...venta, deposito_id: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Items</label>
                {venta.items.map((item, index) => (
                  <div key={index} className="item-row">
                    <input
                      type="text"
                      placeholder="Producto ID"
                      value={item.producto_id}
                      onChange={(e) => {
                        const newItems = [...venta.items]
                        newItems[index].producto_id = e.target.value
                        setVenta({ ...venta, items: newItems })
                      }}
                    />
                    <input
                      type="text"
                      placeholder="Descripción"
                      value={item.descripcion}
                      onChange={(e) => {
                        const newItems = [...venta.items]
                        newItems[index].descripcion = e.target.value
                        setVenta({ ...venta, items: newItems })
                      }}
                    />
                    <input
                      type="number"
                      placeholder="Cantidad"
                      value={item.cantidad}
                      onChange={(e) => {
                        const newItems = [...venta.items]
                        newItems[index].cantidad = e.target.value
                        setVenta({ ...venta, items: newItems })
                      }}
                    />
                  </div>
                ))}
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() =>
                    setVenta({
                      ...venta,
                      items: [...venta.items, { producto_id: '', descripcion: '', cantidad: '' }],
                    })
                  }
                >
                  + Agregar Item
                </button>
              </div>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Registrando...' : 'Registrar Venta'}
              </button>
            </form>
          </div>
        )}

        {activeTab === 'ajuste' && (
          <div className="card">
            <h2>Ajuste de Stock</h2>
            {!isAdmin && (
              <div className="message message-warning">
                Los ajustes negativos requieren aprobación de un administrador.
              </div>
            )}
            <form onSubmit={handleAjuste}>
              <div className="form-group">
                <label>ID Depósito</label>
                <input
                  type="text"
                  value={ajuste.deposito_id}
                  onChange={(e) => setAjuste({ ...ajuste, deposito_id: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>ID Producto</label>
                <input
                  type="text"
                  value={ajuste.producto_id}
                  onChange={(e) => setAjuste({ ...ajuste, producto_id: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>
                  Cantidad (positivo = entrada, negativo = salida)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={ajuste.cantidad}
                  onChange={(e) => setAjuste({ ...ajuste, cantidad: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Motivo</label>
                <input
                  type="text"
                  value={ajuste.motivo}
                  onChange={(e) => setAjuste({ ...ajuste, motivo: e.target.value })}
                />
              </div>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Aplicando...' : 'Aplicar Ajuste'}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  )
}

export default Movimientos
