import { useEffect, useState } from 'react'
import api from '../services/api'
import { useAuth } from '../contexts/AuthContext'
import './Recetas.css'

const Recetas = () => {
  const { isAdmin } = useAuth()
  const [recetas, setRecetas] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('activas')

  useEffect(() => {
    loadRecetas()
  }, [activeTab])

  const loadRecetas = async () => {
    try {
      const estado = activeTab === 'activas' ? 'activas' : 'inactivas'
      const response = await api.get(`/recetas?estado=${estado}`)
      setRecetas(response.data)
    } catch (error) {
      console.error('Error cargando recetas:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div>Cargando recetas...</div>
  }

  return (
    <div className="recetas-page">
      <h1>Recetas</h1>
      <div className="tabs">
        <button
          className={activeTab === 'activas' ? 'active' : ''}
          onClick={() => setActiveTab('activas')}
        >
          Activas
        </button>
        <button
          className={activeTab === 'inactivas' ? 'active' : ''}
          onClick={() => setActiveTab('inactivas')}
        >
          Inactivas
        </button>
      </div>
      <div className="card">
        <h2>Recetas {activeTab === 'activas' ? 'Activas' : 'Inactivas'}</h2>
        {recetas.length === 0 ? (
          <p>No hay recetas {activeTab === 'activas' ? 'activas' : 'inactivas'}</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Versión</th>
                <th>Items</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody>
              {recetas.map((receta) => (
                <tr key={`${receta.codigo}-${receta.version}`}>
                  <td>{receta.codigo}</td>
                  <td>{receta.nombre}</td>
                  <td>{receta.version}</td>
                  <td>{receta.items.length}</td>
                  <td>
                    <span className={receta.is_active ? 'badge badge-success' : 'badge badge-warning'}>
                      {receta.is_active ? 'Activa' : 'Inactiva'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

export default Recetas
