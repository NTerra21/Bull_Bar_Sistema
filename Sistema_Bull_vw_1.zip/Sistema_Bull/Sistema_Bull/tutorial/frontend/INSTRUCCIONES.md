# 🚀 Cómo Ejecutar el Frontend

## Requisitos Previos

1. **Node.js** instalado (versión 16 o superior)
2. **npm** o **yarn**
3. La **API** debe estar corriendo en `http://localhost:8000`

## Instalación

```bash
cd frontend
npm install
```

## Ejecutar en Desarrollo

```bash
npm run dev
```

El frontend estará disponible en: **http://localhost:3000**

## Estructura del Proyecto

```
frontend/
├── src/
│   ├── components/        # Componentes reutilizables
│   │   ├── Layout.jsx     # Layout principal con navegación
│   │   └── PrivateRoute.jsx # Protección de rutas
│   ├── contexts/          # Context API
│   │   └── AuthContext.jsx # Manejo de autenticación
│   ├── pages/             # Páginas principales
│   │   ├── Login.jsx      # Página de login
│   │   ├── Dashboard.jsx  # Dashboard principal
│   │   ├── Stock.jsx      # Gestión de stock
│   │   ├── Movimientos.jsx # Compras, ventas, ajustes
│   │   ├── Produccion.jsx # Registro de producción
│   │   ├── Recetas.jsx    # Gestión de recetas
│   │   ├── Lotes.jsx      # Gestión de lotes
│   │   └── Aprobaciones.jsx # Aprobaciones (solo ADMIN)
│   ├── services/          # Servicios
│   │   └── api.js         # Cliente API con axios
│   ├── App.jsx            # Componente principal
│   └── main.jsx           # Punto de entrada
├── index.html
├── package.json
└── vite.config.js         # Configuración de Vite
```

## Funcionalidades Implementadas

### ✅ Autenticación
- Login con JWT
- Rutas protegidas
- Manejo de roles (ADMIN/USUARIO)
- Logout

### ✅ Dashboard
- Estadísticas generales
- Resumen de stock, lotes y aprobaciones

### ✅ Stock
- Visualización de insumos
- Visualización de barritas
- Tabs para alternar entre ambos

### ✅ Movimientos
- **Compra**: Registrar compras de insumos
- **Venta**: Registrar ventas
- **Ajuste**: Ajustes de stock (requiere aprobación si es negativo y usuario es USUARIO)

### ✅ Producción
- Registrar producción
- Consumos (insumos)
- Producto final
- Requiere aprobación si usuario es USUARIO

### ✅ Recetas
- Listar recetas activas/inactivas
- Visualización de items por receta

### ✅ Lotes
- Listar lotes activos/finalizados
- Finalizar lotes

### ✅ Aprobaciones (Solo ADMIN)
- Ver solicitudes pendientes/aprobadas/rechazadas
- Aprobar solicitudes
- Rechazar solicitudes

## Configuración

### Cambiar URL de la API

Edita `vite.config.js`:

```javascript
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:8000', // Cambiar aquí
      changeOrigin: true,
      rewrite: (path) => path.replace(/^\/api/, '')
    }
  }
}
```

## Build para Producción

```bash
npm run build
```

Los archivos se generarán en la carpeta `dist/` que puedes servir con cualquier servidor web estático.

## Solución de Problemas

### Error: "Cannot connect to API"

- Verifica que la API esté corriendo en `http://localhost:8000`
- Verifica que el proxy esté configurado correctamente en `vite.config.js`

### Error: "Module not found"

- Ejecuta `npm install` nuevamente
- Verifica que estés en el directorio `frontend`

### Error de CORS

- La API debe tener configurado CORS para permitir `http://localhost:3000`
- Verifica `CORS_ORIGINS` en `bull_bar/api/settings.py`

## Próximos Pasos

- [ ] Mejorar formularios con validación
- [ ] Agregar búsqueda y filtros
- [ ] Implementar paginación
- [ ] Agregar notificaciones toast
- [ ] Mejorar diseño responsive
- [ ] Agregar gráficos en dashboard
