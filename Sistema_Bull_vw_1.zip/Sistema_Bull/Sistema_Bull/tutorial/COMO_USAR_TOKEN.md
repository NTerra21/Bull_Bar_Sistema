# 🔑 Cómo Usar el Token en Swagger UI

## ✅ Ya Tienes el Token

Tu token es:
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbiIsInJvbCI6IkFETUlOIiwiZXhwIjoxNzY2NjAzMDQzfQ._eEUk_DcYiPiS_2-57zMgLSLj9YOfYoAsKhLoyWBB0I
```

## 🎯 Método Correcto: Usar el Botón "Authorize"

### Opción 1: Autorización Simple (Recomendado)

1. **Haz clic en el botón verde "Authorize"** (arriba a la derecha, con el candado 🔒)

2. **En el campo que aparece**, pega SOLO el token (sin "Bearer"):
   ```
   eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbiIsInJvbCI6IkFETUlOIiwiZXhwIjoxNzY2NjAzMDQzfQ._eEUk_DcYiPiS_2-57zMgLSLj9YOfYoAsKhLoyWBB0I
   ```

3. **Haz clic en "Authorize"** y luego en "Close"

4. ✅ **¡Listo!** Ahora todos los endpoints están autorizados

---

### Opción 2: Si el Modal da Error

Si el modal de autorización da error, puedes agregar el token manualmente en cada request:

1. **Abre cualquier endpoint** (ej: `/stock/insumos`)

2. **Haz clic en "Try it out"**

3. **Busca la sección "Authorization"** o "Headers"

4. **Agrega un header:**
   - Key: `Authorization`
   - Value: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbiIsInJvbCI6IkFETUlOIiwiZXhwIjoxNzY2NjAzMDQzfQ._eEUk_DcYiPiS_2-57zMgLSLj9YOfYoAsKhLoyWBB0I`

5. **Ejecuta el request**

---

## 🧪 Probar Endpoints

Ahora que tienes el token, prueba estos endpoints:

### 1. Ver Stock de Insumos
- Endpoint: `GET /stock/insumos`
- Haz clic en "Try it out" → "Execute"
- Verás el stock actual

### 2. Ver Stock de Barritas
- Endpoint: `GET /stock/barritas`
- Haz clic en "Try it out" → "Execute"

### 3. Ver Lotes
- Endpoint: `GET /lotes`
- Haz clic en "Try it out" → "Execute"

### 4. Ver Aprobaciones (Solo ADMIN)
- Endpoint: `GET /aprobaciones?estado=pendiente`
- Haz clic en "Try it out" → "Execute"

---

## ⚠️ Nota sobre el Token

El token expira después de 24 horas (configurado en la API). Si expira:
1. Vuelve a hacer login en `/auth/login`
2. Obtén un nuevo token
3. Actualiza la autorización

---

## 🎉 ¡Ya Puedes Usar el Sistema!

Todos los endpoints están disponibles. Explora y prueba las funcionalidades.

