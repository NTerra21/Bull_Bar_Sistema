# 🚀 Cómo Ejecutar la API - Solución al Error "ModuleNotFoundError"

## ❌ Error que estabas viendo:
```
ModuleNotFoundError: No module named 'bull_bar'
```

## ✅ Solución

He creado un script `run_api.py` que configura correctamente el PYTHONPATH.

### Opción 1: Usar el script Python (RECOMENDADO)

```bash
python run_api.py
```

Este script:
- ✅ Configura el PYTHONPATH automáticamente
- ✅ Verifica que el módulo se puede importar
- ✅ Muestra mensajes claros si hay errores
- ✅ Inicia el servidor correctamente

### Opción 2: Usar el .bat actualizado

```bash
start_api.bat
```

### Opción 3: Manual con PYTHONPATH

En PowerShell:
```powershell
$env:PYTHONPATH = (Get-Location).Path
python -m uvicorn bull_bar.api.main:app --reload --host 0.0.0.0 --port 8000
```

En CMD:
```cmd
set PYTHONPATH=%CD%
python -m uvicorn bull_bar.api.main:app --reload --host 0.0.0.0 --port 8000
```

---

## 🔍 Verificar que Funciona

Una vez que veas en la consola:
```
✅ Módulo bull_bar importado correctamente
🚀 Iniciando Bull Bar API
INFO:     Started server process
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000
```

Abre tu navegador en:
- **http://localhost:8000/docs** - Documentación interactiva
- **http://localhost:8000/health** - Health check

---

## 🐛 Si Aún Hay Problemas

1. **Verifica que estás en el directorio correcto:**
   ```bash
   # Deberías estar aquí:
   C:\Users\nicol\Desktop\Sistema_Bull\Sistema_Bull
   
   # Y deberías ver estos archivos:
   # - run_api.py
   # - bull_bar/
   # - bullbar.sqlite
   ```

2. **Verifica que Python puede importar el módulo:**
   ```bash
   python -c "import sys; sys.path.insert(0, '.'); from bull_bar.api.main import app; print('OK')"
   ```

3. **Si el error persiste, ejecuta:**
   ```bash
   python run_api.py
   ```
   Y comparte el mensaje de error completo que aparece.

---

## 📝 Nota sobre el Reload

El script `run_api.py` ejecuta sin `--reload` para evitar problemas con el PYTHONPATH en subprocesos. Si necesitas auto-reload, usa la Opción 3 manual con la variable de entorno configurada.

