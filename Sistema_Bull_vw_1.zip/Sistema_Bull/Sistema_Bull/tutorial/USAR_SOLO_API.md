# 🌐 Usar el Sistema Solo con la API (Sin Frontend)

Si no tienes Node.js instalado o prefieres usar solo la API, puedes acceder al sistema de estas formas:

## 🚀 Opción 1: Documentación Interactiva (Swagger UI)

### Paso 1: Iniciar la API

```bash
python run_api.py
```

### Paso 2: Abrir en el Navegador

Ve a: **http://localhost:8000/docs**

Aquí podrás:
- ✅ Ver todos los endpoints
- ✅ Probar cada endpoint directamente
- ✅ Hacer login y obtener token
- ✅ Ejecutar todas las operaciones

### Cómo Usar:

1. **Hacer Login:**
   - Busca el endpoint `/auth/login`
   - Haz clic en "Try it out"
   - Ingresa:
     - username: `admin`
     - password: `admin`
   - Haz clic en "Execute"
   - **Copia el `access_token`** que aparece en la respuesta

2. **Autorizar:**
   - Haz clic en el botón **"Authorize"** (arriba a la derecha)
   - Pega el token que copiaste
   - Haz clic en "Authorize" y luego "Close"

3. **Usar los Endpoints:**
   - Ahora todos los endpoints están autorizados
   - Puedes probar:
     - `/stock/insumos` - Ver stock
     - `/movimientos/compra` - Registrar compra
     - `/aprobaciones` - Ver aprobaciones (solo ADMIN)
     - etc.

---

## 🚀 Opción 2: Usar Postman o Similar

1. Descarga **Postman** (https://www.postman.com/downloads/)
2. Importa la colección de endpoints
3. Configura el token JWT en las peticiones

---

## 🚀 Opción 3: Usar curl (Línea de Comandos)

### Ejemplo: Login

```bash
curl -X POST "http://localhost:8000/auth/login" ^
  -H "Content-Type: application/x-www-form-urlencoded" ^
  -d "username=admin&password=admin"
```

### Ejemplo: Ver Stock (después de login)

```bash
curl -X GET "http://localhost:8000/stock/insumos" ^
  -H "Authorization: Bearer TU_TOKEN_AQUI"
```

---

## 📚 Documentación Alternativa

También puedes ver la documentación en formato ReDoc:

**http://localhost:8000/redoc**

---

## ✅ Ventajas de Usar Solo la API

- ✅ No necesitas instalar Node.js
- ✅ Puedes integrar con cualquier frontend
- ✅ Ideal para desarrollo y pruebas
- ✅ Documentación interactiva completa

---

**Recomendación:** Usa la opción 1 (Swagger UI) - es la más fácil y completa.

