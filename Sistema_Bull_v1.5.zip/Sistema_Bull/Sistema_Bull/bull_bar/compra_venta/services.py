from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List, Tuple, Optional
from uuid import uuid4

from ..core.enums import (
    TipoDocumento, EstadoDocumento, TipoMovimiento, EstadoMovimiento
)
from ..core.models import DocumentoCompra, DocumentoVenta, DocumentoItem
from ..stock.models import MovimientoStock
from ..stock.service import StockLedger


@dataclass
class PurchaseService:
    ledger: StockLedger
    db_path: Optional[str] = None  # Para auditoría

    def registrar_compra_recibida(
        self,
        numero: str,
        ClienteProveedor_id: str,
        deposito_id: str,
        items: List[DocumentoItem],
        doc_id: str | None = None,
        usuario: Optional[str] = None,
    ) -> Tuple[DocumentoCompra, List[MovimientoStock]]:
        """Compra recibida: entra stock CONFIRMADO."""
        doc = DocumentoCompra(
            id=doc_id or str(uuid4()),
            tipo=TipoDocumento.REMITO_COMPRA,
            numero=numero,
            fecha_emision=datetime.now(),
            tercero_id=ClienteProveedor_id,
            destino_id=deposito_id,
            estado=EstadoDocumento.RECIBIDO,
            items=items,
        )

        movs: List[MovimientoStock] = []
        for it in items:
            movs.append(
                MovimientoStock(
                    id=str(uuid4()),
                    fecha=datetime.now(),
                    producto_id=it.producto_id,
                    deposito_id=deposito_id,
                    tipo=TipoMovimiento.ENTRADA,
                    cantidad=float(it.cantidad),
                    origen_documento_id=doc.id,
                    estado=EstadoMovimiento.CONFIRMADO,
                )
            )

        self.ledger.add_many(movs)
        
        # Registrar auditoría
        if self.db_path:
            try:
                from ..infra.audit import log_audit
                from ..infra.sqlite_compras import registrar_lote_compra
                
                log_audit(
                    self.db_path,
                    "COMPRA_REGISTRADA",
                    usuario=usuario,
                    modulo="compras",
                    entidad_id=doc.id,
                    entidad_tipo="Documento",
                    despues={"numero": numero, "items": [{"producto_id": it.producto_id, "cantidad": it.cantidad} for it in items]},
                    metadata={"deposito_id": deposito_id, "proveedor_id": ClienteProveedor_id},
                )
                
                # Registrar lotes de compra para cada item
                for it in items:
                    registrar_lote_compra(
                        self.db_path,
                        it.producto_id,
                        doc.id,
                        numero,
                        it.cantidad,
                        fecha_compra=doc.fecha_emision.isoformat(),
                        deposito=deposito_id,
                        comprobante=numero,
                    )
            except Exception as e:
                print(f"Error en auditoría de compra: {e}")
        
        return doc, movs


@dataclass
class SaleService:
    ledger: StockLedger
    db_path: Optional[str] = None  # Para auditoría

    def intentar_venta(
        self,
        numero: str,
        ClienteProveedor_id: str,
        deposito_id: str,
        items: List[DocumentoItem],
        doc_id: str | None = None,
        usuario: Optional[str] = None,
    ) -> Tuple[DocumentoVenta, List[MovimientoStock], List[dict]]:
        """Intenta confirmar una venta.

        Si falta stock: devuelve doc en PENDIENTE_STOCK y una lista de faltantes
        para que la UI muestre el modal con opciones (pendiente / ajustar / volver / cancelar).
        """
        faltantes = []
        for it in items:
            disponible = self.ledger.stock_confirmado(deposito_id, it.producto_id)
            if it.cantidad > disponible:
                faltantes.append(
                    {
                        "producto_id": it.producto_id,
                        "solicitado": float(it.cantidad),
                        "disponible": float(disponible),
                        "faltante": float(it.cantidad - disponible),
                    }
                )

        doc = DocumentoVenta(
            id=doc_id or str(uuid4()),
            tipo=TipoDocumento.PEDIDO_VENTA,
            numero=numero,
            fecha_emision=datetime.now(),
            tercero_id=ClienteProveedor_id,
            origen_id=deposito_id,
            estado=EstadoDocumento.BORRADOR,
            items=items,
        )

        if faltantes:
            doc.estado = EstadoDocumento.PENDIENTE_STOCK
            # Registrar auditoría de intento fallido
            if self.db_path:
                try:
                    from ..infra.audit import log_audit
                    log_audit(
                        self.db_path,
                        "VENTA_PENDIENTE_STOCK",
                        usuario=usuario,
                        modulo="ventas",
                        entidad_id=doc.id,
                        entidad_tipo="Documento",
                        despues={"numero": numero, "estado": "PENDIENTE_STOCK", "faltantes": faltantes},
                        metadata={"deposito_id": deposito_id, "cliente_id": ClienteProveedor_id},
                    )
                except Exception as e:
                    print(f"Error en auditoría de venta pendiente: {e}")
            return doc, [], faltantes

        # Hay stock: confirmamos (salidas confirmadas)
        doc.estado = EstadoDocumento.CONFIRMADO
        movs: List[MovimientoStock] = []
        for it in items:
            movs.append(
                MovimientoStock(
                    id=str(uuid4()),
                    fecha=datetime.now(),
                    producto_id=it.producto_id,
                    deposito_id=deposito_id,
                    tipo=TipoMovimiento.SALIDA,
                    cantidad=float(it.cantidad),
                    origen_documento_id=doc.id,
                    estado=EstadoMovimiento.CONFIRMADO,
                )
            )
        self.ledger.add_many(movs)
        
        # Registrar auditoría
        if self.db_path:
            try:
                from ..infra.audit import log_audit
                log_audit(
                    self.db_path,
                    "VENTA_REALIZADA",
                    usuario=usuario,
                    modulo="ventas",
                    entidad_id=doc.id,
                    entidad_tipo="Documento",
                    despues={"numero": numero, "items": [{"producto_id": it.producto_id, "cantidad": it.cantidad} for it in items]},
                    metadata={"deposito_id": deposito_id, "cliente_id": ClienteProveedor_id},
                )
            except Exception as e:
                print(f"Error en auditoría de venta: {e}")
        
        return doc, movs, []
