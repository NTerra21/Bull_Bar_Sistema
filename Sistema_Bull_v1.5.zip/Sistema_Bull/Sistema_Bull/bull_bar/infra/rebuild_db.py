from pathlib import Path
from uuid import uuid4
from bull_bar.infra.sqlite_db import connect, init_schema

DB_DEFAULT = "bullbar.sqlite"

# Receta Cake
CAKE_RECIPE_CODE = "R-CAKE"
CAKE_RECIPE_NAME = "Cake - Imagen"
CAKE_INGREDIENTS = [
    ("PROT_SUERO", "Concentrado proteína suero", 22.4),
    ("PASTA_MANI", "Pasta de maní", 14.0),
    ("LECHE_POLVO_DESC", "Leche en polvo descremada", 21.1),
    ("AGUA", "Agua", 11.6),
    ("COB_CHOC_BLANCO", "Cobertura chocolate blanco", 4.2),
    ("QUINOA_INFL", "Quinoa inflada", 2.6),
    ("AZUCAR", "Azúcar común", 4.5),
    ("HARINA_COCO", "Harina de coco", 3.3),
    ("SORBITOL", "Sorbitol", 4.7),
    ("FIBRA_CF1", "Fibra cítrica CF1", 0.9),
    ("GRANA_MULTICOLOR", "Grana multicolor", 1.0),
    ("SAL", "Sal", 0.3),
    ("SABOR_VAINILLA", "Sabor vainilla", 0.4),
    ("SABOR_CREMA", "Sabor crema", 0.2),
    ("POLIDEXTROSA", "Polidextrosa", 2.7),
    ("PROPIONATO_CALCIO", "Propionato de calcio", 0.8),
    ("GLICERINA", "Glicerina", 3.3),
]

# Receta Cookie
COOKIE_RECIPE_CODE = "R-COOKIE"
COOKIE_RECIPE_NAME = "Cookie - Imagen"
COOKIE_INGREDIENTS = [
    ("PROT_SUERO", "Concentrado de proteína (Nutralac 8220)", 21.1),
    ("PASTA_MANI", "Pasta de maní", 12.6),
    ("LECHE_POLVO_DESC", "Leche en polvo descremada", 20.4),
    ("AGUA", "Agua", 13.8),
    ("COB_CHOC_LECHE", "Cobertura de chocolate con leche", 6.5),
    ("AZUCAR", "Azúcar común", 4.1),
    ("HARINA_ALMENDRAS", "Harina de almendras", 3.0),
    ("SORBITOL", "Sorbitol", 5.7),
    ("CHIPS_CHOCOLATE", "Chips de chocolate", 2.1),
    ("FIBRA_CF1", "Fibra cítrica CF1", 1.1),
    ("SABOR_CHOC", "Sabor chocolate (Flair)", 0.4),
    ("SAL", "Sal", 0.4),
    ("PROPIONATO_CALCIO", "Propionato de calcio", 0.7),
    ("SABOR_COOKIE", "Sabor cookie", 1.2),
    ("POLIDEXTROSA", "Polidextrosa", 1.1),
    ("GLICERINA", "Glicerina", 2.7),
]

def rebuild(db_path: str = DB_DEFAULT):
    db_file = Path(db_path)
    if db_file.exists():
        print(f"Eliminando DB existente: {db_path}")
        db_file.unlink()
    else:
        print(f"No existe DB previa. Se creará: {db_path}")

    conn = connect(db_path)
    init_schema(conn)
    cur = conn.cursor()

    # Consolidar lista de productos (unir ingredientes de ambas recetas)
    all_ingredients = {}
    for codigo, nombre, _ in CAKE_INGREDIENTS + COOKIE_INGREDIENTS:
        all_ingredients[codigo] = nombre

    # Insertar/actualizar productos con UUID y precio NULL
    for codigo, nombre in all_ingredients.items():
        uid = uuid4().hex
        cur.execute("INSERT OR REPLACE INTO products(codigo, nombre, uuid, precio) VALUES(?,?,?,?)", (codigo, nombre, uid, None))

    # Insertar recetas (reemplaza si ya existe)
    cur.execute("INSERT OR REPLACE INTO recetas(codigo, nombre) VALUES(?,?)", (CAKE_RECIPE_CODE, CAKE_RECIPE_NAME))
    cur.execute("INSERT OR REPLACE INTO recetas(codigo, nombre) VALUES(?,?)", (COOKIE_RECIPE_CODE, COOKIE_RECIPE_NAME))

    # Limpiar items previos para estas recetas y volver a insertar
    cur.execute("DELETE FROM receta_items WHERE receta_codigo IN (?,?)", (CAKE_RECIPE_CODE, COOKIE_RECIPE_CODE))

    for codigo, nombre, porcentaje in CAKE_INGREDIENTS:
        cur.execute(
            "INSERT INTO receta_items(receta_codigo, producto_codigo, porcentaje) VALUES(?,?,?)",
            (CAKE_RECIPE_CODE, codigo, porcentaje),
        )
    for codigo, nombre, porcentaje in COOKIE_INGREDIENTS:
        cur.execute(
            "INSERT INTO receta_items(receta_codigo, producto_codigo, porcentaje) VALUES(?,?,?)",
            (COOKIE_RECIPE_CODE, codigo, porcentaje),
        )

    conn.commit()

    # resumen
    cur.execute("SELECT COUNT(1) FROM recetas")
    total_recetas = cur.fetchone()[0]
    cur.execute("SELECT COUNT(1) FROM products")
    total_products = cur.fetchone()[0]
    cur.execute("SELECT COUNT(1) FROM receta_items WHERE receta_codigo = ?", (CAKE_RECIPE_CODE,))
    total_items_cake = cur.fetchone()[0]
    cur.execute("SELECT COUNT(1) FROM receta_items WHERE receta_codigo = ?", (COOKIE_RECIPE_CODE,))
    total_items_cookie = cur.fetchone()[0]

    print(f"DB reconstruida: {db_path}")
    print(f"Recetas: {total_recetas}, Productos: {total_products}")
    print(f"Items en {CAKE_RECIPE_CODE}: {total_items_cake}, items en {COOKIE_RECIPE_CODE}: {total_items_cookie}")

    conn.close()

def main():
    rebuild()

if __name__ == "__main__":
    main()
