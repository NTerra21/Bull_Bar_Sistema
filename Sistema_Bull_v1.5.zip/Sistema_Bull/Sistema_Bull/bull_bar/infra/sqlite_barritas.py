from __future__ import annotations

import sqlite3
from datetime import datetime

from .sqlite_db import connect, init_schema


def _ensure(db_path: str) -> sqlite3.Connection:
    conn = connect(db_path)
    init_schema(conn)
    return conn


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def list_lotes(db_path: str, *, q: str = "") -> list[dict]:
    """Lista lotes (producto terminado). Filtro simple por sku/nombre/lote."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        q = (q or "").strip().upper()
        
        # Verificar si la columna mezcla_kg existe
        cur.execute("PRAGMA table_info(barritas_lotes)")
        columns_info = cur.fetchall()
        has_mezcla_kg = any(col[1] == "mezcla_kg" for col in columns_info)

        if q:
            if has_mezcla_kg:
                cur.execute(
                    "SELECT lote_id, sku, nombre, cantidad_total, cantidad_vendida, cantidad_disponible, "
                    "fecha_produccion, fecha_vencimiento, deposito, estado, notas, mezcla_kg, created_at, updated_at "
                    "FROM barritas_lotes "
                    "WHERE UPPER(lote_id) LIKE ? OR UPPER(sku) LIKE ? OR UPPER(COALESCE(nombre,'')) LIKE ? "
                    "ORDER BY fecha_vencimiento ASC, lote_id ASC",
                    (f"%{q}%", f"%{q}%", f"%{q}%"),
                )
            else:
                # Sin mezcla_kg, usar SELECT sin esa columna
                cur.execute(
                    "SELECT lote_id, sku, nombre, cantidad_total, cantidad_vendida, cantidad_disponible, "
                    "fecha_produccion, fecha_vencimiento, deposito, estado, notas, created_at, updated_at "
                    "FROM barritas_lotes "
                    "WHERE UPPER(lote_id) LIKE ? OR UPPER(sku) LIKE ? OR UPPER(COALESCE(nombre,'')) LIKE ? "
                    "ORDER BY fecha_vencimiento ASC, lote_id ASC",
                    (f"%{q}%", f"%{q}%", f"%{q}%"),
                )
        else:
            if has_mezcla_kg:
                cur.execute(
                    "SELECT lote_id, sku, nombre, cantidad_total, cantidad_vendida, cantidad_disponible, "
                    "fecha_produccion, fecha_vencimiento, deposito, estado, notas, mezcla_kg, created_at, updated_at "
                    "FROM barritas_lotes ORDER BY fecha_vencimiento ASC, lote_id ASC"
                )
            else:
                cur.execute(
                    "SELECT lote_id, sku, nombre, cantidad_total, cantidad_vendida, cantidad_disponible, "
                    "fecha_produccion, fecha_vencimiento, deposito, estado, notas, created_at, updated_at "
                    "FROM barritas_lotes ORDER BY fecha_vencimiento ASC, lote_id ASC"
                )

        rows = []
        for r in cur.fetchall():
            if has_mezcla_kg:
                # Con mezcla_kg (14 columnas)
                rows.append(
                    {
                        "lote_id": r[0],
                        "sku": r[1],
                        "nombre": r[2] or "",
                        "cantidad_total": float(r[3] or 0),
                        "cantidad_vendida": float(r[4] or 0),
                        "cantidad_disponible": float(r[5] or 0),
                        "fecha_produccion": r[6] or "",
                        "fecha_vencimiento": r[7] or "",
                        "deposito": r[8] or "",
                        "estado": r[9] or "",
                        "notas": r[10] or "",
                        "mezcla_kg": float(r[11]) if r[11] is not None else None,
                        "created_at": r[12] or "",
                        "updated_at": r[13] or "",
                    }
                )
            else:
                # Sin mezcla_kg (13 columnas)
                rows.append(
                    {
                        "lote_id": r[0],
                        "sku": r[1],
                        "nombre": r[2] or "",
                        "cantidad_total": float(r[3] or 0),
                        "cantidad_vendida": float(r[4] or 0),
                        "cantidad_disponible": float(r[5] or 0),
                        "fecha_produccion": r[6] or "",
                        "fecha_vencimiento": r[7] or "",
                        "deposito": r[8] or "",
                        "estado": r[9] or "",
                        "notas": r[10] or "",
                        "mezcla_kg": None,
                        "created_at": r[11] or "",
                        "updated_at": r[12] or "",
                    }
                )
        conn.close()
        return rows
    except Exception as e:
        print(f"[ERROR] list_lotes: {e}")
        import traceback
        traceback.print_exc()
        return []


def upsert_lote(
    db_path: str,
    *,
    lote_id: str,
    sku: str,
    nombre: str = "",
    cantidad_total: float = 0.0,
    cantidad_vendida: float = 0.0,
    cantidad_disponible: float | None = None,
    fecha_produccion: str = "",
    fecha_vencimiento: str = "",
    deposito: str = "",
    estado: str = "DISPONIBLE",
    notas: str = "",
    mezcla_kg: float | None = None,
) -> bool:
    """Crea o actualiza un lote.

    - Si cantidad_disponible es None => se recalcula como total - vendida.
    """
    try:
        lote_id = lote_id.strip()
        sku = sku.strip()
        if not lote_id or not sku:
            return False

        if cantidad_disponible is None:
            cantidad_disponible = float(cantidad_total) - float(cantidad_vendida)
        now = _now_iso()

        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM barritas_lotes WHERE lote_id=?", (lote_id,))
        exists = cur.fetchone() is not None

        # Verificar si la columna mezcla_kg existe
        cur.execute("PRAGMA table_info(barritas_lotes)")
        columns_info = cur.fetchall()
        has_mezcla_kg = any(col[1] == "mezcla_kg" for col in columns_info)
        
        if exists:
            if has_mezcla_kg:
                cur.execute(
                    "UPDATE barritas_lotes SET sku=?, nombre=?, cantidad_total=?, cantidad_vendida=?, cantidad_disponible=?, "
                    "fecha_produccion=?, fecha_vencimiento=?, deposito=?, estado=?, notas=?, mezcla_kg=?, updated_at=? WHERE lote_id=?",
                    (
                        sku,
                        nombre,
                        float(cantidad_total),
                        float(cantidad_vendida),
                        float(cantidad_disponible),
                        fecha_produccion,
                        fecha_vencimiento,
                        deposito,
                        estado,
                        notas,
                        float(mezcla_kg) if mezcla_kg is not None else None,
                        now,
                        lote_id,
                    ),
                )
            else:
                # Sin mezcla_kg, actualizar sin esa columna
                cur.execute(
                    "UPDATE barritas_lotes SET sku=?, nombre=?, cantidad_total=?, cantidad_vendida=?, cantidad_disponible=?, "
                    "fecha_produccion=?, fecha_vencimiento=?, deposito=?, estado=?, notas=?, updated_at=? WHERE lote_id=?",
                    (
                        sku,
                        nombre,
                        float(cantidad_total),
                        float(cantidad_vendida),
                        float(cantidad_disponible),
                        fecha_produccion,
                        fecha_vencimiento,
                        deposito,
                        estado,
                        notas,
                        now,
                        lote_id,
                    ),
                )
        else:
            if has_mezcla_kg:
                cur.execute(
                    "INSERT INTO barritas_lotes (lote_id, sku, nombre, cantidad_total, cantidad_vendida, cantidad_disponible, "
                    "fecha_produccion, fecha_vencimiento, deposito, estado, notas, mezcla_kg, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        lote_id,
                        sku,
                        nombre,
                        float(cantidad_total),
                        float(cantidad_vendida),
                        float(cantidad_disponible),
                        fecha_produccion,
                        fecha_vencimiento,
                        deposito,
                        estado,
                        notas,
                        float(mezcla_kg) if mezcla_kg is not None else None,
                        now,
                        now,
                    ),
                )
            else:
                # Sin mezcla_kg, insertar sin esa columna
                cur.execute(
                    "INSERT INTO barritas_lotes (lote_id, sku, nombre, cantidad_total, cantidad_vendida, cantidad_disponible, "
                    "fecha_produccion, fecha_vencimiento, deposito, estado, notas, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        lote_id,
                        sku,
                        nombre,
                        float(cantidad_total),
                        float(cantidad_vendida),
                        float(cantidad_disponible),
                        fecha_produccion,
                        fecha_vencimiento,
                        deposito,
                        estado,
                        notas,
                        now,
                        now,
                    ),
                )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def delete_lote(db_path: str, lote_id: str) -> bool:
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("DELETE FROM barritas_lotes WHERE lote_id=?", (lote_id,))
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def get_next_lote_number(db_path: str) -> str:
    """Genera el siguiente número de lote en formato Lote-N°xxx-xxx.
    
    Los primeros 3 dígitos suben 1 cuando el de la derecha llega a 999.
    Ejemplo: Lote-N°001-000, Lote-N°001-001, ..., Lote-N°001-999, Lote-N°002-000
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        # Buscar el último lote con formato Lote-N°xxx-xxx
        cur.execute("""
            SELECT lote_id FROM barritas_lotes 
            WHERE lote_id LIKE 'Lote-N°___-___'
            ORDER BY lote_id DESC
            LIMIT 1
        """)
        row = cur.fetchone()
        conn.close()
        
        if row:
            # Extraer números del último lote
            ultimo_lote = row[0]
            # Formato: "Lote-N°001-000"
            try:
                partes = ultimo_lote.replace("Lote-N°", "").split("-")
                if len(partes) == 2:
                    num_izq = int(partes[0])
                    num_der = int(partes[1])
                    
                    # Incrementar el número de la derecha
                    num_der += 1
                    
                    # Si llega a 1000, incrementar el de la izquierda y resetear el de la derecha
                    if num_der >= 1000:
                        num_izq += 1
                        num_der = 0
                    
                    return f"Lote-N°{num_izq:03d}-{num_der:03d}"
            except (ValueError, IndexError):
                pass
        
        # Si no hay lotes previos o hay error, empezar desde 001-000
        return "Lote-N°001-000"
    except Exception:
        # En caso de error, empezar desde 001-000
        return "Lote-N°001-000"
