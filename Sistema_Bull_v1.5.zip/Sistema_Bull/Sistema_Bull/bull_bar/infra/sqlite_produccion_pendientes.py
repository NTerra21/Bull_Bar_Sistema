"""
Gestión de movimientos pendientes de producción que requieren aprobación.
"""
import sqlite3
from datetime import datetime
from typing import List, Optional, Dict
from uuid import uuid4


def _ensure_pendientes_table(conn: sqlite3.Connection) -> None:
    """Crea la tabla de movimientos pendientes de producción si no existe."""
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS produccion_pendientes (
        id TEXT PRIMARY KEY,
        tipo TEXT NOT NULL DEFAULT 'PRODUCCION',
        estado TEXT NOT NULL DEFAULT 'PENDIENTE_APROBACION',
        receta_codigo TEXT NOT NULL,
        receta_nombre TEXT,
        mezcla_kg REAL NOT NULL,
        consumos TEXT NOT NULL,  -- JSON: lista de {producto_codigo, cantidad_kg}
        usuario_creador_id TEXT,
        usuario_creador_nombre TEXT,
        timestamp_creacion TEXT NOT NULL,
        usuario_aprobador_id TEXT,
        usuario_aprobador_nombre TEXT,
        timestamp_aprobacion TEXT,
        motivo_denegacion TEXT,
        documento_id TEXT,  -- ID del documento creado al aprobar
        observaciones TEXT
    )
    """)
    conn.commit()


def crear_pendiente(
    db_path: str,
    receta_codigo: str,
    receta_nombre: str,
    mezcla_kg: float,
    consumos: List[Dict[str, any]],  # [{producto_codigo, cantidad_kg}, ...]
    usuario_creador_id: str,
    usuario_creador_nombre: str,
) -> str:
    """
    Crea un movimiento pendiente de producción.
    Retorna el ID del pendiente creado.
    """
    import json
    
    conn = sqlite3.connect(db_path)
    _ensure_pendientes_table(conn)
    cur = conn.cursor()
    
    pendiente_id = str(uuid4())
    timestamp = datetime.now().isoformat()
    
    cur.execute("""
        INSERT INTO produccion_pendientes (
            id, tipo, estado, receta_codigo, receta_nombre, mezcla_kg,
            consumos, usuario_creador_id, usuario_creador_nombre, timestamp_creacion
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        pendiente_id,
        "PRODUCCION",
        "PENDIENTE_APROBACION",
        receta_codigo,
        receta_nombre,
        mezcla_kg,
        json.dumps(consumos),
        usuario_creador_id,
        usuario_creador_nombre,
        timestamp,
    ))
    
    conn.commit()
    conn.close()
    return pendiente_id


def contar_pendientes(db_path: str, estado: str = "PENDIENTE_APROBACION") -> int:
    """
    Cuenta movimientos pendientes con el estado especificado.
    
    Args:
        db_path: Ruta a la base de datos
        estado: Estado a contar (default: PENDIENTE_APROBACION)
    
    Returns:
        Número de pendientes con ese estado
    """
    conn = sqlite3.connect(db_path)
    _ensure_pendientes_table(conn)
    cur = conn.cursor()
    
    cur.execute("""
        SELECT COUNT(*) FROM produccion_pendientes
        WHERE estado = ?
    """, (estado,))
    
    count = cur.fetchone()[0]
    conn.close()
    return count


def listar_pendientes(
    db_path: str,
    estado: Optional[str] = None,
) -> List[Dict]:
    """
    Lista movimientos pendientes de producción.
    Si estado es None, lista todos. Si se especifica, filtra por estado.
    """
    import json
    
    conn = sqlite3.connect(db_path)
    _ensure_pendientes_table(conn)
    cur = conn.cursor()
    
    if estado:
        cur.execute("""
            SELECT id, tipo, estado, receta_codigo, receta_nombre, mezcla_kg,
                   consumos, usuario_creador_id, usuario_creador_nombre, timestamp_creacion,
                   usuario_aprobador_id, usuario_aprobador_nombre, timestamp_aprobacion,
                   motivo_denegacion, documento_id, observaciones
            FROM produccion_pendientes
            WHERE estado = ?
            ORDER BY timestamp_creacion DESC
        """, (estado,))
    else:
        cur.execute("""
            SELECT id, tipo, estado, receta_codigo, receta_nombre, mezcla_kg,
                   consumos, usuario_creador_id, usuario_creador_nombre, timestamp_creacion,
                   usuario_aprobador_id, usuario_aprobador_nombre, timestamp_aprobacion,
                   motivo_denegacion, documento_id, observaciones
            FROM produccion_pendientes
            ORDER BY timestamp_creacion DESC
        """)
    
    rows = cur.fetchall()
    conn.close()
    
    result = []
    for row in rows:
        consumos_data = json.loads(row[6]) if row[6] else []
        result.append({
            "id": row[0],
            "tipo": row[1],
            "estado": row[2],
            "receta_codigo": row[3],
            "receta_nombre": row[4],
            "mezcla_kg": row[5],
            "consumos": consumos_data,
            "usuario_creador_id": row[7],
            "usuario_creador_nombre": row[8],
            "timestamp_creacion": row[9],
            "usuario_aprobador_id": row[10],
            "usuario_aprobador_nombre": row[11],
            "timestamp_aprobacion": row[12],
            "motivo_denegacion": row[13],
            "documento_id": row[14],
            "observaciones": row[15],
        })
    
    return result


def aprobar_pendiente(
    db_path: str,
    pendiente_id: str,
    usuario_aprobador_id: str,
    usuario_aprobador_nombre: str,
    documento_id: Optional[str] = None,
) -> bool:
    """
    Aprueba un movimiento pendiente.
    Retorna True si se aprobó correctamente.
    """
    conn = sqlite3.connect(db_path)
    _ensure_pendientes_table(conn)
    cur = conn.cursor()
    
    timestamp = datetime.now().isoformat()
    
    cur.execute("""
        UPDATE produccion_pendientes
        SET estado = ?,
            usuario_aprobador_id = ?,
            usuario_aprobador_nombre = ?,
            timestamp_aprobacion = ?,
            documento_id = ?
        WHERE id = ?
    """, (
        "APROBADO",
        usuario_aprobador_id,
        usuario_aprobador_nombre,
        timestamp,
        documento_id,
        pendiente_id,
    ))
    
    conn.commit()
    conn.close()
    return cur.rowcount > 0


def denegar_pendiente(
    db_path: str,
    pendiente_id: str,
    usuario_aprobador_id: str,
    usuario_aprobador_nombre: str,
    motivo: str,
) -> bool:
    """
    Deniega un movimiento pendiente.
    Retorna True si se denegó correctamente.
    """
    conn = sqlite3.connect(db_path)
    _ensure_pendientes_table(conn)
    cur = conn.cursor()
    
    timestamp = datetime.now().isoformat()
    
    cur.execute("""
        UPDATE produccion_pendientes
        SET estado = ?,
            usuario_aprobador_id = ?,
            usuario_aprobador_nombre = ?,
            timestamp_aprobacion = ?,
            motivo_denegacion = ?
        WHERE id = ?
    """, (
        "DENEGADO",
        usuario_aprobador_id,
        usuario_aprobador_nombre,
        timestamp,
        motivo,
        pendiente_id,
    ))
    
    conn.commit()
    conn.close()
    return cur.rowcount > 0


def obtener_pendiente(db_path: str, pendiente_id: str) -> Optional[Dict]:
    """Obtiene un movimiento pendiente por su ID."""
    import json
    
    conn = sqlite3.connect(db_path)
    _ensure_pendientes_table(conn)
    cur = conn.cursor()
    
    cur.execute("""
        SELECT id, tipo, estado, receta_codigo, receta_nombre, mezcla_kg,
               consumos, usuario_creador_id, usuario_creador_nombre, timestamp_creacion,
               usuario_aprobador_id, usuario_aprobador_nombre, timestamp_aprobacion,
               motivo_denegacion, documento_id, observaciones
        FROM produccion_pendientes
        WHERE id = ?
    """, (pendiente_id,))
    
    row = cur.fetchone()
    conn.close()
    
    if not row:
        return None
    
    consumos_data = json.loads(row[6]) if row[6] else []
    return {
        "id": row[0],
        "tipo": row[1],
        "estado": row[2],
        "receta_codigo": row[3],
        "receta_nombre": row[4],
        "mezcla_kg": row[5],
        "consumos": consumos_data,
        "usuario_creador_id": row[7],
        "usuario_creador_nombre": row[8],
        "timestamp_creacion": row[9],
        "usuario_aprobador_id": row[10],
        "usuario_aprobador_nombre": row[11],
        "timestamp_aprobacion": row[12],
        "motivo_denegacion": row[13],
        "documento_id": row[14],
        "observaciones": row[15],
    }
