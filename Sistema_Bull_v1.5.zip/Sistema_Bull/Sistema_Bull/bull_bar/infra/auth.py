"""
Sistema de autenticación y gestión de usuarios.
"""
from __future__ import annotations

import sqlite3
import hashlib
import secrets
from datetime import datetime
from typing import Optional, Tuple
from enum import Enum

from .sqlite_db import connect, init_schema


class RolUsuario(str, Enum):
    """Roles de usuario en el sistema."""
    ADMIN = "ADMIN"
    GERENTE = "GERENTE"
    USUARIO = "USUARIO"


def _ensure(db_path: str) -> sqlite3.Connection:
    """Asegura que la conexión y esquema estén listos."""
    conn = connect(db_path)
    init_schema(conn)
    _ensure_users_table(conn)
    _ensure_default_admin(conn)
    return conn


def _ensure_users_table(conn: sqlite3.Connection) -> None:
    """Crea la tabla de usuarios si no existe."""
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        rol TEXT NOT NULL DEFAULT 'USUARIO',
        nombre_completo TEXT,
        email TEXT,
        debe_cambiar_password INTEGER NOT NULL DEFAULT 1,
        password_reset_token TEXT,
        password_reset_expires TEXT,
        activo INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT,
        last_login TEXT
    )
    """)
    conn.commit()


def _ensure_default_admin(conn: sqlite3.Connection) -> None:
    """Crea el usuario admin por defecto si no existe."""
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM usuarios WHERE username = 'Bull'")
    if cur.fetchone() is None:
        password_hash = _hash_password("Bull1243.")
        now = datetime.now().isoformat()
        cur.execute("""
        INSERT INTO usuarios (username, password_hash, rol, nombre_completo, debe_cambiar_password, activo, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, ("Bull", password_hash, RolUsuario.ADMIN.value, "Administrador", 0, 1, now))
        conn.commit()


def _hash_password(password: str) -> str:
    """Genera hash de contraseña usando SHA-256 con salt."""
    salt = secrets.token_hex(16)
    hash_obj = hashlib.sha256()
    hash_obj.update((password + salt).encode('utf-8'))
    return f"{salt}:{hash_obj.hexdigest()}"


def _verify_password(password: str, password_hash: str) -> bool:
    """Verifica si la contraseña coincide con el hash."""
    try:
        salt, hash_value = password_hash.split(":", 1)
        hash_obj = hashlib.sha256()
        hash_obj.update((password + salt).encode('utf-8'))
        return hash_obj.hexdigest() == hash_value
    except Exception:
        return False


def autenticar(db_path: str, username: str, password: str) -> Optional[dict]:
    """
    Autentica un usuario.
    
    Returns:
        dict con datos del usuario si es exitoso, None si falla
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("""
        SELECT id, username, password_hash, rol, nombre_completo, email, 
               debe_cambiar_password, activo, last_login
        FROM usuarios
        WHERE username = ? AND activo = 1
        """, (username,))
        
        row = cur.fetchone()
        if not row:
            conn.close()
            return None
        
        user_id, db_username, password_hash, rol, nombre, email, debe_cambiar, activo, last_login = row
        
        if not _verify_password(password, password_hash):
            conn.close()
            return None
        
        # Verificar si debe cambiar contraseña (usuario == contraseña)
        if debe_cambiar == 1 and username.lower() == password.lower():
            debe_cambiar = 1
        else:
            debe_cambiar = 0
        
        # Actualizar último login
        now = datetime.now().isoformat()
        cur.execute("UPDATE usuarios SET last_login = ?, updated_at = ? WHERE id = ?", (now, now, user_id))
        conn.commit()
        conn.close()
        
        return {
            "id": user_id,
            "username": db_username,
            "rol": rol,
            "nombre_completo": nombre,
            "email": email,
            "debe_cambiar_password": bool(debe_cambiar),
        }
    except Exception as e:
        print(f"Error en autenticación: {e}")
        return None


def cambiar_password(db_path: str, user_id: int, password_actual: str, password_nueva: str) -> Tuple[bool, str]:
    """
    Cambia la contraseña de un usuario.
    
    Returns:
        (éxito, mensaje)
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        # Verificar contraseña actual
        cur.execute("SELECT password_hash FROM usuarios WHERE id = ?", (user_id,))
        row = cur.fetchone()
        if not row:
            conn.close()
            return False, "Usuario no encontrado"
        
        if not _verify_password(password_actual, row[0]):
            conn.close()
            return False, "Contraseña actual incorrecta"
        
        # Actualizar contraseña
        new_hash = _hash_password(password_nueva)
        now = datetime.now().isoformat()
        cur.execute("""
        UPDATE usuarios 
        SET password_hash = ?, debe_cambiar_password = 0, updated_at = ?
        WHERE id = ?
        """, (new_hash, now, user_id))
        
        conn.commit()
        conn.close()
        return True, "Contraseña cambiada correctamente"
    except Exception as e:
        return False, f"Error: {e}"


def crear_usuario(
    db_path: str,
    username: str,
    rol: str = RolUsuario.USUARIO.value,
    nombre_completo: Optional[str] = None,
    email: Optional[str] = None,
) -> Tuple[bool, str]:
    """
    Crea un nuevo usuario con username y password iguales.
    El usuario deberá cambiar su contraseña en el primer login.
    
    Returns:
        (éxito, mensaje)
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        # Verificar si el usuario ya existe
        cur.execute("SELECT 1 FROM usuarios WHERE username = ?", (username,))
        if cur.fetchone():
            conn.close()
            return False, "El usuario ya existe"
        
        # Crear usuario con username = password
        password_hash = _hash_password(username)
        now = datetime.now().isoformat()
        
        cur.execute("""
        INSERT INTO usuarios (username, password_hash, rol, nombre_completo, email, 
                             debe_cambiar_password, activo, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (username, password_hash, rol, nombre_completo or username, email, 1, 1, now))
        
        conn.commit()
        conn.close()
        return True, f"Usuario '{username}' creado. Debe cambiar su contraseña en el primer login."
    except Exception as e:
        return False, f"Error: {e}"


def generar_token_reset(db_path: str, username: str) -> Optional[str]:
    """
    Genera un token para recuperación de contraseña.
    
    Returns:
        token si el usuario existe, None si no
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        cur.execute("SELECT id FROM usuarios WHERE username = ? AND activo = 1", (username,))
        row = cur.fetchone()
        if not row:
            conn.close()
            return None
        
        # Generar token
        token = secrets.token_urlsafe(32)
        expires = datetime.now().timestamp() + 3600  # 1 hora
        
        cur.execute("""
        UPDATE usuarios 
        SET password_reset_token = ?, password_reset_expires = ?, updated_at = ?
        WHERE id = ?
        """, (token, str(expires), datetime.now().isoformat(), row[0]))
        
        conn.commit()
        conn.close()
        return token
    except Exception as e:
        print(f"Error generando token: {e}")
        return None


def reset_password_con_token(db_path: str, token: str, nueva_password: str) -> Tuple[bool, str]:
    """
    Restablece la contraseña usando un token.
    
    Returns:
        (éxito, mensaje)
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        cur.execute("""
        SELECT id, password_reset_expires FROM usuarios 
        WHERE password_reset_token = ? AND activo = 1
        """, (token,))
        
        row = cur.fetchone()
        if not row:
            conn.close()
            return False, "Token inválido"
        
        user_id, expires_str = row
        expires = float(expires_str) if expires_str else 0
        
        if datetime.now().timestamp() > expires:
            conn.close()
            return False, "Token expirado"
        
        # Cambiar contraseña
        new_hash = _hash_password(nueva_password)
        now = datetime.now().isoformat()
        cur.execute("""
        UPDATE usuarios 
        SET password_hash = ?, password_reset_token = NULL, 
            password_reset_expires = NULL, debe_cambiar_password = 0, updated_at = ?
        WHERE id = ?
        """, (new_hash, now, user_id))
        
        conn.commit()
        conn.close()
        return True, "Contraseña restablecida correctamente"
    except Exception as e:
        return False, f"Error: {e}"


def listar_usuarios(db_path: str) -> list[dict]:
    """Lista todos los usuarios."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("""
        SELECT id, username, rol, nombre_completo, email, activo, created_at, last_login
        FROM usuarios
        ORDER BY username
        """)
        
        rows = []
        for r in cur.fetchall():
            rows.append({
                "id": r[0],
                "username": r[1],
                "rol": r[2],
                "nombre_completo": r[3],
                "email": r[4],
                "activo": bool(r[5]),
                "created_at": r[6],
                "last_login": r[7],
            })
        
        conn.close()
        return rows
    except Exception as e:
        print(f"Error listando usuarios: {e}")
        return []


def tiene_permiso(usuario: dict, accion: str, modulo: str) -> bool:
    """
    Verifica si un usuario tiene permiso para realizar una acción.
    
    Args:
        usuario: dict con datos del usuario (debe tener 'rol')
        accion: acción a realizar (ej: 'ver', 'editar', 'crear', 'eliminar')
        modulo: módulo donde se realiza (ej: 'recetas', 'stock', 'compras', 'ventas', 'historial', 'lotes')
    
    Returns:
        True si tiene permiso, False si no
    """
    rol = usuario.get("rol", RolUsuario.USUARIO.value)
    
    # Admin puede todo
    if rol == RolUsuario.ADMIN.value:
        return True
    
    # Gerente
    if rol == RolUsuario.GERENTE.value:
        if modulo == "recetas":
            return accion == "ver"  # Solo ver recetas
        if modulo == "recetas_inactivas":
            return accion == "ver"  # Puede ver recetas inactivas
        if modulo in ["compras", "ventas"]:
            return accion in ["ver", "crear"]  # Puede ver y crear compras/ventas
        if modulo == "produccion":
            return accion in ["ver", "crear"]  # Puede ver y crear producción
        if modulo == "stock":
            return accion == "ver"  # Solo ver stock
        if modulo == "historial":
            return False  # No puede ver historial
        if modulo == "lotes":
            return accion == "ver"  # Solo ver lotes
        if modulo == "ajuste_stock":
            return False  # No puede ajustar stock
        return False
    
    # Usuario normal
    if rol == RolUsuario.USUARIO.value:
        if modulo == "recetas":
            return accion == "ver"  # Solo ver recetas activas
        if modulo in ["compras", "ventas"]:
            return False  # No puede ver compras/ventas
        if modulo == "produccion":
            return accion in ["ver", "crear"]  # Puede ver y crear producción (crea pendientes)
        if modulo == "stock":
            return accion == "ver"  # Solo ver stock
        if modulo == "historial":
            return False  # No puede ver historial
        if modulo == "lotes":
            return accion == "ver"  # Solo ver lotes
        if modulo == "ajuste_stock":
            return False  # No puede ajustar stock
        return False
    
    return False

