from __future__ import annotations

import sqlite3
from datetime import datetime

from .sqlite_db import connect, init_schema


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _ensure(db_path: str) -> sqlite3.Connection:
    conn = connect(db_path)
    init_schema(conn)
    _ensure_migrations(conn)
    return conn


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,))
    return cur.fetchone() is not None


def _column_exists(conn: sqlite3.Connection, table: str, col: str) -> bool:
    cur = conn.cursor()
    cur.execute(f"PRAGMA table_info({table})")
    return any(r[1] == col for r in cur.fetchall())


def _ensure_migrations(conn: sqlite3.Connection) -> None:
    """Migraciones suaves para DBs viejas (con versionado)."""
    cur = conn.cursor()

    # 1) Crear tabla receta_versions si no existe
    if not _table_exists(conn, "receta_versions"):
        cur.execute("""
        CREATE TABLE IF NOT EXISTS receta_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            receta_codigo TEXT NOT NULL,
            version INTEGER NOT NULL,
            created_at TEXT,
            updated_at TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            inactivated_at TEXT,
            UNIQUE(receta_codigo, version)
        )
        """)

    # 2) receta_items: agregar receta_version si falta
    if _table_exists(conn, "receta_items") and not _column_exists(conn, "receta_items", "receta_version"):
        cur.execute("ALTER TABLE receta_items ADD COLUMN receta_version INTEGER DEFAULT 1")

    # 3) receta_items: NULL -> 1
    if _table_exists(conn, "receta_items"):
        cur.execute("UPDATE receta_items SET receta_version = 1 WHERE receta_version IS NULL")

    # 4) Poblar versiones base (v1 activa) para recetas existentes
    if _table_exists(conn, "recetas"):
        cur.execute("SELECT codigo FROM recetas")
        recetas = [r[0] for r in cur.fetchall()]
        now = _now_iso()

        for codigo in recetas:
            cur.execute("SELECT 1 FROM receta_versions WHERE receta_codigo=? LIMIT 1", (codigo,))
            if cur.fetchone() is None:
                cur.execute(
                    "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
                    "VALUES (?, 1, ?, ?, 1, NULL)",
                    (codigo, now, now),
                )

    # 5) Migración v2: Campos de chocolate en recetas
    if _table_exists(conn, "recetas"):
        if not _column_exists(conn, "recetas", "usa_chocolate"):
            cur.execute("ALTER TABLE recetas ADD COLUMN usa_chocolate INTEGER DEFAULT 0")
        if not _column_exists(conn, "recetas", "choco_min_maquina_kg"):
            cur.execute("ALTER TABLE recetas ADD COLUMN choco_min_maquina_kg REAL DEFAULT 8.0")
        if not _column_exists(conn, "recetas", "choco_tipo_sugerido"):
            cur.execute("ALTER TABLE recetas ADD COLUMN choco_tipo_sugerido TEXT")
        if not _column_exists(conn, "recetas", "choco_porcentaje"):
            cur.execute("ALTER TABLE recetas ADD COLUMN choco_porcentaje REAL")

    # 6) Migración v3: Campos de grupo y orden en receta_items
    if _table_exists(conn, "receta_items"):
        if not _column_exists(conn, "receta_items", "grupo_preparacion"):
            cur.execute("ALTER TABLE receta_items ADD COLUMN grupo_preparacion TEXT DEFAULT 'SOLIDOS'")
        if not _column_exists(conn, "receta_items", "orden_grupo"):
            cur.execute("ALTER TABLE receta_items ADD COLUMN orden_grupo INTEGER DEFAULT 10")
        if not _column_exists(conn, "receta_items", "orden_item"):
            cur.execute("ALTER TABLE receta_items ADD COLUMN orden_item INTEGER DEFAULT 0")
        
        # Asignar valores por defecto basados en heurística para items existentes
        # Si el código contiene "LIQ", "CREM", "ACEITE", "LECHE" -> LIQUIDOS
        cur.execute("""
            UPDATE receta_items 
            SET grupo_preparacion = 'LIQUIDOS', orden_grupo = 30 
            WHERE grupo_preparacion IS NULL OR grupo_preparacion = 'SOLIDOS'
            AND (producto_codigo LIKE '%LIQ%' OR producto_codigo LIKE '%CREM%' 
                 OR producto_codigo LIKE '%ACEITE%' OR producto_codigo LIKE '%LECHE%')
        """)
        # El resto queda como SOLIDOS (orden_grupo = 10) que es el default

    conn.commit()



# ------------------------------------------------------------
# Productos
# ------------------------------------------------------------

def list_products(db_path: str):
    """Devuelve productos soportando columnas extra si existiesen (marca, etc.)."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()

        cur.execute("PRAGMA table_info(products)")
        cols = [r[1] for r in cur.fetchall()]

        select_cols = ["codigo", "nombre", "uuid", "precio"]
        if "marca" in cols:
            select_cols.insert(1, "marca")
        if "limite_advertencia_kg" in cols:
            select_cols.append("limite_advertencia_kg")

        cur.execute(f"SELECT {', '.join(select_cols)} FROM products")
        rows = []
        for r in cur.fetchall():
            d = {}
            for idx, c in enumerate(select_cols):
                d[c] = r[idx]
            if "marca" not in d:
                d["marca"] = ""
            if "limite_advertencia_kg" not in d:
                d["limite_advertencia_kg"] = None
            rows.append(d)

        conn.close()
        return rows
    except Exception:
        return []


def update_product_detail(
    db_path: str,
    producto_codigo: str,
    *,
    marca: str | None = None,
    nombre: str | None = None,
    precio: float | None = None,
    limite_advertencia_kg: float | None = None,
) -> bool:
    """Actualiza marca/nombre/precio si existen esas columnas."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(products)")
        cols = {r[1] for r in cur.fetchall()}

        sets = []
        params = []

        if nombre is not None and "nombre" in cols:
            sets.append("nombre = ?")
            params.append(nombre)
        if precio is not None and "precio" in cols:
            sets.append("precio = ?")
            params.append(precio)
        if marca is not None and "marca" in cols:
            sets.append("marca = ?")
            params.append(marca)
        if limite_advertencia_kg is not None and "limite_advertencia_kg" in cols:
            sets.append("limite_advertencia_kg = ?")
            params.append(limite_advertencia_kg)

        if not sets:
            conn.close()
            return True

        params.append(producto_codigo)
        cur.execute(f"UPDATE products SET {', '.join(sets)} WHERE codigo = ?", tuple(params))
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


# ------------------------------------------------------------
# Compat helpers (para UI)
# ------------------------------------------------------------

def list_recetas(db_path: str, *, active: bool | None = True) -> list[str]:
    """Lista códigos de recetas.

    - active=True: solo recetas cuya versión activa está marcada.
    - active=False: solo versiones inactivas (devuelve códigos con al menos 1 versión inactiva).
    - active=None: todas.

    NOTA: esta función existe por compatibilidad, porque algunas pantallas
    (Producción / RecetasTab vieja) esperan `list_recetas`.
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()

        # Si existe la tabla de versiones, usala
        if _table_exists(conn, "receta_versions"):
            if active is None:
                cur.execute("SELECT DISTINCT receta_codigo FROM receta_versions ORDER BY receta_codigo")
            else:
                cur.execute(
                    "SELECT DISTINCT receta_codigo FROM receta_versions WHERE is_active=? ORDER BY receta_codigo",
                    (1 if active else 0,),
                )
            rows = [r[0] for r in cur.fetchall()]
            conn.close()
            return rows

        # Fallback: tabla recetas sin activas/inactivas
        cur.execute("SELECT codigo FROM recetas ORDER BY codigo")
        rows = [r[0] for r in cur.fetchall()]
        conn.close()
        return rows
    except Exception:
        return []


def get_producto_nombre(db_path: str, producto_codigo: str) -> str | None:
    """Devuelve el nombre del producto desde la tabla `products` (si existe)."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute("SELECT nombre FROM products WHERE codigo = ?", (producto_codigo,))
        row = cur.fetchone()
        conn.close()
        if not row:
            return None
        return row[0]
    except Exception:
        return None


def get_recetas_que_usen_producto(db_path: str, producto_codigo: str) -> list[dict]:
    """Obtiene todas las recetas (activas) que usan un producto específico."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        # Obtener recetas activas que usan este producto
        # Necesitamos buscar en receta_items y unir con receta_versions para obtener solo activas
        cur.execute("""
            SELECT DISTINCT rv.receta_codigo, rv.version, r.nombre
            FROM receta_items ri
            INNER JOIN receta_versions rv ON ri.receta_codigo = rv.receta_codigo AND ri.receta_version = rv.version
            LEFT JOIN recetas r ON rv.receta_codigo = r.codigo
            WHERE ri.producto_codigo = ? AND rv.is_active = 1
            ORDER BY rv.receta_codigo
        """, (producto_codigo,))
        
        rows = []
        for r in cur.fetchall():
            rows.append({
                "codigo": r[0],
                "version": int(r[1]),
                "nombre": r[2] or r[0]
            })
        
        conn.close()
        return rows
    except Exception:
        return []


# ------------------------------------------------------------
# Recetas (versionadas)
# ------------------------------------------------------------

def list_receta_versions(db_path: str, *, active: bool | None = True):
    """active=True solo activas, False solo inactivas, None todas."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()

        if active is None:
            cur.execute(
                "SELECT receta_codigo, version, created_at, updated_at, is_active, inactivated_at "
                "FROM receta_versions ORDER BY receta_codigo, version DESC"
            )
        else:
            cur.execute(
                "SELECT receta_codigo, version, created_at, updated_at, is_active, inactivated_at "
                "FROM receta_versions WHERE is_active = ? ORDER BY receta_codigo, version DESC",
                (1 if active else 0,),
            )

        rows = [
            {
                "codigo": r[0],
                "version": int(r[1]),
                "created_at": r[2],
                "updated_at": r[3],
                "is_active": bool(r[4]),
                "inactivated_at": r[5],
            }
            for r in cur.fetchall()
        ]
        conn.close()
        return rows
    except Exception:
        return []


def get_active_version(db_path: str, receta_codigo: str) -> int:
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute(
            "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
            (receta_codigo,),
        )
        row = cur.fetchone()
        if row:
            conn.close()
            return int(row[0])

        cur.execute("SELECT MAX(version) FROM receta_versions WHERE receta_codigo=?", (receta_codigo,))
        row = cur.fetchone()
        conn.close()
        return int(row[0] or 1)
    except Exception:
        return 1


def get_receta_version_meta(db_path: str, receta_codigo: str, version: int):
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        cur.execute(
            "SELECT created_at, updated_at, is_active, inactivated_at FROM receta_versions WHERE receta_codigo=? AND version=?",
            (receta_codigo, int(version)),
        )
        row = cur.fetchone()
        conn.close()
        if not row:
            return None
        return {
            "codigo": receta_codigo,
            "version": int(version),
            "created_at": row[0],
            "updated_at": row[1],
            "is_active": bool(row[2]),
            "inactivated_at": row[3],
        }
    except Exception:
        return None


def get_receta_items(db_path: str, receta_codigo: str, version: int | None = None):
    """Obtiene items de receta incluyendo campos de grupo y orden."""
    try:
        if version is None:
            version = get_active_version(db_path, receta_codigo)
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        # Verificar si existen las columnas nuevas
        cur.execute("PRAGMA table_info(receta_items)")
        columns = [col[1] for col in cur.fetchall()]
        has_grupo = "grupo_preparacion" in columns
        has_orden_grupo = "orden_grupo" in columns
        has_orden_item = "orden_item" in columns
        
        if has_grupo and has_orden_grupo and has_orden_item:
            cur.execute(
                "SELECT producto_codigo, porcentaje, grupo_preparacion, orden_grupo, orden_item "
                "FROM receta_items WHERE receta_codigo=? AND receta_version=?",
                (receta_codigo, int(version)),
            )
            rows = []
            for r in cur.fetchall():
                item = {
                    "producto_codigo": r[0],
                    "porcentaje": r[1],
                    "grupo_preparacion": r[2] or "SOLIDOS",
                    "orden_grupo": r[3],
                    "orden_item": r[4],
                }
                rows.append(item)
        else:
            # Fallback: solo campos básicos
            cur.execute(
                "SELECT producto_codigo, porcentaje FROM receta_items WHERE receta_codigo=? AND receta_version=?",
                (receta_codigo, int(version)),
            )
            rows = [{"producto_codigo": r[0], "porcentaje": r[1]} for r in cur.fetchall()]
        
        conn.close()
        return rows
    except Exception:
        return []


def bump_receta_version(db_path: str, receta_codigo: str) -> int | None:
    """Crea una nueva versión activa duplicando items de la versión activa actual."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        cur.execute(
            "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
            (receta_codigo,),
        )
        row = cur.fetchone()
        if row:
            old_v = int(row[0])
        else:
            cur.execute(
                "SELECT COALESCE(MAX(version), 1) FROM receta_versions WHERE receta_codigo=?",
                (receta_codigo,),
            )
            old_v = int(cur.fetchone()[0] or 1)

        cur.execute("SELECT COALESCE(MAX(version), 0) FROM receta_versions WHERE receta_codigo=?", (receta_codigo,))
        maxv = int(cur.fetchone()[0] or 0)
        new_v = maxv + 1

        cur.execute(
            "UPDATE receta_versions SET is_active=0, updated_at=?, inactivated_at=? WHERE receta_codigo=? AND is_active=1",
            (now, now, receta_codigo),
        )

        cur.execute(
            "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
            "VALUES (?, ?, ?, ?, 1, NULL)",
            (receta_codigo, new_v, now, now),
        )

        # Verificar si existen las columnas nuevas
        cur.execute("PRAGMA table_info(receta_items)")
        columns = [col[1] for col in cur.fetchall()]
        has_grupo = "grupo_preparacion" in columns
        has_orden_grupo = "orden_grupo" in columns
        has_orden_item = "orden_item" in columns
        
        if has_grupo and has_orden_grupo and has_orden_item:
            cur.execute(
                "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje, grupo_preparacion, orden_grupo, orden_item) "
                "SELECT receta_codigo, ?, producto_codigo, porcentaje, grupo_preparacion, orden_grupo, orden_item FROM receta_items "
                "WHERE receta_codigo=? AND receta_version=?",
                (new_v, receta_codigo, int(old_v)),
            )
        else:
            cur.execute(
                "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
                "SELECT receta_codigo, ?, producto_codigo, porcentaje FROM receta_items "
                "WHERE receta_codigo=? AND receta_version=?",
                (new_v, receta_codigo, int(old_v)),
            )

        conn.commit()
        conn.close()
        return new_v
    except Exception:
        return None


def create_receta(db_path: str, receta_codigo: str, *, base_codigo: str | None = None) -> bool:
    """Crea receta nueva (v1 activa). Si base_codigo, copia items desde su versión activa."""
    try:
        receta_codigo = receta_codigo.strip().upper()
        base_codigo = base_codigo.strip().upper() if base_codigo else None

        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        cur.execute("INSERT INTO recetas (codigo, nombre) VALUES (?, ?)", (receta_codigo, receta_codigo))

        cur.execute(
            "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
            "VALUES (?, 1, ?, ?, 1, NULL)",
            (receta_codigo, now, now),
        )

        if base_codigo:
            cur.execute(
                "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
                (base_codigo,),
            )
            row = cur.fetchone()
            base_v = int(row[0]) if row else 1

            # Verificar si existen las columnas nuevas
            cur.execute("PRAGMA table_info(receta_items)")
            columns = [col[1] for col in cur.fetchall()]
            has_grupo = "grupo_preparacion" in columns
            has_orden_grupo = "orden_grupo" in columns
            has_orden_item = "orden_item" in columns
            
            if has_grupo and has_orden_grupo and has_orden_item:
                cur.execute(
                    "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje, grupo_preparacion, orden_grupo, orden_item) "
                    "SELECT ?, 1, producto_codigo, porcentaje, grupo_preparacion, orden_grupo, orden_item FROM receta_items WHERE receta_codigo=? AND receta_version=?",
                    (receta_codigo, base_codigo, base_v),
                )
            else:
                cur.execute(
                    "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
                    "SELECT ?, 1, producto_codigo, porcentaje FROM receta_items WHERE receta_codigo=? AND receta_version=?",
                    (receta_codigo, base_codigo, base_v),
                )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False
    
def set_receta_active_version(db_path: str, receta_codigo: str, version: int) -> bool:
    """Activa una versión y desactiva la que esté activa actualmente para esa receta."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        # inactivar la activa (si existe)
        cur.execute(
            "UPDATE receta_versions SET is_active=0, updated_at=?, inactivated_at=? "
            "WHERE receta_codigo=? AND is_active=1",
            (now, now, receta_codigo),
        )

        # activar la seleccionada
        cur.execute(
            "UPDATE receta_versions SET is_active=1, updated_at=?, inactivated_at=NULL "
            "WHERE receta_codigo=? AND version=?",
            (now, receta_codigo, int(version)),
        )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def replace_receta_items(db_path: str, receta_codigo: str, version: int, items: list[dict]) -> bool:
    """Reemplaza todos los items de una receta/versión."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        cur.execute(
            "DELETE FROM receta_items WHERE receta_codigo=? AND receta_version=?",
            (receta_codigo, int(version)),
        )

        # Verificar si existen las columnas nuevas
        cur.execute("PRAGMA table_info(receta_items)")
        columns = [col[1] for col in cur.fetchall()]
        has_grupo = "grupo_preparacion" in columns
        has_orden_grupo = "orden_grupo" in columns
        has_orden_item = "orden_item" in columns
        
        for it in items:
            prod = (it.get("producto_codigo") or "").strip()
            if not prod:
                continue
            porc = float(it.get("porcentaje") or 0.0)
            
            if has_grupo and has_orden_grupo and has_orden_item:
                grupo = it.get("grupo_preparacion") or "SOLIDOS"
                orden_grupo = it.get("orden_grupo")
                orden_item = it.get("orden_item") or 0
                cur.execute(
                    "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje, grupo_preparacion, orden_grupo, orden_item) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (receta_codigo, int(version), prod, porc, grupo, orden_grupo, orden_item),
                )
            else:
                cur.execute(
                    "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
                    "VALUES (?, ?, ?, ?)",
                    (receta_codigo, int(version), prod, porc),
                )

        cur.execute(
            "UPDATE receta_versions SET updated_at=? WHERE receta_codigo=? AND version=?",
            (now, receta_codigo, int(version)),
        )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False

def create_receta_named(db_path: str, receta_codigo: str, nombre: str, *, base_codigo: str | None = None) -> bool:
    """Crea receta nueva v1 activa, guardando nombre (si tu tabla recetas tiene columna nombre)."""
    try:
        receta_codigo = receta_codigo.strip().upper()
        nombre = (nombre or "").strip()
        base_codigo = base_codigo.strip().upper() if base_codigo else None

        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        # recetas(codigo, nombre)
        cur.execute("INSERT INTO recetas (codigo, nombre) VALUES (?, ?)", (receta_codigo, nombre or receta_codigo))

        cur.execute(
            "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
            "VALUES (?, 1, ?, ?, 1, NULL)",
            (receta_codigo, now, now),
        )

        if base_codigo:
            cur.execute(
                "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
                (base_codigo,),
            )
            row = cur.fetchone()
            base_v = int(row[0]) if row else 1

            # Verificar si existen las columnas nuevas
            cur.execute("PRAGMA table_info(receta_items)")
            columns = [col[1] for col in cur.fetchall()]
            has_grupo = "grupo_preparacion" in columns
            has_orden_grupo = "orden_grupo" in columns
            has_orden_item = "orden_item" in columns
            
            if has_grupo and has_orden_grupo and has_orden_item:
                cur.execute(
                    "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje, grupo_preparacion, orden_grupo, orden_item) "
                    "SELECT ?, 1, producto_codigo, porcentaje, grupo_preparacion, orden_grupo, orden_item FROM receta_items WHERE receta_codigo=? AND receta_version=?",
                    (receta_codigo, base_codigo, base_v),
                )
            else:
                cur.execute(
                    "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
                    "SELECT ?, 1, producto_codigo, porcentaje FROM receta_items WHERE receta_codigo=? AND receta_version=?",
                    (receta_codigo, base_codigo, base_v),
                )

        conn.commit()
        conn.close()
        return True
    except Exception:
        return False

def create_new_version_from_items(db_path: str, receta_codigo: str, items: list[dict]) -> int | None:
    """
    Crea una NUEVA versión (v+1) con los items editados.
    Solo al final desactiva la versión activa anterior.
    Si algo falla, hace rollback y NO cambia nada.
    """
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        now = _now_iso()

        # Version activa actual
        cur.execute(
            "SELECT version FROM receta_versions WHERE receta_codigo=? AND is_active=1 ORDER BY version DESC LIMIT 1",
            (receta_codigo,),
        )
        row = cur.fetchone()
        old_v = int(row[0]) if row else 1

        # Nuevo número de versión
        cur.execute("SELECT COALESCE(MAX(version), 0) FROM receta_versions WHERE receta_codigo=?", (receta_codigo,))
        new_v = int(cur.fetchone()[0] or 0) + 1

        # Crear nueva versión (activa)
        cur.execute(
            "INSERT INTO receta_versions (receta_codigo, version, created_at, updated_at, is_active, inactivated_at) "
            "VALUES (?, ?, ?, ?, 1, NULL)",
            (receta_codigo, new_v, now, now),
        )

        # Verificar si existen las columnas nuevas
        cur.execute("PRAGMA table_info(receta_items)")
        columns = [col[1] for col in cur.fetchall()]
        has_grupo = "grupo_preparacion" in columns
        has_orden_grupo = "orden_grupo" in columns
        has_orden_item = "orden_item" in columns
        
        # Insertar items editados (SIN tocar la versión vieja)
        for it in items:
            prod = (it.get("producto_codigo") or "").strip()
            if not prod:
                continue
            porc = float(it.get("porcentaje") or 0.0)
            
            if has_grupo and has_orden_grupo and has_orden_item:
                grupo = it.get("grupo_preparacion") or "SOLIDOS"
                orden_grupo = it.get("orden_grupo")
                orden_item = it.get("orden_item") or 0
                cur.execute(
                    "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje, grupo_preparacion, orden_grupo, orden_item) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (receta_codigo, new_v, prod, porc, grupo, orden_grupo, orden_item),
                )
            else:
                cur.execute(
                    "INSERT INTO receta_items (receta_codigo, receta_version, producto_codigo, porcentaje) "
                    "VALUES (?, ?, ?, ?)",
                    (receta_codigo, new_v, prod, porc),
                )

        # Recién acá: desactivar la versión vieja
        cur.execute(
            "UPDATE receta_versions SET is_active=0, updated_at=?, inactivated_at=? "
            "WHERE receta_codigo=? AND version=?",
            (now, now, receta_codigo, old_v),
        )

        conn.commit()
        conn.close()
        return new_v
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass
        return None


# ------------------------------------------------------------
# Funciones para campos de chocolate
# ------------------------------------------------------------

def get_receta_chocolate_info(db_path: str, receta_codigo: str):
    """Obtiene información de chocolate de una receta."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        # Verificar si existen las columnas
        cur.execute("PRAGMA table_info(recetas)")
        columns = [col[1] for col in cur.fetchall()]
        has_usa_chocolate = "usa_chocolate" in columns
        has_choco_min = "choco_min_maquina_kg" in columns
        has_choco_tipo = "choco_tipo_sugerido" in columns
        has_choco_porc = "choco_porcentaje" in columns
        
        if has_usa_chocolate:
            cur.execute(
                "SELECT usa_chocolate, choco_min_maquina_kg, choco_tipo_sugerido, choco_porcentaje "
                "FROM recetas WHERE codigo=?",
                (receta_codigo,)
            )
            row = cur.fetchone()
            conn.close()
            if row:
                return {
                    "usa_chocolate": bool(row[0]) if row[0] is not None else False,
                    "choco_min_maquina_kg": float(row[1]) if row[1] is not None else 8.0,
                    "choco_tipo_sugerido": row[2],
                    "choco_porcentaje": float(row[3]) if row[3] is not None else None,
                }
        
        conn.close()
        return {
            "usa_chocolate": False,
            "choco_min_maquina_kg": 8.0,
            "choco_tipo_sugerido": None,
            "choco_porcentaje": None,
        }
    except Exception:
        return {
            "usa_chocolate": False,
            "choco_min_maquina_kg": 8.0,
            "choco_tipo_sugerido": None,
            "choco_porcentaje": None,
        }


def update_receta_chocolate_info(
    db_path: str,
    receta_codigo: str,
    *,
    usa_chocolate: bool | None = None,
    choco_min_maquina_kg: float | None = None,
    choco_tipo_sugerido: str | None = None,
    choco_porcentaje: float | None = None,
) -> bool:
    """Actualiza información de chocolate de una receta."""
    try:
        conn = _ensure(db_path)
        cur = conn.cursor()
        
        # Verificar si existen las columnas
        cur.execute("PRAGMA table_info(recetas)")
        columns = [col[1] for col in cur.fetchall()]
        has_usa_chocolate = "usa_chocolate" in columns
        has_choco_min = "choco_min_maquina_kg" in columns
        has_choco_tipo = "choco_tipo_sugerido" in columns
        has_choco_porc = "choco_porcentaje" in columns
        
        sets = []
        params = []
        
        if has_usa_chocolate and usa_chocolate is not None:
            sets.append("usa_chocolate = ?")
            params.append(1 if usa_chocolate else 0)
        if has_choco_min and choco_min_maquina_kg is not None:
            sets.append("choco_min_maquina_kg = ?")
            params.append(choco_min_maquina_kg)
        if has_choco_tipo and choco_tipo_sugerido is not None:
            sets.append("choco_tipo_sugerido = ?")
            params.append(choco_tipo_sugerido)
        if has_choco_porc and choco_porcentaje is not None:
            sets.append("choco_porcentaje = ?")
            params.append(choco_porcentaje)
        
        if not sets:
            conn.close()
            return True
        
        params.append(receta_codigo)
        cur.execute(f"UPDATE recetas SET {', '.join(sets)} WHERE codigo = ?", tuple(params))
        
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False
