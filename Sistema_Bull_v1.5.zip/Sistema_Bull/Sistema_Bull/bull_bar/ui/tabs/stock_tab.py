import tkinter as tk
from tkinter import ttk, messagebox

from bull_bar.infra.sqlite_recetas import list_products, update_product_detail
from bull_bar.infra.sqlite_compras import listar_lotes_compra
from bull_bar.ui.utils.tree_sort import TreeSortController
from bull_bar.ui.utils.delayed_deselect import DelayedDeselect


class StockTab:
    def __init__(self, notebook, ctx):
        self.ctx = ctx
        self.notebook = notebook

        self.frame = ttk.Frame(notebook)
        notebook.add(self.frame, text="Stock")

        self._cache_by_codigo = {}

        # -------------------------
        # Barra superior
        # -------------------------
        top = ttk.Frame(self.frame)
        top.pack(fill="x", padx=6, pady=6)

        ttk.Label(top, text="Buscar:").pack(side="left")
        self.search = ttk.Entry(top)
        self.search.pack(side="left", fill="x", expand=True, padx=(4, 0))
        self.search.bind("<KeyRelease>", lambda e: self._refresh_list())

        self.btn_detalle = ttk.Button(top, text="Detalle", command=self._open_detail_selected)
        self.btn_detalle.pack(side="right", padx=(6, 0))
        
        # Verificar permisos para edición
        from bull_bar.infra.auth import tiene_permiso
        self.usuario = self.ctx.get("usuario_actual", {})
        self.puede_editar = tiene_permiso(self.usuario, "editar", "stock")

        self.btn_refrescar = ttk.Button(top, text="Refrescar", command=self._refresh_list)
        self.btn_refrescar.pack(side="right")

        # -------------------------
        # Treeview
        # -------------------------
        cols = ("id", "codigo", "marca", "nombre", "cantidad", "precio")
        self.tree = ttk.Treeview(self.frame, columns=cols, show="headings", selectmode="browse")

        # ID oculto
        self.tree.heading("id", text="ID")
        self.tree.column("id", width=0, minwidth=0, stretch=False)

        self.tree.column("codigo", width=140)
        self.tree.column("marca", width=180)
        self.tree.column("nombre", width=360, stretch=True)
        self.tree.column("cantidad", width=110, anchor="e", stretch=False)
        self.tree.column("precio", width=110, anchor="e", stretch=False)

        self.tree.pack(fill="both", expand=True, padx=6, pady=(0, 6))

        # Enter / Double click -> detalle
        self.tree.bind("<Return>", lambda e: self._open_detail_selected())
        self.tree.bind("<Double-1>", self._on_tree_double_click)

        # -------------------------
        # Helpers: sort + deselect tardío
        # -------------------------
        self.sorter = TreeSortController(
            tree=self.tree,
            base_headings={
                "codigo": "Código",
                "marca": "Marca",
                "nombre": "Nombre",
                "cantidad": "Cantidad",
                "precio": "Precio / kg",
            },
            numeric_cols={"cantidad", "precio"},
        )
        self.sorter.install()

        self.deselect = DelayedDeselect(
            root=self.frame.winfo_toplevel(),
            tree=self.tree,
            is_active=self._stock_tab_is_active,
            clear_selection=self._clear_selection,
            exempt_widgets=[self.btn_detalle, self.btn_refrescar],
            delay_click_ms=80,
            delay_focusout_ms=250,
        )

        self._refresh_list()

    # -------------------------
    # Active tab check
    # -------------------------
    def _stock_tab_is_active(self) -> bool:
        try:
            return self.notebook.select() == str(self.frame)
        except Exception:
            return False

    def _clear_selection(self):
        self.tree.selection_remove(self.tree.selection())

    # -------------------------
    # Data load
    # -------------------------
    def _refresh_list(self):
        q = self.search.get().strip().upper()

        for iid in self.tree.get_children():
            self.tree.delete(iid)

        self._cache_by_codigo.clear()

        rows = list_products(self.ctx["db_path"])

        for p in rows:
            codigo = (p.get("codigo") or "").strip()
            nombre = (p.get("nombre") or "").strip()
            marca = (p.get("marca") or "").strip()
            prod_uuid = p.get("uuid") or ""
            precio = p.get("precio")

            haystack = f"{codigo} {marca} {nombre}".upper()
            if q and q not in haystack:
                continue

            # cantidad desde ledger
            prod_obj = self.ctx.get("products", {}).get(codigo)
            prod_id = prod_uuid or (prod_obj.id if prod_obj else "")

            cantidad_val = None
            try:
                cantidad_val = float(self.ctx["ledger"].stock_confirmado(self.ctx["depo"].id, prod_id))
            except Exception:
                cantidad_val = None

            cantidad_str = "N/A" if cantidad_val is None else f"{cantidad_val:.2f}"
            precio_str = "" if precio is None else f"{float(precio):.2f}"

            self._cache_by_codigo[codigo] = {
                "id": prod_id,
                "codigo": codigo,
                "marca": marca,
                "nombre": nombre,
                "cantidad": cantidad_str,
                "precio": precio_str,
            }

            self.tree.insert("", "end", values=(prod_id, codigo, marca, nombre, cantidad_str, precio_str))

        # reset sort a “original”
        self.sorter.set_original_order()
        self.sorter.reset()

    # -------------------------
    # Double click handler
    # -------------------------
    def _on_tree_double_click(self, event):
        # si había un clear tardío, cancelarlo (para que no pise el detalle)
        self.deselect.cancel()

        row_id = self.tree.identify_row(event.y)
        if not row_id:
            return

        self.tree.selection_set(row_id)
        self.tree.focus(row_id)
        self._open_detail_selected()

    # -------------------------
    # Detail
    # -------------------------
    def _open_detail_selected(self):
        sel = self.tree.selection()
        if not sel:
            return

        values = self.tree.item(sel[0], "values")
        if not values or len(values) < 2:
            return

        codigo = values[1]
        data = self._cache_by_codigo.get(codigo)
        if not data:
            return

        self._open_detail_window(data)

    def _open_detail_window(self, data: dict):
        win = tk.Toplevel(self.frame)
        win.title(f"Detalle - {data['codigo']}")
        win.transient(self.frame)
        win.geometry("900x700")  # Ventana más grande

        container = ttk.Frame(win, padding=15)
        container.pack(fill="both", expand=True)
        container.columnconfigure(1, weight=1)

        def row(label, widget, r):
            ttk.Label(container, text=label).grid(row=r, column=0, sticky="e", padx=(0, 8), pady=4)
            widget.grid(row=r, column=1, sticky="we", pady=4)

        var_codigo = tk.StringVar(value=data.get("codigo", ""))
        var_marca = tk.StringVar(value=data.get("marca", ""))
        var_nombre = tk.StringVar(value=data.get("nombre", ""))
        var_cantidad = tk.StringVar(value=data.get("cantidad", "N/A"))
        var_precio = tk.StringVar(value=data.get("precio", ""))

        # NO mostrar ID (eliminado según solicitud del usuario)
        row("Código:", ttk.Entry(container, textvariable=var_codigo, state="readonly"), 0)
        # Verificar permisos para edición
        from bull_bar.infra.auth import tiene_permiso
        puede_editar = tiene_permiso(self.ctx.get("usuario_actual", {}), "editar", "stock")
        
        row("Marca:", ttk.Entry(container, textvariable=var_marca, state="readonly" if not puede_editar else "normal"), 1)
        row("Nombre:", ttk.Entry(container, textvariable=var_nombre, state="readonly" if not puede_editar else "normal"), 2)
        row("Cantidad:", ttk.Entry(container, textvariable=var_cantidad, state="readonly"), 3)
        row("Precio / kg:", ttk.Entry(container, textvariable=var_precio, state="readonly" if not puede_editar else "normal"), 4)
        
        # Calcular y mostrar mezcla máxima posible
        try:
            from bull_bar.infra.sqlite_recetas import get_recetas_que_usen_producto, get_receta_items
            from bull_bar.produccion.helpers import calcular_mezcla_maxima_posible
            
            producto_codigo = data.get("codigo", "")
            prod_obj = self.ctx.get("products", {}).get(producto_codigo)
            prod_id = data.get("id", "") or (prod_obj.id if prod_obj else "")
            
            if prod_id:
                deposito_id = self.ctx["depo"].id
                stock_actual = self.ctx["ledger"].stock_confirmado(deposito_id, prod_id)
                
                # Obtener recetas que usan este producto
                recetas = get_recetas_que_usen_producto(self.ctx["db_path"], producto_codigo)
                
                mezclas_maximas = []
                for receta in recetas:
                    items_receta = get_receta_items(self.ctx["db_path"], receta["codigo"])
                    if items_receta:
                        resultado = calcular_mezcla_maxima_posible(
                            items_receta=items_receta,
                            deposito_id=deposito_id,
                            ledger=self.ctx["ledger"],
                            ctx_products=self.ctx["products"]
                        )
                        mezcla_max = resultado.get("mezcla_max_kg", 0.0)
                        if mezcla_max > 0:
                            mezclas_maximas.append({
                                "receta": receta["codigo"],
                                "nombre": receta["nombre"],
                                "mezcla_max": mezcla_max
                            })
                
                # Mostrar información de mezcla máxima SOLO si hay datos útiles
                if mezclas_maximas:
                    # Encontrar la máxima mezcla posible entre todas las recetas
                    max_mezcla_total = max([m["mezcla_max"] for m in mezclas_maximas])
                    if max_mezcla_total > 0:
                        texto_mezcla = f"Alcanza hasta {max_mezcla_total:.1f} kg de mezcla"
                        
                        # Si hay múltiples recetas, mostrar detalles
                        if len(mezclas_maximas) > 1:
                            detalles = "\n".join([f"  • {m['receta']}: {m['mezcla_max']:.1f} kg" for m in mezclas_maximas])
                            texto_mezcla += f"\n\nPor receta:\n{detalles}"
                        
                        # Solo mostrar si hay datos útiles
                        if "\n" in texto_mezcla:
                            ttk.Label(container, text="Cantidad máxima de Mezcla:", font=("Segoe UI", 9, "bold")).grid(row=5, column=0, sticky="ne", padx=(0, 8), pady=4)
                            mezcla_text = tk.Text(container, height=4, wrap="word", font=("Segoe UI", 9), state="disabled", bg="white")
                            mezcla_text.insert("1.0", texto_mezcla)
                            mezcla_text.grid(row=5, column=1, sticky="we", pady=4)
                        else:
                            var_mezcla_max = tk.StringVar(value=texto_mezcla)
                            mezcla_entry = ttk.Entry(container, textvariable=var_mezcla_max, state="readonly", font=("Segoe UI", 9))
                            mezcla_entry.grid(row=5, column=1, sticky="we", pady=4)
                            ttk.Label(container, text="Cantidad máxima de Mezcla:", font=("Segoe UI", 9, "bold")).grid(row=5, column=0, sticky="e", padx=(0, 8), pady=4)
                # Si no hay mezclas o todas son 0, NO mostrar el campo
        except Exception as e:
            print(f"[DEBUG] Error calculando mezcla máxima en detalle: {e}")
            var_mezcla_max = tk.StringVar(value="Error al calcular")
            row("Cantidad máxima de Mezcla:", ttk.Entry(container, textvariable=var_mezcla_max, state="readonly"), 5)

        ttk.Separator(container).grid(row=6, column=0, columnspan=2, sticky="we", pady=(10, 8))
        
        # Sección de lotes de compra
        ttk.Label(container, text="Lotes de Compra:", font=("Helvetica", 10, "bold")).grid(
            row=7, column=0, columnspan=2, sticky="w", pady=(10, 6)
        )
        
        # Frame para tabla de lotes
        lotes_frame = ttk.Frame(container)
        lotes_frame.grid(row=8, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        lotes_frame.columnconfigure(0, weight=1)
        
        # Treeview para lotes
        cols_lotes = ("fecha_compra", "fecha_vencimiento", "cantidad", "precio", "deposito", "comprobante", "ver")
        tree_lotes = ttk.Treeview(lotes_frame, columns=cols_lotes, show="headings", height=8)
        
        tree_lotes.heading("fecha_compra", text="Fecha Compra")
        tree_lotes.heading("fecha_vencimiento", text="Vencimiento")
        tree_lotes.heading("cantidad", text="Cantidad")
        tree_lotes.heading("precio", text="Precio Unit.")
        tree_lotes.heading("deposito", text="Depósito")
        tree_lotes.heading("comprobante", text="Comprobante")
        tree_lotes.heading("ver", text="Ver")
        
        tree_lotes.column("fecha_compra", width=110)
        tree_lotes.column("fecha_vencimiento", width=110)
        tree_lotes.column("cantidad", width=90, anchor="e")
        tree_lotes.column("precio", width=100, anchor="e")
        tree_lotes.column("deposito", width=130)
        tree_lotes.column("comprobante", width=130)
        tree_lotes.column("ver", width=80)
        
        # Scrollbar para lotes
        scroll_lotes = ttk.Scrollbar(lotes_frame, orient="vertical", command=tree_lotes.yview)
        tree_lotes.configure(yscrollcommand=scroll_lotes.set)
        
        tree_lotes.pack(side="left", fill="both", expand=True)
        scroll_lotes.pack(side="right", fill="y")
        
        # Función para abrir comprobante
        def abrir_comprobante(event):
            selection = tree_lotes.selection()
            if not selection:
                return
            item = tree_lotes.item(selection[0])
            values = item['values']
            
            # Verificar si es la fila de "Sin lotes registrados"
            if values and values[0] == "Sin lotes registrados":
                return
            
            # Buscar el lote correspondiente usando el documento_numero o fecha
            try:
                lotes_actuales = listar_lotes_compra(self.ctx["db_path"], data.get("id", ""))
                if not lotes_actuales:
                    return
                
                # Buscar por fecha de compra (más confiable)
                fecha_compra = values[0] if values else ""
                lote_encontrado = None
                for lote in lotes_actuales:
                    lote_fecha = lote.get("fecha_compra", "")[:10] if lote.get("fecha_compra") else ""
                    if lote_fecha == fecha_compra:
                        lote_encontrado = lote
                        break
                
                if lote_encontrado:
                    ruta = lote_encontrado.get("ruta_archivo")
                    if ruta:
                        import os
                        import subprocess
                        if os.path.exists(ruta):
                            if os.name == 'nt':  # Windows
                                os.startfile(ruta)
                            else:  # Linux/Mac
                                subprocess.call(['xdg-open', ruta])
                        else:
                            messagebox.showwarning("Archivo no encontrado", f"No se encontró el archivo:\n{ruta}")
                    else:
                        messagebox.showinfo("Sin archivo", "Este lote no tiene archivo de comprobante asociado.")
            except Exception as e:
                messagebox.showerror("Error", f"Error al abrir comprobante: {e}")
        
        tree_lotes.bind("<Double-1>", abrir_comprobante)
        
        # Cargar lotes de compra
        lotes = []
        try:
            lotes = listar_lotes_compra(self.ctx["db_path"], data.get("id", ""))
            for lote in lotes:
                precio = lote.get("precio_unitario")
                precio_str = f"${precio:.2f}" if precio is not None else "-"
                ruta = lote.get("ruta_archivo")
                ver_texto = "📄 Ver" if ruta else "-"
                
                tree_lotes.insert("", "end", values=(
                    lote.get("fecha_compra", "")[:10] if lote.get("fecha_compra") else "",
                    lote.get("fecha_vencimiento", "")[:10] if lote.get("fecha_vencimiento") else "",
                    f"{lote.get('cantidad', 0):.2f}",
                    precio_str,
                    lote.get("deposito", ""),
                    lote.get("comprobante", ""),
                    ver_texto,
                ))
        except Exception as e:
            print(f"Error cargando lotes: {e}")
        
        if not lotes:
            tree_lotes.insert("", "end", values=("Sin lotes registrados", "", "", "", "", "", ""))
        
        container.rowconfigure(8, weight=1)

        def save():
            codigo = var_codigo.get().strip()
            marca = var_marca.get().strip()
            nombre = var_nombre.get().strip()

            precio_txt = var_precio.get().strip()
            if precio_txt == "":
                precio_val = None
            else:
                try:
                    precio_val = float(precio_txt)
                except Exception:
                    messagebox.showerror("Error", "Precio inválido")
                    return

            ok = update_product_detail(self.ctx["db_path"], codigo, marca=marca, nombre=nombre, precio=precio_val)
            if not ok:
                messagebox.showerror("Error", "No se pudo actualizar el producto en la DB")
                return

            self._refresh_list()
            win.destroy()

        btns = ttk.Frame(container)
        btns.grid(row=9, column=0, columnspan=2, sticky="e", pady=(10, 0))

        if puede_editar:
            ttk.Button(btns, text="Guardar", command=save).pack(side="right", padx=(6, 0))
        ttk.Button(btns, text="Cancelar", command=win.destroy).pack(side="right", padx=(0, 6))
        ttk.Button(btns, text="Cerrar", command=win.destroy).pack(side="right")

        win.grab_set()
        win.wait_window(win)
