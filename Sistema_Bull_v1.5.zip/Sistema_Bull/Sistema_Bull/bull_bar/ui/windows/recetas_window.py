import tkinter as tk
from tkinter import ttk

from bull_bar.ui.panels.recetas_panel import RecetasPanel


class RecetasWindow(tk.Toplevel):
    def __init__(self, master, ctx):
        super().__init__(master)
        self.ctx = ctx
        self.title("Bull Bar - Recetas")
        self.geometry("1100x720")
        self.minsize(980, 560)
        self.transient(master)

        container = ttk.Frame(self)
        container.pack(fill="both", expand=True, padx=6, pady=6)

        panel = RecetasPanel(container, ctx)
        panel.pack(fill="both", expand=True)

        self.lift()
        try:
            self.focus_force()
        except Exception:
            pass
