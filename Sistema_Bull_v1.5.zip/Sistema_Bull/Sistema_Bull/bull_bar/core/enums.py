from __future__ import annotations
from enum import Enum


class ClienteProveedor(str, Enum):
    PROVEEDOR = "PROVEEDOR"
    CLIENTE = "CLIENTE"


class TipoDocumento(str, Enum):
    # Compras
    PEDIDO_COMPRA = "PEDIDO_COMPRA"
    REMITO_COMPRA = "REMITO_COMPRA"
    FACTURA_COMPRA = "FACTURA_COMPRA"
    # Ventas
    PEDIDO_VENTA = "PEDIDO_VENTA"
    REMITO_VENTA = "REMITO_VENTA"
    FACTURA_VENTA = "FACTURA_VENTA"
    # Producción
    PRODUCCION = "PRODUCCION"


class EstadoDocumento(str, Enum):
    BORRADOR = "BORRADOR"
    EN_PROCESO = "EN_PROCESO"
    APROBADO = "APROBADO"
    EN_TRANSITO = "EN_TRANSITO"
    RECIBIDO = "RECIBIDO"
    CONFIRMADO = "CONFIRMADO"
    PENDIENTE_STOCK = "PENDIENTE_STOCK"
    ANULADO = "ANULADO"


class TipoMovimiento(str, Enum):
    ENTRADA = "ENTRADA"
    SALIDA = "SALIDA"


class EstadoMovimiento(str, Enum):
    PENDIENTE = "PENDIENTE"
    CONFIRMADO = "CONFIRMADO"


class ModoProduccion(str, Enum):
    GUIADO = "GUIADO"     # checklist pasos; descuenta al final
    RAPIDO = "RAPIDO"     # descuenta al toque (remito/parte)


class GrupoPreparacion(str, Enum):
    """Grupos de preparación para ordenar ingredientes en producción."""
    SOLIDOS = "SOLIDOS"
    CHOCOLATE = "CHOCOLATE"
    LIQUIDOS = "LIQUIDOS"
    OTROS = "OTROS"


# Constantes de orden para grupos de preparación
ORDEN_GRUPO_SOLIDOS = 10
ORDEN_GRUPO_CHOCOLATE = 20
ORDEN_GRUPO_LIQUIDOS = 30
ORDEN_GRUPO_OTROS = 40

# Máximo de items por etapa para partir grupos grandes
MAX_ITEMS_POR_ETAPA = 6
